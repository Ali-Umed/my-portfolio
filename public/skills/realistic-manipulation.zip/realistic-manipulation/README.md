# realistic-manipulation (Claude skill)

A Claude skill for making realistic, cinematic photo manipulations: giant animals in fog, night scenes lit by a
lantern, floods, sea monsters. The goal is that people believe it is one real photograph, not a pasted sticker.

Made by Ali Umed: https://ali-umed.netlify.app/skills/realistic-manipulation/

## What is inside
- `SKILL.md`: the step-by-step method Claude follows (idea, photos, cut-out, layers, realism check, export).
- `references/techniques.md`: how to do fog giants, night light, water, snow, silhouettes.
- `references/checklist.md`: what to check before showing a result.
- `references/taste.md`: the author's taste and lessons from real projects. Keep it as an example or replace it
  with your own; Claude adds new lessons after each piece.
- `scripts/lift.swift`: cut people and animals out of photos with Apple Vision (macOS).
- `scripts/realism_check.py`: measures if the subject looks pasted on (contrast, colour, blacks, quality).
- `scripts/assemble.py`: builds an editable PhotoCraft file with named layers and exports JPEG 97 + PNG.
- `scripts/social_pack.py`: only when you ask - a 4:5 carousel for Instagram and Facebook where nothing is cut: the
  post, the source photos, every layer, the PhotoCraft layers list, the app screenshot and a before/after.
- `examples/`: four build scripts (incl. the lantern + wolf night scene), a finished piece with its breakdown, and one rejected "sticker" example.

## Install
Claude Code: copy the folder to `~/.claude/skills/realistic-manipulation/`.
Claude apps: zip the folder and upload it under Settings > Capabilities > Skills.

Build the cut-out tool once (macOS, needs Xcode command line tools):

    cd ~/.claude/skills/realistic-manipulation/scripts && swiftc -O lift.swift -o lift

## Needs
- macOS (for the cut-out tool)
- Python 3 with numpy, scipy and Pillow
- PhotoCraft with `photocraft-cli` (for the layered `.pcraft` file)

Example photos come from Unsplash (free licence).
