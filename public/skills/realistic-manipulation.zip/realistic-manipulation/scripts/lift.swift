import Foundation
import Vision
import CoreImage
import ImageIO
import UniformTypeIdentifiers

let args = CommandLine.arguments
let input = URL(fileURLWithPath: args[1]), output = URL(fileURLWithPath: args[2]), maskOut = URL(fileURLWithPath: args[3])
guard let src = CGImageSourceCreateWithURL(input as CFURL, nil),
      let cg = CGImageSourceCreateImageAtIndex(src, 0, nil) else { fatalError("cannot read input") }
let req = VNGenerateForegroundInstanceMaskRequest()
let handler = VNImageRequestHandler(cgImage: cg, options: [:])
try handler.perform([req])
guard let obs = req.results?.first else { fatalError("no subject found") }
print("instances:", obs.allInstances.count)
let masked = try obs.generateMaskedImage(ofInstances: obs.allInstances, from: handler, croppedToInstancesExtent: false)
let mask = try obs.generateScaledMaskForImage(forInstances: obs.allInstances, from: handler)
let ctx = CIContext()
func save(_ pb: CVPixelBuffer, _ url: URL) throws {
    let ci = CIImage(cvPixelBuffer: pb)
    try ctx.writePNGRepresentation(of: ci, to: url, format: .RGBA8, colorSpace: CGColorSpace(name: CGColorSpace.sRGB)!)
}
try save(masked, output)
try save(mask, maskOut)
print("ok")
