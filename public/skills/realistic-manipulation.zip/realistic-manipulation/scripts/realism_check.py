"""Measure whether a manipulation reads as one photograph. Numbers, not opinions; still view the crops yourself.

  python3 -I realism_check.py FINAL.jpg --subject SUBJECT_LAYER.png
         [--far "name:x0,y0,x1,y1" ...]    real far-away objects of the photo (subject must not be crisper if far)
         [--near "name:x0,y0,x1,y1" ...]   the nearest dark objects (reference for black levels)
         [--open "name:x0,y0,x1,y1"]       open fog/sky behind the subject
         [--person LAYER.png ...]          people/silhouettes placed into the scene
         [--far-subject]                   the subject is meant to be farther than the --far objects

Boxes are in FINAL image pixels. Layers are full-canvas RGBA PNGs (alpha = where the element is); if a layer has a
different size than FINAL, it is scaled. Exit code 1 when a check fails.
"""
import argparse
import os
import sys

import numpy as np
from PIL import Image
from scipy.ndimage import binary_erosion


def lum(a):
    return a @ [0.299, 0.587, 0.114]


def sat(a):
    mx, mn = a.max(-1), a.min(-1)
    return float(((mx - mn) / (mx + 1e-6)).mean())


def stats(img, m):
    l = lum(img)[m]
    if l.size < 50:
        return None
    return {"mean": float(l.mean()), "p2": float(np.percentile(l, 2)), "contrast": float(np.percentile(l, 95) - np.percentile(l, 5)),
            "sat": sat(img[m])}


def box(spec, shape):
    name, coords = spec.rsplit(":", 1)
    x0, y0, x1, y1 = (int(float(v)) for v in coords.split(","))
    m = np.zeros(shape[:2], bool); m[y0:y1, x0:x1] = True
    return name, m


def alpha(path, shape):
    im = Image.open(path).convert("RGBA")
    if im.size != (shape[1], shape[0]):
        im = im.resize((shape[1], shape[0]), Image.LANCZOS)
    return np.asarray(im)[..., 3] / 255.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("final")
    ap.add_argument("--subject")
    ap.add_argument("--far", action="append", default=[])
    ap.add_argument("--near", action="append", default=[])
    ap.add_argument("--open", action="append", default=[])
    ap.add_argument("--person", action="append", default=[])
    ap.add_argument("--far-subject", action="store_true")
    a = ap.parse_args()
    img = np.asarray(Image.open(a.final).convert("RGB")).astype(np.float64)
    H, W = img.shape[:2]
    fails, warns = [], []

    def show(name, s):
        print(f"  {name:28} mean {s['mean']:6.1f}  darkest(p2) {s['p2']:6.1f}  contrast {s['contrast']:5.1f}  sat {s['sat']:.3f}")

    print(f"{os.path.basename(a.final)}  {W}x{H}")
    refs = {}
    for kind in ("far", "near", "open"):
        for spec in getattr(a, kind):
            name, m = box(spec, img.shape)
            s = stats(img, m)
            if s:
                refs.setdefault(kind, []).append(s); show(f"{kind}: {name}", s)
    subj = None
    if a.subject:
        sa = alpha(a.subject, img.shape)
        core = sa > 0.85
        ys = np.nonzero(core.any(1))[0]
        if len(ys):
            # the solid core (thin parts like antlers, legs, tails, wires eroded away) in the 20-55 % height band:
            # that is the face/body, where a sticker look shows
            span = ys.max() - ys.min()
            solid = binary_erosion(core, iterations=max(3, int(0.012 * max(H, W))))
            band = (np.arange(H)[:, None] > ys.min() + span * 0.20) & (np.arange(H)[:, None] < ys.min() + span * 0.55)
            subj = stats(img, solid & band) or stats(img, core)
            if subj:
                show("subject (solid core)", subj)
    if subj and refs.get("far") and a.far_subject:
        far_c = max(r["contrast"] for r in refs["far"])
        # calibrated on The Guardian: approved stag 50 vs far trees 38 (1.3x); too sharp 58 (1.5x) was rejected
        if far_c * 1.15 < subj["contrast"] <= far_c * 1.4:
            warns.append(f"subject contrast {subj['contrast']:.0f} vs farthest objects {far_c:.0f}: at the upper limit "
                         "(fine if the head must stay readable, like the approved stag)")
        if subj["contrast"] > far_c * 1.4:
            fails.append(f"subject contrast {subj['contrast']:.0f} > farthest objects {far_c:.0f}: it reads as a sticker. "
                         "Add haze (mix toward the fog/sky colour) until it is at or below that.")
    if subj and refs.get("open"):
        o = refs["open"][0]
        if subj["mean"] > o["mean"] - 8:
            warns.append("subject is as bright as the open fog/sky behind it: it may vanish or look like a ghost")
    if subj and refs.get("far"):
        fs = np.mean([r["sat"] for r in refs["far"]])
        if subj["sat"] > fs * 1.8 + 0.03:
            warns.append(f"subject saturation {subj['sat']:.2f} is much higher than the scene's ({fs:.2f}): desaturate")
    for p in a.person:
        pa = alpha(p, img.shape)
        s = stats(img, pa > 0.8)
        if not s:
            continue
        show(f"person: {os.path.basename(p)}", s)
        floor = min([r["p2"] for r in refs.get("near", [])] or [12])
        if s["mean"] < max(8, floor * 0.5):
            fails.append(f"{os.path.basename(p)} is nearly pure black (mean {s['mean']:.0f}); in atmosphere lift it to "
                         f"about the darkest real objects ({floor:.0f})")
        if s["p2"] < 3 and s["mean"] < 20:
            warns.append(f"{os.path.basename(p)} has crushed blacks; lift slightly toward the fog colour")
    # quality
    mp = W * H / 1e6
    if max(W, H) < 2400:
        warns.append(f"long side {max(W, H)} px: use the full-size originals (2600+ px) for best quality")
    if a.final.lower().endswith((".jpg", ".jpeg")):
        mb = os.path.getsize(a.final) / 1e6
        print(f"  file {mb:.2f} MB = {mb / mp:.2f} MB per megapixel")
        if mb / mp < 0.22:
            fails.append("JPEG is heavily compressed: export at quality 97 without chroma subsampling (and a PNG)")
    for w in warns:
        print("WARN ", w)
    for f in fails:
        print("FAIL ", f)
    print("PASS" if not fails else f"{len(fails)} problem(s) to fix")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
