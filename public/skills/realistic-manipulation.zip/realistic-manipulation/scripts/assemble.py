"""Assemble manipulation layers in PhotoCraft (editable .pcraft) and export at full quality.

  python3 -I assemble.py BACKGROUND.jpg OUT_STEM --layer "path.png|Layer name[|Blend]" ... \
      [--sharpen-background] [--grade cool|warm|none] [--intent moody] [--no-png]

Writes OUT_STEM.pcraft (named layers, list order = bottom to top), OUT_STEM.jpg (quality 97), OUT_STEM.png
(lossless, unless --no-png) and prints the photo-edit critic result. Layers must be full-canvas RGBA PNGs at the
background's size. Blend names are PhotoCraft's (Normal, Screen, Multiply, Linear Dodge, Overlay ...).
"""
import argparse
import json
import os
import shutil
import subprocess
import sys

from PIL import Image

PCRAFT = os.path.expanduser("~/.claude/skills/photo-edit/scripts/pcraft.py")
GRADES = {
    "cool": [["layer.newAdjustmentLayer.colorBalance", {"midtones": [-6, 0, 5], "shadows": [-4, 0, 4]}],
             ["layer.newAdjustmentLayer.curves", {"points": [[0, 0], [40, 30], [128, 122], [220, 224], [255, 255]]}]],
    "warm": [["layer.newAdjustmentLayer.colorBalance", {"midtones": [6, 0, -6], "shadows": [-3, 0, 4]}],
             ["layer.newAdjustmentLayer.curves", {"points": [[0, 0], [40, 30], [128, 126], [220, 228], [255, 255]]}]],
    "none": [],
}


def run(bg, stem, steps, export, intent=None):
    cmd = [sys.executable, "-I", PCRAFT, "apply", bg, stem, "--steps", json.dumps(steps), "--export", export]
    if export == "jpg":
        cmd += ["--quality", "97"]
    p = subprocess.run(cmd, capture_output=True, text=True)
    if p.returncode:
        sys.exit(p.stderr or p.stdout)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("background")
    ap.add_argument("out_stem")
    ap.add_argument("--layer", action="append", default=[], help='"path.png|Name[|Blend]"')
    ap.add_argument("--sharpen-background", action="store_true", help="Smart Sharpen the photo (near things crisp)")
    ap.add_argument("--grade", default="cool", choices=list(GRADES))
    ap.add_argument("--intent", default="moody")
    ap.add_argument("--no-png", action="store_true")
    a = ap.parse_args()
    W, H = Image.open(a.background).size
    steps = []
    if a.sharpen_background:
        steps += [["layer.duplicate", {}], ["filter.sharpen.smartSharpen", {"amount": 70, "radius": 1.3, "reduceNoise": 35}],
                  ["layer.setProps", {"name": "Photo, sharpened"}]]
    for spec in a.layer:
        parts = spec.split("|")
        path, name = os.path.abspath(parts[0]), parts[1] if len(parts) > 1 else os.path.basename(parts[0])
        if Image.open(path).size != (W, H):
            sys.exit(f"{path} is {Image.open(path).size}, background is {(W, H)}: build layers at full size")
        steps.append(["file.placeEmbedded", {"path": path, "scale": 100, "fit": False, "center": [W / 2, H / 2]}])
        props = {"name": name}
        if len(parts) > 2:
            props["blend"] = parts[2]
        steps.append(["layer.setProps", props])
    steps += GRADES[a.grade]
    os.makedirs(os.path.dirname(os.path.abspath(a.out_stem)), exist_ok=True)
    run(a.background, a.out_stem, steps, "jpg")
    if not a.no_png:
        tmp = a.out_stem + "__png"
        run(a.background, tmp, steps, "png")
        shutil.move(tmp + ".png", a.out_stem + ".png")
        for ext in (".pcraft", ".recipe.json"):
            if os.path.exists(tmp + ext):
                os.remove(tmp + ext)
    crit = subprocess.run([sys.executable, "-I", PCRAFT, "critic", a.out_stem + ".pcraft", "--intent", a.intent],
                          capture_output=True, text=True).stdout
    print("\n".join(crit.splitlines()[1:4]))
    mb = os.path.getsize(a.out_stem + ".jpg") / 1e6
    print(f"{a.out_stem}.jpg  {W}x{H}  {mb:.1f} MB" + ("" if a.no_png else f"  + {a.out_stem}.png") + f"  + {a.out_stem}.pcraft")


if __name__ == "__main__":
    main()
