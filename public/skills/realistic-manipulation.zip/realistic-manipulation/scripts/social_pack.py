"""Post pack for a finished manipulation: Instagram/Facebook post + "how it was made" slides. Only when the user asks.

  python3 -I social_pack.py final/<name>.pcraft OUT_DIR --title "Don't Be Afraid" \
      --source "inputs/wolf.jpg|work/wolf_lifted.png" --source "inputs/forest.jpg" ... \
      --photo "Wolf" --photo "Girl" ... [--app-shot work/pc_window.png] [--split 0.33]

Reads the layer list from the .pcraft (photocraft-cli info) and the layer files + background from the
<name>.recipe.json that assemble.py writes next to it. --source: a source photo, optionally with its cut-out PNG
(the tile is centred on the cut subject). --photo: layer names that came from photos (the rest = made with code;
the background always counts as a photo). --app-shot: a screenshot of the PhotoCraft window with the file open.

Writes, each as <n>_<slide>_2160x2700.jpg (Facebook / hi-res) and <n>_<slide>_instagram_1080x1350.jpg:
  1 post (whole picture, nothing cut; padded only if it is taller than 4:5), 2 source photos, 3 layers grid,
  4 PhotoCraft layers list, 5 made in PhotoCraft (with --app-shot), 6 before / after (split view).
All slides are 4:5, so one carousel shows them all without cropping.
"""
import argparse
import json
import math
import os
import subprocess

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont, ImageOps

Image.MAX_IMAGE_PIXELS = None
SW, SH = 2160, 2700
BG, CARD, LINE = (17, 18, 20), (28, 30, 33), (52, 55, 60)
TXT, DIM, ACC, BLUE = (236, 236, 232), (150, 152, 156), (214, 168, 92), (38, 110, 235)
HN = "/System/Library/Fonts/HelveticaNeue.ttc"


def font(size, bold=False):
    return ImageFont.truetype(HN, size, index=1 if bold else 0)


class Pack:
    def __init__(self, out, title, total):
        self.out, self.title, self.total, self.n = out, title, total, 0
        os.makedirs(out, exist_ok=True)

    def save(self, img, slug):
        self.n += 1
        img.save(f"{self.out}/{self.n}_{slug}_2160x2700.jpg", quality=97, subsampling=0)
        img.resize((1080, 1350), Image.LANCZOS).save(
            f"{self.out}/{self.n}_{slug}_instagram_1080x1350.jpg", quality=95, subsampling=0)

    def slide(self, title, sub):
        s = Image.new("RGB", (SW, SH), BG); d = ImageDraw.Draw(s)
        d.text((110, 120), title, font=font(96, True), fill=TXT)
        d.text((110, 240), sub, font=font(44), fill=ACC)
        d.line((110, SH - 170, SW - 110, SH - 170), fill=LINE, width=2)
        d.text((110, SH - 120), f"{self.title}  ·  photo manipulation", font=font(36), fill=DIM)
        d.text((SW - 110, SH - 120), f"{self.n + 1}/{self.total}", font=font(36), fill=DIM, anchor="ra")
        return s, d


def contain(im, w, h, fill=BG):
    """Whole image inside w x h, padded (never cropped)."""
    im = ImageOps.contain(im, (w, h), Image.LANCZOS)
    c = Image.new("RGB", (w, h), fill); c.paste(im, ((w - im.width) // 2, (h - im.height) // 2))
    return c


def cover(im, w, h, cx=0.5, cy=0.5):
    """Fill w x h, cropping around (cx, cy) - only for source photos, never the final."""
    return ImageOps.fit(im, (w, h), Image.LANCZOS, centering=(cx, cy))


def card(s, im, x, y, r=18):
    m = Image.new("L", im.size, 0); ImageDraw.Draw(m).rounded_rectangle((0, 0, im.width - 1, im.height - 1), r, fill=255)
    sh = Image.new("L", (im.width + 160, im.height + 160), 0)
    ImageDraw.Draw(sh).rounded_rectangle((80, 95, 80 + im.width, 95 + im.height), r, fill=170)
    s.paste((0, 0, 0), (x - 80, y - 80), sh.filter(ImageFilter.GaussianBlur(30)))
    s.paste(im, (x, y), m)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("pcraft"); ap.add_argument("out")
    ap.add_argument("--title", required=True)
    ap.add_argument("--source", action="append", default=[], help='"photo.jpg[|cutout.png]"')
    ap.add_argument("--photo", action="append", default=[], help="layer name that came from a photo")
    ap.add_argument("--app-shot")
    ap.add_argument("--split", type=float, default=0.33, help="before/after line, fraction of the width")
    a = ap.parse_args()

    stem = a.pcraft[:-len(".pcraft")]
    final = Image.open(stem + ".png" if os.path.exists(stem + ".png") else stem + ".jpg").convert("RGB")
    rec = json.load(open(stem + ".recipe.json"))
    files = {b["params"]["name"]: a_["params"]["path"] for a_, b in zip(rec["steps"], rec["steps"][1:])
             if a_["command"] == "file.placeEmbedded"}
    info = json.loads(subprocess.run(["photocraft-cli", "info", a.pcraft], capture_output=True, text=True,
                                     check=True).stdout)
    layers = [(l["name"], l["kind"]) for l in info["layers"]]                  # top to bottom
    background = Image.open(rec["source"]).convert("RGB")
    total = 5 + bool(a.app_shot)
    p = Pack(a.out, a.title, total)

    # 1 the post: the whole picture. 4:5 or wider is posted as is; taller gets side padding up to 4:5
    W, H = final.size
    post = final if W / H >= 0.8 else contain(final, round(H * 0.8), H)
    if post.width / post.height > 1.91:
        post = contain(post, post.width, round(post.width / 1.91))
    p.n += 1
    post.resize((1080, round(1080 * post.height / post.width)), Image.LANCZOS).save(
        f"{p.out}/1_instagram_1080.jpg", quality=97, subsampling=0, optimize=True)
    fs = 2048 / max(post.size)
    post.resize((round(post.width * fs), round(post.height * fs)), Image.LANCZOS).save(
        f"{p.out}/1_facebook_2048.jpg", quality=97, subsampling=0, optimize=True)

    # 2 source photos around the final, blue lines (the classic breakdown look)
    L, FW, FH = 8, 1440, 1800
    s = Image.new("RGB", (SW, SH), BLUE)
    s.paste(contain(final, FW - L, FH - L), (0, 0))
    srcs = a.source[:6]
    right = srcs[:2]; bottom = srcs[2:]
    slots = [(FW + L, i * FH // len(right) + (L if i else 0), SW - FW - L,
              FH // len(right) - L - (L if i else 0) + (L if i == len(right) - 1 else 0)) for i in range(len(right))]
    bw = SW // max(len(bottom), 1)
    slots += [(i * bw + (L if i else 0), FH, bw - (L if i else 0), SH - FH) for i in range(len(bottom))]
    for spec, (x, y, w, h) in zip(srcs, slots):
        parts = spec.split("|"); im = Image.open(parts[0]).convert("RGB"); cx = cy = 0.5
        if len(parts) > 1:
            bb = Image.open(parts[1]).getbbox()
            cx, cy = (bb[0] + bb[2]) / 2 / im.width, (bb[1] + bb[3]) / 2 / im.height
        s.paste(cover(im, w, h, cx, cy), (x, y))
    if not srcs:
        s.paste(contain(final, SW, SH), (0, 0))
    p.save(s, "source_photos")

    # 3 every layer on its own, zoomed to where it has content, faint effects shown at full strength
    names = [n for n, _ in reversed(layers)]                                    # bottom to top
    photo = set(a.photo) | {"Background"}
    n = len(names); cols = 5 if n > 12 else 4; rows = math.ceil(n / cols)
    gx = 36; TW = (SW - (cols + 1) * gx) // cols; TH = round(TW * 1.25)
    rowh = TH + 115
    if 330 + rows * rowh > SH - 40:
        k = (SH - 40 - 330) / (rows * rowh); TW = int(TW * k); TH = round(TW * 1.25); rowh = TH + 115
        gx = (SW - cols * TW) // (cols + 1)
    s = Image.new("RGB", (SW, SH), (16, 17, 19)); d = ImageDraw.Draw(s)
    n_photo = sum(nm in photo for nm in names)
    d.text((SW // 2, 120), f"{n} LAYERS", font=font(120, True), fill=TXT, anchor="mm")
    d.text((SW // 2, 230), f"{n_photo} real photos   +   {n - n_photo} made with code (light, mist, rain...)",
           font=font(46), fill=(170, 175, 182), anchor="mm")
    for i, nm in enumerate(names):
        r, c = divmod(i, cols); x = gx + c * (TW + gx); y = 320 + r * rowh
        if nm == "Background":
            tile = cover(background, TW, TH)
        else:
            arr = np.asarray(Image.open(files[nm]).convert("RGBA")).astype(np.float32)
            al = arr[..., 3] / 255
            ys, xs = np.nonzero(al > max(0.02, np.percentile(al[al > 0], 60) * 0.3)) if (al > 0).any() else ([0], [0])
            y0, y1 = np.percentile(ys, [0.5, 99.5]); x0, x1 = np.percentile(xs, [0.5, 99.5])
            bh = min(max(y1 - y0, (x1 - x0) * 1.25, 500) * 1.25, arr.shape[0]); bw_ = min(bh / 1.25, arr.shape[1])
            bx = int(np.clip((x0 + x1 - bw_) / 2, 0, arr.shape[1] - bw_)); by = int(np.clip((y0 + y1 - bh) / 2, 0, arr.shape[0] - bh))
            arr = arr[by:by + int(bh), bx:bx + int(bw_)]; al = arr[..., 3] / 255
            al = np.clip(al / max(np.percentile(al, 99.7), 0.05), 0, 1)
            lum = (arr[..., :3].mean(2) * al).sum() / max(al.sum(), 1)
            back = 205 if lum < 60 else 14                                       # dark layers on grey, light on black
            rgb = back * (1 - al[..., None]) + arr[..., :3] * al[..., None]
            tile = Image.fromarray(rgb.astype(np.uint8)).resize((TW, TH), Image.LANCZOS)
        s.paste(tile, (x, y))
        isp = nm in photo
        d.rectangle((x - 2, y - 2, x + TW + 1, y + TH + 1), outline=BLUE if isp else (70, 72, 78), width=3)
        d.text((x, y + TH + 18), nm, font=font(29, True), fill=(230, 230, 233))
        d.text((x, y + TH + 58), f"{i + 1:02d}  " + ("photo" if isp else "made with code"), font=font(30),
               fill=(120, 160, 240) if isp else (125, 129, 135))
    p.save(s, "layers")

    # 4 the PhotoCraft layers panel, read from the file itself
    s, d = p.slide("PHOTOCRAFT LAYERS", f"{n} layers  ·  {info['width']}×{info['height']} px")
    ROW = min(112, (SH - 230 - 360 - 24) // n); py = 360; LX, LW = 110, SW - 220
    d.rounded_rectangle((LX, py, LX + LW, py + n * ROW + 24), 22, fill=CARD)
    TH2, TW2 = ROW - 22, round((ROW - 22) * 1.7)
    chk = Image.new("RGB", (TW2, TH2))
    chk.putdata([(205,) * 3 if ((x // 8) + (y // 8)) % 2 else (160,) * 3 for y in range(TH2) for x in range(TW2)])
    fl = font(min(44, ROW * 0.42)); fsm = font(min(36, ROW * 0.34))
    for i, (nm, kind) in enumerate(layers):
        ry = py + 12 + i * ROW
        if i:
            d.line((LX + 30, ry, LX + LW - 30, ry), fill=LINE, width=2)
        tx = LX + 90
        d.text((LX + 46, ry + ROW / 2), str(n - i), font=fsm, fill=DIM, anchor="mm")
        if nm == "Background":
            th = cover(background, TW2, TH2)
        else:
            th = chk.copy(); lay = Image.open(files[nm]).convert("RGBA")
            bb = lay.getchannel("A").point(lambda v: 255 if v > 20 else 0).getbbox() or (0, 0, *lay.size)
            lay = lay.crop(bb); lay.thumbnail((TW2, TH2), Image.LANCZOS)
            th.paste(lay, ((TW2 - lay.width) // 2, (TH2 - lay.height) // 2), lay)
        s.paste(th, (tx, ry + 11))
        d.rectangle((tx - 1, ry + 10, tx + TW2, ry + 11 + TH2), outline=LINE, width=2)
        d.text((tx + TW2 + 36, ry + ROW / 2), nm, font=fl, fill=TXT, anchor="lm")
        d.text((LX + LW - 36, ry + ROW / 2), kind, font=fsm, fill=DIM, anchor="rm")
    p.save(s, "photocraft_layers")

    # 5 the real app window (proof), with its layers panel enlarged
    if a.app_shot:
        win = Image.open(a.app_shot).convert("RGB")
        s, d = p.slide("MADE IN PHOTOCRAFT", f"the real project file, open in the app  ·  {n} layers")
        ww = SW - 220; wh = round(win.height * ww / win.width)
        card(s, win.resize((ww, wh), Image.LANCZOS), 110, 370)
        panel = win.crop((int(win.width * 0.834), int(win.height * 0.405), win.width, int(win.height * 0.958)))
        y2 = 370 + wh + 90; h2 = SH - 230 - y2; pw = round(panel.width * h2 / panel.height)
        card(s, panel.resize((pw, h2), Image.LANCZOS), (SW - pw) // 2, y2, 12)
        p.save(s, "made_in_photocraft")

    # 6 before / after in one frame: the plain background left of the line, the finished picture right of it
    ba = final.copy(); cut = int(W * a.split)
    ba.paste(background.resize(final.size).crop((0, 0, cut, H)), (0, 0))
    d = ImageDraw.Draw(ba); k = W / 2600
    d.rectangle((cut - 3 * k, 0, cut + 3 * k, H), fill=(245, 245, 245))
    cy = H // 2; R = 58 * k
    d.ellipse((cut - R, cy - R, cut + R, cy + R), fill=(245, 245, 245))
    d.polygon([(cut - 14 * k, cy - 22 * k), (cut - 38 * k, cy), (cut - 14 * k, cy + 22 * k)], fill=(30, 30, 30))
    d.polygon([(cut + 14 * k, cy - 22 * k), (cut + 38 * k, cy), (cut + 14 * k, cy + 22 * k)], fill=(30, 30, 30))
    f = font(round(64 * k), True)
    for label, left in [("BEFORE", True), ("AFTER", False)]:
        tw = d.textlength(label, font=f); x = 60 * k if left else W - 60 * k - tw - 60 * k
        d.rounded_rectangle((x, 60 * k, x + tw + 60 * k, 160 * k), 16 * k, fill=(0, 0, 0))
        d.text((x + 30 * k, 110 * k), label, font=f, fill=(245, 245, 245), anchor="lm")
    p.save(contain(ba, SW, SH), "before_after")
    print(f"{p.n} slides in {a.out}")


if __name__ == "__main__":
    main()
