# What this user loves (and rejects)

Kept up to date after every piece. Newest lessons at the bottom of each list.

## The references they sent (what "good" means to them)
| Piece | What makes it work |
|---|---|
| Giant bear in fog over a forest road, small man looking up, birds | Daytime fog; the bear is far, hazy, low-contrast, same blue-grey as the fog; its body dissolves into fog (no ground contact needed); dark trees frame both sides; tiny person for scale. |
| UFO over the pyramids at dusk, camels | Everything darkened into silhouettes against a dramatic sky; one light source (the UFO beam) motivates the whole grade; foreground camel near-black. |
| Kraken attacking a boat, man with a sword, sharks | Water integration: splashes and foam where tentacles enter the sea, matching sky light, overcast grade. |
| Car crash on a bridge at night | Heavy teal grade, headlight glow, motion blur and sparks hide the cut edges; strong perspective. |
| Girl buried in snow, only eyes and hat | Subject sunk into the medium (snow on top of her, falling snow in front), cold grade. |

Common thread: **atmosphere and a medium (fog, water, snow, darkness, dust) hide the joins; one light and one grade
unify everything; a small human sets the scale; the result reads as one photograph.** Easy ideas, done very well.

## Loved
- Cinematic, realistic, "how was this made?" pieces like viral Pinterest/Behance manipulations.
- Moody palettes: blue-grey fog, teal night, dusk silhouettes. Fine grain, deep but not crushed blacks.
- The Guardian (giant stag in fog at the end of a road, small walker): "i love that style" - see
  `../examples/guardian_final.jpg`. Approved after the realism check (more haze than the farthest trees, light wrap,
  fog-lifted walker, varied soft birds).
- Full quality: they noticed a 2000 px, heavily compressed JPEG and asked for better quality.

## Rejected (and why)
- "Simple" bright, clean composites ("your style very simple").
- The sticker look: a sharp, bright subject floating in the sky or in front of a cliff (Light Catcher v1, see
  `../examples/REJECTED_sticker_cat.jpg`) - "cat in sky, not realistic, no one likes it".
- Turning a subject's colours into a blue/grey duotone (the cream cat became grey).
- Hiding parts of the user's own subject (legs/body of their cat) that the photo didn't cut.
- Rebuilding/redrawing the user's subject instead of using their photo as shot.
- Always the same subject: they asked for completely new ideas, "not cat, not just animal".
- Fake details: identical stamped birds, glowing white shoes on a silhouette, pure-black people in fog.

## Pieces log
- 2026-11-02 The Guardian (giant stag in fog, walker) - loved; quality pass to 2624x3936 + PNG.
- 2026-11-02 The Drift (7 photos: foggy night road, man with umbrella, 5 jellyfish) - built after the user asked for
  "more images, more than 5 things, best knowledge". Technique: emissive subjects shot on black added as light
  (screen) - no cut edges; fog extinction + bloom by distance; their light on the wet road (streaks + pool), on rain
  and on the umbrella rim; dark poles occlude them. Lessons: a uniform rim outline on a person reads as a sticker -
  keep rims thin, broken and only on the side facing the light; road reflections must be narrow streaks that fade in
  below the horizon, never a flat wash with a hard line.
- 2026-11-02 The Sea Has Come to Hawler (9 photos: Erbil Citadel, storm sky, storm sea, splash, boat, 3 gulls).
  The user chose this from 4 offered ideas (asked "don't start until we decide" - offer ideas first when asked).
  Technique: storm light (keep the sunny photo's light, pick sky/sea/boat/gulls also sunlit); water line = the sea
  photo's own crest silhouette (per column, where green wave body or white foam starts), only real spray above it -
  procedural foam lines and straight edges looked fake; nearer objects (lamp post) get their own lower water line and
  foam ring; modern distractions (billboard, sign pole) painted out. Splash photos shot against teal sky leak the
  sky: crop above their own horizon and key out blue.
  Review round (user: "make it better / add things"): offered a ranked list of problems + additions, they picked my
  recommendation. Lessons: procedural extras look CG unless toned down - sun rays must be few, wide and faint (first
  try was strong regular lines); a drawn flag needs cloth colours (not screen-pure), folds, top-down shading, scene
  blur; replacing lettering on an object: paint the whole traced plate polygon, then set text along its slant;
  painted-out areas need per-row brightness matching to the neighbour or they show as a lighter panel. The user likes
  Kurdish touches (flag, هەولێر on the boat).
- 2026-11-02 Hawler After 10 Minutes of Rain (meme, 7 photos): user wanted a funny-but-real take on Kurdistan's rain
  floods; asked for ideas first, picked "citadel flooded + boat + man on plastic chair", rainy sky, no caption yet.
  Lessons: calm flood water = brown + strong mirror reflections (fresnel ~0.8 far) + rain rings, straight water line is
  correct for calm water; use the photo's own real cars/people as the drowned elements (best realism); remove sun for
  rain (flatten big light differences, desaturate) but not too dark; Vision cut-outs can include stray lines (a rope) -
  detect by brightness, not by "whiteish" (chair legs matched); mask rain rings off objects; objects stand ON a roof
  surface (a bit below its silhouette top), not on the edge. Local details they enjoy: Kurdish billboard, istikan,
  orange plastic chair.
  User rejected the "man on a plastic chair on a car roof" joke ("not nice, not good"): staged/impossible gags read
  fake - prefer humour from things that really happen in floods (wading, rowing, pushing a stalled car, kids playing).
  Round 3: user said "add all three" (men pushing a stalled taxi, boy wading hip-deep, baby in a washing tub) and
  "remove the billboard". Real flood photos (Unsplash) cut at their own water line, overcast() relight (flatten,
  desaturate to ~0.5 for strong colours like a blue shirt / pink tub, match the rower's brightness), wet band above
  the water, own reflection + ripple rings each. Nearer object drawn over farther (boy over tub, hand on its rim).
  Billboard removal: clone the wall from one/two arch spacings left with a soft seam, repeat brick courses down the
  jambs, and remove duplicated landmarks (a second wall vent gives the clone away).
  Round 4 ("make rain in water better, like real"): drawn ring outlines and sin() ripple displacement looked fake
  (sticker rings, sawtooth zigzag reflections, giant thin ellipses around objects). Fix = a physical height field:
  each drop is a damped ring wave packet in world metres (perspective s(y), squash asp(y)), 1-2 crests only, age-faded;
  light from slope (bright side/dark side, no outline), the same slopes bend + vertically smear reflections; waves
  finer than ~4 px are faded out (moire); far water gets thin horizontal shimmer instead; ~8 % fresh drops get a tiny
  crown splash; moving people/oars make wide slow wakes; object water lines wavy + a broken, faint meniscus.
  Round 5: user loved it; asked for more cars, specifically BYD ("in Erbil now BYD used" - local truth matters), and one
  consistent water depth ("some cars below water, some people above"). Rule: pick ONE flood depth (0.7 m) and cut every
  car/person at it using a scale model s(y)=0.243*(y-3383) px/m: cars at mid-door, people at the hip; moved the main
  WL too so the photo's own parked cars match. Cars seen at an angle get a sloped water line (cut_poly) and per-column
  reflections/contact. Keep brand marks above water (rear BYD letters) - front logos sit below 0.7 m.
  User spotted a car "cut behind": a straight-line mask meant to remove a background scrap sliced the car's roof.
  Remove scraps with a traced polyline along the object's real edge, and always view the cut-out on magenta after.
- 2026-11-03 The Visitor (5 photos: foggy pier, humpback fluke with dripping water, two kids holding hands in fog,
  perched gull, flying gull). User sent a "girl meets bear" reference and asked for something with children, "another
  idea, not a copy". Technique: all sources shot in fog/overcast; giant tail beside the pier at ~3x real size; the pier
  railing occludes the tail's water ring (foreground hides the join); tail = its own photo darkness under ~30 % fog +
  light wrap (a contrast-only remap made it flat grey); sea around the tail remapped to the pier's sea at half contrast;
  drips matted as bright threads over a blurred local background; scale from the photo itself (lone walker 145 px =
  1.7 m -> px/m = 0.65*(y-1640)); kids softened 0.7 px to match the pier's sharpness at their depth; breakdown panel
  under the final like the reference pins.
- 2026-11-03 Don't Be Afraid (3 photos + procedural rain/mist): user asked for ~10 ideas first, then "a little girl idea
  that touches people's feelings"; picked "giant black wolf lowers its head to a toddler in a yellow raincoat" in a
  rainy forest. Technique: dark misty forest crop with the path at the bottom; wolf ~2x real, its nose hidden behind her
  hood (the touch is implied, not shown); wolf photo's legs left the frame -> stretched straight legs, then pushed into
  the shadow under its body (x0.13) and ground mist - a lit, half-transparent leg looked fake; back of the wolf gets a
  little mist + softer outline; rain colour must be light grey (fog colour was too dark to see); yellow coat kept as
  the one colour accent. Emotional ideas (innocence, kindness, missing family) are what the user wants to share.
- 2026-11-03 One Meter, Two Seasons (Erbil smart-meter meme, 16 photos, 26 layers, NO text): user asked for Erbil meme
  ideas, picked the smart meter (کارەبای پێوەری زیرەک) + "no need for gas" (eggs on a hot car) + winter rain water,
  and wants "more and more manipulation" like a hyena/magic-staff reference with a before/after outlined breakdown.
  Build: long frontal boundary wall split at a pillar (summer left / flooded winter right), glowing smart meter on
  the pillar as the light source. Lessons: a halo-sky photo upscaled looked muddy - a gradient sky sampled from the
  photo's own colours + a white sun disk reads hotter; a warm glow layer over the sun turns it beige - keep it white
  and faint; people cut at the waist go behind a car bonnet / over a wall top (the occluder hides the cut); eggs on a
  bonnet must sit on the strip just below the bonnet edge with a small shadow + steam, or they look like stickers;
  a dense water stream looks like a glowing rod - break it into thin threads and drops; cables must not pass through
  people/cars. Breakdown style they like: top = pieces outlined in white, bottom = final, sources strip below.
  REJECTED HARD ("worst design I've seen, just cut and paste"). Why it failed: split-screen collage of 13 stock
  pieces, each shot from a different camera angle and light (side-view car, posed portrait people, a desk gadget as
  the meter) on a flat frontal wall; nothing shared one light or atmosphere, no medium hid the joins, objects sat on
  the surface instead of in the scene. Lesson: "more manipulation" still means ONE photograph - fewer pieces chosen to
  share camera height/angle and light, one unifying light/atmosphere (like the reference's night + glow + dust), and
  every element interacting with the scene. Never build a many-sticker collage again; propose the realism plan first.
- Don't Be Afraid v2 (wolf), user "loved it". Last-pass details that mattered: the warm practical light caught in the
  giant's eyes (small iris warm-up + tiny catch-light on the side facing the light), breath kept off the subject's own
  silhouette (it made a see-through "ghost jaw"), leftover source colours at a prop's base removed, coat raindrops as
  few small running beads instead of dots.
- Don't Be Afraid hidden details (user asked for "small things to discover"): pup peeking from behind the mother's leg
  (eye-level source, flipped to look at the girl, deep shade, paws sunk in the bg's own grass), a moth resting on the
  lantern glass as a dark delta + one blurred in flight, beads on the top fur edge only, faint boot prints. Lessons:
  procedural rings/beads/moths look fake when too many or too regular - fewer, broken, softer; a dark silhouette on a
  bright source reads better than a lit speck.
- 2026-11-03 Post pack: for sharing, the user wanted the full picture for Instagram AND Facebook with nothing cut,
  a "which photos were used" sheet like viral breakdowns (final big, sources around it, blue lines), a layers sheet,
  the PhotoCraft layers list, a real app screenshot as proof, and a before/after. Faint layers (rain, mist) looked
  like empty boxes until each tile was zoomed to its content and shown at full strength. Make the pack only when
  asked (`scripts/social_pack.py`). They also wanted an honest caption and a shareable prompt.
