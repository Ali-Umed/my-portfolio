# Techniques that make a composite believable

Pick the technique first, then the subject. Each lists what must match and what hides the joins.

## 1. Giant in fog (most reliable - The Guardian)
- Sources: background shot in real fog/overcast; subject also shot in fog or overcast, roughly facing the camera.
- Fog level per row = 97th percentile of the row's luminance (smoothed); anything darker than that is "in front"
  (trees mask) and covers the subject.
- Haze: `subject*(1-h) + fog*h` with h about 0.58 at the top rising to 0.93 at the ground; the subject must end up with
  **no more contrast than the farthest real objects** of the photo. Blur ~1.6 px per 2000 px width.
- Light wrap: blend blurred fog over the outer ~9 px of the subject (up to 60%).
- Base: dissolve the feet into ground fog; add a faint flipped dark smear on wet roads.
- A brighter patch of fog behind the subject separates the silhouette.
- Scale: a small person on the road, a dark-grey (not black) silhouette lifted by fog, soft overcast shadow, faint
  reflection on a damp road.

## 2. Silhouette against a dramatic sky (UFO / pyramids style)
- Sources: sky with strong backlight (sunset, storm); foreground subjects photographed against light, or darkened.
- Push everything in the foreground toward near-black silhouettes with a rim of sky colour; one motivated light
  (beam, glow) gets bloom and lights only what faces it. Haze between layers by distance.

## 3. Water integration (kraken / boat / sea creature)
- Matching sky light and wave direction. Where anything enters the water: dark contact line, foam ring, splashes
  (photos of real splashes, screen blend), wet sheen on the subject's lower part, reflections broken by waves.
- Spray and rain in front of the subject soften its edges.

## 4. Buried in a medium (snow, sand, leaves)
- Subject cut low; the medium photo laid **over** the subject's lower edge with a soft, irregular mask; particles
  (falling snow, dust) in front at several sizes and blurs; cold or warm grade from the medium.

## 5. Action / vehicles (car crash style)
- Strong perspective match (horizon line, lens angle). Motion blur in the movement direction, sparks/debris, headlight
  glow and light on the road, heavy teal/orange grade. Blur and glow hide cut edges.

## 6. Night with practical lights (lighthouse, windows, street lamps)
- Harder: each light must light the subject from the right side with the right colour, falloff and shadow direction.
  Prefer techniques 1-2 unless the user asks for night. If night: keep the subject's own colours darkened (not a
  duotone), broad lamp light on surfaces facing it, contact shadows only on real surfaces, mist so beams have volume.

## 7. A small light in a dark scene (lantern / candle - "Don't Be Afraid")
- The light falls off as k/(1+d²/r²): bright pool on the ground, warm edge on the near side of every subject, nothing
  on the far side. Warm the eyes of an animal that faces it (iris tint + one tiny glint) - it brings the face alive.
- A big dark subject in front of bright mist reads as one photo when its back is hazier than its face and its legs
  go dark under the body; keep the face sharp (light unsharp mask) - soft muzzles look pasted.
- Breath, steam and mist never sit on top of a solid subject's silhouette (it looks see-through): cut them by its alpha.
- Hidden details make people look twice: a small second subject peeking, moths at the light, footprints, rain rings
  on puddles. Keep them few, broken, soft and lower-contrast than the main subject.
- Example: `../examples/build_lantern_wolf.py`.

## Always
- One grade over everything at the end (curves + colour balance in PhotoCraft).
- Fine luminance grain (sigma ~2, blurred 0.5 px) over the whole image - it also dithers smooth fog against banding.
- Small details are where fakes show: vary birds (size, wing phase, tilt, softness), no white shoes / leftover
  cut-out gaps on silhouettes, no hard rectangle edges from masks.
