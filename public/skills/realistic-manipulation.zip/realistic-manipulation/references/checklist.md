# Realism and quality checklist (run before every delivery)

View zoomed crops (1:1) of: the subject's face, its outline against the background, where it meets the ground/water,
every person, and small added details. Then run `scripts/realism_check.py`.

## Realism
- [ ] Same light: direction, softness and colour match between subject and background.
- [ ] Distance: a far subject is at least as hazy/low-contrast as the farthest real objects; near objects are sharpest.
- [ ] Edges: no halo, no hard cut, no leftover background inside gaps (between arm and body, antlers).
- [ ] Contact: hidden by a medium, or a real shadow on the right surface; nothing floating, no shadow in mid-air.
- [ ] Occlusion: things that are nearer than the subject are drawn in front of it.
- [ ] Blacks: nothing pure black inside atmosphere; people in fog are dark grey.
- [ ] Colour: subject saturation close to the scene's (fog kills colour); real colours kept.
- [ ] Details: birds, particles, reflections look varied and natural; no repeated stamps.
- [ ] Masks: no rectangles or straight seams from region masks (check sky masks, horizon bands).
- [ ] Story: one clear idea, the scale reads instantly (small person, known object).

## Quality
- [ ] Sources downloaded at full original size; the subject is never upscaled.
- [ ] Final at the background's full resolution (2600+ px on the long side when possible).
- [ ] JPEG quality 97, no chroma subsampling (>= ~0.25 MB per megapixel), plus a lossless PNG.
- [ ] Only near elements sharpened (Smart Sharpen on the background photo layer); far subject stays soft.
- [ ] Fine grain present, no banding in smooth fog/sky.
- [ ] PhotoCraft critic PASS; `.pcraft` keeps every layer named and editable.
