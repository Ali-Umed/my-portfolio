---
name: realistic-manipulation
description: "Make realistic, cinematic photo manipulations the way this user loves them - viral Pinterest/Behance style composites that look like a real photograph, not a pasted sticker. Any subject - giant animals in fog, UFOs over landmarks, sea monsters and boats, cars and action scenes, people buried in snow, surreal scale (tiny person, huge object), fantasy landscapes, night scenes lit by real lights. Holds the user's taste profile (what they love and what they rejected), a realism-first way to pick ideas and source photos, the build pipeline (Apple Vision cut-outs, numpy layers, PhotoCraft assembly with editable layers), a measurable realism check, a full-quality export, and (only when asked) a 4:5 post pack for Instagram/Facebook with source photos, layers, PhotoCraft proof and before/after. Use it whenever the user asks for a manipulation, composite, edit like the Pinterest examples, 'make something like this', 'put X in this photo', 'make it more realistic', 'better quality', or shows reference manipulations - and whenever you need to remember what kind of design and quality they like."
---

# Realistic manipulation (the user's style)

The user judges every piece against professional viral manipulations (giant bear in fog over a road, UFO over the
pyramids, kraken attacking a boat, car crash on a bridge, girl buried in snow). The test is simple: **would someone
believe it is one photograph?** Read `references/taste.md` first: it lists what they loved and exactly what they
rejected and why.

## Workflow

1. **Pick the idea for realism, not for the subject.** Before anything, decide which idea can be made *believable*
   with photos that exist. Use `references/techniques.md` (fog giant, silhouette against sky, water integration, snow
   burial, motion/action, night practical light). If the user gives no idea, propose one with a one-line reason why it
   will look real, then build it. Never default to "the user's pet" - any subject is fine. When the user gives their
   own photo, never hide or cut parts of their subject that the photo itself didn't cut.
2. **Source photos that already share the light.** This is the single biggest factor. Background and subject must be
   shot in the same light (both fog/overcast, both backlit sunset, both night). A subject shot in sunlight will never
   sit in a fog scene, however much you grade it. Search Unsplash in the built-in browser (license=free), collect ids
   with JS, download thumbnails into a contact sheet, pick, then download the **full original** (`?fm=jpg&q=100`,
   no `w=`). Ask before downloading only if the user hasn't already said to go ahead. Put downloads in their own
   folder; run Python with `-I`. Pinterest images are small and copyrighted - use them only as references.
3. **Cut out** with Apple Vision: `scripts/lift <in.jpg> <out.png> <mask.png>` (needs `dangerouslyDisableSandbox`;
   rebuild from `scripts/lift.swift` with `swiftc -O lift.swift -o lift` if the binary is missing). Check the cut on
   magenta before using it.
4. **Build layers with a script** (`<project>/build_<name>.py`, start from `examples/build_guardian.py`): full-canvas
   RGBA PNGs in `work/layers/`, plus a numpy preview. Design every size relative to the canvas (`K = W / 2000`) so the
   piece can be rebuilt at any resolution. Apply the techniques from `references/techniques.md`.
5. **Run the realism check** - `scripts/realism_check.py` (below) - and look at zoomed crops yourself (subject face,
   edges, contact point, people, small details like birds). Fix and repeat. Read `references/checklist.md`.
6. **Assemble in PhotoCraft and export at full quality** - `scripts/assemble.py` (below): editable `.pcraft` with named
   layers, JPEG quality 97 with no chroma subsampling, lossless PNG, and the critic score.
7. **Deliver**: the final, a breakdown image (sources under the final, like the user's references), and when you
   improved something, a before/after. Explain in short plain English (the user is not a native speaker): the idea,
   *why it looks real*, what you checked and fixed, file paths, and the `open -a PhotoCraft` command. Offer an
   Instagram 4:5 (1080x1350) version.
8. **Post pack - only when the user asks** ("post it", "Instagram/Facebook", "show the layers", "which photos were
   used"). Never make it by default. Run `scripts/social_pack.py` (below). It makes one 4:5 carousel where nothing is
   cut: 1 the post (Instagram 1080 + Facebook 2048), 2 the source photos around the final with blue lines,
   3 every layer zoomed so faint effects are visible (photo vs made with code), 4 the PhotoCraft layers panel read
   from the .pcraft, 5 the real app window (proof), 6 before/after split. For slide 5 first capture the app:
   `open -a PhotoCraft final/<name>.pcraft`, then computer-use `app_screenshot` of PhotoCraft (dismiss an update
   dialog with Later, drag the Layers panel divider up so most layers show) and copy the saved image to
   `work/pc_window.jpg`. Look at every slide before sending. If asked, also write the caption and a shareable prompt -
   see "Sharing" below.

## Scripts

```bash
S=~/.claude/skills/realistic-manipulation/scripts
# measure realism: subject vs reference regions of the photo (far objects, nearest dark object, open fog/sky)
python3 -I $S/realism_check.py final.jpg --subject work/layers/02_subject.png \
    --far "far trees:1350,1300,1500,1900" --near "near trees:1700,900,2624,1500" --open "fog:1250,700,1350,900" \
    [--person work/layers/06_person.png] [--far-subject]
# assemble in PhotoCraft (layer order = list order; name|blend), export JPEG 97 + PNG, run the critic
python3 -I $S/assemble.py inputs/background.jpg final/<name> \
    --layer "work/layers/01_glow.png|Glow behind subject" --layer "work/layers/02_subject.png|Subject" ... \
    [--sharpen-background] [--grade cool|warm|none] [--intent moody]
```

# post pack (only when asked): 6 slides, 4:5, hi-res + Instagram size
python3 -I $S/social_pack.py final/<name>.pcraft final/social --title "<Name>" \
    --source "inputs/wolf.jpg|work/wolf_lifted.png" --source inputs/forest.jpg ... \
    --photo "Wolf" --photo "Girl" ... --app-shot work/pc_window.jpg [--split 0.33]
```

`--source` takes up to 6 photos (with the cut-out PNG the tile centres on the subject); `--photo` names the layers
that came from photos (the rest are labelled "made with code"); `--split` moves the before/after line so the
subject's face sits on the "after" side.

`realism_check.py` flags: a far subject with more contrast than the farthest real objects (sticker look), pure-black
people or silhouettes in atmosphere, colour saturation that doesn't match the scene, and low resolution or heavy JPEG
compression of the final. Numbers that pass can still look wrong - always view the crops.

## Sharing (caption and prompt)
Be honest about how it was made: code built the layers (numpy), Apple Vision cut the subjects, and
`photocraft-cli` (PhotoCraft's command-line tool, not MCP, not hand clicks) assembled the editable .pcraft; the app
was opened only to check and screenshot. A piece made over many rounds has no single prompt: write a cleaned-up
prompt that matches exactly what is in the final image (scene, real photos used, light, atmosphere, hidden details,
"separate named layers in PhotoCraft, 4:5 full quality") and say it was refined over several rounds. Keep the
caption short: title, one-line story, "N real photos + M layers made with code", how, "swipe" hint, a few hashtags.

## Hard rules (from the user's feedback)
- Realism beats drama. A sharp, bright, fully-detailed giant floating over a scene = rejected.
- Something must hide or explain where the subject meets the world: fog, water, snow, dust, foreground objects,
  or a real contact shadow on the right surface. Never draw shadows in mid-air.
- Keep the subject's real colours; don't turn it into a blue/grey duotone to "fit the night".
- Full quality always: biggest original sources, never upscale the subject, JPEG 97 + PNG, check file size.
- Decide, then explain briefly - the user wants you to think about the better option before building.
- Save what you learn about their taste to `references/taste.md` (and the memory file) after each piece.
