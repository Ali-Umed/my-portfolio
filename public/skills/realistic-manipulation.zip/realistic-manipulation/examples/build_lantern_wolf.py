# Example build: "Don't Be Afraid" - girl with a lantern meets a giant wolf in rainy mist (20 layers).
"""Don't Be Afraid v2: the giant wolf now stands on its own four paws and bends its head to the girl; a lantern on the
path lights its face warm from below and puts a rim of light around her; its breath drifts around her hood; soft light
beams fall through the trees; dark ferns frame the front; real puddle, splashes and wet coat. Final crop 4:5, tighter."""
import os
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

os.makedirs("work/layers2", exist_ok=True)
rng = np.random.default_rng(21)
W, H = 3200, 4000
bg = np.asarray(Image.open("work/forest_canvas.jpg").convert("RGB")).astype(np.float32)
YY, XX = np.mgrid[0:H, 0:W].astype(np.float32)
FOG = bg[1300:1700, 1100:1900].reshape(-1, 3).mean(0)
WARM = np.array([255, 170, 80], np.float32)


def save(name, rgb, a):
    out = np.dstack([np.clip(rgb, 0, 255), np.clip(a, 0, 1) * 255]).astype(np.uint8)
    Image.fromarray(out, "RGBA").save(f"work/layers2/{name}.png")


def place(im, scale, x0, y0):
    im = im.resize((round(im.width * scale), round(im.height * scale)), Image.LANCZOS)
    arr = np.asarray(im).astype(np.float32)
    rgb = np.zeros((H, W, 3), np.float32); a = np.zeros((H, W), np.float32)
    x0, y0 = int(round(x0)), int(round(y0))
    sx, sy = max(0, -x0), max(0, -y0); ex, ey = min(W, x0 + im.width), min(H, y0 + im.height)
    rgb[y0 + sy:ey, x0 + sx:ex] = arr[sy:ey - y0, sx:ex - x0, :3]
    a[y0 + sy:ey, x0 + sx:ex] = arr[sy:ey - y0, sx:ex - x0, 3] / 255
    return rgb, a


def over(base, rgb, a):
    return base * (1 - a[..., None]) + rgb * a[..., None]


def blur3(rgb, s):
    return np.dstack([ndi.gaussian_filter(rgb[..., c], s) for c in range(3)])


def noise(sy, sx, seed):
    n = ndi.gaussian_filter(np.random.default_rng(seed).normal(0, 1, (H // 8, W // 8)), (sy, sx))
    n = (n - n.min()) / np.ptp(n)
    return np.asarray(Image.fromarray((n * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC)) / 255.0


# ---- positions
G_FEET, G_CX, G_H = 3880, 1500, 1120                               # girl
LX, LY = 1240, 3790                                                # lantern base (on the path, just ahead-left of her)
NOSE_X, NOSE_Y = 1600, 2930                                        # wolf nose: right behind her hood

def lantern_light(px, py, k, r):                                   # inverse-square-ish warm falloff from the flame
    d2 = ((XX - px) ** 2 + (YY - py) ** 2) / r ** 2
    return k / (1 + d2)

FLAME = (LX, LY - 190)

# ---- the wolf: real full-body photo, walking to her with its head low
wolf = Image.open("work/wolf2_lifted.png").convert("RGBA"); wolf = wolf.crop(wolf.getbbox())
_wa = np.asarray(wolf).copy()                                     # remove the tail sticking up above its back
_ty, _tx = np.mgrid[0:_wa.shape[0], 0:_wa.shape[1]]
_tail = np.clip((215 - _ty) / 25, 0, 1) * np.clip((_tx - 235) / 20, 0, 1) * np.clip((470 - _tx) / 20, 0, 1)
_wa[..., 3] = (_wa[..., 3] * (1 - _tail)).astype(np.uint8)
wolf = Image.fromarray(_wa, "RGBA")
NOSE = (1069, 1720)                                                # nose tip inside the cropped cut-out
WS = 0.98
w_rgb, w_a = place(wolf, WS, NOSE_X - NOSE[0] * WS, NOSE_Y - NOSE[1] * WS)
W_PAWS = NOSE_Y + (wolf.height - NOSE[1]) * WS
print("wolf paws at", W_PAWS)
wl = w_rgb.mean(2, keepdims=True)
w_alb = (wl + (w_rgb - wl) * 0.55) * np.array([0.84, 0.9, 0.95])  # grey daylight -> cool, dim forest light
w_base = w_alb * 0.27                                              # ambient under the trees
w_base = w_base * 0.88 + FOG * 0.12 * np.clip((NOSE_Y - YY) / 900, 0, 1)[..., None]   # its back is farther away
light_w = lantern_light(*FLAME, 1.0, 520)
# the girl stands between the lantern and the wolf's chest: her shadow falls on it (girl alpha scaled away from the flame)
_g = Image.open("work/girl_lifted.png").convert("RGBA"); _g = _g.crop(_g.getbbox())
_gs = G_H / _g.height
_, _ga = place(_g, _gs, G_CX - _g.width * _gs / 2, G_FEET - G_H)
K = 1.55
sx_ = np.clip(FLAME[0] + (XX - FLAME[0]) / K, 0, W - 1).astype(int); sy_ = np.clip(FLAME[1] + (YY - FLAME[1]) / K, 0, H - 1).astype(int)
g_shadow = ndi.gaussian_filter(_ga[sy_, sx_], 14) * (YY < FLAME[1])
light_w = (light_w * (1 - 0.85 * g_shadow))[..., None]
w_rgb = w_base + w_alb * (WARM / 255) * light_w * 0.42              # warm light on face, chest and front legs
# fog behind: thin broken cool rim on its back and ears
edge = np.clip(w_a - ndi.gaussian_filter(w_a, 4), 0, 1)
upf = np.clip(-ndi.sobel(ndi.gaussian_filter(w_a, 3), axis=0) * 0.6, 0, 1)
brk = noise(1, 1, 4) ** 2 * 1.6
rim = np.clip(edge * 3 * upf * brk, 0, 0.8)[..., None]
w_rgb = w_rgb * (1 - rim) + FOG * 1.9 * rim
legs = np.clip((YY - 2950) / 150, 0, 1)[..., None]                  # legs: near the lantern, keep them crisp
w_soft = blur3(w_rgb, 0.7)
w_sharp = w_rgb + (w_rgb - blur3(w_rgb, 2.0)) * 0.6                # fur detail on the legs (unsharp mask)
far_leg = (np.clip((1050 - XX) / 120, 0, 1) * np.clip((YY - 3000) / 150, 0, 1))[..., None]   # the far leg was out of focus in its photo
w_sharp = w_sharp + (w_sharp - blur3(w_sharp, 4.0)) * 1.1 * far_leg
face = np.clip(1.4 - np.sqrt(((XX - 1580) / 420) ** 2 + ((YY - 2620) / 380) ** 2), 0, 1)[..., None]
w_face = w_rgb + (w_rgb - blur3(w_rgb, 1.6)) * 0.7
w_rgb = w_soft * (1 - legs) + w_sharp * legs
w_rgb = w_rgb * (1 - face) + w_face * face
# the lantern shows in its eyes: the irises warm a little and a small catch-light sits low-left (towards the flame)
for ex, ey, er in [(1412, 2515, 30), (1680, 2507, 27)]:
    iris = np.clip(1 - np.sqrt((XX - ex) ** 2 + (YY - ey) ** 2) / er, 0, 1) ** 0.6
    w_rgb = w_rgb + WARM * 0.16 * iris[..., None]
    glint = np.exp(-((XX - ex + 9) ** 2 + (YY - ey - 8) ** 2) / (2 * 3.2 ** 2)) * 0.85
    w_rgb = w_rgb * (1 - glint[..., None]) + np.array([255, 228, 175]) * glint[..., None]
# rain on its fur: the top of its head, ears and back carry small beads of water that catch the bright fog,
# and the wet guard hairs there shine a little
wr = np.random.default_rng(77)
from_top = ndi.distance_transform_edt(w_a > 0.5)
head = np.exp(-(((XX - 1550) / 330) ** 2 + ((YY - 2300) / 200) ** 2))
wet = np.clip(np.clip((240 - from_top) / 80, 0, 1) * np.clip((2650 - YY) / 150, 0, 1) + head * 0.6, 0, 1) * (w_a > 0.95)
lum = w_alb.mean(2)
sheen = np.clip((lum - np.percentile(lum[wet > 0.5], 70)) / 50, 0, 1) * wet * 0.15
w_rgb = w_rgb * (1 - sheen[..., None]) + FOG * 1.5 * sheen[..., None]
beads = (wr.random((H, W)) < 0.0007 * (from_top < 140) * (YY < 2700) * (w_a > 0.95)).astype(np.float32) * wr.uniform(0.4, 1.0, (H, W))
core = np.clip(ndi.gaussian_filter(beads, 0.9) * 8, 0, 0.55)
under = np.clip(ndi.gaussian_filter(np.roll(beads, 3, axis=0), 1.6) * 5, 0, 0.35)   # each bead's dark underside
w_rgb = w_rgb * (1 - under[..., None])
w_rgb = w_rgb * (1 - core[..., None]) + FOG * 1.7 * core[..., None]
w_a = ndi.gaussian_filter(w_a, 0.7)

# ---- the girl: now back-lit - darker back, warm rim from the lantern on her left, wet coat
girl = Image.open("work/girl_lifted.png").convert("RGBA"); girl = girl.crop(girl.getbbox())
gs = G_H / girl.height
g_rgb, g_a = place(girl, gs, G_CX - girl.width * gs / 2, G_FEET - G_H)
gl = g_rgb.mean(2, keepdims=True)
g_alb = gl + (g_rgb - gl) * 0.82
g_rgb = g_alb * np.array([0.37, 0.39, 0.42])                       # her back is away from both lights
# wet coat: keep the photo's own sheen (its brightest folds) a little brighter
sheen = np.clip((g_alb.mean(2) - 200) / 40, 0, 1)[..., None] * 0.5
g_rgb = g_rgb + g_alb * sheen * 0.35
# warm rim: the lantern is just past her left side
gedge = np.clip(g_a - ndi.gaussian_filter(g_a, 6), 0, 1)
side = np.clip((G_CX - XX) / 260, 0, 1) * np.clip(1 - (XX - G_CX + 260) / 900, 0, 1)
g_rim = np.clip(gedge * 3.2 * lantern_light(*FLAME, 1.0, 500) * (0.4 + side), 0, 0.9)[..., None]
g_rgb = g_rgb * (1 - g_rim) + (g_alb * 0.5 + WARM * 0.5) * g_rim
g_rgb += g_alb * (WARM / 255) * (lantern_light(*FLAME, 0.35, 380) * np.clip((G_CX + 80 - XX) / 300, 0, 1))[..., None] * 0.6
# raindrops on the coat: tiny bright beads
drops = (rng.random((H, W)) > 0.99988) * (g_a > 0.95) * (YY < G_FEET - 520)
drops = np.clip(ndi.gaussian_filter(drops * 1.0, (1.8, 0.7)) * 9, 0, 0.3)   # small running beads, not dots
g_rgb = g_rgb * (1 - drops[..., None]) + np.array([230, 225, 200]) * drops[..., None]
g_rgb = blur3(g_rgb, 0.6); g_a = ndi.gaussian_filter(g_a, 0.6)

# ---- the lantern on the path
lan = Image.open("work/lantern_lifted.png").convert("RGBA"); lan = lan.crop(lan.getbbox())
_la = np.asarray(lan).copy(); _la[int(_la.shape[0] * 0.965):, :, 3] = 0; lan = Image.fromarray(_la, "RGBA").crop(Image.fromarray(_la, "RGBA").getbbox())   # grass bits under its base
L_H = 0.34 * G_H / 0.95                                            # ~34 cm tall next to a 95 cm girl
ls = L_H / lan.height
l_rgb, l_a = place(lan, ls, LX - lan.width * ls / 2, LY - L_H)
l_rgb = l_rgb * 0.95
# its base came with purple flowers from the source photo: turn that strip into dark, warm-lit metal
base = np.clip((YY - (LY - L_H * 0.14)) / (L_H * 0.06), 0, 1)[..., None]
l_rgb = l_rgb * (1 - base) + l_rgb.mean(2, keepdims=True) * np.array([0.85, 0.68, 0.5]) * 0.75 * base
l_a = ndi.gaussian_filter(l_a, 0.6)

# ---- ground: wet path lit by the lantern, puddle reflecting lantern + coat + wolf, contact shadows
pool = lantern_light(LX, LY - 20, 1.0, 420) * (YY > 3420)
ground_light = np.clip(pool * 0.7, 0, 0.7)
save("01_lantern_light_on_ground", np.broadcast_to(WARM * 0.85, (H, W, 3)).copy(), ground_light * (bg.mean(2) / 120)[...])
puddle = np.clip(1.15 - np.sqrt(((XX - 1450) / 900) ** 2 + ((YY - 3790) / 120) ** 2), 0, 1) ** 0.7
puddle *= noise(2, 6, 9) > 0.35
puddle = ndi.gaussian_filter(puddle * 1.0, 6)

def mirror(rgb, a, gy):
    rows = np.arange(H); s = np.clip(2 * gy - rows, 0, H - 1).astype(int)
    return rgb[s], a[s] * (rows[:, None] > gy)
rw_rgb, rw_a = mirror(w_rgb, w_a, W_PAWS)
rg_rgb, rg_a = mirror(g_rgb, g_a, G_FEET)
rl_rgb, rl_a = mirror(l_rgb, l_a, LY)
ref = over(over(rw_rgb * rw_a[..., None], rl_rgb, rl_a), rg_rgb, rg_a)
ref_a = 1 - (1 - rw_a) * (1 - rl_a) * (1 - rg_a)
ref = blur3(ref, (5, 1.5)); ref_a = ndi.gaussian_filter(ref_a, (5, 1.5))
ripple = (noise(1, 8, 12) - 0.5) * 0.5
refl_a = np.clip(ref_a * puddle * (0.55 + ripple), 0, 0.7)
sky_ref = np.broadcast_to(FOG * 0.9, (H, W, 3))                     # the puddle also mirrors the misty sky
p_rgb = ref * (ref_a[..., None] > 0.02) + sky_ref * (ref_a[..., None] <= 0.02)
p_a = np.maximum(refl_a, puddle * 0.25)
# contact shadows
def contact(a, gy, sx, k):
    m = ndi.gaussian_filter((a > 0.5) * (np.abs(YY - gy + 25) < 30) * 1.0, (8, sx))
    return np.clip(m * k, 0, 0.75)
sh = np.maximum.reduce([contact(g_a, G_FEET, 20, 2.0), contact(l_a, LY, 12, 1.8)])
# each paw gets its own contact shadow at the bottom of its own leg (the farther legs stand higher in the frame)
lab, nl = ndi.label(ndi.binary_opening(w_a > 0.5, iterations=3) & (YY > 3150))
paw = np.zeros((H, W), np.float32)
for i in range(1, nl + 1):
    ys_, xs_ = np.where(lab == i)
    if len(ys_) < 2000:
        continue
    by = ys_.max(); bx = xs_[ys_ > by - 40].mean(); bw = max(60, np.ptp(xs_[ys_ > by - 80]))
    paw += np.exp(-(((XX - bx) / (bw * 0.9)) ** 2 + ((YY - by + 6) / 22) ** 2))
    print("paw at", int(bx), int(by))
sh = np.maximum(sh, np.clip(paw * 0.7, 0, 0.7))
# her long shadow on the wet path, thrown away from the lantern (to the lower right), softer the farther it goes
rows = np.arange(H); dy = np.clip(rows - G_FEET, 0, None)
src_y = np.clip(G_FEET - dy / 0.32, 0, H - 1).astype(int)
cast = np.zeros((H, W), np.float32)
for yv in range(G_FEET, H):
    d_ = yv - G_FEET
    row = g_a[src_y[yv]]
    cast[yv] = np.roll(row, int(d_ * 2.6))
cast = ndi.gaussian_filter(cast, (3, 6)) * np.clip(1 - (YY - G_FEET) / 160, 0, 1) * (YY > G_FEET - 4)
sh = np.maximum(sh, np.clip(cast * 0.55, 0, 0.55))
save("02_shadows", np.full((H, W, 3), 8, np.float32), sh)
# ---- her small boot prints in the wet path, leading from us to where she stands: shallow, darker, a little water in them
fp = np.zeros((H, W), np.float32); fp_rim = np.zeros((H, W), np.float32); fp_wet = np.zeros((H, W), np.float32)
for cx, cy, ang in [(1590, 3942, 0.15), (1458, 3994, 0.10), (1600, 4048, 0.14)]:
    u = (XX - cx) * np.cos(ang) - (YY - cy) * np.sin(ang); v = (XX - cx) * np.sin(ang) + (YY - cy) * np.cos(ang)
    halfw = np.interp(v, [-24, -19, -8, 1, 6, 15, 19], [0, 23, 28, 16, 20, 19, 0])
    sole = ndi.gaussian_filter((np.abs(u) < halfw) * 1.0, 1.4)
    tread = 0.75 + 0.25 * (np.sin(v * 1.3) > 0)
    fp = np.maximum(fp, sole * tread)
    fp_rim = np.maximum(fp_rim, np.clip(sole - np.roll(sole, 3, axis=0), 0, 1))   # the far inner wall, lit
    fp_wet = np.maximum(fp_wet, sole * (noise(1, 1, int(cx)) > 0.5))
fp_wet = ndi.gaussian_filter(fp_wet, 2)
fp_col = np.zeros((H, W, 3), np.float32) + np.array([14, 11, 8])
fp_light = np.clip(lantern_light(LX, LY, 1.4, 500), 0, 1)
fp_col = fp_col * (1 - fp_rim[..., None]) + (bg * 1.3 + WARM * 0.3 * fp_light[..., None]) * fp_rim[..., None]
fp_col = fp_col * (1 - fp_wet[..., None] * 0.6) + FOG * 0.85 * fp_wet[..., None] * 0.6   # water in the print mirrors the mist
fp_tex = np.clip(0.55 + (bg.mean(2) - ndi.gaussian_filter(bg.mean(2), 4)) / 30, 0.3, 1)   # the path's own grain shows through
save("02b_footprints", fp_col, np.clip((fp * 0.65 + fp_rim * 0.6 + fp_wet * 0.25) * (0.45 + 0.55 * fp_tex), 0, 0.75))
save("03_puddle_reflections", p_rgb, p_a)
# ---- the pup: peeks out from behind its mother's front leg, low in her shadow, looking at the girl
pup = Image.open("work/pup_a_lifted.png").convert("RGBA"); pup = pup.crop(pup.getbbox())
_pa = np.asarray(pup).copy()
_pa[..., 3] = (_pa[..., 3] * np.clip((0.9 - np.arange(_pa.shape[0]) / _pa.shape[0]) / 0.12, 0, 1)[:, None]).astype(np.uint8)  # lost in the grass
pup = Image.fromarray(_pa, "RGBA").transpose(Image.FLIP_LEFT_RIGHT)  # now it looks right, at her
P_H, P_X0, P_GROUND = 330, 800, 3470
ps = P_H / pup.height
p_rgb, p_a = place(pup, ps, P_X0, P_GROUND - P_H)
pl = p_rgb.mean(2, keepdims=True)
p_alb = (pl + (p_rgb - pl) * 0.55) * np.array([0.84, 0.9, 0.95])
p_alb = 128 + (p_alb - 128) * 1.25
p_rgb = p_alb * 0.24                                               # under its mother's chest: deep shade
p_rgb = p_rgb * 0.95 + FOG * 0.05                            # a little farther back than her legs
p_rgb += p_alb * (WARM / 255) * (lantern_light(*FLAME, 1.0, 520) * 0.16 * np.clip((XX - 900) / 150, 0, 1))[..., None]
p_edge = np.clip(p_a - ndi.gaussian_filter(p_a, 3), 0, 1) * np.clip(-ndi.sobel(ndi.gaussian_filter(p_a, 2), axis=0), 0, 1)
p_rgb = p_rgb * (1 - p_edge[..., None] * 0.5) + FOG * 1.4 * (p_edge[..., None] * 0.5)   # thin fog rim on its ears
for ox, oy in [(2419, 2211), (1534, 1985)]:                        # its eyes catch a little of the lantern
    ex, ey = P_X0 + (pup.width - ox) * ps, P_GROUND - P_H + oy * ps
    gl_ = np.exp(-((XX - ex + 1.5) ** 2 + (YY - ey - 1) ** 2) / (2 * 1.2 ** 2)) * 0.6
    p_rgb = p_rgb * (1 - gl_[..., None]) + np.array([255, 220, 165]) * gl_[..., None]
p_rgb = blur3(p_rgb, 0.8); p_a = ndi.gaussian_filter(p_a, 0.8)    # same softness as the far leg's photo
grass = np.clip((YY - 3365) / 30, 0, 1) * np.clip((bg[..., 1] - bg[..., 2]) / 25 + 0.3 * noise(0.5, 0.5, 88), 0, 1)
p_a = p_a * (1 - grass) * np.clip((3392 - YY) / 60, 0, 1)                 # paws hidden down in the grass
p_rgb = p_rgb * (1 - 0.35 * np.clip((YY - 3240) / 120, 0, 1))[..., None]   # its white legs are in the deepest shade
save("03b_pup", p_rgb, p_a)
save("04_wolf", w_rgb, w_a)
# low mist around its paws (it is a few metres behind her)
gm = np.exp(-((YY - W_PAWS + 40) / 70) ** 2) * (0.3 + 0.6 * noise(2, 10, 5)) * np.clip(1 - np.abs(XX - 1150) / 1500, 0, 1)
gm *= 1 - 0.75 * w_a * (YY < W_PAWS - 30)                         # mist only at paw level, not up the legs
save("05_ground_mist", np.broadcast_to(FOG * 1.2, (H, W, 3)).copy(), np.clip(gm, 0, 0.3))
save("06_lantern", l_rgb, l_a)
# ---- the wolf's warm breath: a soft cloud from its nose curling around her hood (behind her), lit by the lantern
br = np.zeros((H, W), np.float32)
nz = noise(2, 2, 31)
for (cx, cy, rx, ry, k) in [(NOSE_X + 120, NOSE_Y + 30, 150, 90, 0.5), (NOSE_X + 260, NOSE_Y - 40, 210, 120, 0.35),
                             (NOSE_X - 260, NOSE_Y + 60, 170, 100, 0.4), (NOSE_X - 380, NOSE_Y - 30, 200, 120, 0.15),
                             (NOSE_X + 420, NOSE_Y - 140, 260, 150, 0.2)]:
    br += np.exp(-(((XX - cx) / rx) ** 2 + ((YY - cy) / ry) ** 2)) * k
nz2 = noise(0.8, 5, 47)                                            # stretched sideways: drifting wisps
wisp = np.clip(0.55 + 1.3 * (nz2 - 0.5) + 0.5 * (nz - 0.5), 0.15, 1.2)
br = np.clip(ndi.gaussian_filter(br * wisp, 4), 0, 0.45)
near_nose = np.exp(-(((XX - NOSE_X) / 140) ** 2 + ((YY - NOSE_Y) / 110) ** 2))
br *= 1 - 0.92 * w_a                              # over its jaw it read as a see-through ghost jaw
br_col = np.broadcast_to(np.array([150, 152, 150], np.float32), (H, W, 3)).copy()
br_col += (WARM * 0.3 * np.clip(lantern_light(*FLAME, 0.7, 600), 0, 1)[..., None])
save("06b_breath", br_col, br)
save("07_girl", g_rgb, g_a)

# ---- light beams through the trees from the bright fog, onto the two of them
ang = np.arctan2(XX - 1900, YY + 600)
beams = np.zeros((H, W), np.float32)
for a0, wdt, k in [(-0.18, 0.025, 1.0), (-0.12, 0.018, 0.7), (-0.05, 0.03, 0.9), (0.03, 0.02, 0.6), (-0.25, 0.015, 0.5)]:
    beams += np.exp(-((ang - a0) / wdt) ** 2) * k
beams *= np.clip((YY - 300) / 900, 0, 1) * np.clip((3900 - YY) / 900, 0, 1)
beams *= 0.6 + 0.8 * noise(6, 1, 17)
beams = np.clip(beams * 0.26, 0, 0.32)
beams *= 1 - 0.6 * w_a * np.clip((YY - 2950) / 250, 0, 1)                              # the beams don't wash out its legs
save("09_light_beams", np.broadcast_to(FOG * 2.3, (H, W, 3)).copy(), beams)

# ---- rain: back-lit streaks (bright against the fog, faint against dark trees) + splashes on the wet path
def rain_layer(count, length, alpha, blur, seed, slant=0.07):
    r = np.random.default_rng(seed); acc = np.zeros((H, W), np.float32)
    for x, y, l in zip(r.uniform(0, W, count), r.uniform(-length, H, count), length * r.uniform(0.6, 1.3, count)):
        t_ = np.linspace(0, 1, int(l)); px = (x + t_ * l * slant).astype(int); py = (y + t_ * l).astype(int)
        ok = (px >= 0) & (px < W) & (py >= 0) & (py < H)
        acc[py[ok], px[ok]] += r.uniform(0.5, 1.0) * np.sin(np.pi * t_[ok])
    return np.clip(ndi.gaussian_filter(acc, blur) * alpha, 0, 1)
rain = np.maximum.reduce([rain_layer(9000, 40, 0.4, 0.6, 1), rain_layer(2600, 110, 0.45, 1.0, 2), rain_layer(240, 360, 0.35, 2.4, 3)])
back = np.clip(bg.mean(2) / 90, 0.35, 1.3) + lantern_light(*FLAME, 1.2, 500)
save("10_rain", np.broadcast_to(np.array([175, 182, 178], np.float32), (H, W, 3)).copy(), np.clip(rain * back * 0.5, 0, 0.6))
sp = np.zeros((H, W), np.float32)
for _ in range(900):
    y = rng.uniform(3420, H); x = rng.uniform(0, W); s = 1.5 + 6 * (y - 3420) / (H - 3420)
    for k in range(rng.integers(3, 6)):
        a0 = rng.uniform(-2.6, -0.5); L = s * rng.uniform(1, 2.2)
        for t in np.linspace(0, 1, 6):
            px = int(x + np.cos(a0) * L * t); py = int(y + np.sin(a0) * L * t * 0.8)
            if 0 <= px < W and 0 <= py < H:
                sp[py, px] = max(sp[py, px], 0.8 * (1 - t * 0.6))
sp = ndi.gaussian_filter(sp, 0.8) * 1.6 * ~((g_a > 0.5) | (w_a > 0.5) | (l_a > 0.5))
sp_col = np.broadcast_to(np.array([160, 165, 160], np.float32), (H, W, 3)) + WARM * np.clip(lantern_light(LX, LY, 1.0, 400), 0, 1)[..., None] * 0.6
save("11_splashes", sp_col, np.clip(sp * 0.35, 0, 0.35))
# rain rings on the puddle: thin flat ellipses (seen at a low angle), warm where the lantern lights the water
rr = np.zeros((H, W), np.float32)
for _ in range(24):
    cx, cy = rng.uniform(800, 2100), rng.uniform(3700, 3900)
    if puddle[int(cy), int(cx)] < 0.6 or rng.random() < 0.3:
        continue
    R = rng.uniform(6, 24); y0, y1, x0, x1 = int(cy - R), int(cy + R) + 1, int(cx - 3 * R), int(cx + 3 * R) + 1
    dy, dx = YY[y0:y1, x0:x1] - cy, XX[y0:y1, x0:x1] - cx
    ring = np.exp(-((np.sqrt(dx ** 2 + (dy / 0.28) ** 2) - R * 2.2) / 1.8) ** 2)
    ring *= np.clip(0.3 + np.cos(np.arctan2(dy / 0.28, dx) * rng.integers(1, 3) + rng.uniform(0, 6)), 0, 1)   # broken, not perfect circles
    rr[y0:y1, x0:x1] += ring * rng.uniform(0.4, 1.0)
rr = np.clip(ndi.gaussian_filter(rr, 1.0) * puddle * ~(g_a > 0.5) * ~(l_a > 0.5), 0, 1)
rr_col = np.broadcast_to(FOG * 1.1, (H, W, 3)) + WARM * np.clip(lantern_light(LX, LY, 1.2, 380), 0, 1)[..., None] * 0.8
save("11b_ripples", rr_col, np.clip(rr * 0.22, 0, 0.22))

# ---- the lantern's glow in the air (bloom) - it is the warm heart of the picture
fl = np.exp(-(((XX - FLAME[0]) / 40) ** 2 + ((YY - FLAME[1]) / 55) ** 2))
bloom = np.clip(ndi.gaussian_filter(fl, 30) * 6 + lantern_light(*FLAME, 0.22, 260), 0, 0.75)
save("12_lantern_glow", np.broadcast_to(WARM, (H, W, 3)).copy(), bloom)
# rain hitting the hot lantern cap: a thin curl of steam rising from it, lit warm from below, drifting right
top = LY - L_H
st = np.zeros((H, W), np.float32)
for i, (k_, ph) in enumerate([(1.0, 0.0), (0.6, 2.1), (0.45, 4.0)]):
    t = np.clip((top - YY) / 330, 0, 1)                            # 0 at the cap, 1 at the top of the plume
    cxs = LX + 6 + 55 * t ** 1.4 + 14 * np.sin(t * 7 + ph) * t       # rises, leans right, wavers
    wdt = 7 + 38 * t
    st += k_ * np.exp(-((XX - cxs) / wdt) ** 2) * (YY < top + 5) * np.clip(t * 12, 0, 1) * (1 - t) ** 1.3
st = ndi.gaussian_filter(st * np.clip(0.5 + 1.2 * (noise(1.2, 3, 61) - 0.5), 0.1, 1), 3)
st_col = np.broadcast_to(np.array([185, 182, 172], np.float32), (H, W, 3)) + WARM * np.clip(lantern_light(*FLAME, 1.6, 300), 0, 1)[..., None] * 0.7
save("12b_lantern_steam", st_col, np.clip(st * 0.32, 0, 0.3))
# ---- moths at the lantern: one resting on the glowing glass (a dark shape), one flying across it, one lit above it
m_rgb = np.zeros((H, W, 3), np.float32); m_a = np.zeros((H, W), np.float32)
for mx, my, sz, ang, trail, col, k in [(1268, 3528, 12, 0.5, 9, (40, 26, 14), 0.75),
                                         (1200, 3625, 13, 1.57, 1, (30, 20, 12), 0.85),
                                         (1322, 3420, 7, -2.0, 4, (255, 195, 125), 0.75)]:
    y0, x0 = int(my) - 40, int(mx) - 40
    yy, xx = YY[y0:y0 + 80, x0:x0 + 80] - my, XX[y0:y0 + 80, x0:x0 + 80] - mx
    shape = np.zeros_like(yy)
    for side in (-1, 1):                                           # two wings spread from a thin body
        wa = ang + side * 0.75
        cx_, cy_ = np.cos(wa) * sz * 0.55, np.sin(wa) * sz * 0.55
        uu = (xx - cx_) * np.cos(wa) + (yy - cy_) * np.sin(wa); vv = -(xx - cx_) * np.sin(wa) + (yy - cy_) * np.cos(wa)
        shape = np.maximum(shape, ((uu / (sz * 0.6)) ** 2 + (vv / (sz * 0.38)) ** 2 < 1) * 1.0)
        if trail < 3:
            continue
        wb = ang + side * 1.35                                     # the same wing caught on its down-beat
        cx_, cy_ = np.cos(wb) * sz * 0.5, np.sin(wb) * sz * 0.5
        uu = (xx - cx_) * np.cos(wb) + (yy - cy_) * np.sin(wb); vv = -(xx - cx_) * np.sin(wb) + (yy - cy_) * np.cos(wb)
        shape = np.maximum(shape, ((uu / (sz * 0.55)) ** 2 + (vv / (sz * 0.3)) ** 2 < 1) * 0.5)
    if trail == 1:                                                 # resting: wings folded back into a delta
        hh = sz * 1.2
        delta = (np.abs(xx) < (yy + hh * 0.45) * 0.85) & (yy > -hh * 0.45) & (yy < hh * 0.55 - 0.15 * np.abs(xx))
        shape = delta * 1.0
    blurred = np.zeros_like(shape)
    for t in np.linspace(0, 1, trail):                             # motion: smeared along its flight
        blurred += ndi.shift(shape, (np.sin(ang + 1.57) * t * trail, np.cos(ang + 1.57) * t * trail), order=1)
    blurred = ndi.gaussian_filter(blurred / trail, 0.9)
    blurred = np.maximum(blurred, ndi.gaussian_filter(shape, 0.7) * 0.55)   # it was there sharpest at the end of the exposure
    m_rgb[y0:y0 + 80, x0:x0 + 80] = np.array(col, np.float32)
    m_a[y0:y0 + 80, x0:x0 + 80] = np.maximum(m_a[y0:y0 + 80, x0:x0 + 80], np.clip(blurred * k, 0, 1))
save("12c_moths", m_rgb, m_a)

# ---- dark out-of-focus ferns in the front corners (we watch from the bushes)
fern = np.asarray(Image.open("inputs/fern1.jpg").convert("RGB")).astype(np.float32)
fa = np.clip((fern[..., 1] - 18) / 45, 0, 1)                       # ferns glow green on a black background
fern_im = Image.fromarray(np.dstack([fern, fa * 255]).astype(np.uint8), "RGBA")
f_rgb = np.zeros((H, W, 3), np.float32); f_a = np.zeros((H, W), np.float32)
for (fx, fy, fsc, flip, rot) in [(-950, 3250, 0.6, False, 25), (2450, 3300, 0.6, True, -20)]:
    im = fern_im.transpose(Image.FLIP_LEFT_RIGHT) if flip else fern_im
    im = im.rotate(rot, expand=True, resample=Image.BICUBIC)
    r_, a_ = place(im, fsc, fx, fy)
    f_rgb = over(f_rgb, r_, a_); f_a = np.maximum(f_a, a_)
f_rgb = blur3(f_rgb, 9) * 0.32; f_a = ndi.gaussian_filter(f_a, 9) * 0.97
f_rgb += WARM * 0.25 * np.clip(lantern_light(*FLAME, 0.6, 700), 0, 1)[..., None] * (f_rgb.mean(2, keepdims=True) / 40)
save("13_foreground_ferns", f_rgb, f_a)

vig = np.clip(((XX - 1500) / (W * 0.6)) ** 2 + ((YY - 3000) / (H * 0.6)) ** 2, 0, 1)
save("14_vignette", np.zeros((H, W, 3), np.float32), vig ** 1.5 * 0.5)

comp = bg.copy()
for name in sorted(os.listdir("work/layers2")):
    lay = np.asarray(Image.open(f"work/layers2/{name}")).astype(np.float32)
    comp = over(comp, lay[..., :3], lay[..., 3] / 255)
CROP = (250, 750, 2850, 4000)                                      # 2600 x 3250 = 4:5, tighter on the meeting
out = Image.fromarray(np.clip(comp, 0, 255).astype(np.uint8))
out.save("work/preview2_full.jpg", quality=95)
out.crop(CROP).save("work/preview2.jpg", quality=95)
out.crop(CROP).resize((866, 1083), Image.LANCZOS).save("work/preview2_small.jpg")
print("ok")
