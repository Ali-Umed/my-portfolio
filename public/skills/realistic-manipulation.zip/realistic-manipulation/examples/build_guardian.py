"""THE GUARDIAN: a giant stag standing at the end of a fog-bound forest road; a small walker on the road.

Realism plan (from the user's giant-bear reference): both photos were shot in real fog / overcast light, so no
relighting; the stag is far away and gets the scene's own fog (haze grows toward the ground so his legs dissolve);
every tree stays in front of him; one grade over everything.
Inputs: inputs/road_full.jpg (Unsplash 1601389389984, 2624x3936), inputs/stag_full.jpg (Unsplash 1614640514617), work/stag_lifted_full.png
(Apple Vision lift), ../lighthouse/work/person_lifted.png. Writes work/layers/ and work/preview.jpg.
"""
import os
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter

OUT = "work/layers"
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(3)
bg = np.asarray(Image.open("inputs/road_full.jpg").convert("RGB")).astype(np.float64)
H, W = bg.shape[:2]
yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
lum = bg @ [0.299, 0.587, 0.114]
K = W / 2000.0                                                              # all sizes were designed at 2000 px wide


def blur(a, r):
    return gaussian_filter(a, r) if a.ndim == 2 else np.stack([gaussian_filter(a[..., c], r) for c in range(3)], -1)


def save(name, rgb, a):
    Image.fromarray(np.dstack([np.clip(rgb, 0, 255), np.clip(a, 0, 1) * 255]).astype(np.uint8), "RGBA").save(f"{OUT}/{name}.png")


def over(dst, rgb, a):
    return dst * (1 - a[..., None]) + rgb * a[..., None]


# ---------------- fog level per row (the brightest open fog) and the tree mask ---------------------------------
fog_l = np.array([np.percentile(lum[y], 97) for y in range(H)])
fog_l = gaussian_filter(fog_l, 25 * K)
fog_rgb = np.stack([gaussian_filter(np.array([np.percentile(bg[y, :, c], 97) for y in range(H)]), 25 * K) for c in range(3)], -1)
fog_img = np.broadcast_to(fog_rgb[:, None, :], (H, W, 3)).copy()
trees = np.clip((fog_l[:, None] - lum - 6) / 34, 0, 1)                   # darker than the open fog = something in front
trees = gaussian_filter(trees, 1.2 * K)

# ---------------- the stag at the end of the road ------------------------------------------------------------
S = 0.86 * K * 2400 / 3908                                                  # full-size stag photo
FEET_Y, CX = round(2190 * K), round(900 * K)                                                      # hooves at the vanishing point
st = Image.open("work/stag_lifted_full.png").convert("RGBA")
a0 = np.asarray(st)[..., 3]
ys, xs = np.nonzero(a0 > 128)
st = st.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
st = st.resize((round(st.width * S), round(st.height * S)), Image.LANCZOS)
cv = Image.new("RGBA", (W, H), (0, 0, 0, 0)); cv.alpha_composite(st, (round(CX - st.width / 2), FEET_Y - st.height))
c = np.asarray(cv).astype(np.float64)
srgb, sa = c[..., :3], c[..., 3] / 255
top = FEET_Y - st.height
# distance haze: heavy everywhere, heavier toward the ground where fog is thickest (legs dissolve)
h = (yy - top) / st.height
haze = np.clip(0.58 + 0.35 * np.clip(h - 0.30, 0, 1) / 0.70, 0, 0.93)    # at least as hazy as the farthest trees
stag = srgb * (1 - haze[..., None]) + fog_img * haze[..., None]
stag = blur(stag, 1.6 * K)                                                     # far away: softer than the trees
# light wrap: the bright fog behind him bleeds over his outline
_a = np.asarray(cv)[..., 3] / 255
wrap = np.clip(_a - gaussian_filter(_a, 9 * K), 0, 1) * 1.6 + np.clip(gaussian_filter(1 - _a, 5 * K) * _a, 0, 1) * 0.5
stag = stag * (1 - np.clip(wrap, 0, 0.6)[..., None]) + blur(fog_img, 20 * K) * np.clip(wrap, 0, 0.6)[..., None]
sa = gaussian_filter(sa, 1.8 * K) * np.clip((FEET_Y + 10 * K - yy) / (120 * K), 0, 1)    # hooves lost in ground fog
sa *= 1 - trees                                                             # trees stand in front of him
# a brighter patch of fog behind him separates the silhouette (like the bear's glow)
glow = np.exp(-(((xx - CX) / (700 * K)) ** 2 + ((yy - (top + st.height * 0.35)) / (900 * K)) ** 2)) * 0.22 * (1 - trees)

# where his hooves meet the wet road: a faint darker smear (shadow + reflection), mostly swallowed by fog
HL = round(260 * K)
legs = np.asarray(cv)[..., 3][FEET_Y - HL:FEET_Y] / 255
hoof = np.zeros((H, W)); hoof[FEET_Y:FEET_Y + HL] = np.flipud(legs) * np.linspace(0.30, 0, HL)[:, None]
hoof = gaussian_filter(hoof, (6 * K, 3 * K)) * (1 - trees)
hoof_rgb = blur(fog_img, 10 * K) * 0.55

# ---------------- the walker on the road -----------------------------------------------------------------------
per = Image.open("../lighthouse/work/person_lifted.png").convert("RGBA")
pa0 = np.asarray(per)[..., 3]
ys, xs = np.nonzero(pa0 > 128)
per = per.crop((xs.min(), ys.min(), xs.max() + 1, ys.max() + 1))
PH = round(300 * K)
per = per.resize((round(per.width * PH / per.height), PH), Image.LANCZOS)
PF = (round(960 * K), round(2640 * K))
pcv = Image.new("RGBA", (W, H), (0, 0, 0, 0)); pcv.alpha_composite(per, (round(PF[0] - per.width / 2), PF[1] - PH))
p = np.asarray(pcv).astype(np.float64)
prgb, pa = p[..., :3], p[..., 3] / 255
# he is ~60 m into the fog: a little haze, dark but not black; soft overcast contact shadow
pl = prgb @ [0.299, 0.587, 0.114]
prgb = (24 + np.clip(pl, 0, 60) * 0.18)[..., None] * np.array([1.0, 1.02, 1.05]) + fog_img * 0.2   # an even dark silhouette (no white shoes / cutout gaps)
pa = gaussian_filter(pa, 0.8 * K)
pshadow = np.exp(-(((xx - PF[0]) / (95 * K)) ** 2 + ((yy - PF[1] - 4 * K) / (12 * K)) ** 2)) * 0.55
# faint reflection on the damp road
refl = np.zeros((H, W)); rrgb = np.zeros((H, W, 3))
fl = np.flipud(p[PF[1] - PH:PF[1]])
n = min(PH, H - PF[1])
refl[PF[1]:PF[1] + n] = fl[:n, :, 3] / 255 * np.linspace(0.22, 0, n)[:, None]
rrgb[PF[1]:PF[1] + n] = prgb[PF[1] - PH:PF[1]][::-1][:n] * 0.9
refl = gaussian_filter(refl, 3 * K)

# ---------------- birds, low fog drifting over the road, grade -------------------------------------------------
birds = np.zeros((H, W))
# each bird different: size, wing lift (flap phase) and a little tilt; soft because they are in the fog
for bx, by, s_, lift, tilt in ((1180, 250, 8, 0.55, 0.10), (1236, 283, 6.5, 0.15, -0.08), (1292, 238, 7, 0.75, 0.05),
                              (1143, 304, 5.5, 0.35, -0.12), (1331, 292, 5, -0.10, 0.15), (1262, 331, 4.5, 0.60, 0.0)):
    bx, by, s_ = bx * K, by * K, s_ * K
    for t in np.linspace(-1, 1, 70):
        x = bx + t * s_ * 1.7
        y = by - (abs(t) ** 0.7) * s_ * lift + t * s_ * tilt
        birds += np.exp(-((xx - x) ** 2 + (yy - y) ** 2) / ((1.2 + 0.4 * (1 - abs(t))) * K * K)) * ((abs(xx - x) < 5 * K) & (abs(yy - y) < 5 * K))
birds = gaussian_filter(np.clip(birds * 1.3, 0, 1), 1.1 * K) * 0.5
noise = blur(rng.random((H, W)), 60 * K); noise = (noise - noise.mean()) / noise.std()
drift = np.clip(np.exp(-((yy - 2250 * K) / (260.0 * K)) ** 2) * (0.35 + 0.15 * noise), 0, 0.5)
vig = np.clip(np.hypot((xx - W * 0.47) / (W * 0.62), (yy - H * 0.45) / (H * 0.62)) - 0.5, 0, 1) ** 1.2 * 0.8

save("01_fog_glow", fog_img * 1.08, glow)
save("02_stag", stag, sa)
save("02b_hoof_reflection", hoof_rgb, hoof)
save("03_ground_fog", fog_img * 1.02, drift)
save("04_walker_shadow", np.zeros((H, W, 3)) + [10, 11, 13], pshadow)
save("05_walker_reflection", rrgb, refl)
save("06_walker", prgb, pa)
save("07_birds", np.zeros((H, W, 3)) + [70, 76, 82], birds)
save("08_vignette", np.zeros((H, W, 3)) + [6, 8, 12], vig)

out = over(bg, fog_img * 1.08, glow)
out = over(out, stag, sa)
out = over(out, hoof_rgb, hoof)
out = over(out, fog_img * 1.02, drift)
out = over(out, np.zeros((H, W, 3)) + [10, 11, 13], pshadow)
out = over(out, rrgb, refl)
out = over(out, prgb, pa)
out = over(out, np.zeros((H, W, 3)) + [70, 76, 82], birds)
out = over(out, np.zeros((H, W, 3)) + [6, 8, 12], vig)
# grade: cool teal-grey fog, deeper darks (the user's references), fine grain
l = out @ [0.299, 0.587, 0.114]
out = out * np.array([0.93, 0.99, 1.04]) - 10 * (1 - np.clip(l / 120, 0, 1))[..., None]
out = out + gaussian_filter(rng.normal(0, 2.2, (H, W)), 0.5)[..., None]
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).save("work/preview.jpg", quality=97, subsampling=0)
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).resize((600, 900), Image.LANCZOS).save("work/preview_small.jpg", quality=85)
print("stag top", top, "size", st.size)
