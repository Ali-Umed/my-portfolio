"""THE LIGHT CATCHER v2 (fog technique, like the user's giant-bear reference): the cat is far out at sea, rising
out of a fog bank behind the lighthouse, hazy and low-contrast like everything that far away; the photo's real
beams sweep IN FRONT of her face; her lower body dissolves into the fog, so she never needs to touch the ground.

Inputs: inputs/lighthouse.jpg, work/cat_lifted.png, work/layers/08_keeper.png + 09_lantern_glow.png + 07_path_lantern_light.png
(from build_keeper.py). Writes work/layers2/ and work/preview2.jpg.
"""
import os
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter

OUT = "work/layers2"
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(5)
bg = np.asarray(Image.open("inputs/lighthouse.jpg").convert("RGB")).astype(np.float64)
H, W = bg.shape[:2]
yy, xx = np.mgrid[0:H, 0:W].astype(np.float64)
HORIZON = 690
LAMP = (1420.0, 405.0)


def blur(a, r):
    return gaussian_filter(a, r) if a.ndim == 2 else np.stack([gaussian_filter(a[..., c], r) for c in range(3)], -1)


def save(name, rgb, a):
    Image.fromarray(np.dstack([np.clip(rgb, 0, 255), np.clip(a, 0, 1) * 255]).astype(np.uint8), "RGBA").save(f"{OUT}/{name}.png")


def over(dst, rgb, a):
    return dst * (1 - a[..., None]) + rgb * a[..., None]


def screen(dst, rgb, a):
    return 255 - (255 - dst) * (1 - rgb * a[..., None] / 255)


# ---------------- split the sky into "empty sky" and "beams + glow" so the beams can pass in front of her -------
lum = bg @ [0.299, 0.587, 0.114]
# real sky mask: smooth (low local texture) and blue, connected to the top edge; cliff and tower are textured
from scipy.ndimage import uniform_filter, binary_opening, binary_closing, label, binary_fill_holes
cand = (yy < HORIZON - 2) & (bg[..., 2] - bg[..., 0] > 14)            # sky is clearly blue; rock and tower are not
cand = binary_opening(binary_closing(cand, iterations=4), iterations=2)   # close the star holes
lab, _ = label(cand); keep = np.unique(lab[:40][lab[:40] > 0])
skyb = binary_fill_holes(np.isin(lab, keep)) & (yy < HORIZON - 2)
sky = gaussian_filter(skyb.astype(np.float64), 1.2)
skyb[:6] = True                                                       # opening eats the top border
sky_line = np.cumprod(skyb, axis=0).sum(0).astype(np.float64)       # first non-sky row per column
empty = np.zeros_like(bg)
for y in range(HORIZON):
    row = sky[y] > 0
    if row.sum() > 50:
        ok = row & (lum[y] <= np.percentile(lum[y][row], 30))
        empty[y] = np.median(bg[y][ok], axis=0)
empty[HORIZON:] = empty[HORIZON - 1]
empty = blur(empty, 6)
beams = np.clip(blur(bg - empty, 2.5), 0, 255) * sky[..., None]          # blur drops the stars, keeps the beams
beams = beams * np.clip((yy < HORIZON - 4), 0, 1)[..., None]

# ---------------- the cat: huge, far away, rising out of the fog bank left of the tower -----------------------
S, OX, OY = 1.25, 40, 115
cat = Image.open("work/cat_lifted.png").convert("RGBA")
cat = cat.resize((round(cat.width * S), round(cat.height * S)), Image.LANCZOS)
cv = Image.new("RGBA", (W, H), (0, 0, 0, 0)); cv.alpha_composite(cat, (OX, OY))
c = np.asarray(cv).astype(np.float64)
crgb, ca = c[..., :3], c[..., 3] / 255
ca *= np.clip((HORIZON - 20 - yy) / 170, 0, 1) ** 1.2                    # her body sinks into the fog bank
ca *= sky                                                                  # never in front of cliff or tower
cl = crgb @ [0.299, 0.587, 0.114] / 255

# distance haze: her own colours, low contrast, pulled hard toward the night sky behind her (like the bear)
fogcol = blur(empty, 40) * 1.25 + np.array([6, 9, 14])
far = crgb * np.array([0.30, 0.33, 0.42]) * (0.55 + 0.45 * cl[..., None])
haze = 0.52 + 0.25 * np.clip((yy - 200) / 500, 0, 1)                      # thicker toward the fog bank
cat_far = far * (1 - haze[..., None]) + blur(empty, 40) * 1.05 * haze[..., None]
# where the beams cross her she is lit through the air (face and chest under the upper-left arm)
bl = np.clip(blur(beams @ [0.3, 0.5, 0.2], 10) / 60, 0, 1)
cat_far = cat_far + crgb * np.array([1.0, 0.9, 0.72]) * (bl * 0.10)[..., None] * ca[..., None]
# eyes: a faint amber reflection of the lamp
er, eg, eb = crgb[..., 0], crgb[..., 1], crgb[..., 2]
eye = ((er > 140) & (er - eb > 90) & (eg > 70) & (eg < 200)).astype(np.float64)
box = np.zeros((H, W)); box[OY + round(160 * S):OY + round(280 * S), OX + round(570 * S):OX + round(705 * S)] = 1
eye = gaussian_filter(eye * box, 1.6)
cat_far = over(cat_far, np.clip(crgb * [1.05, 0.85, 0.45] * 0.8 + fogcol * 0.25, 0, 255), eye * 0.75)
cat_far = blur(cat_far, 1.3)                                               # far away: softer than the tower
ca = gaussian_filter(ca, 2.4)                                               # far away in haze: soft edges

# ---------------- fog bank on the horizon (in front of her base), lit warmer near the lamp --------------------
noise = blur(rng.random((H, W)), 35); noise = (noise - noise.mean()) / noise.std()
bank = np.exp(-((yy - (HORIZON - 30)) / 95.0) ** 2) * np.clip(0.8 + 0.3 * noise, 0, 1.4)
bank = np.clip(bank * 0.8, 0, 0.85) * np.clip(sky + gaussian_filter(((yy >= HORIZON - 6) & (yy < HORIZON + 60)).astype(float), 20) * 0.5, 0, 1)
lampwarm = np.exp(-np.hypot(xx - LAMP[0], (yy - HORIZON) * 2.5) / 600)
bank_rgb = fogcol * 1.15 + np.array([40, 30, 14]) * lampwarm[..., None]
# general air between camera and her (weak), and low mist over the water and rocks
air = np.clip(0.10 + 0.08 * noise * 0.3, 0, 0.2) * sky
low = np.clip(np.exp(-((yy - 830) / 140.0) ** 2) * (0.25 + 0.1 * noise), 0, 0.32)

# ---------------- keeper (from v1) and grade ---------------------------------------------------------------
K = {n: np.asarray(Image.open(f"work/layers/{n}.png")).astype(np.float64) for n in ("07_path_lantern_light", "08_keeper", "09_lantern_glow")}
vig = np.clip(np.hypot((xx - W * 0.5) / (W * 0.6), (yy - H * 0.38) / (H * 0.62)) - 0.48, 0, 1) ** 1.25 * 0.9
fg_dark = np.clip((yy - sky_line[None, :]) / 40, 0, 1) * np.clip((1100 - xx) / 250, 0, 1) * 0.3  # crush the near cliff a little (framing)

save("01_empty_sky", empty, sky)
save("02_cat", cat_far, ca)
save("03_air", fogcol, air)
save("04_fog_bank", bank_rgb, bank)
save("05_beams", beams * (1.05 - 0.4 * ca)[..., None], np.ones((H, W)))   # added (Linear Dodge); already masked to the sky
save("06_low_mist", fogcol * 1.1, low)
save("10_foreground_shade", np.zeros((H, W, 3)) + [2, 4, 8], fg_dark)
save("11_vignette", np.zeros((H, W, 3)), vig)

out = over(bg, empty, sky)
out = over(out, cat_far, ca)
out = over(out, fogcol, air)
out = over(out, bank_rgb, bank)
out = np.clip(out + beams * (1.05 - 0.4 * ca)[..., None], 0, 255)                                   # the beams in front of her
out = screen(out, fogcol * 1.1, low)
out = screen(out, K["07_path_lantern_light"][..., :3], K["07_path_lantern_light"][..., 3] / 255)
out = over(out, K["08_keeper"][..., :3], K["08_keeper"][..., 3] / 255)
out = screen(out, K["09_lantern_glow"][..., :3], K["09_lantern_glow"][..., 3] / 255)
out = over(out, np.zeros((H, W, 3)) + [2, 4, 8], fg_dark)
out = over(out, np.zeros((H, W, 3)), vig)
out = out + rng.normal(0, 2.0, (H, W))[..., None]
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).save("work/preview2.jpg", quality=92)
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).resize((1200, 801), Image.LANCZOS).save("work/preview2_small.jpg", quality=85)
