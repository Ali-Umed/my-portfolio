"""HAWLER AFTER 10 MINUTES OF RAIN (meme, no text): Erbil Citadel under grey rain, the street flooded with calm muddy
water up to the car windows. The real parked cars (and the real taxi) stick out of the flood, the real passer-by is
now wading chest-deep, a man rows a boat across, and in front a man sits on an orange plastic chair on the roof of a
submerged car with an istikan of tea beside him.

Realism: calm flood water is a flat mirror - straight water line, reflections of everything, rain rings; no sun
(sky is overcast, the citadel is darkened, desaturated and flattened); every object gets its own water line,
ripples and reflection. Inputs: inputs/*.jpg (Unsplash), work/<rower|chairman|tea|subcar>_lifted.png (Apple Vision).
"""
import os
import numpy as np
from PIL import Image
from scipy.ndimage import gaussian_filter, label, binary_fill_holes, binary_opening, binary_closing, map_coordinates

OUT = "work/layers"
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(31)
F = np.float32
W, H0, H = 2800, 4200, 5200                       # the citadel photo is extended downward with more flood water
K = W / 2000.0
LUMW = np.array([0.299, 0.587, 0.114], F)
yy, xx = np.mgrid[0:H, 0:W].astype(F)
WL = 3990                                         # flood level: just under the car windows


def blur(a, r):
    return gaussian_filter(a, r) if a.ndim == 2 else np.stack([gaussian_filter(a[..., c], r) for c in range(a.shape[2])], -1)


def save(name, rgb, a):
    Image.fromarray(np.dstack([np.clip(rgb, 0, 255), np.clip(a, 0, 1) * 255]).astype(np.uint8), "RGBA").save(f"{OUT}/{name}.png")


def over(dst, rgb, a):
    return dst * (1 - a[..., None]) + rgb * a[..., None]


def place(img, x, y):
    cv = Image.new("RGBA", (W, H), (0, 0, 0, 0)); cv.alpha_composite(img, (int(x), int(y)))
    a = np.asarray(cv).astype(F)
    return a[..., :3], a[..., 3] / 255


def lifted(name, crop=None):
    im = Image.open(f"work/{name}_lifted.png").convert("RGBA")
    a0 = np.asarray(im)[..., 3]; ys_, xs_ = np.nonzero(a0 > 128)
    return im.crop((xs_.min(), ys_.min(), xs_.max() + 1, ys_.max() + 1))


# ---------------- citadel: sky -> rain clouds, sun -> overcast -------------------------------------------------
cit0 = np.asarray(Image.open("inputs/citadel.jpg").convert("RGB").resize((W, H0), Image.LANCZOS)).astype(F)
# paint out the awards billboard (user asked): clone the wall/mound from one arch (400 px) to the left, column by
# column so the cloned area continues itself; below the arches the plain brick infill repeats downward
BX, BY, ARCH = 2290, 2990, 400
lum0 = cit0 @ LUMW
car_top = np.full(W, 4000)
for x_ in range(BX, W):                                                           # the beige car in front stays
    hit = np.nonzero(lum0[3860:4000, x_] > 115)[0]
    car_top[x_] = 3860 + hit[0] if len(hit) else 4000
pt = cit0.copy()
xs_ = np.arange(BX, W)
t_ = np.clip((xs_ - 2400) / 40, 0, 1)[None, :, None]                             # one arch left, then two (poles), soft seam
pt[BY:3790, BX:] = cit0[BY:3790, BX - ARCH:W - ARCH] * (1 - t_) + cit0[BY:3790, BX - 2 * ARCH:W - 2 * ARCH] * t_
pt[3380:3455, 2470:2550] = pt[3380:3455, 2570:2650]                                 # no second copy of the wall vent
for y_ in range(3790, 4000):
    pt[y_, BX:] = pt[3740 + (y_ - 3740) % 50, BX:]                                 # two brick courses repeat down the jambs
bm = np.zeros((H0, W), F)
for x_ in range(BX, W):
    bm[BY:car_top[x_] - 1, x_] = 1
bm = gaussian_filter(bm, 2.0)
cit0 = cit0 * (1 - bm[..., None]) + pt * bm[..., None]
cit = np.zeros((H, W, 3), F); cit[:H0] = cit0; cit[H0:] = cit0[-1]
r, g, b = cit[..., 0], cit[..., 1], cit[..., 2]
cand = (g - r > 22) & (b - r > 22) & (r < 90) & (yy < 1800)
cand = binary_opening(binary_closing(cand, iterations=3), iterations=2)
lab, _ = label(cand); keep = np.unique(lab[:30][lab[:30] > 0])
skyb = binary_fill_holes(np.isin(lab, keep)) | ((g - r > 30) & (b - r > 30) & (r < 70) & (yy < 2400))
sky_a = gaussian_filter(skyb.astype(F), 1.0)
rs = Image.open("inputs/rainsky.jpg").convert("RGB")
rs = rs.resize((W, round(rs.height * W / rs.width)), Image.LANCZOS)
sky = np.zeros((H, W, 3), F); sh = min(rs.height, H); sky[:sh] = np.asarray(rs).astype(F)[:sh]
sky = sky * (0.80 + 0.12 * np.clip(yy / 1800, 0, 1))[..., None]                 # heavier at the top
skymean = sky[:1500].reshape(-1, 3).mean(0)

# overcast relight: no sun - flatter, darker, less colour, a little cool; wet walls
cl = cit @ LUMW
lo = gaussian_filter(cl, 40)
cit = cit * ((lo * 0.72 + lo.mean() * 0.28) / np.maximum(lo, 1))[..., None]     # big sun/shade differences flattened
cit = cit * 0.70 + (cit @ LUMW)[..., None] * 0.30                                  # 30 % less saturation
cit = cit * 0.90 + np.array([6, 9, 13], F)                                        # a little darker, cool lift
# rain haze: farther = greyer (the citadel top is farther than the street)
haze = (0.18 - 0.10 * np.clip((yy - 1200) / 2600, 0, 1))
cit = cit * (1 - haze[..., None]) + skymean * 0.85 * haze[..., None]
scene = over(cit, sky, sky_a)

# ---------------- people and objects in the flood ------------------------------------------------------------------
subcar = lifted("subcar")
CAR_W, CAR_X, CAR_WL = 1150, 1530, 4800
subcar = subcar.resize((CAR_W, round(subcar.height * CAR_W / subcar.width)), Image.LANCZOS)
car_rgb, car_a = place(subcar, CAR_X, CAR_WL - subcar.height)
car_rgb = car_rgb * 0.86                                                           # same grey light

rower = lifted("rower")
RW = 780
rower = rower.resize((RW, round(rower.height * RW / rower.width)), Image.LANCZOS)
ROW_CX, ROW_WL = 820, 4560
row_rgb, row_a = place(rower, ROW_CX - RW / 2, ROW_WL - rower.height + 18)
row_rgb = row_rgb * 0.9


def overcast(rgb, a, target, sat=0.62):
    """studio/sun photo -> the scene's grey light: flatter, less colour, same brightness as the rower."""
    l = rgb @ LUMW
    lo = gaussian_filter(l, 30)
    rgb = rgb * ((lo * 0.6 + 120 * 0.4) / np.maximum(lo, 1))[..., None]
    rgb = rgb * sat + (rgb @ LUMW)[..., None] * (1 - sat)
    m = (rgb @ LUMW)[a > 0.5].mean()
    return rgb * (target / m) + np.array([3, 5, 8], F)


def cut_at(img, row, feather=3):
    """keep the part above the water (row in the image's own pixels); soft edge at the water."""
    arr = np.asarray(img).astype(F)
    ramp = np.clip((row - np.arange(img.height, dtype=F)) / feather, 0, 1)
    arr[..., 3] *= ramp[:, None]
    return Image.fromarray(arr[:row + 2].astype(np.uint8), "RGBA")


def wet_band(rgb, a, wl, h):
    """clothes and paint are darker just above the water (soaked, splashed)."""
    k = np.clip(1 - (wl - yy) / h, 0, 1) * (yy < wl)
    return rgb * (1 - 0.30 * k)[..., None]


TARGET = (row_rgb @ LUMW)[row_a > 0.5].mean()


def wavy(a, wl, amp):
    """the water never meets an object in a ruler-straight line: small waves lap up and down along it."""
    def nz(sig):
        v = gaussian_filter(rng.normal(0, 1, W).astype(F), sig); return v / v.std()
    n_ = nz(7) * 1.6 * amp + nz(1.5) * 0.6 * amp
    return a * np.clip((wl + n_[None, :] - yy) / 1.5, 0, 1)


# two men pushing a stalled taxi (mid-distance, behind the drowned car)
pu = Image.open("work/pushers_lifted.png").convert("RGBA").crop((354, 2260, 2203, 3166))
pu_px = np.asarray(pu).astype(F)
pu_px[600:690, 95:330, :3] = blur(pu_px[600:690, 95:330, :3], 6)                  # the Indian number plate unreadable
pu = cut_at(Image.fromarray(pu_px.astype(np.uint8), "RGBA"), 724)
PUW, PU_X, PU_WL = 820, 1880, 4330
pu = pu.resize((PUW, round(pu.height * PUW / 1849)), Image.LANCZOS)
pu_rgb, pu_a = place(pu, PU_X, PU_WL - pu.height + 2)
pu_rgb = wet_band(overcast(pu_rgb, pu_a, TARGET * 0.95, sat=0.5), pu_a, PU_WL, 40)
pu_a = wavy(pu_a, PU_WL, 1.0)

# a boy wading hip-deep, guiding a washing tub with a baby in it (foreground left)
wd = cut_at(Image.open("work/wader_lifted.png").convert("RGBA").crop((246, 196, 1494, 2899)), 2100 - 196)
WD_H, WD_CX, WD_WL = 400, 560, 5030
wd = wd.resize((round(wd.width * WD_H / wd.height), WD_H), Image.LANCZOS)
wd_rgb, wd_a = place(wd, WD_CX - wd.width / 2, WD_WL - wd.height + 2)
wd_rgb = wet_band(overcast(wd_rgb, wd_a, TARGET * 1.05, sat=0.7), wd_a, WD_WL, 35)
wd_a = wavy(wd_a, WD_WL, 1.3)
WD_HAND = WD_CX + round(wd.width * 0.40)                                         # his right hand, screen right

tb = cut_at(Image.open("work/tubkid_lifted.png").convert("RGBA").crop((161, 1592, 5135, 5923)), 4250 - 1592, feather=20)
TBW, TB_X, TB_WL = 230, WD_HAND - 32, 5000                                   # his hand on the rim
tb = tb.resize((TBW, round(tb.height * TBW / 4974)), Image.LANCZOS)
tb_rgb, tb_a = place(tb, TB_X, TB_WL - tb.height + 2)
tb_rgb = wet_band(overcast(tb_rgb, tb_a, TARGET * 1.08, sat=0.5), tb_a, TB_WL, 12)
tb_a = wavy(tb_a, TB_WL, 0.8)

# ---------------- the flood: muddy water, a mirror of everything above it, rain rings ------------------------------
fw = Image.open("inputs/floodwater.jpg").convert("RGB")
fw = fw.crop((0, int(fw.height * 0.55), fw.width, fw.height)).resize((W, H - WL), Image.LANCZOS)
fwa = np.asarray(fw).astype(F)
water_col = fwa.reshape(-1, 3).mean(0) * np.array([0.92, 0.88, 0.80], F)          # muddy brown
tex = (fwa @ LUMW) - gaussian_filter(fwa @ LUMW, 25)                              # the photo's ripples
brown = np.zeros((H, W, 3), F); brown[WL:] = water_col + tex[..., None] * 0.8

# everything that stands in or above the water, for reflections
above = over(scene, car_rgb, car_a); above = over(above, row_rgb, row_a)


# ---- the water surface as a real height field: every raindrop makes a small ring wave that spreads and dies out;
# light comes from its slopes (bright on the side that faces the sky, dark on the other), and the same slopes bend the
# reflections. No drawn outlines. Perspective from the scene: s(y) px per metre, rings squashed by asp(y).
YH = 3208                                                                          # horizon of the water plane
def s_(y): return 0.179 * (y - YH)
def asp_(y): return (y - YH) / 4000.0


HW = H - WL
hf = np.zeros((HW, W), F)


def wave(cx, cy, r0, lam, pw, amp):
    """add one ring wave packet (radius r0 m, wavelength lam m, packet width pw m) centred at screen (cx, cy)."""
    sp, ap = s_(cy), asp_(cy)
    ext = (r0 + 2.2 * pw) * sp
    x0, x1 = int(max(cx - ext, 0)), int(min(cx + ext + 1, W))
    y0, y1 = int(max(cy - ext * ap, WL)), int(min(cy + ext * ap + 1, H))
    if x1 <= x0 or y1 <= y0:
        return
    gy_, gx_ = np.mgrid[y0:y1, x0:x1].astype(F)
    d = np.sqrt(((gx_ - cx) / sp) ** 2 + ((gy_ - cy) / (sp * ap)) ** 2)
    amp *= min(1.0, lam * sp * ap / 4.0) ** 2                                      # waves finer than the pixels just vanish (no moire)
    hf[y0 - WL:y1 - WL, x0:x1] += amp * np.cos(2 * np.pi * (d - r0) / lam) * np.exp(-((d - r0) / pw) ** 2)


# rain drops: same density per square metre of water, so many more (and smaller) per pixel in the distance
u = rng.random(16000)
lo3, hi3 = (WL - YH) ** -2.0, (H - YH) ** -2.0
drop_y = YH + (lo3 + u * (hi3 - lo3)) ** -0.5
drop_x = rng.uniform(0, W, drop_y.size)
age = rng.random(drop_y.size)
for x_, y_, t_ in zip(drop_x, drop_y, age):
    r0 = 0.015 + 0.20 * t_
    wave(x_, y_, r0, 0.03, 0.017 + 0.06 * r0, (1 - t_) ** 2.5 * rng.uniform(0.5, 1.0))   # one or two crests, not tree rings
    if t_ > 0.45:                                                                  # an older drop has a second, inner ring
        wave(x_, y_, r0 * 0.55, 0.028, 0.015, (1 - t_) ** 2.5 * 0.4)
# people moving through the water push out slow, wide wakes
for cx_, wl_, r_, n_ in ((WD_CX, WD_WL, 0.32, 3), (TB_X + TBW / 2, TB_WL, 0.36, 2), (PU_X + PUW * 0.45, PU_WL, 1.2, 3),
                         (ROW_CX - RW * 0.45, ROW_WL + 6, 0.25, 2), (ROW_CX + RW * 0.48, ROW_WL + 6, 0.25, 2)):
    for k_ in range(n_):
        wave(cx_, wl_ + 4, r_ + 0.16 * k_, 0.07, 0.05, 0.9 / (1 + k_))
# fine chop from the rain on top (much finer in the distance)
ch_far = gaussian_filter(rng.normal(0, 1, (HW, W)).astype(F), (0.6, 1.5))
ch_near = gaussian_filter(rng.normal(0, 1, (HW, W)).astype(F), (1.6, 3.5))
wt = np.clip((np.arange(HW) / HW)[:, None], 0, 1)
hf += (ch_far * (1 - wt) + ch_near * wt) * 0.10

# slopes in world units (per metre), then screen displacement and light
gyp, gxp = np.gradient(hf)
sy_ = s_(np.arange(WL, H, dtype=F))[:, None]
slx = gxp * sy_ / 40.0
sly = gyp * sy_ * asp_(np.arange(WL, H, dtype=F))[:, None] / 40.0
DX = np.zeros((H, W), F); DY = np.zeros((H, W), F); SL = np.zeros((H, W), F)
DX[WL:] = slx * sy_ * 0.045                                                        # bend reflections sideways a little
DY[WL:] = sly * sy_ * 0.12                                                         # and much more up/down
SL[WL:] = sly
# far away the single rings are too small to see; together they break the mirror into thin shimmering streaks
farw = (1 - wt) ** 1.5
DY[WL:] += gaussian_filter(rng.normal(0, 1, (HW, W)).astype(F), (0.7, 9)) * 7.0 * farw
DX[WL:] += gaussian_filter(rng.normal(0, 1, (HW, W)).astype(F), (0.7, 9)) * 3.0 * farw
SL[WL:] += gaussian_filter(rng.normal(0, 1, (HW, W)).astype(F), (0.6, 6)) * 1.6 * farw


def reflect(img, wl, ystart, yend):
    """mirror rows above wl into rows below it, bent by the water's slopes."""
    ys = np.arange(ystart, yend)
    gy, gx = np.meshgrid((2 * wl - ys).astype(F), np.arange(W, dtype=F), indexing="ij")
    gx2 = np.clip(gx + DX[ys], 0, W - 1); gy2 = np.clip(gy - DY[ys], 0, H - 1)
    if img.ndim == 2:
        return map_coordinates(img, [gy2, gx2], order=1)
    return np.stack([map_coordinates(img[..., c], [gy2, gx2], order=1) for c in range(img.shape[-1])], -1)


R = np.zeros((H, W, 3), F)
R[WL:] = reflect(scene, WL, WL, H)
R = gaussian_filter(R, (1.6, 0.5, 0))
R[WL:] = R[WL:] * (1 - farw[..., None] * 0.6) + gaussian_filter(R[WL:], (4.0, 1.2, 0)) * farw[..., None] * 0.6                                              # rain-roughened water smears reflections downward
fres = np.clip(0.78 - 0.30 * (yy - WL) / (H - WL), 0.48, 0.78)[..., None]
brown = brown * 0.5 + water_col * 0.5                                              # less of the source photo's own ripples
water = brown * (1 - fres) + (R * 0.80 * np.array([1.0, 0.93, 0.82], F)) * fres
# slope light: a facet tilted towards us reflects the darker street, tilted away reflects the bright sky
water = water + (np.clip(SL, -1.5, 1.5) * 22)[..., None] * np.array([1.0, 1.0, 1.02], F)
water_a = (yy >= WL).astype(F)


def obj_reflection(rgb, a, wl, depth, start=0.6):
    rr = np.zeros((H, W, 3), F); ra = np.zeros((H, W), F)
    y1 = min(H, wl + depth)
    rr[wl:y1] = reflect(rgb, wl, wl, y1)
    ra[wl:y1] = reflect(a, wl, wl, y1) * np.linspace(start, 0.0, y1 - wl)[:, None]
    rr = gaussian_filter(rr, (1.4, 0.5, 0)); ra = gaussian_filter(ra, (1.4, 0.5))
    shade = 1 + np.clip(SL, -1.5, 1.5)[..., None] * 0.18                          # same ripples light the reflections
    return rr * np.array([0.62, 0.58, 0.50], F) * shade, ra


car_r, car_ra = obj_reflection(car_rgb, car_a, CAR_WL, 380)
row_r, row_ra = obj_reflection(row_rgb, row_a, ROW_WL, 240)
pu_r, pu_ra = obj_reflection(pu_rgb, pu_a, PU_WL, 200, 0.75)
wd_r, wd_ra = obj_reflection(wd_rgb, wd_a, WD_WL, min(170, H - WD_WL), 0.8)
tb_r, tb_ra = obj_reflection(tb_rgb, tb_a, TB_WL, min(110, H - TB_WL), 0.8)
OBJ_A = np.maximum.reduce([car_a, row_a, pu_a, wd_a, tb_a])
REF_RGB = row_r + car_r + pu_r + wd_r + tb_r
REF_A = np.maximum.reduce([row_ra, car_ra, pu_ra, wd_ra, tb_ra])

# fresh drops: a tiny crown splash jumping up from the surface (only the newest ~8 % of drops)
spl = np.zeros((H, W), F)
for x_, y_, t_ in zip(drop_x, drop_y, age):
    if t_ > 0.08:
        continue
    sp = s_(y_)
    hgt = max(2.0, 0.035 * sp * rng.uniform(0.6, 1.4)); wid = max(0.6, 0.004 * sp)
    x0, x1 = int(max(x_ - 4 * wid - 2, 0)), int(min(x_ + 4 * wid + 3, W)); y0, y1 = int(max(y_ - hgt * 1.8, 0)), int(min(y_ + 3, H))
    gy_, gx_ = np.mgrid[y0:y1, x0:x1].astype(F)
    col_ = np.exp(-((gx_ - x_) / wid) ** 2) * np.clip((y_ - gy_) / hgt, 0, 1) * (gy_ <= y_) * np.exp(-((y_ - gy_) / hgt) ** 4)
    tip = (sp > 230) * np.exp(-(((gx_ - x_) / (wid * 1.3)) ** 2 + ((gy_ - (y_ - hgt * 1.35)) / (wid * 1.3)) ** 2))   # a droplet thrown up
    base = np.exp(-(((gx_ - x_) / (wid * 2.5)) ** 2 + ((gy_ - y_) / (wid * 1.0)) ** 2)) * 0.45           # the crown at the surface
    spl[y0:y1, x0:x1] = np.maximum(spl[y0:y1, x0:x1], np.maximum.reduce([col_ * 0.8, tip * 0.9, base]))
spl *= (1 - np.clip(gaussian_filter(OBJ_A, 2) * 2, 0, 1))
spl_a = gaussian_filter(spl, 0.4) * 0.55

# where the water touches walls, cars and people: a thin bright meniscus and wet darkening above it
wline = np.exp(-((yy - WL) / 2.2) ** 2) * 0.55 * (0.6 + 0.4 * gaussian_filter(rng.random((H, W)).astype(F), 4))
wet = np.clip(1 - (WL - yy) / 70, 0, 1) * (yy < WL) * 0.35
contact = np.zeros((H, W), F)
for a_, wl_ in ((car_a, CAR_WL), (row_a, ROW_WL), (pu_a, PU_WL), (wd_a, WD_WL), (tb_a, TB_WL)):
    edge = gaussian_filter((a_[wl_ - 4] > 0.5).astype(F), 3)
    brk = np.clip(gaussian_filter(rng.normal(0, 1, W).astype(F), 5) * 3 + 0.3, 0, 1)        # broken, not a ruler line
    contact = np.maximum(contact, np.exp(-((yy - wl_ - 2) / 2.0) ** 2) * (edge * brk)[None, :] * 0.32)

# ---------------- rain: streaks over everything, a grey veil ------------------------------------------------------
def streaks(count, length, angle, sigma, seed):
    r_ = np.random.default_rng(seed)
    a = np.zeros((H, W), F)
    a[r_.integers(0, H, count), r_.integers(0, W, count)] = 1
    L = int(length)
    k = np.zeros((L, L), F)
    for t in np.linspace(-0.5, 0.5, L * 2):
        k[int((L - 1) / 2 + t * (L - 1) * np.cos(angle)), int((L - 1) / 2 + t * (L - 1) * np.sin(angle))] = 1
    from scipy.ndimage import convolve
    return gaussian_filter(convolve(a, k / k.sum() * 6), sigma)


rain = streaks(30000, 40, 0.14, 0.7, 1) * 0.7 + streaks(9000, 80, 0.14, 1.4, 2) * 0.6 + streaks(2500, 150, 0.14, 2.6, 3) * 0.5
rain_a = np.clip(rain * 1.4, 0, 0.55)
veil = np.clip(0.08 + 0.06 * (1 - yy / H), 0, 0.15)
vig = np.clip(np.hypot((xx - W * 0.5) / (W * 0.65), (yy - H * 0.47) / (H * 0.62)) - 0.5, 0, 1) ** 1.2 * 0.55

# ---------------- layers + preview ---------------------------------------------------------------------------------
save("01_rain_clouds", sky, sky_a)
save("02_wet_walls_at_the_water", np.zeros((H, W, 3), F) + [26, 22, 20], wet)
save("03_flood_water", water, water_a)
save("04_water_line", np.zeros((H, W, 3), F) + [190, 185, 172], wline * (yy >= WL - 3))
save("05_water_line_at_people_and_cars", np.zeros((H, W, 3), F) + [200, 195, 182], contact)
save("06_reflections", REF_RGB, REF_A)
save("07_rower", row_rgb, row_a)
save("08_men_pushing_taxi", pu_rgb, pu_a)
save("09_submerged_car", car_rgb, car_a)
save("10_baby_in_tub", tb_rgb, tb_a)
save("11_boy_wading", wd_rgb, wd_a)
save("12_rain_splashes", np.zeros((H, W, 3), F) + [214, 214, 210], spl_a)
save("13_rain", np.zeros((H, W, 3), F) + [200, 204, 208], rain_a)
save("14_rain_veil", np.zeros((H, W, 3), F) + skymean, veil * np.ones((H, W), F))
save("15_vignette", np.zeros((H, W, 3), F) + [8, 9, 10], vig)

out = over(cit, sky, sky_a)
out = over(out, np.zeros((H, W, 3), F) + [26, 22, 20], wet)
out = over(out, water, water_a)
out = over(out, np.zeros((H, W, 3), F) + [190, 185, 172], wline * (yy >= WL - 3))
out = over(out, np.zeros((H, W, 3), F) + [200, 195, 182], contact)
out = over(out, REF_RGB, REF_A)
out = over(out, row_rgb, row_a)
out = over(out, pu_rgb, pu_a)
out = over(out, car_rgb, car_a)
out = over(out, tb_rgb, tb_a)
out = over(out, wd_rgb, wd_a)
out = over(out, np.zeros((H, W, 3), F) + [214, 214, 210], spl_a)
out = over(out, np.zeros((H, W, 3), F) + [200, 204, 208], rain_a)
out = over(out, np.zeros((H, W, 3), F) + skymean, veil * np.ones((H, W), F))
out = over(out, np.zeros((H, W, 3), F) + [8, 9, 10], vig)
out = out + gaussian_filter(rng.normal(0, 2.0, (H, W)).astype(F), 0.5)[..., None]
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).save("work/preview.jpg", quality=95)
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).resize((560, 1040), Image.LANCZOS).save("work/preview_small.jpg", quality=85)
Image.fromarray(np.clip(cit, 0, 255).astype(np.uint8)).save("work/citadel_canvas.jpg", quality=97, subsampling=0)
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).crop((900, 4750, 1700, 5150)).save("work/zoom_new.jpg", quality=92)
Image.fromarray(np.clip(out, 0, 255).astype(np.uint8)).crop((1800, 4150, 2800, 4550)).save("work/zoom_far.jpg", quality=92)
print("car top", CAR_WL - subcar.height, "pushers h", pu.height, "tub h", tb.height)
