# AniCraft engine notes (CLI 0.2.1, verified 2026-11-13)

Read this before writing a custom recipe. Params are verbatim from `anicraft-cli commands`.

## Transports

- `anicraft-cli serve [file]`: JSON lines, `{"id", "cmd", "params"}` → `{"id", "ok", "result"|"error"}`. The runner
  uses this so it can read ids (`layer.new` → `{"layer": id}`, `text.create` → `{element, width, height}`).
- `run <file> script.json [--save out]`: a list of `{"cmd", "params"}`, all or nothing (a failed step saves nothing).
- `exec <file> <id> '<json>' [--save]`, `new --out f --width --height --fps`, `info <file>`,
  `render <file> --out f.png --frame N(1-based) [--scale]`, `render-seq`, `gif`.
- `--sample` instead of a file opens the demo document. No `--save` = nothing written.

## Core commands

| Command | Params |
|---|---|
| `doc.set_stage` | {width?, height?, fps?, background?: "#rrggbb"} |
| `layer.new` / `layer.rename` | {name?} / {name, layer?} |
| `layer.select` | {layer: id} or {index}, select?: bool |
| `draw.rect` | {x, y, w, h, radius?, fill?, stroke?, stroke_width?, profile?, cap?, join?, style?, dash?, object?} |
| `draw.ellipse` | {x, y, w, h, fill?, stroke?, …} |
| `draw.star` | {cx, cy, outer, inner?, points?, fill?, stroke?, …} |
| `draw.path` | {d: SVG path data (stage space), fill?, stroke?, stroke_width?, object?} |
| `text.create` | {text, x?, y? (top-left; default centred), font?, size?, bold?, italic?, color?, align?, letter_spacing?, line_spacing?, width?} |
| `text.fonts` | {} → {default, families[]} |
| `modify.convert_to_symbol` | {name?, kind?: graphic\|movie_clip\|button} → {symbol, instance, name, layer} |
| `library.place` | {symbol \| bitmap \| sound: id, x?, y?} (centred on x, y) |
| `timeline.insert_frame` | {layer? \| layers?, frame?, count?} |
| `timeline.insert_keyframe` / `insert_blank_keyframe` | {layer? \| layers?, frame?} |
| `timeline.create_motion_tween` | {layer?, frame?} (objects on the key become one graphic symbol) |
| `timeline.create_tween` / `create_shape_tween` | {layer?, frame?, easing?} (classic / shape tween between keyframes) |
| `motion.set_key` | {property, value (px, %, °), frame?, layer?}; properties: x y scale_x scale_y rotation skew alpha brightness tint tint_red/green/blue red/green/blue/alpha_multiplier red/green/blue/alpha_offset |
| `motion.set_ease` | {easing, property? (default every property), frame? (inside the segment), layer?} |
| `motion.info` | {frame?, layer?} → keys per property and current `values` |
| `motion.set_path` / `orient` | move along a path / turn to follow it |
| `camera.add` / `camera.set` | {} / {x?, y?, dx?, dy?, zoom? (%), zoom_by?, rotation?, tint?, tint_amount?, reset?, frame?} |
| `sound.place` | {sound, layer?, frame?, sync?: event\|start\|stop\|stream, repeat?, loop?, envelope?, extend?} |
| `bone.add` / `bone.pose` | inverse-kinematics armatures (see the commands file) |
| `file.export_video` | {path (.mp4 \| .webm), from?, to?, scale?, audio?, ffmpeg?, confirm?} |
| `file.export_gif` | {path, from?, to?, scale?, loop?, confirm?} |
| `file.export_lottie` | {path, from?, to?, background? (default transparent), confirm?} |
| `file.export_sprite_sheet` | {path (.png; frame map .json beside it), from?, to?, scale?, columns?, padding?, background?, confirm?} |
| `file.export_png` / `export_png_sequence` / `export_svg` / `export_html` | single frame / frames / vector / web player |

Units: alpha and scale in %, rotation in degrees, x/y in stage px (instance position). `motion.info.values` gives
the resting values `@animate` adds `"+n"` to.

## Patterns

- **Fade + rise in**: `@animate {from: {y: "+60", alpha: 0}, start, end: start+18, ease: CubicOut}`.
- **Exit**: `@animate {keys: {alpha: [[f, 100], [f+12, 0]]}, ease: CubicIn}`.
- **Bounce/squash**: see `templates/bounce-loop.json` (scale about the centre, so add `y: "+k"` on the squash
  frame to keep the bottom on the ground; round at the apex, stretched while moving).
- **Looping GIF/sticker**: `"loop": true`, first and last keys equal, export `gif` (or `lottie` for apps/web).
- **Game sprite sheet**: `--render sprite` → PNG + JSON frame map.
- **Character**: draw parts as separate symbols on separate layers, then `bone.add` for IK, or classic tweens
  per part; keep the pivot (transform point) at the joint.

## Known gaps (0.2.1)

No documented live-app control channel yet (build headless, then open). Easing is a fixed list (no custom
curves via the CLI). Template text positions assume the stage size in the template; for other sizes adjust x/width.
