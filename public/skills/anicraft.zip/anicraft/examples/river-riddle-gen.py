import json,re
S=json.load(open("audio/lines.json"));D=S["duration"]+1.2;S=S["segments"]
F=30;f=lambda t:int(round(t*F));N=f(D);s=lambda i:f(S[i]["start"]);e=lambda i:f(S[i]["end"])
OL={"stroke":"#0b0a10","stroke_width":7};FONT="Rabar_031"
NG,FG,RT,RB=1380,640,700,1290
st=[]
def T(d,ox,oy,k=1):
    out=[];toks=re.findall(r"[A-Za-z]|-?\d+\.?\d*",d);i=0;cmd=None;pair=[]
    for t in toks:
        if t.isalpha(): cmd=t;out.append(t);pair=[];continue
        v=float(t)
        if cmd=="V": out.append(str(oy+v*k));continue
        if cmd=="H": out.append(str(ox+v*k));continue
        pair.append(v)
        if len(pair)==2: out+= [str(ox+pair[0]*k),str(oy+pair[1]*k)];pair=[]
    return " ".join(out)
def rect(x,y,w,h,r,fill,ox,oy,k=1,ol=True): st.append(["draw.rect",{"x":ox+x*k,"y":oy+y*k,"w":w*k,"h":h*k,"radius":r*k,"fill":fill}|(OL if ol else {})])
def circ(cx,cy,r,fill,ox,oy,k=1,ol=True): st.append(["draw.ellipse",{"x":ox+(cx-r)*k,"y":oy+(cy-r)*k,"w":2*r*k,"h":2*r*k,"fill":fill}|(OL if ol else {})])
def path(d,fill,ox,oy,k=1,ol=True,sw=7,col="#0b0a10"): st.append(["draw.path",{"d":T(d,ox,oy,k),"fill":fill}|({"stroke":col,"stroke_width":sw} if ol else {})])
def FARMER(ox,oy,k=1):
    rect(-34,-150,68,100,20,"#3b82f6",ox,oy,k);rect(-30,-56,24,56,8,"#1e3a8a",ox,oy,k);rect(6,-56,24,56,8,"#1e3a8a",ox,oy,k)
    circ(0,-188,38,"#ffd9b8",ox,oy,k);circ(-12,-190,6,"#0b0a10",ox,oy,k,0);circ(14,-190,6,"#0b0a10",ox,oy,k,0)
    path("M-10 -170 Q2 -162 14 -170",None,ox,oy,k,sw=5);path("M-62 -214 L62 -214 L40 -232 Q0 -268 -40 -232Z","#f59e0b",ox,oy,k)
def WOLF(ox,oy,k=1):
    rect(-58,-92,116,66,30,"#6b7280",ox,oy,k);rect(-48,-36,20,36,6,"#4b5563",ox,oy,k);rect(28,-36,20,36,6,"#4b5563",ox,oy,k)
    path("M58 -80 L92 -100 L70 -60Z","#4b5563",ox,oy,k);hx,hy=ox-60*k,oy-110*k
    path("M-30 -40 L-18 -78 L0 -46 L18 -78 L30 -40Z","#4b5563",hx,hy,k);circ(0,0,44,"#6b7280",hx,hy,k);path("M-44 6 L-84 18 L-40 30Z","#9ca3af",hx,hy,k)
    for x in(-14,12): circ(x,-8,7,"#fde047",hx,hy,k,0);circ(x,-8,3,"#0b0a10",hx,hy,k,0)
def GOAT(ox,oy,k=1):
    rect(-52,-88,104,62,28,"#f5f5f4",ox,oy,k);rect(-42,-34,18,34,6,"#d6d3d1",ox,oy,k);rect(24,-34,18,34,6,"#d6d3d1",ox,oy,k);hx,hy=ox-54*k,oy-108*k
    path("M-16 -30 Q-30 -70 -4 -64 M16 -30 Q30 -70 4 -64",None,hx,hy,k);circ(0,0,36,"#f5f5f4",hx,hy,k);path("M-6 30 L0 52 L6 30Z","#d6d3d1",hx,hy,k)
    circ(-12,-6,6,"#0b0a10",hx,hy,k,0);circ(12,-6,6,"#0b0a10",hx,hy,k,0)
def CABB(ox,oy,k=1):
    circ(0,-56,56,"#22c55e",ox,oy,k);path("M-30 -60 Q0 -110 30 -60 Q0 -20 -30 -60Z","#86efac",ox,oy,k);path("M0 -104 V-14",None,ox,oy,k,sw=6,col="#15803d")
def text(s_,y,size,col="#ffffff",x=60,w=960): st.append(["text.create",{"text":s_,"x":x,"y":y,"width":w,"size":size,"font":FONT,"bold":True,"color":col,"align":"center"}])
def layer(n,first=False): st.append(["layer.rename" if first else "layer.new",{"name":n}])
def anim(n,keys,ease="CubicOut"): st.append(["@animate",{"layer":n,"keys":keys,"ease":ease}])
def vis(on,off=None,fade=6):  # alpha keys: visible from on to off
    k=[[0,0],[on,0],[on+fade,100]]
    if off: k+=[[off-fade,100],[off,0]]
    return k
def pop(on,off=None):
    k=[[0,0],[on,0],[on+6,100]]
    if off: k+=[[off-1,100],[off,0]]
    return k
# world
layer("World",True)
st.append(["draw.rect",{"x":0,"y":FG-20,"w":1080,"h":RT-FG+20,"fill":"#7c4a2a"}]);st.append(["draw.rect",{"x":0,"y":FG-20,"w":1080,"h":20,"fill":"#16a34a"}])
st.append(["draw.rect",{"x":0,"y":RT,"w":1080,"h":RB-RT,"fill":"#2563eb"}]);st.append(["draw.rect",{"x":0,"y":RB,"w":1080,"h":700,"fill":"#7c4a2a"}]);st.append(["draw.rect",{"x":0,"y":RB,"w":1080,"h":20,"fill":"#16a34a"}])
layer("Waves")
for i in range(6): path(f"M-60 {RT+70+i*90} "+" ".join(f"Q{-15+j*90} {RT+52+i*90} {30+j*90} {RT+70+i*90}" for j in range(14)),None,0,0,sw=6,col="#60a5fa")
anim("Waves",{"x":[[j,"+0" if (j//45)%2==0 else "+28"] for j in range(0,N,45)]},"QuadInOut")
layer("TopT");text("گورگ · بزن · کەلەم",230,84);anim("TopT",{"alpha":vis(s(1)-8,s(9))})
# boat
layer("Boat");path("M-170 0 L170 0 L130 70 L-130 70Z","#a16207",540,RB-200)
SX=[150,400,650,900];home={"F":SX[0],"W":SX[1]+40,"G":SX[2]+30,"C":SX[3]}
def trip(a,b): # boat dy
    return [[0,"+0"],[a,"+0"],[b,f"{-(RB-200-(RT-20))}"]]
bt=[[0,"+0"],[s(5)+9,"+0"],[s(6)-3,f"-{RB-200-RT+20}"],[s(7)-8,f"-{RB-200-RT+20}"],[s(7)-7,"+0"],[s(7)+9,"+0"],[s(8)-3,f"-{RB-200-RT+20}"],[s(9)-8,f"-{RB-200-RT+20}"],[s(9)-7,"+0"]]
anim("Boat",{"alpha":vis(s(2),fade=8),"y":bt},"CubicInOut")
# characters: draw at home, ride via relative keys
def rider(name,draw,hx,item_in):
    layer(name);draw(hx,NG)
    return name
up=RB-200-RT+20
rides={"F":[5,7],"W":[5],"C":[7]}
def keys_for(c,slot_x):
    dx=slot_x-home[c];dyb=(RB-200+10)-NG
    xk=[[0,"+0"]];yk=[[0,"+0"]]
    for i in rides.get(c,[]):
        a,b=s(i)+9,s(i+1)-3
        xk+=[[a-8,"+0"],[a,f"{dx:+d}"],[b,f"{dx:+d}"],[s(i+2)-8,f"{dx:+d}"],[s(i+2)-7,"+0"]]
        yk+=[[a-8,"+0"],[a,f"{dyb:+d}"],[b,f"{dyb-up:+d}"],[s(i+2)-8,f"{dyb-up:+d}"],[s(i+2)-7,"+0"]]
    return xk,yk
for k,(c,dr) in enumerate([("F",FARMER),("W",WOLF),("G",GOAT),("C",CABB)]):
    layer(c);dr(home[c],NG)
    xk,yk=keys_for(c,460 if c=="F" else 620)
    on=s(1)+9+k*8;al=[[0,0],[on,0],[on+6,100]]
    sc=[[0,0],[on,0],[on+8,112],[on+12,100]]
    # rules dimming
    dim={"F":[(3,5)],"C":[(3,4)],"W":[(4,5)]}.get(c,[])
    for a,b in dim: al+=[[s(a),100],[s(a)+8,25],[s(b)-8,25],[s(b),100]]
    if c=="C": al+=[[s(6)+6,100],[s(6)+18,0],[s(7)-8,0],[s(7)-7,100]]
    if c=="G": al+=[[s(8)+6,100],[s(8)+18,0],[s(9)-8,0],[s(9)-7,100]]
    if c in("F","W","C"): al=sorted({x[0]:x for x in al}.values())
    anim(c,{"x":xk,"y":yk,"alpha":al,"scale_x":sc,"scale_y":sc},"CubicInOut")
# title scene (cover)
layer("Cover");st.append(["draw.rect",{"x":0,"y":0,"w":1080,"h":1920,"fill":"#121014"}]);anim("Cover",{"alpha":[[0,100],[s(1)-10,100],[s(1)-2,0]]})
layer("Q");text("؟",420,420,"#fbbf24");anim("Q",{"alpha":pop(4,s(1)-6)})
layer("Icons");WOLF(300,1250);GOAT(540,1250);CABB(780,1250);anim("Icons",{"alpha":pop(18,s(1)-6)})
# caption + warnings + X
layer("Cap");rect(380,940,320,120,40,"#ffffff",0,0);text("١ + جوتیار",975,58,"#121014",380,320);anim("Cap",{"alpha":pop(s(2)+9,s(3))})
for n,(x1,x2),i in (("W1",(home["W"],home["G"]),3),("W2",(home["G"],home["C"]),4)):
    x=(x1+x2)/2;y=NG-380;layer(n);path(f"M{x} {y-90} L{x+90} {y+70} L{x-90} {y+70}Z","#fbbf24",0,0);text("!",y-40,110,"#121014",x-60,120)
    anim(n,{"alpha":pop(s(i)+15,s(i+1)-7 if i==4 else s(i+1))})
for n,i in (("X1",6),("X2",8)):
    layer(n);circ(540,960,150,"#ef4444",0,0);path("M480 900 L600 1020 M600 900 L480 1020",None,0,0,sw=34,col="#ffffff")
    rect(300,1135,480,130,40,"#ffffff",0,0);text("هەڵەیە!",1150,88,"#ef4444",300,480);anim(n,{"alpha":pop(s(i)+12,s(i+1)-8)})
layer("How");text("چۆن؟",300,210,"#fbbf24");anim("How",{"alpha":pop(s(9)+6,s(10)-8)})
for j,c in enumerate("٣٢١"):
    a=e(9)+6+j*int((s(10)-e(9)-14)/3);n=f"N{j}";layer(n);circ(540,990,70,"#ffffff",0,0);text(c,935,84,"#121014",470,140);anim(n,{"alpha":pop(a,a+int((s(10)-e(9)-14)/3))})
layer("CTA");st.append(["draw.rect",{"x":0,"y":0,"w":1080,"h":1920,"fill":"#121014"}])
path("M250 470 L830 470 Q860 470 860 500 L860 720 Q860 750 830 750 L500 750 L400 840 L415 750 L250 750 Q220 750 220 720 L220 500 Q220 470 250 470Z","#ffffff",0,0)
text("وەڵامەکەت بنووسە",565,62,"#121014",220,640);circ(370,1060,120,"#ef4444",0,0);path("M370 1120 L300 1050 Q280 1000 325 990 Q355 985 370 1020 Q385 985 415 990 Q460 1000 440 1050Z","#ffffff",0,0,ol=False)
circ(710,1060,120,"#fbbf24",0,0);path("M710 1000 L710 1120 M650 1060 L770 1060",None,0,0,sw=26,col="#121014")
anim("CTA",{"alpha":vis(s(10)-6,fade=8)})
json.dump({"stage":{"width":1080,"height":1920,"fps":F,"background":"#121014"},"frames":N,"steps":st},open("river.json","w"),ensure_ascii=False)
print(N,len(st))
