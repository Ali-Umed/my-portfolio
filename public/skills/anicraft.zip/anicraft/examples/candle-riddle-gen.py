import json,sys
L=sys.argv[1]; B=f"{L}"
S=json.load(open(f"{B}/audio/lines.json"))["segments"]; D=json.load(open(f"{B}/audio/lines.json"))["duration"]
F=30; f=lambda t:int(round(t*F)); N=f(D)+20
T={"ku":["مەتەڵێک","تەنها زیرەکەکان وەڵامەکە دەزانن","١٠ مۆم داگیرساون","با ٣ مۆم دەکوژێنێتەوە","هیچ مۆمێکی تر ناکوژێتەوە","چەند مۆم دەمێنێتەوە؟","وەڵامەکەت لە کۆمێنت بنووسە"],
   "en":["A riddle","Only smart people know the answer","10 candles are burning","The wind blows out 3","No other candle goes out","How many are left?","Write your answer in the comments"],
   "ar":["لغز","فقط الأذكياء يعرفون الجواب","١٠ شموع مشتعلة","الريح تطفئ ٣","لا تنطفئ أي شمعة أخرى","كم شمعة تبقى؟","اكتب جوابك في التعليقات"]}[L]
FONT="Helvetica Neue" if L=="en" else "Rabar_031"; K=1.0 if L=="en" else 1.12
INK="#ffffff"; ACT="#F7941D"; BG="#121014"
st=[["layer.rename",{"name":"Floor"}],["draw.rect",{"x":0,"y":1670,"w":1080,"h":250,"fill":"#1d1a21"}]]
def text(name,s,y,size,col=INK,start=0,end=None):
    st.append(["layer.new",{"name":name}])
    st.append(["text.create",{"text":s,"x":60,"y":y,"width":960,"size":int(size*K),"font":FONT,"bold":True,"color":col,"align":"center","line_spacing":1.1}])
    k={"alpha":[[0,0],[start,0],[start+10,100]],"y":[[0,"+50"],[start,"+50"],[start+12,"+0"]]}
    if end: k["alpha"]+= [[end,100],[end+8,0]]
    st.append(["@animate",{"layer":name,"keys":k,"ease":"CubicOut"}])
s=[(f(x["start"]),f(x["end"])) for x in S]
# title scene
text("T0",T[0],560,150,ACT,0,s[0][1]); text("T1",T[1],780,84,INK,12,s[0][1])
# candles 5x2
xs=[150,345,540,735,930]; rows=[1000,1440]; out={1,5,8}
for i in range(10):
    x=xs[i%5]; y=rows[i//5]; a=s[1][0]+i*3
    st.append(["layer.new",{"name":f"C{i}"}]); st.append(["draw.rect",{"x":x-45,"y":y,"w":90,"h":200,"radius":12,"fill":"#f2ede4"}])
    st.append(["draw.rect",{"x":x-4,"y":y-30,"w":8,"h":34,"radius":4,"fill":"#2b2730"}])
    st.append(["@animate",{"layer":f"C{i}","keys":{"alpha":[[0,0],[a,0],[a+8,100]],"y":[[0,"+80"],[a,"+80"],[a+12,"+0"]]},"ease":"CubicOut"}])
    st.append(["layer.new",{"name":f"F{i}"}]); st.append(["draw.path",{"d":f"M{x} {y-120} C{x+36} {y-70} {x+30} {y-30} {x} {y-26} C{x-30} {y-30} {x-36} {y-70} {x} {y-120}Z","fill":ACT}])
    lit=a+14; k={"alpha":[[0,0],[lit,0],[lit+6,100]],"scale_y":[[0,100]]}
    for j in range(lit+6,N,9): k["scale_y"].append([j,100 if (j//9+i)%2 else 88])
    if i in out:
        o=s[2][0]+30+[1,5,8].index(i)*8; k["alpha"]+=[[o,100],[o+6,0]]
        st.append(["@animate",{"layer":f"F{i}","keys":k,"ease":"QuadInOut"}])
        st.append(["layer.new",{"name":f"S{i}"}]); st.append(["draw.ellipse",{"x":x-14,"y":y-80,"w":28,"h":40,"fill":"#6b6672"}])
        st.append(["@animate",{"layer":f"S{i}","keys":{"alpha":[[0,0],[o,0],[o+4,70],[o+30,0]],"y":[[0,"+0"],[o,"+0"],[o+30,"-120"]]},"ease":"CubicOut"}])
    else: st.append(["@animate",{"layer":f"F{i}","keys":k,"ease":"QuadInOut"}])
# wind swooshes
st.append(["layer.new",{"name":"Wind"}])
for dy in (0,70,140): st.append(["draw.path",{"d":f"M0 {1000+dy} C120 {960+dy} 240 {1040+dy} 380 {1000+dy}","stroke":"#8c8796","stroke_width":14,"fill":None}])
w=s[2][0]+10; st.append(["@animate",{"layer":"Wind","keys":{"x":[[0,"-500"],[w,"-500"],[w+40,"+1300"]],"alpha":[[0,0],[w,0],[w+5,100],[w+35,100],[w+40,0]]},"ease":"QuadInOut"}])
text("L1",T[2],440,110,INK,s[1][0],s[1][1]+5)
text("L2",T[3],440,110,ACT,s[2][0],s[2][1]+5)
text("L3",T[4],440,110,INK,s[3][0],s[3][1]+5)
text("L4",T[5],400,124,ACT,s[4][0],s[5][0]-8)
for n,c in enumerate("321" if L=="en" else "٣٢١"):
    a=s[4][1]+10+n*int(F*0.9); text(f"N{n}",c,560,190,INK,a,a+20)
text("CTA",T[6],440,108,ACT,s[5][0])
json.dump({"stage":{"width":1080,"height":1920,"fps":F,"background":BG},"frames":N,"steps":st},open(f"{B}/recipe.json","w"),ensure_ascii=False,indent=0)
