import json,math,re
TL=json.load(open("timeline.json"));LN={l["i"]:l for l in TL["lines"]};END=TL["end"]
W,H,FPS=1080,1920,30;f=lambda t:int(round(t*FPS));N=f(END)
G=1290;KU="Rabar_031";AR="KFGQPC HAFS Uthmanic Script";INK="#121014";CREAM="#f4eee0"
st=[];first=[True]
def layer(n): st.append(["layer.rename" if first[0] else "layer.new",{"name":n}]);first[0]=False
def R(x,y,w,h,c,r=0): st.append(["draw.rect",{"x":x,"y":y,"w":w,"h":h,"radius":r,"fill":c}])
def E(cx,cy,w,h,c): st.append(["draw.ellipse",{"x":cx-w/2,"y":cy-h/2,"w":w,"h":h,"fill":c}])
def P(d,c=None,s=None,sw=0): st.append(["draw.path",{"d":d,"fill":c}|({"stroke":s,"stroke_width":sw} if s else {})])
def T(s,y,size,col,font=KU,x=60,w=960,ls=1.2):
    s=re.sub(r"[٠-٩][٠-٩.,]*",lambda m:m.group(0)[::-1],s)  # AniCraft reverses digit runs in RTL
    lines=[s]
    if isinstance(y,int) and font==KU and len(s)*size*0.42>w:  # AniCraft stacks wrapped RTL lines bottom-up: wrap by hand
        mx=int(w/(size*0.42));lines=[];cur=""
        for wd in s.split():
            if cur and len(cur)+1+len(wd)>mx: lines.append(cur);cur=wd
            else: cur=(cur+" "+wd).strip()
        lines.append(cur)
    for j,ln in enumerate(lines):
        st.append(["text.create",{"text":ln,"x":x,"y":y+int(j*size*ls) if j else y,"width":w,"size":size,"font":font,"bold":font==KU,"color":col,"align":"center","line_spacing":ls}])
def anim(n,k,ease="CubicOut"):
    k={p:sorted({fr:[fr,v] for fr,v in pts if fr<N}.values()) for p,pts in k.items()}
    st.append(["@animate",{"layer":n,"keys":k,"ease":ease}])
def show(a,b,fade=8,dy=None):
    k={"alpha":[[0,0],[a,0],[a+fade,100]]+([[b-fade,100],[b,0]] if b else [])}
    if dy: k["y"]=[[0,f"+{dy}"],[a,f"+{dy}"],[a+fade+4,"+0"]]
    return k
S=lambda i:f(LN[i]["start"]);Ee=lambda i:f(LN[i]["end"])
SEC=[dict(ar="امشوا",ku="ڕۆیشتن",why="بۆ ڕزق",col="#1e88e5",sky="#cfe8f7",bld="#e6f3fb",walk="#e9dfc9",gnd="#d8c9a8",per=1.0,amp=20,spd=110,lean=0,ref="﴿ الملك : ١٥ ﴾"),
     dict(ar="اسعوا",ku="بەپەلەچوون",why="بۆ نوێژ",col="#12805c",sky="#bfe3fb",bld="#e3f2fd",walk="#dfe6d6",gnd="#c9d4bf",per=.7,amp=26,spd=220,lean=3,ref="﴿ الجمعة : ٩ ﴾"),
     dict(ar="سارعوا",ku="پێشبڕکێ",why="بۆ لێخۆشبوون",col="#c99a06",sky="#fde2b8",bld="#fff1dc",walk="#efdcc0",gnd="#e0c39c",per=.48,amp=34,spd=380,lean=6,ref="﴿ آل عمران : ١٣٣ ﴾"),
     dict(ar="فرّوا",ku="ڕاکردن",why="بەرەو خوا",col="#d9531e",sky="#f6c9a0",bld="#fbe0c8",walk="#c9876a",gnd="#a8634a",per=.3,amp=42,spd=760,lean=12,ref="﴿ الذاريات : ٥٠ ﴾")]
secS=[S(2)-8,S(5)-8,S(8)-8,S(11)-8];secE=secS[1:]+[S(14)-8]
# ---------- section worlds ----------
def strip(k,s):
    out=[]
    for o in (0,1080):
        for bx,bw,bh in ((20,150,260),(200,190,330),(420,120,220),(600,210,300),(850,160,250)): R(o+bx,G-40-bh,bw,bh,s["bld"])
        if k==0:
            for sx in (60,640):
                R(o+sx,G-170,220,130,"#e8b77a",6)
                for j in range(5): R(o+sx-10+j*48,G-230,48,50,"#d93b3b" if j%2==0 else "#ffffff")
                for j in range(5): E(o+sx+25+j*42,G-180,34,34,["#f39c12","#e74c3c","#f1c40f","#e67e22","#c0392b"][j])
        if k==1:
            mx=o+700;R(mx-150,G-260,300,220,"#ffffff");P(f"M{mx-130} {G-258} Q{mx} {G-460} {mx+130} {G-258}Z","#12805c")
            R(mx+180,G-520,40,480,"#12805c");P(f"M{mx+175} {G-520} L{mx+200} {G-600} L{mx+225} {G-520}Z","#12805c")
            P(f"M{mx-35} {G-40} L{mx-35} {G-120} Q{mx} {G-175} {mx+35} {G-120} L{mx+35} {G-40}Z","#f7c948")
        if k==2:
            for tx in (120,520,940): R(o+tx-10,G-200,20,160,"#7a5230");E(o+tx,G-240,150,150,"#43a85a")
            P(f"M{o+300} {G-40} L{o+300} {G-300} Q{o+400} {G-430} {o+500} {G-300} L{o+500} {G-40}",None,"#2f9e4f",34)
        if k==3:
            for j in range(6): R(o+40+j*180,G-120-j%3*30,90,6+j%2*4,"#ffffff",3)
    for j in range(18): R(j*120,G-40,6,80,s["gnd"])
for k,s in enumerate(SEC):
    a,b=secS[k],secE[k]
    layer(f"Sky{k}");R(0,0,W,H,s["sky"])
    if k==3: E(540,820,900,900,"#fbe3b0");E(540,820,560,560,"#fff3d6")
    if k==1: E(900,160,150,150,"#fff3b0")
    R(0,G-40,W,80,s["walk"]);R(0,G+40,W,H-G-40,s["gnd"])
    anim(f"Sky{k}",{"alpha":[[0,0],[a,0],[a+8,100],[b+7,100],[b+8,0]]})
    layer(f"Back{k}");strip(k,s)
    per=max(2,f(1080/s["spd"]));xk=[[0,"+0"],[a,"+0"]];t0=a
    while t0<b+8: xk+=[[t0,"+0"],[t0+per-1,f"-{1080*(per-1)/per:.0f}"]];t0+=per
    anim(f"Back{k}",{"x":xk,"alpha":[[0,0],[a,0],[a+8,100],[b+7,100],[b+8,0]]},"Linear")
# ---------- characters ----------
def person(name,cx,shirt,phase,xoff=None,on=None):
    hip=G-112;L=100
    for leg,sg in (("La",1),("Lb",-1)):
        n=f"{name}{leg}";layer(n);R(cx-11,hip,22,L-6,"#2a52be",8);E(cx+8,G-8,46,20,"#2b2730")
        rot=[[0,0]];x=[[0,"+0"]];y=[[0,"+0"]]
        for k,s in enumerate(SEC):
            for fr in range(secS[k],secE[k]+8,2):
                th=sg*s["amp"]*math.sin(2*math.pi*(fr/FPS)/s["per"]+phase);r=math.radians(th);c=(L/2)
                rot.append([fr,round(th,1)]);x.append([fr,f"{-math.sin(r)*c+(xoff(fr) if xoff else 0):+.1f}"]);y.append([fr,f"{(math.cos(r)-1)*c:+.1f}"])
        k={"rotation":rot,"x":x,"y":y,"alpha":on}
        anim(n,k,"Linear")
    n=f"{name}Top";layer(n)
    R(cx-62,G-268,124,170,shirt,40);E(cx,G-310,100,100,"#f2c08f");P(f"M{cx-50} {G-315} Q{cx-50} {G-372} {cx} {G-366} Q{cx+50} {G-372} {cx+50} {G-315} Q{cx+20} {G-345} {cx-50} {G-315}Z","#2b2730")
    E(cx-16,G-308,10,12,INK);E(cx+16,G-308,10,12,INK);P(f"M{cx-14} {G-286} Q{cx} {G-276} {cx+14} {G-286}",None,INK,4)
    rot=[[0,0]];y=[[0,"+0"]];x=[[0,"+0"]]
    for k,s in enumerate(SEC):
        for fr in range(secS[k],secE[k]+8,2):
            ph=2*math.pi*(fr/FPS)/s["per"]+phase
            y.append([fr,f"{-abs(math.sin(ph))*s['amp']*0.35:+.1f}"]);rot.append([fr,s["lean"]]);x.append([fr,f"{(xoff(fr) if xoff else 0)+s['lean']*2:+.1f}"])
    anim(n,{"y":y,"rotation":rot,"x":x,"alpha":on},"Linear")
ALL=[[0,0],[secS[0],0],[secS[0]+10,100],[secE[3],100],[secE[3]+8,0]]
R2=[[0,0],[secS[2],0],[secS[2]+10,100],[secE[2],100],[secE[2]+6,0]]
person("Blue",330,"#3b6fd8",1.3,lambda fr:-40*math.sin(fr/50),R2)
person("Pink",750,"#e05a9b",2.1,lambda fr:40*math.sin(fr/43+1),R2)
person("Me",540,"#2e8b4a",0,None,ALL)
# speed lines for running
layer("Lines")
for j,(y0,w0) in enumerate(((G-330,160),(G-250,220),(G-180,140),(G-120,200))): R(120+j*40,y0,w0,8,"#ffffff",4)
anim("Lines",{"alpha":[[0,0],[secS[3],0],[secS[3]+10,85],[secE[3],85],[secE[3]+6,0]],"x":[[fr,"+0" if (fr//6)%2 else "-60"] for fr in range(secS[3],secE[3]+6,3)]},"Linear")
# ---------- section label + speed meter ----------
for k,s in enumerate(SEC):
    a,b=secS[k],secE[k]
    layer(f"Lab{k}");R(270,110,540,170,"#ffffff",34);T(s["ar"],118,70,INK,AR,270,540);T(f"{s['ku']} · {s['why']}",222,40,s["col"],KU,270,540)
    anim(f"Lab{k}",{"alpha":[[0,0],[a+4,0],[a+14,100],[b,100],[b+6,0]],"y":[[0,"-60"],[a+4,"-60"],[a+18,"+0"]]})
layer("Meter");R(860,330,170,86,"#ffffff",22)
for j in range(4): R(886+j*36,396-(j+1)*13,24,(j+1)*13,"#d9d4cc",5)
anim("Meter",show(secS[0]+10,secE[3]))
for j,s in enumerate(SEC):
    layer(f"M{j}");R(886+j*36,396-(j+1)*13,24,(j+1)*13,s["col"],5)
    anim(f"M{j}",{"alpha":[[0,0],[secS[j]+14,0],[secS[j]+20,100],[secE[3],100],[secE[3]+6,0]],"scale_y":[[0,100],[secS[j]+14,20],[secS[j]+22,100]]})
# ---------- overlays: s (big word) and q (ayah) ----------
for k,s in enumerate(SEC):
    si,qi=2+3*k,3+3*k
    a=S(si);b=S(qi)+0;q0=S(qi);q1=Ee(qi)+10
    layer(f"Dim{k}");R(0,0,W,H,"#121014")
    anim(f"Dim{k}",{"alpha":[[0,0],[a-6,0],[a+6,72],[q1-6,82],[q1+4,0]]})
    layer(f"Big{k}");T(s["ar"],640,190,s["col"],AR);T(s["ku"],"below:Big{k}+0".replace("{k}",str(k)) if False else 930,110,"#ffffff");T(s["why"],1070,56,"#d9d4cc")
    anim(f"Big{k}",{"alpha":[[0,0],[a,0],[a+8,100],[b-8,100],[b-2,0]],"scale_x":[[0,100],[a,70],[a+10,108],[a+14,100]],"scale_y":[[0,100],[a,70],[a+10,108],[a+14,100]]})
    ay=LN[qi]["ayah"]
    layer(f"Ay{k}");T(ay["ar"],600,88,"#ffffff",AR,40,1000,1.5)
    anim(f"Ay{k}",show(q0+4,q1-4,10,40))
    layer(f"Hl{k}");T(ay["hl"],380,150,s["col"],AR)
    anim(f"Hl{k}",{"alpha":[[0,0],[q0,0],[q0+6,100],[q1-8,100],[q1-2,0]],"scale_x":[[0,100],[q0,60],[q0+10,110],[q0+15,100]],"scale_y":[[0,100],[q0,60],[q0+10,110],[q0+15,100]]})
    layer(f"Tr{k}");T(ay["ku"],"below:Ay{}+50".format(k),54,"#f7d79a")
    anim(f"Tr{k}",show(q0+14,q1-4,10,30))
    layer(f"Ref{k}");T(s["ref"].strip("﴿﴾ ").replace(" : "," · ئایەتی "),"below:Tr{}+40".format(k),42,"#d9d4cc")
    anim(f"Ref{k}",show(q0+20,q1-4,10,30))
# ---------- captions for narration ----------
for i in (4,7,10,13):
    a,b=S(i),Ee(i)+12;layer(f"Cap{i}");nl=math.ceil(len(LN[i]["text"])*50*0.42/940);R(50,1415,980,90+nl*68,"#121014",36);T(LN[i]["text"],1448,50,"#ffffff",KU,70,940,1.35)
    anim(f"Cap{i}",show(a,b,8,40))
# ---------- intro and end panels ----------

def mini(name,cx,gy,k,shirt,s,a,b,phase=0):
    hip=gy-112*k;L=100*k;rng=range(a,(b or N),2)
    for leg,sg in (("La",1),("Lb",-1)):
        n=f"{name}{leg}";layer(n);R(cx-11*k,hip,22*k,L-6*k,"#2a52be",8*k);E(cx+8*k,gy-8*k,46*k,20*k,"#2b2730")
        rot=[[0,0]];x=[[0,"+0"]];y=[[0,"+0"]]
        for fr in rng:
            th=sg*s["amp"]*math.sin(2*math.pi*(fr/FPS)/s["per"]+phase);r=math.radians(th)
            rot.append([fr,round(th,1)]);x.append([fr,f"{-math.sin(r)*L/2:+.1f}"]);y.append([fr,f"{(math.cos(r)-1)*L/2:+.1f}"])
        anim(n,{"rotation":rot,"x":x,"y":y,"alpha":VIS},"Linear")
    n=f"{name}Top";layer(n)
    R(cx-62*k,gy-268*k,124*k,170*k,shirt,40*k);E(cx,gy-310*k,100*k,100*k,"#f2c08f")
    P(f"M{cx-50*k} {gy-315*k} Q{cx-50*k} {gy-372*k} {cx} {gy-366*k} Q{cx+50*k} {gy-372*k} {cx+50*k} {gy-315*k} Q{cx+20*k} {gy-345*k} {cx-50*k} {gy-315*k}Z","#2b2730")
    E(cx-16*k,gy-308*k,10*k,12*k,INK);E(cx+16*k,gy-308*k,10*k,12*k,INK)
    y=[[0,"+0"]];rot=[[0,0]]
    for fr in rng: y.append([fr,f"{-abs(math.sin(2*math.pi*(fr/FPS)/s['per']+phase))*s['amp']*0.35*k:+.1f}"]);rot.append([fr,s["lean"]])
    anim(n,{"y":y,"rotation":rot,"alpha":VIS},"Linear")
def panel(name,a,b,title):
    layer(name+"Bg");R(0,0,W,H,CREAM);anim(name+"Bg",{"alpha":[[0,0 if a>0 else 100],[a,0 if a>0 else 100],[a+10,100]]+([[b-8,100],[b,0]] if b else [])})
    layer(name+"Card");R(80,120,920,330,"#fffaf0",44)
    if title=="intro":T("أَرۡبَعُ سُرُعَاتٖ فِي ٱلۡقُرۡءَانِ",150,84,INK,AR);T("چوار خێرایی لە قورئاندا",290,72,"#12805c");T("تێڕامانێک لە ئایەتەکان",385,38,"#8c8796")
    else:T("بۆ دنیا بڕۆ...",190,92,INK);T("بۆ خوا ڕابکە.",310,104,"#d9531e")
    anim(name+"Card",{"alpha":[[0,0],[a+2,0],[a+12,100]]+([[b-8,100],[b,0]] if b else []),"y":[[0,"-50"],[a+2,"-50"],[a+16,"+0"]]})
    for j,s in enumerate(SEC):
        y=540+j*320;n=f"{name}R{j}";layer(n);R(0,y,W,300,s["sky"]);R(0,y+230,W,70,s["walk"])
        aa=a+10+j*6;VIS_=[[0,0],[aa,0],[aa+10,100]]+([[b-8,100],[b,0]] if b else [])
        anim(n,{"alpha":VIS_})
        # moving buildings behind the walker, at that row's speed
        nb=f"{name}B{j}";layer(nb)
        for o in (0,540):
            for bx,bw,bh in ((10,90,120),(130,110,160),(270,80,100),(380,120,140)): R(o+bx,y+230-bh,bw,bh,s["bld"])
        per2=max(2,f(540/s["spd"]));xk=[[0,"+0"]];t0=aa
        while t0<(b or N): xk+=[[t0,"+0"],[t0+per2-1,f"-{540*(per2-1)/per2:.0f}"]];t0+=per2
        anim(nb,{"x":xk,"alpha":VIS_},"Linear")
        global VIS;VIS=VIS_
        mini(f"{name}W{j}",270,y+262,0.62,"#2e8b4a",s,aa,b,j)
        nc=f"{name}C{j}";layer(nc);R(560,y+50,420,200,"#ffffff",28);T(s["ar"],y+62,70,INK,AR,560,420);T(s["ku"],y+170,48,s["col"],KU,560,420)
        anim(nc,{"alpha":VIS_,"x":[[0,"+200"],[aa,"+200"],[aa+14,"+0"]]})

panel("In",0,secS[0]+6,"intro")
panel("Out",S(14)-8,None,"end")
json.dump({"stage":{"width":W,"height":H,"fps":FPS,"background":CREAM},"frames":N,"steps":st},open("qs.json","w"),ensure_ascii=False)
print(N,len(st),sum(len(v) for s_ in st if s_[0]=="@animate" for v in s_[1]["keys"].values()))
