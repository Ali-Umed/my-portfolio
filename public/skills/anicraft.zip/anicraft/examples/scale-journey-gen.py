import json,math,random
W,H,F=1080,1350,30;CX,CY=540,560
ST=json.load(open("../story.json"))
f=lambda t:int(round(t*F));N=f(90)
INK="#ffffff";ACT="#F7941D";MUT="#8c8796";FONT="Rabar_031"
st=[];first=[True]
def layer(n): st.append(["layer.rename" if first[0] else "layer.new",{"name":n}]);first[0]=False
def E(x,y,w,h,c): st.append(["draw.ellipse",{"x":x-w/2,"y":y-h/2,"w":w,"h":h,"fill":c}])
def C(x,y,r,c): E(x,y,2*r,2*r,c)
def R(x,y,w,h,c,r=0): st.append(["draw.rect",{"x":x,"y":y,"w":w,"h":h,"radius":r,"fill":c}])
def P(d,c=None,s=None,sw=0): st.append(["draw.path",{"d":d,"fill":c}|({"stroke":s,"stroke_width":sw} if s else {})])
import re
def text(s,y,size,col=INK):
    s=re.sub(r"[٠-٩][٠-٩.,]*",lambda m:m.group(0)[::-1],s)
    st.append(["text.create",{"text":s,"x":40,"y":y,"width":1000,"size":size,"font":FONT,"bold":True,"color":col,"align":"center"}])
def anim(n,k,ease="CubicOut"):
    k={p:sorted({fr:[fr,v] for fr,v in pts}.values()) for p,pts in k.items()}
    st.append(["@animate",{"layer":n,"keys":k,"ease":ease}])
# --- objects, each centred on CX,CY ---
def ant():
    for dx,r in((-120,55),(0,45),(110,70)): E(CX+dx,CY,r*2,r*1.6,"#3a2a22")
    for dx in(-40,0,40): P(f"M{CX+dx} {CY} L{CX+dx-50} {CY+110} M{CX+dx} {CY} L{CX+dx+50} {CY+110}",None,"#3a2a22",14)
    P(f"M{CX-150} {CY-30} Q{CX-200} {CY-130} {CX-250} {CY-110}",None,"#3a2a22",10)
def human():
    C(CX,CY-240,70,"#ffd9b8");R(CX-80,CY-160,160,240,ACT,50);R(CX-70,CY+70,55,200,"#2b2730",20);R(CX+15,CY+70,55,200,"#2b2730",20)
def tower():
    R(CX-90,CY-330,180,660,"#3a3f52",8);R(CX-40,CY-420,80,100,"#3a3f52",6);P(f"M{CX} {CY-560} L{CX} {CY-420}",None,"#3a3f52",12)
    for y in range(-300,300,60):
        for x in(-60,0,40): R(CX+x,CY+y,24,30,"#F7c97a")
def everest():
    P(f"M{CX-420} {CY+300} L{CX} {CY-320} L{CX+420} {CY+300}Z","#4a4558");P(f"M{CX-120} {CY-140} L{CX} {CY-320} L{CX+120} {CY-140} L{CX+50} {CY-170} L{CX} {CY-120} L{CX-50} {CY-170}Z","#ffffff")
def earth():
    C(CX,CY,300,"#2563eb");P(f"M{CX-200} {CY-120} Q{CX-120} {CY-230} {CX-20} {CY-150} Q{CX+40} {CY-60} {CX-60} {CY} Q{CX-180} {CY+40} {CX-200} {CY-120}Z","#22a35a")
    P(f"M{CX+60} {CY+60} Q{CX+180} {CY} {CX+230} {CY+120} Q{CX+160} {CY+240} {CX+80} {CY+180}Z","#22a35a")
def moon():
    C(CX-330,CY,90,"#2563eb");C(CX+330,CY,45,"#c9c4cf")
    P(f"M{CX-230} {CY} L{CX+275} {CY}",None,MUT,6)
def sun():
    C(CX,CY,330,ACT);C(CX-330+20,CY+300,6,"#2563eb")
def solar():
    for i,r in enumerate([60,95,135,180,260,330,390,440]):
        P(f"M{CX-r} {CY} A{r} {r*0.42} 0 1 0 {CX+r} {CY} A{r} {r*0.42} 0 1 0 {CX-r} {CY}",None,"#3a3646",3)
        a=i*1.7;C(CX+r*math.cos(a),CY+r*0.42*math.sin(a),[6,9,10,8,24,20,14,14][i],["#9a9aa5","#e8c07a","#2563eb","#d9603b","#e0b07a","#e8d29a","#8fd3e8","#3b6fe0"][i])
    C(CX,CY,30,ACT)
def galaxy():
    random.seed(4)
    for arm in range(3):
        for k in range(70):
            t=k/70*4.2;r=30+k*5.6;a=t+arm*2*math.pi/3
            C(CX+r*math.cos(a)+random.uniform(-14,14),CY+r*0.62*math.sin(a)+random.uniform(-10,10),random.choice([3,4,5,7]),random.choice(["#ffffff","#cfc9ff",ACT]))
    E(CX,CY,140,90,"#ffe1b0")
def universe():
    random.seed(9)
    for k in range(260):
        a=random.uniform(0,2*math.pi);r=420*math.sqrt(random.random())
        C(CX+r*math.cos(a),CY+r*math.sin(a),random.choice([2,3,4,6]),random.choice(["#ffffff","#cfc9ff","#9fb6ff",ACT]))
    P(f"M{CX-440} {CY} A440 440 0 1 0 {CX+440} {CY} A440 440 0 1 0 {CX-440} {CY}",None,"#3a3646",4)
OBJ=[ant,human,tower,everest,earth,moon,sun,solar,galaxy,universe]
# intro
layer("I1");text("لە مێروولەیەکەوە...",470,92);anim("I1",{"alpha":[[0,0],[8,100],[f(3.4),100],[f(3.9),0]],"y":[[0,"+40"],[14,"+0"]]})
layer("I2");text("تا کۆتایی گەردوون",600,104,ACT);anim("I2",{"alpha":[[0,0],[f(1),0],[f(1.4),100],[f(3.4),100],[f(3.9),0]],"y":[[0,"+40"],[f(1),"+40"],[f(1.5),"+0"]]})
# progress dots
for i in range(10):
    layer(f"D{i}");C(135+i*90,1290,9,ACT)
    a=f(4+8*i);anim(f"D{i}",{"alpha":[[0,0],[f(4),0],[f(4.5),35],[a,35],[a+8,100]]})
for i,(name,size) in enumerate(ST):
    a=f(4+8*i);b=a+f(8)
    layer(f"O{i}");OBJ[i]()
    sc=[[0,40],[a,40],[a+f(1),100],[b-f(1),112],[b,8]]
    al=[[0,0],[a,0],[a+f(0.6),100],[b-f(0.5),100],[b,0]]
    k={"scale_x":sc,"scale_y":sc,"alpha":al}
    if i in(7,8): k["rotation"]=[[0,0],[a,0],[b,-25 if i==8 else 0]]
    anim(f"O{i}",k,"CubicInOut")
    layer(f"N{i}");text(name,1000,92)
    anim(f"N{i}",{"alpha":[[0,0],[a+12,0],[a+24,100],[b-12,100],[b-4,0]],"y":[[0,"+40"],[a+12,"+40"],[a+28,"+0"]]})
    layer(f"S{i}");text(size,1120,64,ACT)
    anim(f"S{i}",{"alpha":[[0,0],[a+20,0],[a+32,100],[b-12,100],[b-4,0]],"y":[[0,"+40"],[a+20,"+40"],[a+36,"+0"]]})
# end
e=f(84)
layer("E0");C(CX,CY,10,ACT);anim("E0",{"alpha":[[0,0],[e,0],[e+10,100]],"scale_x":[[0,100],[e,300],[e+20,100]],"scale_y":[[0,100],[e,300],[e+20,100]]})
layer("E1");text("و ئێمە... تەنها خاڵێکین",760,88);anim("E1",{"alpha":[[0,0],[e+15,0],[e+30,100]],"y":[[0,"+40"],[e+15,"+40"],[e+33,"+0"]]})
layer("E2");text("بۆ هاوڕێکانتی بنێرە",900,64,ACT);anim("E2",{"alpha":[[0,0],[e+50,0],[e+64,100]],"y":[[0,"+40"],[e+50,"+40"],[e+66,"+0"]]})
json.dump({"stage":{"width":W,"height":H,"fps":F,"background":"#121014"},"frames":N,"steps":st},open("scale.json","w"),ensure_ascii=False)
print(N,len(st))
