"""AniCraft runner: validate, build, render and score 2D animations headless (anicraft-cli serve).

  anicraft.py check  --recipe R.json | --steps '[...]'        validate only (no engine run)
  anicraft.py apply  --recipe R.json OUT_STEM [--render mp4,gif,lottie,webm,png,sheet] [--critic] [--force]
  anicraft.py template list | show ID | apply ID OUT_STEM [--var k=v ...] [--render ...] [--critic]
  anicraft.py critic FILE.anicraft [--recipe R.json]
  anicraft.py sheet  FILE.anicraft [--n 8]                    contact sheet PNG of N frames

Recipe: {"stage": {width, height, fps, background}, "frames": N, "loop"?: bool,
         "steps": [[cmd, params] | {"cmd", "params"} | ["@animate", {...}]]}
Layers are referred to by NAME ("layer": "Title"); the runner maps names to ids. Frames in recipes are
0-based like the engine (frame 0 = first). Output is short on purpose: one line per step only on error.
"""
import argparse
import json
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.dirname(HERE)
CLI = os.path.expanduser("~/.local/bin/anicraft-cli")
EASES = ["Linear", "QuadIn", "QuadOut", "QuadInOut", "CubicIn", "CubicOut", "CubicInOut", "Smooth"]
MOTION_PROPS = {"x", "y", "scale_x", "scale_y", "rotation", "skew", "alpha", "brightness", "tint", "tint_red",
                "tint_green", "tint_blue", "red_multiplier", "green_multiplier", "blue_multiplier",
                "alpha_multiplier", "red_offset", "green_offset", "blue_offset", "alpha_offset"}
FLAT_SHAPES = {"draw.rect", "draw.ellipse", "draw.star", "draw.path"}
EXPORTS = {"mp4": ("file.export_video", ".mp4"), "webm": ("file.export_video", ".webm"),
           "gif": ("file.export_gif", ".gif"), "lottie": ("file.export_lottie", ".json"),
           "png": ("file.export_png_sequence", "_frames"), "sprite": ("file.export_sprite_sheet", "_sprite.png")}


def die(msg):
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(1)


def cli(*args, inp=None):
    p = subprocess.run([CLI, *args], capture_output=True, text=True, input=inp, timeout=600)
    return p.stdout, p.stderr, p.returncode


_REG = _FONTS = None


def registry():
    global _REG
    if _REG is None:
        out, err, rc = cli("commands")
        if rc:
            die(f"anicraft-cli commands failed: {err.strip()}")
        _REG = {c["id"]: c for c in json.loads(out)}
    return _REG


def fonts():
    global _FONTS
    if _FONTS is None:
        out, _, _ = cli("exec", "--sample", "text.fonts", "{}", inp="")
        try:
            _FONTS = set(json.loads(out[out.find("{"):])["families"])
        except (ValueError, KeyError):
            _FONTS = set()
    return _FONTS


def doc_keys(doc):
    """Top-level keys of a params doc like '{x, y, radius?, fill?: …} or {index}'. Returns (keys, open_ended)."""
    keys, depth, i, n, key_pos, opened = set(), 0, 0, len(doc or ""), False, False
    doc = doc or ""
    while i < n:
        ch = doc[i]
        if ch == "{":
            depth += 1
            key_pos = depth == 1
            opened = True
        elif ch == "}":
            depth = max(0, depth - 1)
        elif ch in "([":
            depth += 10
        elif ch in ")]":
            depth = max(0, depth - 10)
        elif depth == 1 and ch == ",":
            key_pos = True
        elif depth == 1 and key_pos and (ch.isalpha() or ch == "_"):
            j = i
            while j < n and (doc[j].isalnum() or doc[j] == "_"):
                j += 1
            if j >= n or doc[j] in "?:,}= |":
                keys.add(doc[i:j])
            key_pos = j < n and doc[j] == "|"
            i = j
            continue
        elif depth == 1 and not ch.isspace() and ch != "|":
            key_pos = False
        i += 1
    return keys, ("…" in doc and depth == 0 and not keys) or not opened


# ------------------------------------------------------------------ recipe → steps

def norm(step):
    if isinstance(step, dict):
        return step.get("cmd") or step.get("command"), dict(step.get("params") or {})
    return step[0], dict(step[1] if len(step) > 1 else {})


def fill_vars(obj, vars_):
    if isinstance(obj, str):
        def rep(m):
            v = vars_.get(m.group(1), m.group(0))
            return str(v)
        whole = re.fullmatch(r"\{\{(\w+)\}\}", obj)
        if whole and whole.group(1) in vars_:
            return vars_[whole.group(1)]  # keeps the var's type: "-300" stays a relative string, 1080 a number
        return re.sub(r"\{\{(\w+)\}\}", rep, obj)
    if isinstance(obj, list):
        return [fill_vars(x, vars_) for x in obj]
    if isinstance(obj, dict):
        return {k: fill_vars(v, vars_) for k, v in obj.items()}
    return obj


def check(recipe, strict=True):
    """Return a list of problems (empty = ok). No engine run."""
    reg, probs = registry(), []
    frames = recipe.get("frames")
    stage = recipe.get("stage", {})
    for k in stage:
        if k not in ("width", "height", "fps", "background"):
            probs.append(f"stage: unknown key {k!r}")
    for i, raw in enumerate(recipe.get("steps", [])):
        cmd, p = norm(raw)
        if cmd == "@animate":
            for k in p:
                if k not in ("layer", "start", "end", "from", "to", "keys", "ease"):
                    probs.append(f"step {i} @animate: unknown key {k!r}")
            props = set(p.get("from", {})) | set(p.get("to", {})) | set(p.get("keys", {}))
            for pr in props - MOTION_PROPS:
                probs.append(f"step {i} @animate: unknown property {pr!r} (use {sorted(MOTION_PROPS)[:8]}…)")
            eases = p.get("ease", "CubicOut")
            eases = [x for v in eases.values() for x in (v if isinstance(v, list) else [v])] \
                if isinstance(eases, dict) else (eases if isinstance(eases, list) else [eases])
            for e in eases:
                if e not in EASES:
                    probs.append(f"step {i} @animate: ease {e!r} not in {EASES}")
            if frames is not None and max(p.get("end", 0), p.get("start", 0)) >= frames:
                probs.append(f"step {i} @animate: end {p.get('end')} is past the last frame {frames - 1} (frames are 0-based)")
            continue
        if cmd not in reg:
            near = [c for c in reg if c.split(".")[-1] == str(cmd).split(".")[-1]][:3]
            probs.append(f"step {i}: unknown command {cmd!r}" + (f" (did you mean {near})" if near else ""))
            continue
        doc = (reg[cmd].get("params") or "").strip()
        keys, open_ended = doc_keys(doc)
        no_params = doc.startswith("{}")
        for k in p:
            if k == "confirm":
                continue
            if no_params or (keys and k not in keys and not open_ended):
                probs.append(f"step {i} {cmd}: unknown param {k!r} — AniCraft ignores it silently (known: {sorted(keys)})")
        if "easing" in p and p["easing"] not in EASES:
            probs.append(f"step {i} {cmd}: easing {p['easing']!r} not in {EASES}")
        if cmd == "text.create" and p.get("font") and fonts() and p["font"] not in fonts():
            probs.append(f"step {i} text.create: font {p['font']!r} is not installed (falls back to Arial)")
        if frames is not None and isinstance(p.get("frame"), int) and p["frame"] >= frames:
            probs.append(f"step {i} {cmd}: frame {p['frame']} is past the last frame {frames - 1} (0-based)")
    return probs


# ------------------------------------------------------------------ engine session

class Session:
    def __init__(self):
        self.p = subprocess.Popen([CLI, "serve"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=subprocess.DEVNULL, text=True, bufsize=1)
        hello = json.loads(self.p.stdout.readline())
        if not hello.get("ready"):
            die("anicraft-cli serve did not start")
        self.n, self.layers, self.notes, self.boxes = 0, {}, [], {}

    def call(self, cmd, params=None):
        self.n += 1
        self.p.stdin.write(json.dumps({"id": self.n, "cmd": cmd, "params": params or {}}) + "\n")
        self.p.stdin.flush()
        r = json.loads(self.p.stdout.readline())
        if not r.get("ok"):
            raise RuntimeError(f"{cmd}: {r.get('error')}")
        res = r.get("result")
        if isinstance(res, dict) and res.get("note"):
            self.notes.append(f"{cmd}: {res['note']}")
        return res

    def close(self):
        try:
            self.p.stdin.close()
            self.p.wait(timeout=10)
        except Exception:
            self.p.kill()


def resolve(sess, p):
    """Turn layer names into ids (creating nothing)."""
    for key in ("layer",):
        v = p.get(key)
        if isinstance(v, str):
            if v not in sess.layers:
                raise RuntimeError(f"no layer named {v!r} (create it with layer.new {{name}} first)")
            p[key] = sess.layers[v]
    if isinstance(p.get("layers"), list):
        p["layers"] = [sess.layers.get(x, x) if isinstance(x, str) else x for x in p["layers"]]
    return p


def rel(v, base):
    if isinstance(v, str) and re.fullmatch(r"[+-]\d+(\.\d+)?", v):
        return base + float(v)
    return float(v)


def animate(sess, p, frames):
    """@animate {layer, start, end, from:{prop: v}, to:{prop: v} | keys:{prop: [[f, v], …]}, ease}.
    Values may be relative to the element's resting value: "+60" / "-40"."""
    layer = p.get("layer")
    lid = sess.layers[layer] if isinstance(layer, str) else layer
    start, end = int(p.get("start", 0)), int(p.get("end", frames - 1))
    base_params = {"frame": start} | ({"layer": lid} if lid else {})
    if frames > 1:  # the tween spans the whole layer, so keys anywhere in the movie land inside it
        d = sess.call("doc.info") or {}
        lay = next((l for l in d.get("layers", []) if l["id"] == (lid or d.get("layer"))), {})
        end_now = max((k["start"] + k["duration"] for k in lay.get("keyframes", [])), default=1)
        if end_now < frames:  # insert_frame on a long-enough layer would ADD a frame (new layers start at movie length)
            sess.call("timeline.insert_frame", {"frame": frames - 1} | ({"layer": lid} if lid else {}))
    sess.call("timeline.create_motion_tween", base_params)
    info = sess.call("motion.info", {"frame": start} | ({"layer": lid} if lid else {})) or {}
    base = (info.get("values") if isinstance(info, dict) else None) or {}
    # before its first key a tween shows the RESTING value, so hold the from-value from frame 0 (staggers work)
    keys = {k: ([[0, v]] if start > 0 else []) + [[start, v]] for k, v in p.get("from", {}).items()}
    for k, v in p.get("to", {}).items():
        keys.setdefault(k, [[start, base.get(k, 0)]]).append([end, v])
    for k, v in p.get("from", {}).items():
        if k not in p.get("to", {}):
            keys[k].append([end, base.get(k, 0)])
    for k, pts in p.get("keys", {}).items():
        keys[k] = pts
    for prop, pts in keys.items():
        for f, v in pts:
            sess.call("motion.set_key", {"property": prop, "value": rel(v, base.get(prop, 0)), "frame": int(f)}
                      | ({"layer": lid} if lid else {}))
    ease_all = p.get("ease", "CubicOut")
    for prop, pts in keys.items():
        eases = ease_all.get(prop, "CubicOut") if isinstance(ease_all, dict) else ease_all
        segs = pts[:-1]
        if segs and len(segs) > 1 and segs[0][0] == 0 and start > 0 and segs[1][0] == start:
            segs = segs[1:]  # the frame-0 hold segment keeps the default ease (the value doesn't change)
        for (f, _), e in zip(segs, eases if isinstance(eases, list) else [eases] * len(segs)):
            sess.call("motion.set_ease", {"easing": e, "property": prop, "frame": int(f)}
                      | ({"layer": lid} if lid else {}))


def build(recipe, out_stem, renders, force=False):
    stem = os.path.abspath(out_stem)
    proj = stem + ".anicraft"
    if os.path.exists(proj) and not force:
        die(f"{proj} exists (use --force or a new name)")
    os.makedirs(os.path.dirname(stem), exist_ok=True)
    st = recipe.get("stage", {})
    frames = int(recipe.get("frames", 1))
    sess = Session()
    try:
        sess.call("file.new", {k: st[k] for k in ("width", "height", "fps") if k in st})
        if st.get("background"):
            sess.call("doc.set_stage", {"background": st["background"]})
        info = sess.call("doc.info") or {}
        first = (info.get("layers") or [{}])[0]
        if first.get("id") is not None:
            sess.layers[first.get("name", "Layer 1")] = first["id"]
        for i, raw in enumerate(recipe.get("steps", [])):
            cmd, p = norm(raw)
            try:
                if cmd == "@animate":
                    animate(sess, p, frames)
                    continue
                if cmd in FLAT_SHAPES and "stroke" not in p:
                    p["stroke"] = None  # draw tools add a dark outline by default; the user's style is flat
                if cmd == "text.create":
                    p.setdefault("bold", False)  # text inherits the last bold/italic otherwise
                    p.setdefault("italic", False)
                    m = re.fullmatch(r"below:(.+?)([+-]\d+)?", str(p.get("y", "")))
                    if m:  # stack under another layer's text, whatever its wrapped height
                        if m.group(1) not in sess.boxes:
                            raise RuntimeError(f"y below:{m.group(1)}: no text on a layer named {m.group(1)!r} yet")
                        y0, hgt = sess.boxes[m.group(1)]
                        p["y"] = y0 + hgt + float(m.group(2) or 0)
                res = sess.call(cmd, resolve(sess, p))
                if cmd == "text.create" and isinstance(res, dict) and "height" in res:
                    cur = sess.call("doc.info").get("layer")
                    name = next((k for k, v in sess.layers.items() if v == cur), None)
                    if name:
                        sess.boxes[name] = (float(p.get("y", 0)), float(res["height"]))
                if cmd == "camera.add" and isinstance(res, dict) and "layer" in res:
                    sess.layers["Camera"] = res["layer"]  # animate it with @animate {layer: "Camera"}: x/y centre, scale = zoom %
                if cmd == "layer.new" and isinstance(res, dict) and "layer" in res:
                    sess.layers[p.get("name") or f"Layer {res['layer']}"] = res["layer"]
                elif cmd == "layer.rename":
                    lid = p.get("layer") or sess.call("doc.info").get("layer")
                    sess.layers = {k: v for k, v in sess.layers.items() if v != lid} | {p["name"]: lid}
            except RuntimeError as e:
                die(f"step {i} {e}")
        # every layer runs to the last frame (shorter layers would vanish)
        for lay in (sess.call("doc.info") or {}).get("layers", []):
            end = max((k["start"] + k["duration"] for k in lay.get("keyframes", [])), default=1)
            if end < frames:
                sess.call("timeline.insert_frame", {"layer": lay["id"], "frame": frames - 1})
        sess.call("file.save_as", {"path": proj, "confirm": True})
        outs = [proj]
        for r in renders:
            if r == "sheet":
                continue
            cmd, ext = EXPORTS[r]
            path = stem + ext
            try:
                if r == "png":  # the sequence takes a folder, not a path
                    os.makedirs(path, exist_ok=True)
                    sess.call(cmd, {"dir": path})
                else:
                    sess.call(cmd, {"path": path, "confirm": True})
            except RuntimeError as e:
                die(f"export {r}: {e}")
            outs.append(path)
    finally:
        sess.close()
    with open(stem + ".recipe.json", "w") as f:
        json.dump(recipe, f, ensure_ascii=False, indent=1)
    if "sheet" in renders:
        outs.append(sheet(proj))
    for n in sess.notes:
        print(f"note: {n}")
    print("wrote: " + ", ".join(os.path.basename(o) for o in outs) + f"  (in {os.path.dirname(stem)})")
    return proj


# ------------------------------------------------------------------ frames, sheet, critic

def total_frames(proj):
    out, _, _ = cli("info", proj)
    try:
        d = json.loads(out)
        return int(d.get("movie_frames") or d.get("frames") or 1), d
    except ValueError:
        return 1, {}


def render_frames(proj, idxs, scale=0.5):
    import tempfile
    from PIL import Image
    tmp = tempfile.mkdtemp(prefix="ani-")
    ims = []
    for f in idxs:
        path = os.path.join(tmp, f"f{f}.png")
        cli("render", proj, "--out", path, "--frame", str(f + 1), "--scale", str(scale))
        ims.append(Image.open(path).convert("RGB"))
    return ims


def sheet(proj, n=8):
    from PIL import Image, ImageDraw
    total, _ = total_frames(proj)
    idxs = sorted({round(i * (total - 1) / max(1, n - 1)) for i in range(n)})
    ims = render_frames(proj, idxs, 0.25)
    w, h = ims[0].size
    cols = min(4, len(ims))
    rows = (len(ims) + cols - 1) // cols
    out = Image.new("RGB", (cols * (w + 8) + 8, rows * (h + 26) + 8), "#e8e8e8")
    d = ImageDraw.Draw(out)
    for k, (im, f) in enumerate(zip(ims, idxs)):
        x, y = 8 + (k % cols) * (w + 8), 8 + (k // cols) * (h + 26)
        out.paste(im, (x, y))
        d.text((x, y + h + 4), f"frame {f}", fill="#333")
    path = os.path.splitext(proj)[0] + "_sheet.png"
    out.save(path)
    return path


def lum(hexc):
    hexc = hexc.lstrip("#")
    c = [int(hexc[i:i + 2], 16) / 255 for i in (0, 2, 4)]
    c = [x / 12.92 if x <= 0.03928 else ((x + 0.055) / 1.055) ** 2.4 for x in c]
    return 0.2126 * c[0] + 0.7152 * c[1] + 0.0722 * c[2]


def contrast(a, b):
    la, lb = sorted((lum(a), lum(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


def critic(proj, recipe=None):
    import numpy as np
    recipe = recipe or {}
    total, info = total_frames(proj)
    fps = (info.get("stage") or {}).get("fps") or recipe.get("stage", {}).get("fps") or 24
    bg = (info.get("stage") or {}).get("background") or recipe.get("stage", {}).get("background") or "#ffffff"
    loop = recipe.get("loop", False)
    idxs = sorted({round(i * (total - 1) / 7) for i in range(8)} | {total - 1, max(0, total - 1 - int(fps * 0.5))})
    ims = [np.asarray(im).astype(int) for im in render_frames(proj, idxs, 0.5)]
    issues = []

    def add(sev, msg, fix):
        issues.append((sev, msg, fix))

    def flat(a):  # share of pixels that differ from the frame's most common (median) colour
        return (np.abs(a - np.median(a.reshape(-1, 3), axis=0)).sum(axis=2) > 30).mean() < 0.0005
    blank_all = [f for f, a in zip(idxs, ims) if flat(a)]
    blank = [f for f in blank_all if f != 0]  # an empty first frame is a normal fade-in start
    if len(blank_all) == len(ims):
        blank = blank_all
    if len(blank) == len(ims):
        add("severe", "every sampled frame is a flat colour: nothing is drawn", "check the steps drew on a visible layer")
    elif blank and not loop:
        add("minor", f"blank frames at {blank}", "start the first element on frame 0 or trim the start")
    diffs = [np.abs(a - b).mean() for a, b in zip(ims, ims[1:])]
    if max(diffs, default=0) < 0.5 and total > 1:
        add("major", "nothing moves: sampled frames are identical", "add an @animate step")
    secs = total / fps
    if not loop:
        hold = np.abs(ims[idxs.index(total - 1)] - ims[idxs.index(max(0, total - 1 - int(fps * 0.5)))]).mean()
        if hold > 0.5 and secs > 1:
            add("minor", "no hold: still moving in the last 0.5 s", "end motion ≥ 0.5 s (fps/2 frames) before the last frame")
    last = ims[idxs.index(total - 1)]
    bgc = np.array([int(bg.lstrip("#")[i:i + 2], 16) for i in (0, 2, 4)])
    ink = np.abs(last - bgc).sum(axis=2) > 40
    h, w = ink.shape
    if ink.any():
        ys, xs = np.where(ink)
        m = 0.05
        if xs.min() < w * m or xs.max() > w * (1 - m) or ys.min() < h * m or ys.max() > h * (1 - m):
            if not recipe.get("fullBleed"):
                add("minor", "content inside the 5% safe margin on the last frame", "pull it in or set \"fullBleed\": true")
        cx, cy = (xs.min() + xs.max()) / 2, (ys.min() + ys.max()) / 2
        if recipe.get("centered", True) and abs(cx - w / 2) > w * 0.01:
            add("minor", f"composition is {abs(cx - w / 2) * 2:.0f} px off the horizontal centre",
                "the user checks centring by eye: fix x or set \"centered\": false")
        if recipe.get("centered", True) and abs(cy - h / 2) > h * 0.03:
            add("minor", f"composition is {abs(cy - h / 2) * 2:.0f} px {'above' if cy < h / 2 else 'below'} the vertical centre",
                "move the group or set \"centered\": false")
    steps = [norm(s) for s in recipe.get("steps", [])]
    for cmd, p in steps:
        if cmd == "text.create" and p.get("color") and re.fullmatch(r"#[0-9a-fA-F]{6}", bg):
            r = contrast(p["color"], bg)
            if r < 4.5:
                add("major" if r < 3 else "minor", f"text {p.get('text', '')[:24]!r} contrast {r:.1f}:1 on {bg}",
                    "≥ 4.5:1 (darken/lighten the text)")
            t = str(p.get("text", ""))
            if sum(ch.isalpha() for ch in t) > 4 and t.upper() == t and any(ch.isascii() and ch.isalpha() for ch in t):
                add("minor", f"ALL CAPS text {t[:24]!r}", "sentence case (user's style)")
            if not re.search(r"[؀-ۿ]", t) and p.get("letter_spacing", 0) > 2:
                add("minor", f"wide letter spacing on {t[:24]!r}", "normal spacing (user's style)")
            if re.search(r"[؀-ۿ]", t) and p.get("letter_spacing"):
                add("major", "letter spacing on Kurdish/Arabic text breaks joining", "remove letter_spacing")
        if cmd in ("motion.set_ease", "timeline.set_easing") and p.get("easing") == "Linear":
            add("minor", "linear easing looks mechanical", "CubicOut for entrances, CubicIn for exits")
        if cmd == "@animate" and p.get("ease") == "Linear":
            add("minor", "linear easing looks mechanical", "CubicOut for entrances, CubicIn for exits")
    words = sum(len(str(p.get("text", "")).split()) for c, p in steps if c == "text.create")
    if words and not loop and secs < 1.5 + words / 3:
        add("minor", f"{words} words on screen for {secs:.1f} s: too short to read", f"≥ {1.5 + words / 3:.1f} s")
    fills = {str(p.get(k)).lower() for c, p in steps for k in ("fill", "color") if isinstance(p.get(k), str)}
    if len(fills) > 4:
        add("minor", f"{len(fills)} colours: the user's style is one action colour + one accent + neutrals", "cut colours")
    score = max(0, 100 - sum({"severe": 30, "major": 15, "minor": 5}[s] for s, _, _ in issues))
    for s, m, fix in issues:
        print(f"  [{s}] {m} → {fix}")
    ok = score >= 85 and not any(s == "severe" for s, _, _ in issues)
    print(f"score: {score}/100 — {'PASS' if ok else 'FAIL'} ({total} frames, {secs:.1f} s at {fps} fps)")
    return score


# ------------------------------------------------------------------ templates

def tpl_path(tid):
    return os.path.join(SKILL, "templates", f"{tid}.json")


def tpl_load(tid, var_args):
    if not os.path.exists(tpl_path(tid)):
        die(f"no template {tid!r}; see `template list`")
    t = json.load(open(tpl_path(tid)))
    vars_ = {k: v.get("default") if isinstance(v, dict) else v for k, v in t.get("vars", {}).items()}
    for kv in var_args or []:
        k, _, v = kv.partition("=")
        if k not in vars_:
            die(f"template {tid} has no var {k!r} (vars: {', '.join(vars_)})")
        if isinstance(vars_[k], (int, float)) and not isinstance(vars_[k], bool):
            try:
                v = float(v) if "." in v else int(v)
            except ValueError:
                die(f"--var {k} needs a number")
        vars_[k] = v
    return t, fill_vars(t["recipe"], vars_)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check")
    c.add_argument("--recipe")
    c.add_argument("--steps")
    a = sub.add_parser("apply")
    a.add_argument("--recipe", required=True)
    a.add_argument("out_stem")
    t = sub.add_parser("template")
    t.add_argument("action", choices=["list", "show", "apply"])
    t.add_argument("id", nargs="?")
    t.add_argument("out_stem", nargs="?")
    t.add_argument("--var", action="append")
    for p in (a, t):
        p.add_argument("--render", default="mp4,sheet")
        p.add_argument("--critic", action="store_true")
        p.add_argument("--force", action="store_true")
    k = sub.add_parser("critic")
    k.add_argument("file")
    k.add_argument("--recipe")
    s = sub.add_parser("sheet")
    s.add_argument("file")
    s.add_argument("--n", type=int, default=8)
    o = ap.parse_args()
    if not os.path.exists(CLI):
        die("anicraft-cli not installed: python3 -I ~/.claude/skills/craft-studio/scripts/craft_update.py apply anicraft")

    def run(recipe, stem):
        probs = check(recipe)
        if probs:
            die("recipe check failed:\n  " + "\n  ".join(probs))
        renders = [r for r in o.render.split(",") if r]
        bad = [r for r in renders if r not in EXPORTS and r != "sheet"]
        if bad:
            die(f"unknown render {bad}; use {sorted(EXPORTS) + ['sheet']}")
        proj = build(recipe, stem, renders, o.force)
        if o.critic:
            critic(proj, recipe)

    if o.cmd == "check":
        recipe = json.load(open(o.recipe)) if o.recipe else {"steps": json.loads(o.steps or "[]")}
        probs = check(recipe)
        print("\n".join(probs) if probs else "ok")
        sys.exit(1 if probs else 0)
    if o.cmd == "apply":
        run(json.load(open(o.recipe)), o.out_stem)
    elif o.cmd == "template":
        if o.action == "list":
            for f in sorted(os.listdir(os.path.join(SKILL, "templates"))):
                if f.endswith(".json"):
                    tj = json.load(open(os.path.join(SKILL, "templates", f)))
                    print(f"{f[:-5]:16} {tj.get('title', '')} — vars: {', '.join(tj.get('vars', {}))}")
        elif o.action == "show":
            tj, recipe = tpl_load(o.id, o.var)
            print(json.dumps({"vars": tj.get("vars"), "use": tj.get("use")}, ensure_ascii=False, indent=1))
        else:
            if not o.out_stem:
                die("template apply ID OUT_STEM")
            _, recipe = tpl_load(o.id, o.var)
            run(recipe, o.out_stem)
    elif o.cmd == "critic":
        critic(os.path.abspath(o.file), json.load(open(o.recipe)) if o.recipe else None)
    elif o.cmd == "sheet":
        print(sheet(os.path.abspath(o.file), o.n))


if __name__ == "__main__":
    main()
