---
name: anicraft
description: "Make 2D animation with code through AniCraft, the ArtCraft open-source Adobe Animate/Flash clone (anicraft-cli, .anicraft). Frame-by-frame timelines, motion/classic/shape tweens with easing, symbols, layers, bones, camera, scenes, sound; renders MP4, WebM, GIF, Lottie, PNG sequences and sprite sheets. Validated runner (catches the params AniCraft silently ignores), a critic that measures blank/frozen frames, holds, centring, contrast and the user's flat style, tested templates incl. Kurdish (Sorani RTL). Use it whenever the user mentions AniCraft or an .anicraft file, wants a cartoon-style/2D character or shape animation, a looping sticker or GIF, a bouncing logo, a sprite sheet for a game, or Flash/Animate-style work with the ArtCraft apps. Kinetic type and motion graphics over footage fit EffectCraft; a promo video with no app named fits motion-video. Also builds narrated riddle/explainer videos synced to a voice-over (lines.json), with flat characters ported from SVG."
---

# AniCraft (Animate/Flash-style 2D animation, with code)

AniCraft (`storytold/AniCraft`, Learning Machines, team DJ6XS33FX8; app + CLI 0.2.1 here) is a clean-room
Rust Animate clone. Every menu item is a command (`draw.rect`, `timeline.create_motion_tween`, `motion.set_key`…)
with JSON params; the CLI, `serve`, MCP and the app run the same engine, so a file built headless opens in the
app with real layers, symbols and tweens (`open -a AniCraft out.anicraft`).

**Taste:** flat, bold style (, sentence case, one action colour + one accent +
neutrals, no glow/gradients/outlines/ALL CAPS, everything centred must measure centred). Motion: ease out on
entrances, in on exits, stagger 6–10 frames, hold the final state ≥ 0.5 s (and long enough to read: 1.5 s + 1 s
per 3 words). Squash/stretch only for playful loops.

## Workflow (the runner does the heavy lifting; keep its output small)

```bash
R=~/.claude/skills/anicraft/scripts/anicraft.py
python3 -I $R template list                                   # title-pop, kurdish-title, bounce-loop
python3 -I $R template apply title-pop OUT/name --var title="…" --var action="#…" --render mp4,gif,sheet --critic
python3 -I $R check --recipe R.json                           # validate a custom recipe (no engine run)
python3 -I $R apply --recipe R.json OUT/name --render mp4,lottie,sheet --critic
python3 -I $R critic OUT/name.anicraft --recipe OUT/name.recipe.json
```

1. **Template first**, a custom recipe only when none fits. Recipe = `{"stage": {width, height, fps, background},
   "frames": N, "loop"?: bool, "steps": [[cmd, params], …]}`. Layers by **name** (`layer.rename` the first one,
   `layer.new {name}` the rest; the runner maps names to ids). Read `references/anicraft-engine.md` before
   writing steps; for anything else `grep` `references/anicraft-commands.md` (all 240 commands, 48 KB: never read it whole).
2. **Animate with `@animate`** (one step = tween + keys + eases): `["@animate", {"layer": "Title", "start": 6,
   "end": 26, "from": {"y": "+60", "alpha": 0}, "ease": "CubicOut"}]` or `"keys": {"y": [[0, "-300"], [11,
   "+0"]]}` with `"ease": {"y": ["CubicIn", "CubicOut"]}`. `"+n"/"-n"` are relative to the resting value; plain
   numbers are absolute. Eases: Linear QuadIn QuadOut QuadInOut CubicIn CubicOut CubicInOut Smooth.
3. **Stack text** with `"y": "below:Title+36"` (under that layer's text, whatever it wraps to).
4. **Run with `--critic`; fix until ≥ 85 and no severe issue, then look**: Read `<name>_sheet.png` (8 frames).
   The score misses taste: check spacing, centring and that entrances don't start visible.
5. **Deliver**: the movie/GIF + `.anicraft` paths, the sheet, the score, a 3-row table of what moves and how,
   and how to tweak (`--var`, the recipe, or open it in the app).

## Gotchas (each cost a test run)

- **Unknown param keys are silently ignored** (`"colour"` draws with no colour) and unknown fonts fall back to
  Arial with only a `note`. The runner's `check` rejects both; never skip it.
- **Frames are 0-based in commands, 1-based in `anicraft-cli render --frame`.** A 30-frame movie ends at frame 29.
- Before its first key a tween shows the **resting** value; `@animate` holds the from-value from frame 0 so
  staggered entrances start hidden. With raw `motion.set_key`, add a frame-0 key yourself.
- `draw.*` adds a dark outline and `text.create` inherits the last bold/italic; the runner defaults them off
  (`stroke: null`, `bold: false`). Pass them explicitly when wanted.
- New layers are as long as the movie; `timeline.insert_frame` on a long-enough layer **adds** a frame.
- `render`/exports refuse to overwrite without `"confirm": true` (the runner guards outputs; `--force` replaces).
- `file.export_video` needs ffmpeg (`/opt/homebrew/bin/ffmpeg` is installed).
- Kurdish/Arabic: centred lines, no `letter_spacing` (breaks joining), sizes 10–15% larger than Latin, animate
  whole lines. Tested installed fonts: Rabar_031, Rabar_016, Speda, K24 Kurdish Light, Noto Naskh Arabic UI.
  More: `~/.claude/skills/effectcraft/references/kurdish-rtl.md`.

- **Camera moves (verified 2026-11-14):** add `["camera.add", {}]` as the last build step; the runner names it
  "Camera", so `@animate {"layer": "Camera", "keys": {"x", "y" (view centre, stage px), "scale_x"/"scale_y" (= zoom %)}}`
  gives eased pushes, and two keys one frame apart make a hard cut between shots. `camera.set {frame}` alone does
  NOT keyframe. Zoom < 100 shows the stage edge. Example: `rezhna/17-anicraft/gen2.py` (6 shots on one world).
- **One `@animate` per layer.** Each call makes a new tween; put every property's keys for the whole movie in
  one `"keys"` dict (hard cuts = two keys one frame apart).
- **Alpha is 0–100 only** (`set_key` errors on 115). Overshoot pops go on `scale_x`/`scale_y`, never alpha.
- The critic's contrast check measures text against the stage background, so dark text on a white bubble
  reads as "1:1" and drops the score to 0: a false positive, judge by the sheet.
- Fonts: Tajarib/Rooftop aren't installed; Kurdish/Arabic use Rabar_031, English "Helvetica Neue".

## Narrated videos (riddles, explainers): proven 2026-11-14

Generate the recipe with a small Python `gen.py` instead of writing JSON by hand. Working examples:
`examples/candle-riddle-gen.py` (shapes + text per language) and `examples/river-riddle-gen.py` (flat SVG
characters ported 1:1 with a path-transform helper `T(d, ox, oy, k)`, riders on a boat, dimming, X marks,
countdown, CTA).
1. Voice first (any TTS that writes per-line timings) → `audio/lines.json`; the generator
   reads segment start/end and turns them into frames (`f = round(t*30)`), so the scenes follow the voice.
2. `check`, then `apply … --render mp4,sheet --critic --force`; Read the sheet.
3. Mux: `ffmpeg -i out/x.mp4 -i audio/vo.wav -c:v libx264 -crf 18 -pix_fmt yuv420p -c:a aac -shortest final.mp4`;
   16:9 YouTube = blurred-background overlay of the 9:16.
Characters: each one is its own layer drawn at its home spot; move it with relative keys (`"+310"`).
Measured on the 47 s river riddle: AniCraft renders in 11 s against 26 s for the HTML/Chrome capture; a rebuild
took about 2 minutes once the design existed. Limits: parts move, turn, scale and fade but don't bend (bones are
untested), and there's no stroke-dash ring animation.

### Lessons from the 82 s Quran explainer (2026-11-14): `examples/quran-speeds-gen.py`

- **Kurdish/Arabic digits come out reversed** (١.٧ renders as ٧.١). Reverse each digit run before `text.create`:
  `re.sub(r"[٠-٩][٠-٩.,]*", lambda m: m.group(0)[::-1], s)`.
- **Wrapped RTL text stacks its lines bottom-up.** Wrap by hand (≈ `width / (size*0.42)` chars a line) and make
  one `text.create` per line; size any card behind it from the line count.
- **Quran text:** the font "KFGQPC HAFS Uthmanic Script" is installed and renders harakat well, but it turns
  `﴿ … : ١٥ ﴾` into an ayah-end glyph. Write the surah/ayah reference in Rabar: `الملك · ئایەتی ١٥`.
- **Walk cycle with a hip pivot:** a layer rotates about its own centre, so key the leg's `rotation` θ and
  compensate `x = -sin θ · L/2`, `y = (cos θ - 1) · L/2` (L = leg length) every 2 frames, ease Linear. Body bob
  = `-|sin(phase)| · amp · 0.35`; speed = period (walk 1.0 s, hurry 0.7, race 0.48, run 0.3) plus a lean
  rotation; scroll a 2×1080 background strip at the same speed. `mini()` in the example draws a scaled walker.
- **Keys:** drop keys at frame ≥ N and de-duplicate frames per property, or `set_key`/`set_ease` errors.
- 107 layers / 35 000 keys rendered 82 s in 39 s (the HTML capture took 68 s); the build took minutes once the
  layout existed, against about 5 hours for the first HTML version.
- **Opening in the app:** `open -a AniCraft file.anicraft` fails ("cannot open files in the AniCraft Document
  format"); use the app's Open… button on the start screen. The window shows the layers, the timeline and the
  Motion Editor (curves per property), so the result stays editable by hand.
- **"Made with AniCraft" posts:** screen recording is blocked here, so take app screenshots (timeline, select-all
  to show every element, Motion Editor) and add a short end card or a 4:5 grid with the app icon
  (`/Applications/AniCraft.app/Contents/Resources/AniCraft.icns` → `sips -s format png`).

## Other paths (ask first)

`anicraft-cli mcp` registers an MCP server (persistent config: ask). `--plugins <dir>` loads WebAssembly
plug-ins (untrusted code: ask). The app has no control port documented yet; build headless and open the file.

## Keeping it current

`python3 -I ~/.claude/skills/craft-studio/scripts/craft_update.py apply anicraft` installs a verified CLI update;
then `python3 -I ~/.claude/skills/craft-studio/scripts/gen_refs.py anicraft` regenerates the command list.

The complete, always-current command list is `references/anicraft-commands.md` (generated from the installed CLI; prefer it when it disagrees with hand-written references).
