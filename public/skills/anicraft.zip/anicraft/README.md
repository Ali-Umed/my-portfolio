# AniCraft skill for Claude

Makes 2D animation with code through AniCraft (anicraft-cli), the open-source Animate/Flash-style app from the ArtCraft suite.
Claude writes a small Python generator that builds a recipe (layers, shapes, text, motion tweens), the runner checks
and renders it to MP4/GIF/Lottie, and the result is a real `.anicraft` file you can open and edit in the app.

Install: copy this folder to `~/.claude/skills/anicraft/`. Needs `anicraft-cli` (from the AniCraft app), Python 3 and ffmpeg.

Start with `SKILL.md`, then the `examples/` generators:
- `quran-speeds-gen.py`: an 82 s voice-synced explainer with walking characters, Quran text, captions.
- `scale-journey-gen.py`: a 90 s silent motion piece (ant to universe).
- `river-riddle-gen.py`, `candle-riddle-gen.py`: riddle videos synced to a voice-over.
