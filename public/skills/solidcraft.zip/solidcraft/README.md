# SolidCraft skill for Claude

Lets Claude model 3D parts in SolidCraft (Fusion 360-style parametric CAD) with code: sketches, extrude, loft, fillets,
named parameters, STEP/STL/3MF export and snapshots.

Install (Claude Code): copy this folder to `~/.claude/skills/solidcraft/`. Claude apps: upload the zip under
Settings > Capabilities > Skills. Needs SolidCraft with `solidcraft-cli`.

`examples/episode-04/` is from "One car, 17 apps", Episode 4: the prompt, the input (`moon-r1-outlines.json`, the
Episode 2 blueprint outlines), the 3D car Claude built (`moon-r1.sc` with live parameters, `moon-r1.step`,
`moon-r1.png`) and the giant-wing version (`wing.json` changes `wing_height` from 1136 to 1500 mm;
run it with `solidcraft-cli run wing.json --in moon-r1.sc --save moon-r1-wing.sc`; preview `moon-r1-wing.png`).
Video: https://youtu.be/NJ0bcjItuYA
