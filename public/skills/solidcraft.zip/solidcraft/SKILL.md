---
name: solidcraft
description: "Model 3D parts with code through SolidCraft (Tangency Labs, a Fusion 360-style parametric CAD app; solidcraft-cli). Sketches, extrude, boxes, cylinders, holes, fillets, sheet metal, parameters; save .sc designs, open STEP, export STL, 3MF, OBJ, STEP and DXF, and render snapshots. Use it when the user mentions SolidCraft or a .sc design, wants a 3D-printable part, enclosure, bracket or mechanical model, or asks about its CLI or MCP. Sibling - CADCraft for 2D drawings."
---

# SolidCraft (solidcraft-cli)

The CLI ships inside the app (`~/.local/bin/solidcraft-cli` links to it), so it updates with SolidCraft.

```bash
solidcraft-cli commands > /tmp/sc_cmds.json          # 570 commands, ~330 KB: never print it whole; query it:
python3 -c "import json;d={c['id']:c['params'] for c in json.load(open('/tmp/sc_cmds.json'))};print(d['solid.cylinder'])"
solidcraft-cli run part.json --save part.sc --out part.stl [--param-check strict]   # run a script, save + export
solidcraft-cli run --in part.sc --out part.step                                      # convert/export a design
solidcraft-cli eval part.sc                                  # measurements (volume, bounds...) as JSON
solidcraft-cli snapshot --in part.sc --out part.png --width 1080 --height 1080 [--view iso|front|top...]
solidcraft-cli script part.sc --out script.json              # a design's history as a replayable script
```

Script = JSON array of `{"command": id, "params": {...}}`; lengths are mm expressions (strings like "40" or "d/2").
Tested: `[{"command":"solid.box","params":{"length":"40","width":"30","height":"10"}}]` -> .sc + .stl + snapshot.

- **Use `--param-check strict`.** Wrong keys are otherwise ignored silently (e.g. `solid.cylinder` takes `base`,
  not `center`; it also needs `radius` or `diameter`, and `height`).
- Joining bodies: `operation` ("join", "cut", "intersect", "new"), check the command's params for exact names.
- Always snapshot and look; for prints, `eval` the size before exporting STL/3MF.
- MCP: `solidcraft-cli mcp --headless`; `solidcraft-cli mcp setup --client claude-code` changes Claude's config - ask first.

## 2D drawings from the model (tested on Fanos, 2026-11-05)
- `file.export_view_dxf {camera: {target, yaw, pitch, distance, fov: 0}, hidden: omit|dashed, path}` gives exact
  hidden-line views (front: yaw 0 pitch 0; top: pitch 1.5708). ~75 s each. Drop tiny seam stubs (< 3.5 mm) before use.
- `inspect.section` does NOT affect the export, and big box cuts through revolved bodies often fail ("no result").
  For a section view rebuild revolved parts with `angle: 180, direction: symmetric` (back half only) and export that.
- Hatch loops: `sketch.fit_curves_to_section {body}` in a sketch on XZ, then `sketch.export_dxf` (sketch y = -Z).
- Feed the views to CADCraft as plines; example: a small script that writes CADCraft plines.

## Parametric car from 2D outlines (tested in the Craft series Episode 4, 2026-11-21, CLI 0.41.0)
- Named parameters drive the model: `parameters.add {name, expression, unit, comment, favorite}` first, then use the
  names in expressions. Change one later with a script `[{"command":"parameters.change","params":{"name":"wing_height","expression":"1500"}}]`
  run as `solidcraft-cli run wing.json --in car.sc --save car-wing.sc` (rebuilt in ~5 s). Several at once:
  `parameters.change {changes: {a: "1", b: "2"}}`. `parameters.list {filter: "user"}` shows values and what uses them.
- Two-view body: extrude the side outline across the width, trim with the plan outline extruded vertically; if the
  combine fails on a seam tolerance, loft from the front section to the rear section instead.
- Booleans fail when a tool face sits exactly on another face (move the tool ~10 mm) and when joining coplanar
  pieces ("the union would delete face 0") - keep them as separate bodies instead.
- Hide construction sketches before a snapshot: `browser.visibility {folder: "sketches", visible: false}`.
- The default iso camera can make a correct body look like a flat slab: check `eval` bounds and front/left views
  before rebuilding anything.
- Turntable: `snapshot --in car.sc --no-grid --no-axes --camera '{"target":[cx,0,cz],"yaw":Y,"pitch":0.3,"distance":7200,"fov":0.6}'`
  at evenly spaced yaws (~4 s per 1920x1080 frame; 120 angles give a smooth spin at 20 fps).
- `.sc` files keep the parameters; the STEP export is a dead copy (a parameter change on it does nothing).
