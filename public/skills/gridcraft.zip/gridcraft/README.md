# GridCraft skill for Claude

Lets Claude build, edit and check spreadsheets in GridCraft (the open-source Excel-style app from the ArtCraft suite)
with code: formulas, tables, formats, charts, PDF export, and a critic that proves every formula recalculates.

Install (Claude Code): copy this folder to `~/.claude/skills/gridcraft/`. Claude apps: upload the zip under
Settings > Capabilities > Skills. Needs GridCraft with `gridcraft-cli` and Python 3.

`examples/episode-01/` is from "One car, 17 apps", Episode 1: the prompt, the spec sheet Claude built
(`moon-spec.xlsx`, `moon-spec.pdf`), and the wet-road version (tyre grip changed from 1.30 to 0.70).
Video: https://youtu.be/oIwImBqNJLY
