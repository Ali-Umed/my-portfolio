# GridCraft engine reference (gridcraft-cli 0.6.1)

Sources: the storytold/gridcraft docs (AGENTS.md, README, docs/cli.md, control-protocol.md, mcp.md,
gaps.md, file-format-parity.md, function-parity.md, chart-parity.md, …) plus the live registry
(`gridcraft-cli commands --json`: 339 commands; `functions --json`: 513 functions in 0.6.1). **The
live registry is the source of truth.** The CLI is 0.6.1 but the desktop app is still 0.5.0, so a
command added in 0.6.1 works headless and may be missing in live mode (see "Version skew" below). Print exact params with `scripts/gridcraft.py describe <id>`; find ids
with `scripts/gridcraft.py search <word>`.

## How it works
- Every ribbon button, menu item and dialog is an engine **command** (`id` + JSON params). The CLI,
  MCP server and desktop control channel run the same commands, so results equal the app's.
- Commands with params run directly and never open a dialog.
- `gridcraft-cli run [--in FILE | --sample budget|sales|grades] --cmd 'id={json}'… [--script steps.jsonl]
  [--out FILE] [--print RANGE] [--sheet S] [--formulas] [--csv] [--quiet]`. Steps run in order; the
  first failure stops the run with a non-zero exit **and nothing is saved**. `--out` saves at the end.
  A script line is `id={json}`, `id {json}`, `id`, or `{"command":…, "params":…}`; `#` lines are comments.
- Each command prints `{"command": id, "result": …}` when the result is not null.
- **Unknown param keys are silently ignored.** Tested: `home.bold {"rnage":"A2:B2"}` bolded A1 (the
  selection) instead. `gridcraft.py check` rejects them.
- **Unknown values can be silently replaced.** Tested: a `cellIs` rule with `"operator":"lessThan"`
  highlighted the *positive* numbers in 0.5.0 (fixed in 0.6.1, retested). `check` validates the closed
  lists the docs give.
- **Unknown function names become `#NAME?`** with no error. `check` rejects them.
- **Toggles toggle.** `home.bold`/`italic`/`underline`/`wrapText`/… without `"on": true` flip the
  state (decided by the active cell), so a second bold call can switch bold *off*. Always pass `on`.
- Without `range`, a command acts on the current selection of the **active sheet**. A run starts with
  A1 selected on the first sheet. `range.setValues` and `cell.set` don't move the selection.
- Ranges may be sheet-qualified (`"Two!A1"`); `cell.set`, `sheet.read`, `cell.get` also take `sheet`.
  `home.insertSheet` makes the new sheet active; use `sheet.activate {"sheet": "Name"}` to switch.
- The CLI **overwrites files without asking**, including the `--in` file. `gridcraft.py apply`
  refuses to write over the source and over existing outputs (without `--force`).

## Cell values and formulas
| Task | Command and params |
|---|---|
| Fill a block (fastest) | `range.setValues {"range":"A1","values":[["Item","Cost"],["Rent",1200],["Total","=SUM(B2:B2)"]]}`: rows of numbers/strings/bools/null; strings starting with `=` are formulas; ragged rows and `[]` rows are fine |
| One cell | `cell.set {"cell":"B2","input":"=SUM(A1:A9)", "sheet"?: "Data", "array"?: true}` (typed input: `"2026-03-02"`, `"5%"`, `"$12"` become numbers) |
| Same input in every cell, relative refs adjust | `range.fill {"range":"D2:D20","input":"=B2*C2"}` - **bug still in 0.6.1 (retested 2026-10-13): references shift by the active cell, not the range start** (E2:E10 with `=C2-D2` became `=G3-H3…` with A1 active, `#REF!` with H20 active; correct after `selection.set {"range":"E2:E10"}`). Run `selection.set` on the range first, or use `cell.set` + `edit.fillDown` |
| Copy a formula down / right | `cell.set` the first cell, then `edit.fillDown {"range":"D2:D20"}` / `edit.fillRight` |
| Series by example (1,3,5…; Jan, Feb…) | `edit.autoFill {"source":"A2:A3","target":"A2:A13","mode":"series"|"alternate"|"copy"|"formats"|"values"}` (`alternate` = Ctrl+drag: a lone number counts up 1,2,3…, any other series copies; tested 0.6.1) |
| Linear/date series | `edit.fillSeries {"range":"A2:A13","type":"date","dateUnit":"month","step":1}` |
| Dynamic arrays | `cell.set {"cell":"A4","input":"=SORT(UNIQUE(Sales[Region]))"}`; spills; refer to the spill with `A4#` |
| Named range / named LAMBDA | `formulas.defineName {"name":"Rate","refersTo":"=Inputs!$B$2","scope"?:"Workbook","comment"?}`; edit/rename an existing name with `"oldName"`(+`"oldScope"`): formulas follow the new name |
| Evaluate without changing the sheet | `formulas.evaluate {"formula":"=PMT(5%/12,360,-300000)","cell"?}` or `gridcraft-cli eval '=…' [--in FILE]` |
| Every error cell after recalculation | `formulas.errorChecking {}` → `{errors:[{sheet,cell,error,formula}], circular:[…]}` (apply prints it) |
| Recalculation mode / iteration | `formulas.calculationOptions {"mode"?:"automatic"|"automaticExceptTables"|"manual","iterative"?:bool,"maxIterations"?:1-32767,"maxChange"?:0.001}` → the settings (stored in the workbook; all keys optional, `{}` just reads them); `file.options {}` reads them too; `formulas.calculateNow {}` |
| Read values | `sheet.read {"range":"A1:D10","sheet"?,"formulas"?:true,"formatted"?:true}`; `cell.get {"cell":"B2"}` (value, formula, style, comment, link) |
| AutoSum | `formulas.autoSum {"function":"SUM","range":"B2:B9"}` |
| Trace | `formulas.tracePrecedents {"cell":"F15"}` / `formulas.traceDependents {"cell":"B4"}` |

## Formatting
| Task | Command and params |
|---|---|
| Bold / italic / underline | `home.bold {"range":"A1:E1","on":true}` (always pass `on`) |
| Font, size, colour | `home.fontName {"range","name":"Calibri"}`, `home.fontSize {"range","size":14}`, `home.fontColor {"range","color":"#C00000"}` |
| Fill colour | `home.fillColor {"range":"B3:B5","color":"#FFF2CC"}` (`"none"` clears) |
| Number formats | `home.numberFormat {"range","format":"Currency"|"Accounting"|"Percentage"|"Short Date"|…}` or `{"range","code":"#,##0.00"}`; shortcuts `home.accounting {"range","symbol":"$"}`, `home.percent`, `home.comma`, `home.increaseDecimal` |
| Borders | `home.borders {"range","preset":"all"|"outside"|"thickOutside"|"bottom"|"doubleBottom"|"topDoubleBottom"|"none"…,"style"?:"thin"|"medium"|"thick"|"double"|"dashed","color"?:"#hex"}` |
| Cell styles | `home.cellStyle {"range":"A3:E3","name":"Heading 1"|"Heading 2"|"Title"|"Total"|"Good"|"Bad"|"Neutral"|"Accent1"…}` |
| Align, wrap, merge | `home.alignCenter {"range"}`, `home.wrapText {"range","on":true}`, `home.mergeCenter {"range":"A1:E1"}`, `home.orientation {"range","angle":45}` |
| Everything at once (Style JSON) | `home.formatCells {"range","style":{"font":{"bold":true,"color":{"Rgb":16777215}},"fill":{"pattern":"Solid","fg":{"Rgb":2071893}}}}`: colours are `{"Rgb": 0xRRGGBB as an integer}` (`#1F9D55` = 2071893), `{"Theme":[i,tint]}` or `"Auto"`; a hex string fails. Read a cell's `style` with `cell.get` to copy the shape |
| Column width / row height | `home.columnWidth {"cols":"B:E"|"B:B,D:F","chars":14}` (`width` is in **pixels** despite the docs: 64 = default 48 pt), `home.rowHeight {"rows":"2:5"|"2:2,4:5","height":20}` (pixels: 20 = 15 pt), `home.autofitColumnWidth {"cols":"A:F"}`. Whole-sheet font: column style `home.fontName {"range":"A:Z",...}` (new cells inherit it; a cell range like A1:Z300 bloats the used range) |
| Freeze panes | `view.freezePanes {"cell":"A4"}` (rows above, columns left freeze), `view.freezeTopRow {}` |
| Conditional formatting | `home.conditionalFormat {"range":"D4:D10","rule":{"type":"cellIs","operator":"less","value":"0","preset":"lightRedFillDarkRedText"}}`. Operators: `less, greater, between, notBetween, equal, notEqual, greaterOrEqual, lessOrEqual`; 0.6.1 also handles the Excel names `lessThan, greaterThan, lessThanOrEqual` correctly (tested; wrong cells in 0.5.0). Every matching rule now applies, as in Excel. Other types: `{"type":"colorScale","colors":["#63BE7B","#FFEB84","#F8696B"]}`, `{"type":"dataBar","color":"#1F9D55"}`, `{"type":"iconSet","set":…}`, `{"type":"expression","formula":"=$E2>1"}`, `top10`, `duplicate`, `containsText`… Presets: `lightRedFill, redText, yellowFill, greenFill, redBorder, lightRedFillDarkRedText`. Custom `style` uses internal Style JSON: `{"font":{"color":{"Rgb":int}},"fill":{"pattern":"Solid","fg":{"Rgb":int}}}`. Text states: `{"type":"containsText","text":"Done"}`, or in 0.6.1 `cellIs equal` with the plain text `"value":"Done"` (tested); `"\"Done\""` with escaped quotes never matches |
| Clear | `edit.clearFormats {"range"}`, `edit.clearContents {"range"}`, `home.clearRules {"range"}` |
| Workbook theme | `pageLayout.theme {"name":"Craft"|"Slate"|"Meadow"|"Ember"|"Ocean"|"Orchid"|"Graphite","majorFont"?,"minorFont"?}`: theme colours/cell styles; `minorFont` does **not** change existing cells (still Calibri) - set fonts with column styles |

## Sheets, rows, structure
| Task | Command and params |
|---|---|
| Rename / add / delete / move a sheet | `sheet.rename {"sheet"?,"name"}`, `home.insertSheet {"name","before"?}`, `home.deleteSheet {"sheet"}`, `sheet.move {"sheet","to":0,"copy"?}` |
| Switch sheet | `sheet.activate {"sheet":"Summary"}` (name or index) |
| Insert / delete rows, columns | `home.insertRows {"rows":"3:5"}`, `home.deleteColumns {"cols":"C:D"}`, `home.insertCells {"range","shift":"down"}`; after `edit.copy`/`edit.cut`: `home.insertCopiedCells {"at":"B3","shift"?:"down"|"right"}` (cut whole rows/cols = move them) |
| Reorder columns | `sheet.moveColumns {"cols":"B:C","before":5}` (`before` is a zero-based column index) |
| Hide | `home.hideRows {"rows"}`, `home.hideColumns {"cols"}`, `sheet.hide {"sheet"}` |
| Group / outline | `data.group {"rows":"2:5"}` (or `{"by":"rows"|"cols"}` on the selection), `data.ungroup`, `data.hideDetail`/`showDetail {"rows"|"cols"|"by","level"?:1-7}`, `data.showLevels {"rows"?:1-8,"cols"?:1-8}` (outline level buttons), `data.subtotal {"range","groupBy":"A","function":"sum","columns":["C"]}` |
| Notes, comments, links | `review.newNote {"cell","text"}`, `review.newComment {"cell","text","author"?}` (0.6.1 writes threaded comments to XLSX), `review.convertToComments {}`, `review.nextComment`/`previousComment {}` → `{sheet,cell}`, `review.showAllNotes {"on"}`, `insert.link {"cell","target":"https://…"|"Sheet2!A1","text"?}` |
| Protection | `review.protectSheet {"password"?, …}`; `home.lockCell {"range","on":false}` for input cells first; `review.protectWorkbook {"on":true,"password"?}` (structure; pass `on`, it toggles); `review.allowEditRanges {"action":"add","title","range","password"?}` (`list` default, `modify`, `delete`, `unlock`) |
| Checkboxes | `insert.checkbox {"range":"E2:E20"}`: TRUE/FALSE and empty cells draw as checkboxes (empty become FALSE), saved as XLSX cell controls in 0.6.1 |

## Data tools
| Task | Command and params |
|---|---|
| Table | `insert.table {"range":"A1:F49","header":true,"style":"TableStyleMedium2","name":"Sales"}`. A name that looks like a cell reference (`T1`, `AB12`) is silently replaced (`Table1`); use words. Then `Sales[Revenue]` works in formulas. `table.totalRow {"table":"Sales","on":true}`, `table.totalFunction {"table","column":"Revenue","function":"sum"}` |
| Sort | `data.sort {"range":"A1:D50","header":true,"keys":[{"column":"B","order":"asc"},{"column":"C","order":"desc"}]}` |
| AutoFilter | select a cell of a **plain range** (`selection.set {"range":"A1"}`), `data.filter {}`, then `data.filterBy {"column":"B","values":["Art"]}` (or `custom {"op":">","value":"10"}`, `top {"count":5}`). There is no `range` key. On a table, `filterBy` still fails with "no filter" in 0.6.1 (retested): use a slicer |
| Slicer (table filter buttons) | `insert.slicer {"table":"Sales","column":"Region","at":"H2","columns"?,"width"?,"height"?}` (or `table.insertSlicer`) → `{slicer: id}`; `slicer.toggle {"slicer"?,"value":"East","multi"?:false}`, `slicer.selectAll`/`slicer.clear {}`, `slicer.delete {}`. Tested 0.6.1: filters the table rows (`SUBTOTAL(109,…)` follows). **The slicer object is not written to .xlsx** (only the hidden rows are saved) and isn't drawn in PDF/PNG |
| Remove duplicates | `data.removeDuplicates {"range":"A1:D6","header":true,"columns"?:["A","C"]}` → `{removed, remaining}` |
| Validation (dropdown, limits) | `data.validation {"range":"C2:C100","type":"list","formula1":"Yes,No"}` or `{"type":"whole","operator":"between","formula1":"0","formula2":"100","errorMessage":"0-100 only"}`; test with `data.validate {"cell","input"}` |
| Text to columns | `data.textToColumns {"range":"A2:A50","delimiters":[","],"destination":"B2"}` |
| Import CSV/JSON into a new sheet | `data.fromTextCsv {"path"|"text","delimiter"?,"sheet"?}`, `data.getData {"path"|"text"}`; or simply open the CSV with `--in data.csv` |
| PivotTable | `insert.pivotTable {"source":"Sales","destination":"Summary!A18","name":"ByProduct","rows":["Product"],"columns":["Region"],"values":[{"field":"Revenue","func":"sum"}]}`; then `pivot.layout`, `pivot.valueSettings {"field","numberFormat":"#,##0"}`, `pivot.group {"field":"Date","by":"months"}`. **A PivotTable does not follow source edits until `pivot.refresh {"pivot":"ByProduct"}`** (or `data.refreshAll`), like Excel |
| Pivot calculated field | `pivot.calculatedField {"pivot":"ByProduct","name":"Bonus","formula":"=Revenue*0.1","values"?:true,"delete"?:bool}` (fields bare or 'quoted'; computed on the sums; tested 0.6.1) |
| PivotChart | `insert.pivotChart {"pivot":"ByProduct","type":"column"|"bar"|"line"|"pie"|"area"…,"subtype"?,"title"?,"at":"H2","width"?,"height"?}` → `{chart,pivot,series}`: categories = innermost row items, series = column items × value fields; follows refreshes (tested 0.6.1) |
| Goal Seek | `data.goalSeek {"set":"B6","to":500,"changing":"B3"}` (writes the found value into `changing`) |
| Solver | `data.solver {"objective":"B10","goal":"max"|"min"|"value","value"?,"variables":"B2:B4,D1","constraints"?:["B5 <= 10","B2:B4 >= C2:C4","B2 int","B3 bin",{"lhs":"B6","op":"=","rhs":3}],"nonNegative"?:true,"method"?:"grg"|"simplex","keep"?:true,"saveModel"?:true}` → `{status: optimal|converged|iterationLimit|infeasible|unbounded|notLinear, objective, values, …}`; writes the solution (unless `keep:false`) and saves hidden `solver_*` names. Check `status` before trusting it (tested 0.6.1: max of 3x−x² → x=1.5, converged) |
| Forecast Sheet | `data.forecastSheet {"timeline":"A2:A25","values":"B2:B25","periods"?:n | "end"?,"confidence"?:95,"seasonality"?:"auto"|0|2-8760,"statistics"?:bool,"chart"?:"line"|"column"}` → `{sheet,table,chart,…}`: inserts a sheet **before the active one** with a FORECAST.ETS table, confidence bounds and a chart (tested 0.6.1) |
| Analysis ToolPak (static results) | `data.analysisToolPak {"tool":"descriptive"|"regression"|"correlation"|"histogram"|"movingAverage"|"exponentialSmoothing"|"tTestPaired"|…,"range":"B1:B9","labels"?:true,"output"?:"E1"|"newSheet"?:name,"overwrite"?}`; regression takes `inputY`/`inputX`, t-tests/fTest `range1`/`range2`, histogram `bins`. Writes values, not formulas (re-run after data changes); tested descriptive in 0.6.1 |
| Scenarios, data tables | `data.scenarioAdd {"name","changing":"B2:B4","values":[…]}`, `data.scenarioSummary {"resultCells":"B10"}`, `data.dataTable {"range":"D2:E10","columnInput":"B2"}` (static values) |

## Charts, sparklines, pictures
| Task | Command and params |
|---|---|
| Insert a chart | `insert.chart {"range":"A3:C10","type":"column"|"bar"|"line"|"pie"|"doughnut"|"area"|"scatter"|"bubble"|"radar"|"combo"|"histogram"|"waterfall"|"funnel"|"treemap"|"sunburst"|"boxWhisker"|"stock","subtype"?:"clustered"|"stacked"|"stacked100"|"markers","title"?,"at"?:"G3","width"?,"height"?}` (**pixels**, 0.75 pt each) → `{"chart": id}` (ids count all objects: omit `chart` in the following `chart.set`/`chart.changeColors` steps to act on the new chart). Header row → series names, first column → categories; a wide range (months across) gives one series per row. Multi-area ranges give one series only: chart a small block of links instead. A first column of numbers/dates becomes a series, not categories: use text labels |
| Change a chart | `chart.set {"chart":id,"title"?,"legend"?:"bottom"|"none"…,"dataLabels"?:true,"gridlines"?,"xTitle"?,"yTitle"?,"at"?,"width"?,"height"?}`; `chart.changeType {"chart","type","subtype"?}`; `chart.changeColors {"chart","colors":["#1F9D55","#F28E2B"]}`; `chart.formatSelection {"chart","series":0,"color":"#hex"}`; `chart.addElement {"chart","element":"title"|"legend"|"dataLabels"|"gridlines"|"axisTitles"|"smooth","on"}`; trendline (0.6.1, tested): `{"element":"trendline","type":"linear"|"exponential"|"linearForecast"|"movingAverage"|"logarithmic"|"power"|"polynomial","series"?,"order"?,"period"?,"forward"?,"backward"?,"displayEquation"?,"displayRSquared"?}`; `chart.selectData {"chart"?,"range"?,"byRows"?,"categories"?:"Sheet1!A2:A7","removeSeries"?:[i]}` sets axis labels / drops series; `insert.chartRecommendations {"range"}` lists suitable types, `insert.recommendedCharts {"range","type"?,"subtype"?}` inserts one |
| Sparklines | `insert.sparkline {"range":"B2:M2","location":"N2","type":"line"|"column"|"winLoss","markers"?}` |
| Picture | `insert.picture {"path":"/abs/logo.png","at":"B2","width"?,"height"?,"placement"?:"cell"|"overCells","alt"?}` |
| Shapes, text boxes | `insert.shape {"kind":"roundedRectangle","at","width","height","text"?,"fill"?}`, `insert.textBox {"at","width","height","text"}` |

## Files, printing, export
| Task | How |
|---|---|
| Save | `--out book.xlsx` on `run` (or `file.save {"path"}` / `file.saveAs {"path"}`); format from the extension: `.xlsx` (default), `.xlsm` (keeps an existing VBA project, never runs it), `.csv`, `.tsv`, `.json`, `.html`, and in 0.6.1 `.pdf` (a PDF of the **active sheet**, → `{pages,bytes,path}`; tested). 0.6.1 keeps unmodelled XLSX parts on save |
| Convert | `gridcraft-cli convert in.xlsx out.csv [--sheet Name]` (one sheet; CSV holds displayed values in 0.6.1, e.g. `14%` for =1/7 as Percentage, tested; 0.5.0 wrote raw `0.142857…`) |
| PDF | `file.exportPdf {"path":"/abs/out.pdf","sheets"?:"active"|"all","range"?,"fitToPage"?:true}` → `{pages, bytes, path}`; honours each sheet's Page Setup |
| Page setup | `pageLayout.pageSetup {"orientation":"landscape","paper":"A4","fitToPage":true,"fitWidth":1,"fitHeight":0,"printArea":"A1:F50","titleRows":"1:3","header"?,"footer":"&CPage &P of &N","gridlines"?}` |
| Headers / footers | `pageLayout.headerFooter {"sheet"?,"header"?,"footer":"&CPage &P of &N","differentFirst"?,"differentOddEven"?,"firstHeader"?,"firstFooter"?,"evenHeader"?,"evenFooter"?}` or one section `{"part":"footer","section":"right","text":"Page &[Page] of &[Pages]","page"?:"odd"|"even"|"first"}` |
| Sheet view (saved per sheet) | `view.normal`/`view.pageLayout`/`view.pageBreakPreview {"sheet"?}` → `{view}`; `view.formulaBar {"on"}`, `view.zoom100 {}`, `view.ruler {"on"}` (app option) |
| Inspect | `gridcraft-cli info book.xlsx [--json]` (sheets, used ranges, tables, charts, names); `document.inspect {}` |
| Calc + round-trip check (0.6.1) | `gridcraft-cli check book.xlsx [--json]`: formulas vs cached values, XLSX round trip; exit 1 on a difference |
| Read back | `gridcraft-cli cat book.xlsx [--range A1:F20] [--sheet S] [--formulas] [--csv]` |
| PNG preview | `gridcraft.py preview book.xlsx out.png [--all] [--as-printed] [--crop]`: per-sheet PDF → `sips` → PNG on white; default forces landscape fit-to-page, `--as-printed` keeps the sheet's page setup (page 1). `apply --export png` uses as-printed when the workbook has its own fit-to-page setup |
| PDF text check | GridCraft PDFs are uncompressed: each cell is `x y w h re W n` + `(text) Tj`, so `#####` and `?` runs can be parsed (the critic does) |
| Kurdish/Arabic PNG/PDF | `gridcraft.py rtl-render book.xlsx out.png|out.pdf` (Pillow + raqm; see kurdish-rtl.md) |

Opening: `.xlsx`, `.xlsm`, `.xltx`, `.csv`, `.tsv`, `.txt`, `.json` fully; `.xlsb` and `.ods` as
values only (formulas become their saved results, formatting dropped; save as `.xlsx`). The 0.6.1 CLI
also opens `.xls` (BIFF8 import: values, formulas, number formats; no fonts, fills, borders, charts)
and password-protected `.xlsx` via `file.open {"path","password"}` (registry, not tested here), always
saved without the password. Never written: `.xls`, `.xlsb`, `.ods`, encrypted files, `.prn`, `.dif`,
`.slk`. `gridcraft.py apply --in` has no password option: for an encrypted file, put
`["file.open",{"path":…,"password":…}]` as the first step (with the user's password) or ask for a
re-saved `.xlsx`. The desktop app is still 0.5.0, so `.xls`/encrypted files don't open in live mode.

## Recommended step order
1. Data first: `range.setValues` blocks (labels, inputs, formulas), then `edit.fillDown` for long formula columns.
2. Structure: `insert.table` (named), `formulas.defineName`, extra sheets (`home.insertSheet` + `sheet.activate`).
3. Formulas that use tables/names on summary sheets.
4. Formatting: number formats → styles → bold/fills (with `on`) → conditional formats → column widths last
   (widths after formats, because dates and currency need more room; a too-narrow date shows `#######`).
5. Charts, sparklines, PivotTables (place them clear of the data: estimate ~20 pt per row, ~64 pt per column).
6. `view.freezePanes`, page setup, `selection.set {"range":"A1"}` so the file opens at the top.

## Version skew (CLI 0.6.1, desktop app 0.5.0)
- The CLI was updated to 0.6.1 on 2026-10-13; `/Applications/GridCraft.app` is still 0.5.0. Headless
  work (`apply`, `template`, `critic`, MCP) gets everything above; live mode (`gridcraft_control.py`,
  `engine.execute`) only has the 0.5.0 commands and behaviour: no slicers, Solver, Forecast Sheet,
  ToolPak, PivotCharts, calculated fields, trendlines, `.pdf` save or `.xls` open, and `lessThan`
  highlights the wrong cells there. Check with `engine.commands` before using a 0.6.1 command live.
- New in 0.6.1 (24 commands): `data.solver`, `data.forecastSheet`, `data.analysisToolPak`,
  `data.showLevels`, `insert.slicer`, `table.insertSlicer`, `slicer.toggle|selectAll|clear|delete`,
  `insert.pivotChart`, `pivot.calculatedField`, `insert.chartRecommendations`, `home.insertCopiedCells`,
  `sheet.moveColumns`, `review.allowEditRanges|convertToComments|nextComment|previousComment|showAllNotes|showComments`,
  `file.options`, `view.formulaBar`, `view.zoom100`; functions FORECAST.ETS(.CONFINT/.SEASONALITY/.STAT),
  ODDF/ODDL PRICE/YIELD, PERCENTOF, EUROCONVERT, BAHTTEXT, TRIMRANGE.
- New CLI subcommand in 0.6.1: `gridcraft-cli check <file-or-dir>… [--json] [--tolerance 1e-9]`
  recomputes every formula against the file's cached values and round-trips the XLSX (exit 1 on any
  difference; tested on a pivot/solver workbook: all matched, round trip ok). Useful on files from Excel.
- Still only in the repo docs, not in the 0.6.1 CLI registry: `view.theme`, `view.animations`,
  `app.language.set` (app-side settings). Check with
  `gridcraft.py search <word>` before relying on anything from the docs. `=0.1+0.2=0.3` returned TRUE
  in 0.5.0 even though gaps.md lists 15-digit comparison as open (#57).

## Transports
| Path | Use | Notes |
|---|---|---|
| `gridcraft-cli run` (via `gridcraft.py apply`) | default | trusted local, any path, one-shot |
| `gridcraft-cli mcp [--in FILE | --sample NAME]` | an MCP client wants tools (`read_range`, `write_range`, `set_cell`, `format_range`, `insert_chart`, `create_table`, `sort_range`, `filter`, `execute_command`, `save_workbook`, `list_functions`…) | stdio JSON-RPC, headless. `claude mcp add gridcraft -- gridcraft-cli mcp` is a persistent config change: only when the user asks |
| Desktop control channel `gridcraft --control 7979` (`scripts/gridcraft_control.py`, or `gridcraft-cli send 7979 METHOD JSON`) | show the work live in the window, or edit the workbook already open there | JSON lines on 127.0.0.1, **no token and no folder restriction in the 0.5.0 app**: any local process can drive it while open. Only enabled at launch. Methods: `engine.execute {command, params}`, `engine.commands`, `document.inspect`, `sheet.read`, `cell.get`, `ui.inspect`, `ui.screenshot {path}`, `ui.click`, `ui.key`, `ui.text`, `ui.ribbon {tab}`, `ui.dialog*`, `app.open {path, password?}`, `app.save {path?}`, `app.quit`. Replies time out after 60 s if the window is minimised |
| `gridcraft-cli mcp --connect 7979` | MCP bridged to the live app | needs the control channel |

## Known gaps (docs/gaps.md, target-app-parity.md, parity docs)
- Stage **alpha**, "~50% ready for real work". XLSX output has never been checked in Excel across a real
  corpus (repair prompts unknown); open-edit-save drops slicers, timelines, the data model and unmodelled chart details.
- Charts: no axis options (min/max/log), no error bars, per-point formatting or chart sheets (trendlines exist from 0.6.1); combo, stock,
  histogram, box, waterfall, funnel, treemap and sunburst lose their kind in XLSX in this era; charts are simple
  (title, legend position, data-label and gridline flags, axis titles, series colours).
- No Arabic/Kurdish/Persian shaping or bidi in cells; PDF export uses the 14 standard fonts, so **non-Latin text
  (Arabic, Kurdish, CJK, Devanagari) does not export to PDF**. Sheet right-to-left mirrors the grid only.
- Single-threaded recalc; ~100 MB XLSX files fail to open (#175).
- PivotTables: no timelines, calculated items or GETPIVOTDATA (0.6.1 adds calculated fields, PivotCharts and table slicers; slicers are not saved to .xlsx).
- Missing: Power Query/Get & Transform (CSV/JSON/HTML import only), data model, VBA (kept in .xlsm, never
  run), SmartArt, WordArt, equations, Show Changes, co-authoring, `.xls` writing, saving with a password.
- CSV export writes displayed values in 0.6.1 (`14%`, tested), so precision is lost; 0.5.0 wrote raw values. Export a values sheet with General/0.00 formats when a CSV must keep full precision.
- Known calc bugs: stale spills after structural edits (#133, #139), 3-D reference endpoint deletion (#140),
  qualified names after sheet rename (#134). Verify numbers that matter with `gridcraft.py verify`.
