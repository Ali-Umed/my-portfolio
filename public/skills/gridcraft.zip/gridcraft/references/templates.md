# GridCraft templates

`gridcraft.py template list | show ID | apply ID OUT.xlsx [--var key=value ...] [--export png,pdf] [--force]`.
Every template builds through the same checked `apply` path (recipe validation, `.recipe.json`
sidecar, formula errors, critic summary). Previews: `templates/thumbs/<id>.png`; contact sheet
`templates/gallery.png` (numbers below match it); scores: `templates/thumbs/scores.json`
(rebuild all with `gridcraft.py thumbs`). All score 100/100 with no issues on their defaults.

Common variables: `palette` (ledger, slate, forest, ember, ocean, graphite, plum, zagros - see
design-guide.md), `font` (body font, default Arial), `currency` (symbol before, e.g. `$`, or a code
after, e.g. `IQD`), and `p.<role>=#hex` to override one palette colour. List variables take JSON
(`--var 'items=[["Rent",1200,1200]]'`) or a file (`--var items=@lines.csv`); totals, charts and
print ranges follow the list length.

| # | id | Use case | Key variables | Pages | Critic |
|---|---|---|---|---|---|
| 1 | `budget` | Household/team budget vs actual: KPI tiles (income, spent, left), variance, % used bars, bar chart | title, period, income, items [category, budget, actual], currency | 1 landscape A4 | 100 |
| 2 | `invoice` | Freelance/small-business invoice: line items, subtotal, tax rate input, total due, due date = issue date + terms, payment note | company, company_address, company_contact, client, client_address, invoice_no, issue_date, terms_days, tax_rate, items [description, qty, unit price], payment_note | 1 portrait A4 | 100 |
| 3 | `kurdish-budget` | Sorani RTL budget in IQD (بودجەی مانگانە): Tahoma, zagros palette, data bars; preview via `rtl-render` | title, period, income, items [بەش, بودجە, ڕاستەقینە], font | 1 portrait A4 | 100 |
| 4 | `loan` | Loan/mortgage amortization: inputs, payment, total interest, payoff date, dated schedule closing at exactly 0, balance chart | title, amount, rate, years (sets schedule length), first_payment | 1 landscape A4 (48 rows) | 100 |
| 5 | `pnl-forecast` | 12-month P&L model: Assumptions sheet with named drivers, months across, FY column, EBITDA, chart feed + column chart | company, first_month, start_revenue, growth, cogs_pct, salaries, rent, marketing_pct, other, currency_label | 1 landscape + 1 portrait | 100 |
| 6 | `project-tracker` | Tasks with owner, dates, status dropdown, % done bars, days left/overdue, KPI tiles with an "as of" input | project, as_of, tasks [task, owner, start, due, status, % done] | 1 landscape A4 | 100 |
| 7 | `sales-dashboard` | KPI tiles + by region / product / month panels with charts over a `Sales` table on a Data sheet | title, subtitle, data [date, region, product, units, price], regions, products, first_month, months | 1 landscape + data | 100 |
| 8 | `timesheet` | Weekly hours from start/end/break, regular vs overtime, gross pay, signature lines | title, company, employee, week_start, rate, ot_after, ot_multiplier, days [day, start, end, break] | 1 portrait A4 | 100 |

Examples:
```bash
S=~/.claude/skills/gridcraft/scripts
python3 -I $S/gridcraft.py template apply invoice ~/Desktop/inv_031.xlsx --var client="Hawler Print" \
    --var 'items=[["Poster design",1,350],["Printing A2",50,4.2]]' --var tax_rate=0 --export pdf
python3 -I $S/gridcraft.py template apply loan car.xlsx --var amount=30000 --var rate=0.055 --var years=5
python3 -I $S/gridcraft.py template apply kurdish-budget ku.xlsx --var income=2500000 && \
python3 -I $S/gridcraft.py rtl-render ku.xlsx ku.pdf
```
Writing a new template: copy the closest one, keep placeholders `{{name}}`, `{{p.role}}`,
`{{fmt.money}}`, `{{items.first|second|last|next|after..after5|count}}`, `"derived"` arithmetic and
`"blocks"` (see `scripts/templating.py` docstring), then run `gridcraft.py thumbs <id>` and look at
the thumbnail until it scores >= 85 with no severe issue and looks right.
