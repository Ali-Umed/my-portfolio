# Kurdish (Sorani) and right-to-left sheets in GridCraft 0.5.0

Test string: `سڵاو، ئەمە تاقیکردنەوەیە بۆ کوردی: ێ ۆ ڵ ڕ ە ڤ ـ ١٢٣ 123 ArtCraft`.
Evidence and the reproducible test were run in the author's test folder.
(`kurdish_matrix.py`, `matrix.png`, `font_<name>.png`, `gridcraft_pdf.png`, `matrix.json`).

## What works and what doesn't
| Path | Kurdish result |
|---|---|
| The .xlsx file | **Keeps the exact text** (`gridcraft-cli cat` round-trip identical). Excel, Numbers and LibreOffice shape it with the cell's font. |
| `view.rightToLeft {"on":true}` | Writes `rightToLeft="1"`; Excel opens the sheet with column A on the right. |
| GridCraft's PDF / PNG export (`file.exportPdf`, `preview`, `--export pdf,png`) | **Fails for every font**: only Helvetica/Times/Courier (WinAnsi) are embedded, every Kurdish character prints as `?` (10/10 test cells, `gridcraft_pdf.png`). |
| GridCraft window | No Arabic-script shaping or bidi in cells (docs/localization-parity.md); not used here. |
| `gridcraft.py rtl-render BOOK.xlsx OUT.png|OUT.pdf` | **Best available workaround**: Pillow + raqm draws the sheet as it prints (engine display values, fills, borders, merges, data bars, colour scales, highlights, RTL column order) with correctly shaped Sorani. PDF output is a 200 dpi raster page (text not selectable). Charts become titled placeholders. |
| HTML export | Loses per-cell fonts and forces `text-align:left`; not useful for Kurdish. |

## Font matrix (strict rendering with Pillow/raqm, no font fallback)
Checks per font: cmap has all Kurdish letters (ڵ ڕ ێ ۆ ە ڤ ی ک گ چ پ ژ ه ئ), Eastern Arabic digits
١٢٣, Latin + digits for mixed text; joining forms (shaped output differs from unshaped for ـXـ /
ـX of every special letter); lam-alef ligature.
| Font | Installed where | Result | Use it for |
|---|---|---|---|
| **Tahoma** | macOS + Windows | PASS | **default for Kurdish sheets**: clear at 9-10 pt, has bold, same font on the reader's PC |
| **Arial** | macOS + Windows | PASS | mixed Kurdish/English sheets; pairs with Arial headings |
| Times New Roman | macOS + Windows | PASS | formal letters-style tables |
| Microsoft Sans Serif | macOS + Windows | PASS | fallback |
| Courier New | macOS + Windows | PASS (monospaced Arabic looks spaced out) | not for text |
| Rabar_016, Rabar_031, Speda (bold only), K24 Kurdish Light, UniQAIDAR_Hewal 011, Unikurd Web, RudawRegular, Peshang Des 2, Sarchia_Halab, UniMahan Nurhan, Nizar Aldhabi | this Mac only (user fonts) | PASS | branded Kurdish titles; the reader must have the font, so prefer them in `rtl-render` output or PDFs |
| Geeza Pro, Damascus, Noto Naskh Arabic UI (bold only) | macOS | PASS Kurdish only - no Latin glyphs | Kurdish-only cells |
| Arial Unicode MS | macOS | FAIL: no joining forms for ڵ ێ (letters break apart) | avoid |
| Baghdad | macOS | FAIL: ڵ ڕ ێ ۆ ە missing | avoid |
| Helvetica | macOS | FAIL: no Arabic script | avoid |
| Calibri, Aptos | not installed here | untested; no Kurdish letters on Windows, viewers substitute | avoid for Kurdish |
Recommended pairs: **Tahoma + Tahoma** (one family, bold for headers, works for every reader);
**Arial + Rabar_016/Speda titles** when the sheet stays on this Mac or ships as an `rtl-render` PDF;
English labels next to Kurdish: Arial for Latin, Tahoma for Kurdish (similar x-height).

## How to build a Kurdish sheet (template `kurdish-budget` does all of this)
1. `view.rightToLeft {"on":true}` first.
2. Column style font: `home.fontName {"range":"A:Z","name":"Tahoma"}`, size 10.
3. Leave Kurdish text at General alignment (it starts at the right). Give numeric columns and
   their headers an explicit side (`home.alignLeft` on both in an RTL sheet) so headers and numbers
   line up; `rtl-render` treats explicit left/right as physical sides and General numbers as left in
   RTL sheets (Excel's mirrored behaviour; check once in the reader's Excel).
4. Keep numbers in Western digits in numeric cells (they calculate and sort); write Eastern digits
   (١٢٣) only inside text such as the period line. State the currency in the subtitle
   ("بە دیناری عێراقی") or use a code after the number (`--var currency=د.ع` gives `#,##0 "د.ع"`).
5. IQD amounts are long: money columns 16 chars, KPI values 15 pt.
6. Prefer data bars and highlights over charts: GridCraft charts with Kurdish labels look right in
   Excel but cannot be previewed or exported here.
7. Deliver the .xlsx plus `rtl-render` PNG/PDF; run `critic` (it checks RTL direction, Kurdish
   font coverage and warns about the `?` export).

## Known RTL bugs in 0.5.0 and workarounds
| Bug | Workaround |
|---|---|
| PDF/PNG export prints `?` for Arabic script | `gridcraft.py rtl-render` |
| No shaping/bidi in the app's cells | edit the text in the recipe (JSON is UTF-8), check with `rtl-render` |
| HTML export forces left alignment and one font | don't use HTML for Kurdish |
| No `readingOrder` in `home.formatCells` | Excel's context order handles Kurdish text; nothing needed |
| Conditional-format text tests with `cellIs equal` don't apply | `containsText` (works for Kurdish text too) |
| File names: Kurdish characters in .xlsx paths work with the CLI | keep an ASCII copy name for email systems that mangle Unicode |

Sheet names, document title (`file.properties`) and footers accept Kurdish text in the .xlsx; the
GridCraft PDF footer would print `?`, so set Kurdish footers only for Excel printing.
