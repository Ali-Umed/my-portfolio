# GridCraft design guide: professional spreadsheet craft

Rules a financial analyst, a report designer and a print shop would agree on, each tied to the
GridCraft 0.5.0 command that applies it. The critic (`gridcraft.py critic`) measures most of them;
the last section lists every check. Templates in `templates/` already follow all of this.

## 1. What GridCraft can actually draw (know this before choosing fonts)
- **PDF/PNG export uses only the 14 standard PDF fonts.** The engine maps every cell font by name
  (crates/pdf, verified on 0.5.0): names containing `times, cambria, georgia, garamond, serif, book,
  palatino, baskerville` print as **Times**; `courier, consolas, mono, menlo, lucida console, code,
  typewriter` print as **Courier**; everything else (Arial, Calibri, Aptos, Verdana, Tahoma, Avenir,
  Charter, Didot...) prints as **Helvetica**. Bold/italic are kept. So the PDF shows three families,
  while Excel/Numbers show the real font named in the cell.
- **Calibri and Aptos are not installed on this Mac.** Numbers and Quick Look substitute a serif for
  them, which looks broken. Excel users have them; Mac users without Office don't.
- **Kurdish/Arabic text prints as `?`** in GridCraft's PDF/PNG. Use `gridcraft.py rtl-render` (see
  `kurdish-rtl.md`).
- **Sizes are pixels, not points:** `home.columnWidth {"width"}`, `home.rowHeight {"height"}` and
  `insert.chart {"width","height"}` take pixels (0.75 pt each); prefer `columnWidth {"chars"}`.
  Column width in points = round(chars*7+5)*0.75; text gets 1.5 pt padding per side; one indent
  level (`home.increaseIndent`) costs 6.75 pt.

## 2. Typography
| Role | Font | Size | Weight / colour |
|---|---|---|---|
| Sheet title | body font (or Georgia for a classic report) | 16-18 pt | bold, `head` colour |
| Subtitle / period / units | body | 10 pt | `muted` |
| Section title (dashboards) | body | 12 pt | bold, `head` |
| Column headers | body | 10 pt | bold, white on `head` fill, or bold `muted` with a rule below |
| Body numbers and text | body | 10 pt (11 if the sheet is read on screen only) | `ink`; inputs `input_text` |
| KPI value | body | 15-18 pt | bold, `accent` |
| KPI label, notes, sources | body | 9 pt | `muted`, notes italic |

- **Default pairing: Arial everywhere.** Installed on every Mac and Windows PC, and metric-
  compatible with Helvetica, so column widths sized in GridCraft hold in the PDF and in Excel.
  Set it once with column styles: `home.fontName {"range":"A:Z","name":"Arial"}` +
  `home.fontSize {"range":"A:Z","size":10}` before writing values (new cells inherit it; a
  cell range like A1:Z300 instead bloats the used range to 7,800 cells and prints blank pages).
- Alternatives that exist on both platforms: **Georgia** titles + Arial body (classic report; PDF shows
  Times), **Verdana/Tahoma** body for small on-screen sizes (wider than Helvetica: give columns 10%
  more room), **Courier New** only for codes/IDs. Kurdish: **Tahoma** (see `kurdish-rtl.md`).
- Avoid Helvetica Neue, Avenir, SF fonts (Mac only) and Calibri/Aptos (Office only) in shared files.
- Scale: 9 / 10 / 12 / 16-18. Five sizes at most per sheet; 8 pt is the floor (footnotes only).
- Line length: notes longer than ~90 characters run off the printed area; split them into rows.

## 3. Colour
Palettes live in `templates/palettes.json` (`gridcraft.py palettes` prints the contrast table).
Every pair below is checked: body text >= 13:1, muted >= 4.8:1, header text on header fill >= 8.6:1,
blue input text on input fill >= 6.2:1, accent >= 5:1 on white (safe for KPI numbers), comparison
grey >= 3:1 (graphics minimum).

| Palette | head | accent | accent2 | band | Use |
|---|---|---|---|---|---|
| ledger | #1F3A5F | #1F5F99 | #8693A3 | #EEF3F8 | finance, investors (default) |
| slate | #334155 | #0F766E | #8695A8 | #F1F5F9 | neutral reports, ops |
| forest | #14532D | #187A43 | #86998C | #EEF7F1 | personal finance, growth |
| ember | #7C2D12 | #C2410C | #A68B7C | #FDF3EC | household, events |
| ocean | #0C4A6E | #0369A1 | #7F96AB | #EEF6FB | dashboards, sales |
| graphite | #262626 | #404040 | #8C8C8C | #F3F3F3 | black-and-white print, audit |
| plum | #4C1D95 | #6D28D9 | #968DAA | #F5F3FF | studios, education |
| zagros | #1E5631 | #2F7D4F | #B07A1A | #F3F8F4 | Kurdish projects |

Each palette also has `ink`, `muted`, `rule` (hairlines), `input_fill` (#FFF6D5 family),
`input_text` (#1D4ED8), `neg` (red), `pos` (green) and a dark variant (`dark_bg`, `dark_text`,
`dark_muted`, all >= 7:1) for dark KPI tiles or a dark dashboard band.
- **60-30-10:** 60% white paper and black text, 30% the light `band` tint (tiles, totals column,
  section rows), 10% `head`/`accent` (one header band, KPI numbers, the key series). One accent only.
- Colour encodes meaning, never decoration: blue = input, red = negative/over budget, green only for
  "done/positive" states. Pair red/green with signs, brackets or words (1 in 12 men can't tell them apart).
- No saturated fills (#FFFF00, #00FF00): use tints. Data bars use the light `rule` colour so the
  number on top stays readable (dark bars hide black text in GridCraft's render).
- Dark variant: only for KPI tiles or a title band; fill `dark_bg`, text `dark_text`. Full-dark
  sheets print badly.

## 4. Layout and grid
- Column A is a 2-character gutter and row 1 a spacer: content starts at **B2**. Rows 5-7 KPI tiles,
  a 10-12 px spacer row, then tables. `home.rowHeight` 18-30 px for tiles and header rows; body rows
  stay at the default 15 pt (20 px) for an even rhythm.
- Width plan (chars): labels 14-28, money 11-14 (16 for IQD millions), percentages 9-11, dates 11-13,
  gaps between panels 3. Set widths **after** number formats.
- Align: text left, numbers right (headers over numbers right-aligned too), dates left or right but
  consistently, counters centred. Never centre amounts: decimals stop lining up.
- Tiles: fill a 2-3 column block with `band`, label 9 pt muted in the top row, value 15-18 pt bold
  below, optional 9 pt note row; separate tiles with a thick white border (`home.borders preset right
  style thick color #FFFFFF`) instead of merging. Numbers don't overflow into the next cell, so the
  value's own column must fit it (the critic checks).
- Rules, not grids: hairline `insideHorizontal` borders in `rule` colour, a thin `ink` rule above
  totals and a double rule below grand totals. `view.gridlines {"on":false}` for finished sheets.
- Merges only for titles outside data blocks; never inside a table (sort and filter break, and
  `review.checkAccessibility` flags them).

## 5. Financial-model conventions
- **Inputs, calculations, outputs apart.** Inputs on an Assumptions sheet (or a labelled block),
  each with a unit/note column; models reference them through names (`formulas.defineName`
  `Growth`, `COGSPct`...) so formulas read `=C5*(1+Growth)`.
- **Font colour code:** blue (`input_text`) = typed input, black = formula, green (`pos`) = link from
  another sheet, `input_fill` background on the editable cells. Never type a number into a formula row.
- One formula per row (or column), copied across: enter the first cell with `cell.set` and copy with
  `edit.fillRight`/`edit.fillDown`. In 0.5.0 and 0.6.1 `range.fill` shifts relative references by the
  **active cell** (E9 got `=G17-H17`): only use it after `selection.set` on the target range.
- Signs: costs negative and shown in brackets; totals are plain SUMs. Time runs left to right
  (months in columns), a FY/total column at the right on a `band` fill.
- No hard-coded constants inside formulas except units (12 months, 100, 365...): put rates and
  thresholds in input cells. Round only where money is booked (`ROUND(...,2)` on balances).
- Close the loop: amortization balance must end at exactly 0 (last row pays the remaining balance),
  totals tie to their components, and `gridcraft.py verify --set ... --expect ...` proves it.
- Chart feeds: when the series you want are not adjacent, add a small muted 8 pt "Chart data
  (links)" block of `=C5`-style links and chart that (multi-area ranges give one series in 0.5.0).

## 6. Number formats (use the template variables `{{fmt.*}}` or these codes)
| Kind | Code | Shows |
|---|---|---|
| Money | `"$"#,##0.00_);("$"#,##0.00);"–"_)` | $1,234.50 / ($1,234.50) / – |
| Money, whole | `"$"#,##0_);("$"#,##0);"–"_)` | $1,235 |
| Code after (IQD, EUR) | `#,##0 "IQD"_);(#,##0 "IQD");"–"_)` | 1,250,000 IQD |
| Number | `#,##0_);(#,##0);"–"_)` | 12,000 / (450) / – |
| Percent | `0.0%_);(0.0%);"–"_)` | 12.3% / (5.0%) |
| Multiple | `0.0"x"` | 2.5x |
| Thousands | `#,##0,"k"` | 1,235k |
| Date / month | `d mmm yyyy`, `mmm yyyy`, `mmm yy`, `d mmm` | 5 Nov 2026 |
| Time / hours | `h:mm`, `0.00` | 8:30, 7.75 |
- `_)` pads positives so they line up with bracketed negatives; `"–"` shows zero as a dash so the
  eye skips it. Summary tables: whole units. Detail tables: 2 decimals for money only.
- Never leave General on decimals (473.5583333), ratios (0.153) or dates (46023). Typed inputs
  `"2026-11-05"`, `"5%"`, `"8:30"` are parsed into real dates, percentages and times.
- Chart axes inherit the source format: whole-number formats give clean `$400` axes, not `$400.00`.

## 7. Tables, charts, conditional formats
- Tables: `insert.table` with a word name (`Sales`) for structured references; light styles
  (`TableStyleLight1`) for data sheets. Calculated columns are not auto-filled: `cell.set` + `edit.fillDown`.
- Charts: one message per chart, the title says it ("Revenue by region"). Column for categories
  over time or few items, bar for long labels (Excel draws the first category at the bottom), line
  for 6+ time points, pie only for 2-5 parts of a whole. Single series: `chart.set {"legend":"none"}`;
  two series: legend top, comparison in `accent2` grey and the focus in `accent`
  (`chart.changeColors`). No 3-D. Size dashboards panels ~270x200 px, report charts 340-420 px wide.
- Conditional formats: at most 2-3 per table. Text states use `containsText` (works in the 0.5.0 app
  too; `cellIs equal "Done"` only matches from 0.6.1); numbers use `cellIs` with `less/greater/between`. Presets
  `redText`, `lightRedFillDarkRedText`, `greenFill` meet contrast.
- Dropdowns for states (`data.validation type list`), ranges for percentages (decimal 0-1).

## 8. Dashboards
- Top: title + period + units line. Row of 3-4 KPI tiles. Then 2-3 panels side by side, each a
  small table (4-8 rows) above its chart, all the same width; one landscape page
  (`fitWidth 1, fitHeight 1`). Data on its own sheet as a table; the dashboard only references it.
- Helper columns (e.g. month start dates behind text month labels) go right of the panels and
  are hidden (`home.hideColumns`); the input that drives them stays visible and blue.

## 9. Print setup (every deliverable)
`pageLayout.pageSetup {"paper":"A4","orientation":...,"fitToPage":true,"fitWidth":1,"fitHeight":0|1,
"titleRows":"<header>:<header>","margins":{"left":0.5,"right":0.5,"top":0.6,"bottom":0.6,"header":0.3,"footer":0.3},
"footer":"&L&8Title · period&R&8Page &P of &N"}` and `file.properties {"title":...}`.
- One page wide always; tall lists may run to more pages with the header repeated (`titleRows`).
- Portrait for invoices, timesheets, lists; landscape for budgets with charts, models, dashboards.
- Freeze panes below the header for 25+ rows (`view.freezePanes {"cell":"A<first data row>"}`).
- Finish with `selection.set` on the first input so the file opens where the user works.

## 10. Common mistakes and fixes
| Mistake | Fix |
|---|---|
| `#####` in the PDF | widen with `home.columnWidth {"chars":N}` after formats; mind indents and 16 pt KPI values |
| Totals that miss the last row | `=SUM(first:last)` built from the list length (`{{items.last}}`) |
| Typed number inside a formula column | re-enter the formula, copy with `edit.fillDown` |
| Every row says `=C9-D9` / refs point at empty cells | `cell.set` first cell + `edit.fillDown`; never `range.fill` without `selection.set` |
| Header looks like data | bold + fill or a rule (`home.borders preset bottom`) |
| Rainbow fills, neon yellow | one tint + one accent (60-30-10) |
| Chart covering cells, legend on one series | `chart.set {"at":...,"legend":"none"}` |
| Notes cut off at the page edge | split into two rows |
| Kurdish shows `?` in the PDF | `gridcraft.py rtl-render BOOK.xlsx OUT.pdf` |

## 11. Designer checklist (before delivering)
1. `gridcraft.py critic OUT.xlsx`: score >= 85, no severe issue, recalculation probe updates formulas.
2. `gridcraft.py verify` with Python-computed expectations, including one changed input.
3. Look at the preview (`--export png` or `preview --as-printed --crop`): hierarchy readable in
   3 seconds, one accent, numbers aligned, nothing clipped, one page wide.
4. Inputs blue, outputs bold/accent, notes say what to edit. Title property, footer, sheet names set.
5. Kurdish: RTL sheet, Tahoma, `rtl-render` preview checked by eye.

## 12. What the critic checks (score = 100 minus points; severe -12, major -5, minor -2, tip 0; capped per category)
- **formulas:** error values after recalculation (severe each); circular references (severe);
  manual calculation mode (major); cached results that differ from a fresh recalculation or are
  missing (major/minor); typed numbers inside a block of identical formulas (severe); a formula
  that breaks its block's pattern (major); formulas whose references all point at empty cells
  (severe when 3+); runs of identical relative formulas that did not move (major); SUM ranges that
  leave out the adjacent number (severe); hard-coded business constants in formulas (minor);
  numbers stored as text inside numeric columns (major); **recalculation probe**: up to 8 real
  inputs (named ranges resolved) are changed one at a time in memory and all formulas re-read -
  no update at all is severe, a dead input feeding only arithmetic is minor, new errors are minor.
- **display:** `#####` predicted from Helvetica/Times/Courier metrics, column width, merges and
  indent (severe), confirmed against the text GridCraft actually prints in its PDF; text cut off by
  the next cell (major on header rows); text running past the last column (minor); General format
  showing scientific notation or 3+ decimals (major); large numbers without separators (minor);
  dates shown as serials and ratios not shown as % under matching headers (major); negative zero (minor).
- **type:** more than 3 fonts or 5 sizes (minor); text under 8 pt (major); amounts centred (minor);
  header rows with no bold/fill/rule (major); total rows not set apart (minor).
- **colour:** WCAG contrast of text on fill (< 3:1 severe, < 4.5:1 major; 3:1 for 14 pt bold/18 pt)
  for cells and conditional-format styles; more than 6 fills or saturated fills (minor); red-green
  scales (tip).
- **layout/charts:** long tables without frozen headers (minor); merges inside tables (minor); charts
  covering filled cells (severe) or each other (major); charts without title (major), single-series
  legend, pies over 6 slices, 3-D, over 6 series, tiny charts (minor).
- **print:** more than one page wide, multi-page without repeated headers, scale under 55% (minor);
  no page numbers (tip).
- **doc:** missing title property (tip), default sheet names in multi-sheet books and
  `review.checkAccessibility` findings (minor).
- **rtl:** mostly Kurdish/Arabic text on a left-to-right sheet, most Kurdish cells forced left
  (minor); Kurdish text in Calibri/Aptos (minor) or a font lacking ڵ ڕ ێ ۆ ە ڤ (major); a tip that
  GridCraft's PDF prints `?` and `rtl-render` makes the PDF.
Robustness: on the three original test workbooks the critic reports only real print/legend points
(98, 94, 94); a planted-mistakes workbook (`craft-tests/gridcraft/design-upgrade/critic_selftest`)
triggers 30 issues.
