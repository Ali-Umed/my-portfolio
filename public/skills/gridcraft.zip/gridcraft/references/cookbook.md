# GridCraft cookbook: user wording → recipe

Every recipe is a JSON list of `[command-id, params]` steps for `scripts/gridcraft.py apply`.
Tested recipes (in the author's test folder) (`test1_budget/budget_steps.json`,
`test2_sales/sales_steps.json`, `test3_loan/loan_steps.json`): copy one as a starting point.

| User says | Steps (essentials) |
|---|---|
| "Make me a budget / expense tracker" | `range.setValues` (Category, Budget, Actual, `=B4-C4`, `=IF(B4=0,0,C4/B4)`, Total row `=SUM(…)`) → `home.accounting` → `home.percent` → `home.cellStyle` "Heading 1"/"Total" → `home.conditionalFormat` `cellIs` `less` 0 → `insert.chart` bar clustered → `view.freezePanes` |
| "Add a total row / column" | `cell.set {"cell":"B11","input":"=SUM(B4:B10)"}` then `edit.fillRight {"range":"B11:E11"}`; on a table: `table.totalRow {"table":"Sales","on":true}`, then `table.totalFunction {"table":"Sales","column":"Status","function":"none"}` for text columns (the default sums them to 0) |
| "Make it look professional" | Title `home.fontSize` 15–16 + `home.bold on`; header `home.cellStyle` "Heading 2"; number formats; `home.cellStyle` "Total" on totals; `home.columnWidth` (chars 12–22); `pageLayout.theme` "Slate"; freeze the header |
| "Highlight overspending / negatives in red" | `home.conditionalFormat {"range","rule":{"type":"cellIs","operator":"less","value":"0","preset":"lightRedFillDarkRedText"}}` |
| "Colour scale / heat map" | `{"type":"colorScale","colors":["#63BE7B","#FFEB84","#F8696B"]}` (low → high) |
| "Data bars" | `{"type":"dataBar","color":"#1F9D55"}` (check the render: long values can be clipped) |
| "Summarise by region / category" | Table first (`insert.table … "name":"Sales"`), then `=SORT(UNIQUE(Sales[Region]))` and `=SUMIFS(Sales[Revenue],Sales[Region],A4)`; or `insert.pivotTable` with rows/columns/values |
| "Pivot table" | `insert.pivotTable {"source":"Sales","destination":"Summary!A18","rows":["Product"],"columns":["Region"],"values":[{"field":"Revenue","func":"sum"}]}` + `pivot.refresh` after data edits |
| "Lookup the price for each item" | `=XLOOKUP(A2,Prices[Item],Prices[Price],"not found")` (or VLOOKUP/INDEX-MATCH) |
| "Loan / mortgage calculator" | inputs + `=PMT(rate/12,years*12,-amount)`, `=SEQUENCE(n)` months, `IPMT`/`PPMT` columns, `=ROUND(amount-SUM($D$10:D10),2)` balance, line chart of the balance |
| "Chart this" | `insert.chart {"range":"A3:C10","type":"column","title":"…","at":"G3","width":420,"height":260}`; pie for one series of parts; line for time; bar for long category names |
| "Sparklines next to each row" | `insert.sparkline {"range":"B2:M2","location":"N2","type":"line"}` per row |
| "Sort by X then Y" | `data.sort {"range","header":true,"keys":[{"column":"B","order":"asc"},{"column":"C","order":"desc"}]}` |
| "Filter to only …" | plain range: `selection.set A1` → `data.filter` → `data.filterBy {"column":"B","values":["Art"]}`; totals of visible rows: `=SUBTOTAL(109,C2:C50)` |
| "Add a slicer / filter buttons" (table) | `insert.slicer {"table","column":"Region","at":"H2"}` → `slicer.toggle {"value":"East"}`; slicer not saved to .xlsx, the filtered rows are (0.6.1 CLI only) |
| "Maximise profit / best mix under limits" | `data.solver {"objective","goal":"max","variables","constraints":[…],"method":"simplex" for linear}`; report `status` (0.6.1 CLI only) |
| "Forecast the next months" | `data.forecastSheet {"timeline","values","periods"}` (new sheet with FORECAST.ETS + bounds + chart), or `FORECAST.ETS` cells (0.6.1) |
| "Descriptive stats / regression" | `data.analysisToolPak {"tool":"descriptive","range","labels":true,"output"}` / `{"tool":"regression","inputY","inputX"}` (static values, 0.6.1) |
| "Chart of the pivot" / "trend line" | `insert.pivotChart {"pivot","type":"column","at"}`; `chart.addElement {"element":"trendline","type":"linear","displayEquation":true}` (0.6.1) |
| "Remove duplicates" | `data.removeDuplicates {"range","header":true}` (report `removed`) |
| "Dropdown list in column D" | `data.validation {"range":"D2:D200","type":"list","formula1":"Open,Done,Blocked"}` |
| "Split full names into first/last" | `data.textToColumns {"range":"A2:A100","delimiters":[" "],"destination":"B2"}` |
| "Clean up this CSV and make it a spreadsheet" | `apply out.xlsx --in data.csv` with `sheet.rename`, `insert.table`, number formats, `home.autofitColumnWidth`, freeze top row |
| "What if X changes?" | `gridcraft.py verify book.xlsx --set B4=0.05 --expect '{"B6": …}'` (in memory), or Goal Seek `data.goalSeek {"set":"B6","to":400,"changing":"B3"}` into a new file |
| "Print it on one page / PDF" | `pageLayout.pageSetup {"orientation":"landscape","fitToPage":true,"fitWidth":1,"fitHeight":1}` then `--export pdf` |
| "Protect the formulas, leave inputs editable" | `home.lockCell {"range":"B3:B5","on":false}` → `review.protectSheet {}` |
| "Gradebook with letter grades" | `=IFS(B2>=90,"A",B2>=80,"B",B2>=70,"C",TRUE,"F")`, `=AVERAGE(...)`, `=RANK.EQ(...)`; the `grades` sample is a reference (`--sample grades`) |

## Design-grade starting points (templates, see templates.md)
| User says | Do |
|---|---|
| "Make me a budget / invoice / loan calculator / timesheet / project tracker / sales dashboard / P&L forecast" | `gridcraft.py template apply <id> OUT.xlsx --var ...` then `critic` and look at the preview |
| "Make it look professional" (existing workbook) | `critic BOOK.xlsx`, apply its fixes in a recipe on the original, then the design guide: Arial 10 column style, title 18 bold, header band, number formats with `_)`, one accent, gridlines off, print setup |
| "Kurdish / Sorani sheet", "بە کوردی" | `template apply kurdish-budget` or the steps in kurdish-rtl.md; deliver `.xlsx` + `rtl-render` PDF/PNG |
| "Is this spreadsheet right?" / "check my formulas" | `critic BOOK.xlsx` (errors, recalculation probe, broken formula blocks, SUM gaps, hard-coded numbers) + `verify` |
