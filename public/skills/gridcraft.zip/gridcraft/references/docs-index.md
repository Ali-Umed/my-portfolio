# storytold/gridcraft docs index

Every markdown file in the repo (30 files, tree read 2026-10-12 via `gh api`), each opened and
read. Copies: `<scratchpad>/gridcraft-docs/`. "Automation" says whether it matters for driving
GridCraft with code. The docs describe the repo HEAD, which is newer than the installed 0.5.0 CLI/app.

| Path | What it covers | Automation |
|---|---|---|
| `AGENTS.md` | Contributor/agent rules: clean-room, asset policy, never-crash, layering, "everything is a command", programmatic calls never open dialogs, how to run with `--control 7979`, headless CLI examples, roadmap pointers, contributor credits | **Yes** (command model, control examples). Its instructions for repo contributors (read `plan/STATUS.md`, pick work from gaps, update docs, add `people.toml` credits) are not for users of the app; not followed |
| `CLAUDE.md` | Same as AGENTS.md without the contributor-credits section | Same as above |
| `README.md` | Overview, features, quick start, web build, ribbon access keys, logs location, "For agents" (MCP, CLI, control channel), architecture, downloads | **Yes** (agent section, formats) |
| `ROADMAP.md` | Stage alpha, headline numbers (~50% ready, 513/523 functions), dimensions, languages, upcoming work, progress log | Context: what works and when it landed |
| `ATTRIBUTION.md` | Asset licences (brand files, placeholder icon, README screenshots) | No |
| `assets/app-icon/README.md` | Placeholder app icon, palette (#1f9d55), geometry, regeneration | No |
| `docs/architecture.md` | Crates and layers, data flow (command → COW model → recalc → render), agent control, known architectural gaps | Background (single-threaded calc, no streaming XLSX) |
| `docs/cell-pictures.md` | Pictures placed in cells: `insert.picture {"placement":"cell","at","alt"}`, XLSX rich values, limits | Yes (newer than 0.5.0 in part; `placement` exists in 0.5.0) |
| `docs/chart-parity.md` | Chart types and elements vs Excel, round-trip loss, work list | **Yes** (what charts can and can't do) |
| `docs/cli.md` | Every `gridcraft-cli` subcommand, `run` syntax (`--cmd 'id={json}'`, `--script`), `check` calc oracle with JSON schema | **Yes** (`check` is not in 0.5.0) |
| `docs/contributors.md` | About-window credits, `people.toml`, maintainer refresh | No (contributor instructions, not followed) |
| `docs/control-protocol.md` | Desktop control channel: `--control` port, JSON lines, every method (`engine.execute`, `sheet.read`, `ui.*`, `app.open/save/quit`), theme/animation/language commands, password open | **Yes** (basis of `gridcraft_control.py`) |
| `docs/decisions.md` | Spanish formula localization design, dynamic-array export classification (#64), static cell pictures storage | Minor (explains `t="array"` formulas in saved XLSX) |
| `docs/file-format-parity.md` | Every Excel format with read/write support and fidelity: XLSX pass-through and losses, XLSB/ODS values only, `.xls` partial, encryption, CSV, PDF fonts | **Yes** (format rules and losses) |
| `docs/formula-input.md` | Spanish formula names/separators in the editor only; APIs keep English syntax | Yes (automation always uses English syntax) |
| `docs/function-parity.md` | Function coverage by category (513/523), stubs, missing, formula-language features and bugs (#57, spills) | **Yes** |
| `docs/gaps.md` | Ranked list of 24 shortfalls vs Excel (XLSX unproven, large files, chart round-trip, non-Latin text, calc bugs, `.xls`, pivots…). Says "pick from the top" (contributor instruction; not followed) | **Yes** (known gaps) |
| `docs/hardware-parity.md` | Multi-core recalc (none), GPU backends, pen, windows, DPI | Minor |
| `docs/localization-parity.md` | UI languages (ribbon only), en-US formulas, no Arabic/Devanagari shaping, PDF can't export non-Latin | **Yes** for Kurdish/Arabic text |
| `docs/mcp.md` | MCP server (headless or `--connect`), Claude Code setup, tools, resources, example session | **Yes** |
| `docs/ods-import.md` | ODS import: values only, saved results instead of formulas, no ODS writing | Yes |
| `docs/parity-checklist.md` | Generated ribbon checklist, 274/290; lists the missing ids (`insert.smartArt`, `data.fromWeb`, `review.showChanges`…) | Yes (what has no command) |
| `docs/release-playbook.md` | Pointer to craftrules release playbook | No |
| `docs/releasing.md` | Release pipeline: versions, signing, notarization, artefacts per platform, packaging details | No (install provenance only) |
| `docs/roadmap.md` | Current focus, alpha gate (six core workflows pass), beta gates, milestones | Context |
| `docs/target-app-parity.md` | Authoritative parity assessment: method, weights, feature areas, readiness by audience, performance, platforms, what works today | **Yes** (capability overview) |
| `docs/ui-parity.md` | Window chrome, grid interaction, keyboard shortcut audit, dialogs, accessibility | For teaching the app UI; not for automation |
| `docs/xlsb-import.md` | XLSB import: values only, no XLSB writing | Yes |
| `packaging/macos/dmg/README.md` | DMG window background and layout generation | No |
| `packaging/web/README.md` | Hosting the WASM web build: MIME, compression, caching, iframe embedding | No (only if the user wants the web app) |

Also read (pointed to by the docs): `apps/gridcraft-cli/src/main.rs` (subcommand behaviour: `run`
order, `--out` via `file.save`, no overwrite check), `apps/gridcraft/src/main.rs` and
`control_server.rs` (launch flags `--control`, `--sample`, files; loopback bind, no auth, 60 s
reply timeout), `crates/engine/src/cmd/insert.rs` (conditional-format operator parsing). Agent-task
tests: none named `agent_*`; the relevant ones are `apps/gridcraft-cli/tests/cli.rs` and the fuzz
harness `crates/engine/tests/command_sequence_fuzz.rs` (contributor tooling).

## Agent-directed instructions found (reported, not followed)
- AGENTS.md/CLAUDE.md: "Read `plan/STATUS.md` … Follow the autonomous operation protocol"; read craftrules
  `AGENTS.md` and "contribute reusable learnings back there".
- AGENTS.md: when preparing a PR, ask the human whether to add a credit entry to `contributors/people.toml`
  and add it (also docs/contributors.md).
- gaps.md: "This is the work list: pick from the top … and update the entry when you land work."
- AGENTS.md/ROADMAP: "Update the affected docs … whenever work lands."
All are for contributors editing the repo; the skill only uses the app.
