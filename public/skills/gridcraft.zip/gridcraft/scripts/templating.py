"""Parameterised workbook templates for gridcraft.py (`template list | show | apply`).

A template is templates/<id>.json:
  {"id", "title", "use", "palette": "ledger", "variables": {name: {"default", "help", "start_row"?}},
   "steps": [[command, params], ...], "verify"?: {"set": {...}, "expect": {...}}, "preview"?: {...}}

Placeholders inside step strings:
  {{name}}            a variable (a string that is only a placeholder keeps the value's JSON type,
                      so "{{amount}}" becomes the number 18000 and "{{items}}" a list of rows)
  {{p.role}}          palette colour (palettes.json roles: head, accent, band, ink, input_fill...)
  {{fmt.money}}       number formats built from {{currency}}: money, money0, num, num1, pct, pct0, mult, date, month
  {{items.first}} {{items.second}} {{items.last}} {{items.next}} {{items.after}}..{{items.after5}} {{items.count}}
                      rows of a list variable that has "start_row" (next = row after the list,
                      after = two rows after), so totals and charts follow the data length;
                      "blocks": {"sched": {"count": "months", "start_row": 11}} gives the same for a
                      computed length, and "derived": {"months": "years*12"} adds + - * / max() min() arithmetic
Lists can come from files: --var items=@lines.csv (CSV rows, numbers typed) or @rows.json.
"""
import csv
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATES = os.path.join(os.path.dirname(HERE), "templates")
PH = re.compile(r"\{\{\s*([\w.]+)\s*\}\}")


def palettes():
    with open(os.path.join(TEMPLATES, "palettes.json")) as fh:
        return {k: v for k, v in json.load(fh).items() if not k.startswith("_")}


def list_templates():
    out = []
    for f in sorted(os.listdir(TEMPLATES)):
        if f.endswith(".json") and f != "palettes.json":
            with open(os.path.join(TEMPLATES, f)) as fh:
                out.append(json.load(fh))
    return out


def load(tid):
    p = os.path.join(TEMPLATES, f"{tid}.json")
    if not os.path.exists(p):
        ids = [t["id"] for t in list_templates()]
        raise SystemExit(f"gridcraft: no template {tid!r}; available: {', '.join(ids)}")
    with open(p) as fh:
        return json.load(fh)


def parse_value(text):
    if text.startswith("@"):
        path = os.path.expanduser(text[1:])
        if path.lower().endswith(".json"):
            with open(path) as fh:
                return json.load(fh)
        with open(path, newline="", encoding="utf-8-sig") as fh:
            rows = list(csv.reader(fh))
        def typed(v):
            try:
                return int(v) if re.fullmatch(r"-?\d+", v) else float(v) if re.fullmatch(r"-?\d*\.\d+", v) else v
            except ValueError:
                return v
        return [[typed(v) for v in r] for r in rows if any(x.strip() for x in r)]
    try:
        v = json.loads(text)
        if isinstance(v, (int, float, list, dict)) and not isinstance(v, bool):
            return v
    except ValueError:
        pass
    return text


def number_formats(currency):
    cur = currency or ""
    if not cur:
        m, m0 = "#,##0.00_);(#,##0.00);\"–\"_)", "#,##0_);(#,##0);\"–\"_)"
    elif re.search(r"[A-Za-z؀-ۿ]", cur):  # IQD, EUR, د.ع: code after the number
        m = f"#,##0.00 \"{cur}\"_);(#,##0.00 \"{cur}\");\"–\"_)"
        m0 = f"#,##0 \"{cur}\"_);(#,##0 \"{cur}\");\"–\"_)"
    else:
        m = f"\"{cur}\"#,##0.00_);(\"{cur}\"#,##0.00);\"–\"_)"
        m0 = f"\"{cur}\"#,##0_);(\"{cur}\"#,##0);\"–\"_)"
    return {"money": m, "money0": m0, "num": "#,##0_);(#,##0);\"–\"_)", "num1": "#,##0.0_);(#,##0.0);\"–\"_)",
            "num2": "#,##0.00_);(#,##0.00);\"–\"_)", "pct": "0.0%_);(0.0%);\"–\"_)", "pct0": "0%_);(0%);\"–\"_)",
            "mult": "0.0\"x\"", "date": "d mmm yyyy", "month": "mmm yyyy", "hours": "0.00_);(0.00);\"–\"_)"}


def variables(tpl, overrides):
    """Resolve defaults + --var overrides + palette + formats + list row helpers."""
    spec = tpl.get("variables", {})
    vals = {k: v.get("default") for k, v in spec.items()}
    for k, v in overrides.items():
        if k not in spec and not k.startswith("p."):
            raise SystemExit(f"gridcraft: template {tpl['id']} has no variable {k!r}; "
                             f"variables: {', '.join(spec)} (or p.<role> to change one colour)")
        vals[k] = v
    pals = palettes()
    pname = vals.get("palette") or tpl.get("palette") or "ledger"
    if pname not in pals:
        raise SystemExit(f"gridcraft: unknown palette {pname!r}; palettes: {', '.join(pals)}")
    vals["palette"] = pname
    for role, colour in pals[pname].items():
        if role != "use":
            vals.setdefault("p." + role, colour)
    for k, v in overrides.items():
        if k.startswith("p."):
            vals[k] = v
    for k, expr in tpl.get("derived", {}).items():
        vals[k] = arith(expr, vals)
    for k, v in number_formats(vals.get("currency", "$")).items():
        vals["fmt." + k] = v
    rows = {k: (len(vals[k]), int(s["start_row"])) for k, s in spec.items()
            if "start_row" in s and isinstance(vals.get(k), list)}
    for k, s in tpl.get("blocks", {}).items():  # {"sched": {"count": "months", "start_row": 11}}
        rows[k] = (int(arith(s["count"], vals)), int(s["start_row"]))
    for k, (n, r) in rows.items():
        vals.update({f"{k}.first": r, f"{k}.second": r + 1, f"{k}.last": r + n - 1, f"{k}.next": r + n, f"{k}.after": r + n + 1,
                     f"{k}.after2": r + n + 2, f"{k}.after3": r + n + 3, f"{k}.after4": r + n + 4,
                     f"{k}.after5": r + n + 5, f"{k}.count": n})
    return vals


def arith(expr, vals):
    """Evaluate + - * / // ( ) max() min() over numeric variables ("years*12"); a list variable
    stands for its number of rows. Nothing else is allowed."""
    import ast
    import operator as op
    ops = {ast.Add: op.add, ast.Sub: op.sub, ast.Mult: op.mul, ast.Div: op.truediv, ast.FloorDiv: op.floordiv}

    def ev(n):
        if isinstance(n, ast.Expression):
            return ev(n.body)
        if isinstance(n, ast.Constant) and isinstance(n.value, (int, float)):
            return n.value
        if isinstance(n, ast.Name) and isinstance(vals.get(n.id), (int, float)):
            return vals[n.id]
        if isinstance(n, ast.Name) and isinstance(vals.get(n.id), list):  # a list counts its rows
            return len(vals[n.id])
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("max", "min") and n.args:
            return (max if n.func.id == "max" else min)(ev(a) for a in n.args)
        if isinstance(n, ast.BinOp) and type(n.op) in ops:
            return ops[type(n.op)](ev(n.left), ev(n.right))
        if isinstance(n, ast.UnaryOp) and isinstance(n.op, ast.USub):
            return -ev(n.operand)
        raise SystemExit(f"gridcraft: bad derived expression {expr!r}")
    v = ev(ast.parse(str(expr), mode="eval"))
    return int(v) if float(v).is_integer() else v


def substitute(obj, vals):
    if isinstance(obj, str):
        m = PH.fullmatch(obj.strip())
        if m:
            if m.group(1) not in vals:
                raise SystemExit(f"gridcraft: template uses undefined placeholder {{{{{m.group(1)}}}}}")
            v = vals[m.group(1)]
            return substitute(v, vals) if isinstance(v, (list, dict)) else v

        def rep(mm):
            if mm.group(1) not in vals:
                raise SystemExit(f"gridcraft: template uses undefined placeholder {{{{{mm.group(1)}}}}}")
            return str(vals[mm.group(1)])
        return PH.sub(rep, obj)
    if isinstance(obj, list):
        return [substitute(x, vals) for x in obj]
    if isinstance(obj, dict):
        return {k: substitute(v, vals) for k, v in obj.items()}
    return obj


def build(tid, overrides):
    tpl = load(tid)
    vals = variables(tpl, overrides)
    return tpl, vals, substitute(tpl["steps"], vals)


def describe(tpl):
    lines = [f"{tpl['id']}: {tpl['title']}", f"  use: {tpl['use']}", f"  palette: {tpl.get('palette', 'ledger')}"]
    for k, v in tpl.get("variables", {}).items():
        d = v.get("default")
        ds = json.dumps(d, ensure_ascii=False)
        if isinstance(d, list):
            ds = f"[{len(d)} rows, e.g. {json.dumps(d[0], ensure_ascii=False)}]"
        lines.append(f"  --var {k}=…  {v.get('help', '')}  (default {ds})")
    lines.append(f"  preview: templates/thumbs/{tpl['id']}.png")
    return "\n".join(lines)
