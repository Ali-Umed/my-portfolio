"""Render a sheet with real text shaping: the Kurdish/Arabic workaround for GridCraft 0.5.0.

GridCraft's own PDF/PNG export only has the 14 standard PDF fonts, so Sorani text prints as '?'.
This renderer draws the sheet as it prints - the engine's displayed values (number formats
applied), fills, borders, bold/italic, font sizes, merges, alignment, indent, wrap, right-to-left
sheets, data bars, colour scales and cellIs/containsText highlights - with Pillow + raqm, which
shapes Kurdish correctly (joining, lam-alef, bidi with Latin and digits). Charts are drawn as a
titled placeholder (GridCraft charts cannot carry shaped Kurdish labels). Output: PNG, or a
raster PDF (one page, 200 dpi) for printing/sharing.

  python3 -I rtl_render.py BOOK.xlsx OUT.png|OUT.pdf [--sheet NAME] [--font "Tahoma"] [--scale 2.5]

Font rule: a cell keeps its own font when it is installed and covers the text (see
references/kurdish-rtl.md); otherwise Kurdish text falls back to --font (default Tahoma, which
passes the Sorani matrix and exists on Windows and macOS) and Latin text to Arial.
"""
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fonts  # noqa: E402
import xlsxinfo as X  # noqa: E402

from PIL import Image, ImageDraw, ImageFont, features  # noqa: E402

CLI = shutil.which("gridcraft-cli") or os.path.expanduser("~/.local/bin/gridcraft-cli")
MARGIN = 28  # points around the sheet
_FONTS = {}


def engine_values(path, sheet, used):
    cmds = [{"command": "sheet.read", "params": {"sheet": sheet, "range": used, "formatted": True}},
            {"command": "sheet.read", "params": {"sheet": sheet, "range": used}}]
    with tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False) as fh:
        fh.write("\n".join(json.dumps(c, ensure_ascii=False) for c in cmds))
    try:
        out = subprocess.run([CLI, "run", "--in", path, "--script", fh.name], capture_output=True, text=True, check=True).stdout
    finally:
        os.unlink(fh.name)
    res = [json.loads(l)["result"] for l in out.splitlines() if l.startswith("{")]
    r0, c0, _, _ = X.parse_range(used)
    disp, raw = {}, {}
    for i, row in enumerate(res[0]["values"]):
        for j, v in enumerate(row):
            if v not in (None, ""):
                disp[(r0 + i, c0 + j)] = str(v)
    for i, row in enumerate(res[1]["values"]):
        for j, v in enumerate(row):
            if v not in (None, ""):
                raw[(r0 + i, c0 + j)] = v
    return disp, raw


def font_for(name, bold, italic, size_px, text, fallback):
    arabic = fonts.is_arabic_script(text)
    candidates = [name]
    candidates.append(fallback if arabic else "Arial")
    candidates.append("Arial")
    for cand in candidates:
        loc = fonts.find(cand, bold=bold, italic=italic)
        if not loc:
            continue
        if arabic and fonts.coverage_chars(loc, "".join(ch for ch in set(text) if not ch.isspace())):
            continue
        key = (loc, round(size_px))
        if key not in _FONTS:
            _FONTS[key] = ImageFont.truetype(loc[0], max(4, round(size_px)), index=loc[1],
                                             layout_engine=ImageFont.Layout.RAQM)
        return _FONTS[key], cand
    return ImageFont.load_default(), "default"


def hexrgb(h):
    h = (h or "000000").lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def cf_effects(sheet, wb, raw):
    """{(r,c): {"fill": rgb, "font": rgb, "bold": bool, "bar": (fraction, rgb)}} from conditional formats."""
    eff = {}
    for rule in sheet.cf:
        cells = []
        for part in (rule["sqref"] or "").split():
            r1, c1, r2, c2 = X.parse_range(part)
            cells += [(r, c) for r in range(r1, r2 + 1) for c in range(c1, c2 + 1)]
        nums = [raw[x] for x in cells if isinstance(raw.get(x), (int, float)) and not isinstance(raw.get(x), bool)]
        t = rule["type"]
        dx = wb.dxfs[rule["dxf"]] if rule.get("dxf") is not None and rule["dxf"] < len(wb.dxfs) else None
        for x in cells:
            v = raw.get(x)
            e = eff.setdefault(x, {})
            if t == "dataBar" and isinstance(v, (int, float)) and nums:
                lo, hi = min(min(nums), 0), max(nums)
                frac = 0 if hi == lo else (v - lo) / (hi - lo)
                e["bar"] = (max(0.0, min(1.0, frac)), hexrgb((rule.get("colors") or ["638EC6"])[0] or "638EC6"))
            elif t == "colorScale" and isinstance(v, (int, float)) and nums and rule.get("colors"):
                cols = [hexrgb(c or "FFFFFF") for c in rule["colors"]]
                lo, hi = min(nums), max(nums)
                f = 0 if hi == lo else (v - lo) / (hi - lo)
                if len(cols) == 2:
                    e["fill"] = mix(cols[0], cols[1], f)
                else:
                    e["fill"] = mix(cols[0], cols[1], f * 2) if f < 0.5 else mix(cols[1], cols[2], (f - 0.5) * 2)
            elif dx and (t == "cellIs" and isinstance(v, (int, float)) and rule["formula"] or t == "containsText"):
                hit = False
                if t == "containsText":
                    m = re.search(r'"([^"]*)"', " ".join(f or "" for f in rule["formula"]))
                    hit = isinstance(v, str) and m is not None and m.group(1).lower() in v.lower()
                else:
                    try:
                        a = float(rule["formula"][0])
                        b = float(rule["formula"][1]) if len(rule["formula"]) > 1 else a
                    except (TypeError, ValueError):
                        continue
                    op = rule["operator"]
                    hit = {"lessThan": v < a, "greaterThan": v > a, "equal": v == a, "notEqual": v != a,
                           "lessThanOrEqual": v <= a, "greaterThanOrEqual": v >= a,
                           "between": min(a, b) <= v <= max(a, b), "notBetween": not (min(a, b) <= v <= max(a, b))}.get(op, False)
                if hit:
                    if dx.get("fill"):
                        e["fill"] = hexrgb(dx["fill"])
                    if dx.get("font_color"):
                        e["font"] = hexrgb(dx["font_color"])
                    if dx.get("bold"):
                        e["bold"] = True
    return eff


def render(path, out, sheet=None, font=None, scale=2.5):
    if not features.check("raqm"):
        raise SystemExit("rtl-render needs Pillow with raqm (libraqm) for Kurdish shaping")
    fallback = font or "Tahoma"
    wb = X.open_workbook(path)
    info = json.loads(subprocess.run([CLI, "info", path, "--json"], capture_output=True, text=True, check=True).stdout)
    names = [s.name for s in wb.sheets if s.state == "visible"]
    name = sheet or info["sheets"][info.get("activeSheet", 0)]["name"]
    if name not in names:
        raise SystemExit(f"no visible sheet {name!r}; sheets: {names}")
    sh = next(s for s in wb.sheets if s.name == name)
    used = next((s.get("usedRange") for s in info["sheets"] if s["name"] == name), None)
    if not used:
        raise SystemExit("sheet is empty")
    disp, raw = engine_values(path, name, used)
    r1, c1, r2, c2 = X.parse_range(used)
    r1, c1 = 1, 1
    for ch in sh.charts:
        if ch["box"]:
            r2, c2 = max(r2, ch["box"][2]), max(c2, ch["box"][3])
    k = scale
    colx, x = {}, MARGIN
    for c in range(c1, c2 + 1):
        colx[c] = x
        x += sh.width(c)
    width_pt = x + MARGIN
    rowy, y = {}, MARGIN
    for r in range(r1, r2 + 1):
        rowy[r] = y
        if r in sh.row_pt or r in sh.hidden_rows:
            h = sh.height(r)
        else:
            biggest = max([sh.style(r, c)["font"]["size"] for c in range(c1, c2 + 1) if (r, c) in disp] or [11])
            h = max(sh.default_row_pt, round(biggest * 1.36, 2))
        y += h
    rowy[r2 + 1] = y
    colx[c2 + 1] = x
    height_pt = y + MARGIN
    W, H = int(width_pt * k), int(height_pt * k)
    img = Image.new("RGB", (W, H), "white")
    d = ImageDraw.Draw(img)

    def box(r, c, rr=None, cc=None):
        rr, cc = rr or r, cc or c
        x0, x1 = colx[c], colx[cc + 1]
        if sh.rtl:
            x0, x1 = width_pt - x1, width_pt - x0
        return (x0 * k, rowy[r] * k, x1 * k, rowy[rr + 1] * k)

    eff = cf_effects(sh, wb, raw)
    covered = set()
    for m in sh.merges:
        for r in range(m[0], m[2] + 1):
            for c in range(m[1], m[3] + 1):
                if (r, c) != (m[0], m[1]):
                    covered.add((r, c))
    # fills, data bars, borders
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            if (r, c) in covered:
                continue
            st = sh.style(r, c)
            m = sh.merge_at(r, c)
            b = box(r, c, m[2] if m else None, m[3] if m else None)
            e = eff.get((r, c), {})
            fill = e.get("fill") or (hexrgb(st["fill"]) if st["fill"] else None)
            if fill:
                d.rectangle(b, fill=fill)
            if e.get("bar"):
                frac, col = e["bar"]
                pad = 2 * k
                bw = (b[2] - b[0] - 2 * pad) * frac
                if sh.rtl:
                    d.rectangle((b[2] - pad - bw, b[1] + pad, b[2] - pad, b[3] - pad), fill=col)
                else:
                    d.rectangle((b[0] + pad, b[1] + pad, b[0] + pad + bw, b[3] - pad), fill=col)
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            st = sh.style(r, c)
            m = sh.merge_at(r, c)
            if (r, c) in covered:
                continue
            b = box(r, c, m[2] if m else None, m[3] if m else None)
            for side, (style, col) in st["border"].items():
                wpx = {"thin": 0.75, "hair": 0.5, "medium": 1.5, "thick": 2.25, "double": 0.75}.get(style, 0.75) * k
                rgb = hexrgb(col)
                left, right = ("right", "left") if sh.rtl else ("left", "right")
                if side == "top":
                    d.line((b[0], b[1], b[2], b[1]), fill=rgb, width=max(1, round(wpx)))
                elif side == "bottom":
                    d.line((b[0], b[3], b[2], b[3]), fill=rgb, width=max(1, round(wpx)))
                    if style == "double":
                        d.line((b[0], b[3] - 2.2 * k, b[2], b[3] - 2.2 * k), fill=rgb, width=max(1, round(wpx)))
                elif side == left:
                    d.line((b[0], b[1], b[0], b[3]), fill=rgb, width=max(1, round(wpx)))
                elif side == right:
                    d.line((b[2], b[1], b[2], b[3]), fill=rgb, width=max(1, round(wpx)))
    # text
    used_fonts = set()
    for (r, c), text in sorted(disp.items()):
        if (r, c) in covered or not (r1 <= r <= r2 and c1 <= c <= c2):
            continue
        st = sh.style(r, c)
        f = st["font"]
        e = eff.get((r, c), {})
        bold = f["bold"] or e.get("bold", False)
        fnt, used = font_for(f["name"], bold, f["italic"], f["size"] * k, text, fallback)
        used_fonts.add(used)
        colour = e.get("font") or hexrgb(f["color"] or "000000")
        m = sh.merge_at(r, c)
        b = box(r, c, m[2] if m else None, m[3] if m else None)
        v = raw.get((r, c))
        is_num = isinstance(v, (int, float)) and not isinstance(v, bool)
        arabic = fonts.is_arabic_script(text)
        h = st["h"] or "general"
        if h == "general":
            if is_num:
                h = "left" if sh.rtl else "right"
            else:
                h = "right" if (arabic or (sh.rtl and not re.search(r"[A-Za-z]", text))) else "left"
        direction = "rtl" if arabic else "ltr"
        kw = {"direction": direction, "language": "ckb" if arabic else "en"}
        pad = 1.5 * k + st.get("indent", 0) * 6.75 * k
        clip = list(b)
        tw = fnt.getlength(text, **kw)
        if not is_num and not st["wrap"] and not m:  # text overflows into empty neighbours, like Excel
            step = -1 if (h == "right") != sh.rtl else 1
            cc = c + step
            while tw + 2 * pad > clip[2] - clip[0] and c1 <= cc <= c2 and (r, cc) not in disp:
                nb = box(r, cc)
                clip = [min(clip[0], nb[0]), clip[1], max(clip[2], nb[2]), clip[3]]
                cc += step
        if h in ("center", "centerContinuous"):
            tx, anchor = (b[0] + b[2]) / 2, "m"
        elif h == "right":
            tx, anchor = b[2] - pad, "r"
        else:
            tx, anchor = b[0] + pad, "l"
        v_al = st.get("v") or "bottom"
        lines = [text]
        if st["wrap"]:
            words, lines, cur = text.split(), [], ""
            for wd in words:
                trial = (cur + " " + wd).strip()
                if fnt.getlength(trial, **kw) + 2 * pad <= b[2] - b[0] or not cur:
                    cur = trial
                else:
                    lines.append(cur)
                    cur = wd
            lines.append(cur)
        asc, desc = fnt.getmetrics()
        lh = (asc + desc) * 1.05
        total = lh * len(lines)
        if v_al == "center":
            ty = (b[1] + b[3]) / 2 - total / 2
        elif v_al == "top":
            ty = b[1] + 2 * k
        else:
            ty = b[3] - 2 * k - total
        layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ld = ImageDraw.Draw(layer)
        for i, line in enumerate(lines):
            ld.text((tx, ty + i * lh + asc), line, font=fnt, fill=colour + (255,), anchor=anchor + "s", **kw)
        mask = Image.new("L", img.size, 0)
        ImageDraw.Draw(mask).rectangle([round(v) for v in clip], fill=255)
        alpha = Image.composite(layer.getchannel("A"), Image.new("L", img.size, 0), mask)
        layer.putalpha(alpha)
        img.paste(layer, (0, 0), layer)
    # chart placeholders
    lab = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", round(9 * k))
    for ch in sh.charts:
        if not ch["box"]:
            continue
        b = box(ch["box"][0], ch["box"][1], ch["box"][2], ch["box"][3])
        d.rectangle(b, outline=(200, 205, 212), width=max(1, round(0.75 * k)))
        t = ch["title"] or "chart"
        d.text(((b[0] + b[2]) / 2, (b[1] + b[3]) / 2), f"[{t}]  chart: open the .xlsx to see it",
               font=font_for("Arial", False, False, 9 * k, t, fallback)[0], fill=(120, 128, 140), anchor="mm",
               direction="rtl" if fonts.is_arabic_script(t) else "ltr")
    ext = os.path.splitext(out)[1].lower()
    if ext == ".pdf":
        portrait = (sh.page.get("orientation") or "portrait") == "portrait"
        pw, ph = (595, 842) if portrait else (842, 595)
        dpi = 200
        page = Image.new("RGB", (int(pw / 72 * dpi), int(ph / 72 * dpi)), "white")
        m = int(36 / 72 * dpi)
        fit = min((page.width - 2 * m) / img.width, (page.height - 2 * m) / img.height, dpi / 72 / k)
        im2 = img.resize((int(img.width * fit), int(img.height * fit)), Image.LANCZOS)
        page.paste(im2, ((page.width - im2.width) // 2 if sh.page.get("fitToPage") else m, m))
        page.save(out, "PDF", resolution=dpi, title=wb.props.get("title") or name)
    else:
        img.save(out)
    print(f"rtl-render: {out} (sheet {name}{', right-to-left' if sh.rtl else ''}; fonts {', '.join(sorted(used_fonts))})")
    return out


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("out")
    ap.add_argument("--sheet")
    ap.add_argument("--font")
    ap.add_argument("--scale", type=float, default=2.5)
    a = ap.parse_args(argv)
    render(a.file, a.out, a.sheet, a.font, a.scale)


if __name__ == "__main__":
    main()
