"""Drive the running GridCraft desktop app over its JSON-lines control channel (docs/control-protocol.md).

  gridcraft_control.py status [--port 7979]
      Is GridCraft running, and is a control port answering?
  gridcraft_control.py launch [--port 7979] [FILE | --sample budget|sales|grades]
      Start GridCraft with --control PORT. Refuses while GridCraft is already running: the user
      saves their work and quits it first (ask them), because control can only be switched on at launch.
  gridcraft_control.py call METHOD [PARAMS_JSON] [--port 7979]
      One request, e.g.  call engine.execute '{"command":"home.bold","params":{"range":"A1:C1","on":true}}'
                         call sheet.read '{"range":"A1:D10"}'
                         call ui.screenshot '{"path":"/Users/me/shot.png"}'      (absolute paths)
                         call app.save '{"path":"/Users/me/Documents/book_edit.xlsx"}'
  gridcraft_control.py batch FILE.json [--port 7979]
      [{"method":..., "params":...}, ...] in order on one connection; stops at the first error.

Every engine.execute request is checked first with gridcraft.py's validator (command ids, param
keys, formula function names), because the engine silently ignores unknown keys.
The channel has no token in GridCraft 0.5.0: any local process can drive the app while the port is
open, so quit control mode (app.quit after saving, then relaunch normally) when the task is done.
"""
import argparse
import json
import os
import socket
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import gridcraft  # noqa: E402  (validator and registry)

APP_BIN = "/Applications/GridCraft.app/Contents/MacOS/GridCraft"


class Conn:
    def __init__(self, port, timeout=65):
        try:
            self.s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
        except OSError as e:
            sys.exit(f"no GridCraft control channel on 127.0.0.1:{port} ({e.strerror or e}). "
                     "Start it with `gridcraft_control.py launch` (only after the user agrees).")
        self.f = self.s.makefile("rwb")
        self.n = 0

    def call(self, method, params=None):
        self.n += 1
        self.f.write((json.dumps({"id": self.n, "method": method, "params": params or {}}) + "\n").encode())
        self.f.flush()
        while True:
            line = self.f.readline()
            if not line:
                sys.exit("connection closed by GridCraft")
            msg = json.loads(line)
            if msg.get("id") in (self.n, None):
                return msg


def running():
    return subprocess.run(["pgrep", "-x", "GridCraft"], capture_output=True).returncode == 0


def port_open(port):
    try:
        socket.create_connection(("127.0.0.1", port), timeout=1).close()
        return True
    except OSError:
        return False


def validate(method, params):
    """engine.execute {command, params} and bare command-id methods go through the validator."""
    if method == "engine.execute":
        steps = [{"command": params.get("command"), "params": params.get("params") or {}}]
    elif method in gridcraft.registry():
        steps = [{"command": method, "params": params or {}}]
    else:
        return
    problems, warnings = gridcraft.check(steps)
    for w in warnings:
        print("warning: " + w, file=sys.stderr)
    if problems:
        sys.exit("rejected before sending:\n  " + "\n  ".join(problems))


def show(reply):
    text = json.dumps(reply, ensure_ascii=False)
    print(text if len(text) < 4000 else text[:4000] + " …(truncated)")


def cmd_status(a):
    print(f"GridCraft running: {running()}; control port {a.port} answering: {port_open(a.port)}")


def cmd_launch(a):
    if running():
        sys.exit("GridCraft is already running. Ask the user to save their work and quit it, then launch again.")
    if not os.path.exists(APP_BIN):
        sys.exit(f"{APP_BIN} not found; install GridCraft.app (or use the headless CLI instead).")
    args = [APP_BIN, "--control", str(a.port)]
    if a.sample:
        args += ["--sample", a.sample]
    if a.file:
        args.append(os.path.abspath(a.file))
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    for _ in range(60):
        time.sleep(0.5)
        if port_open(a.port):
            show(Conn(a.port).call("ui.inspect"))
            print(f"GridCraft control ready on 127.0.0.1:{a.port}")
            return
    sys.exit("GridCraft did not answer on the control port within 30 s")


def cmd_call(a):
    params = json.loads(a.params) if a.params else {}
    validate(a.method, params)
    reply = Conn(a.port).call(a.method, params)
    show(reply)
    sys.exit(0 if reply.get("ok") else 1)


def cmd_batch(a):
    with open(a.file) as f:
        steps = json.load(f)
    for s in steps:  # validate everything before touching the app
        validate(s["method"], s.get("params") or {})
    c = Conn(a.port)
    for s in steps:
        r = c.call(s["method"], s.get("params"))
        show(r)
        if not r.get("ok"):
            sys.exit(1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", type=int, default=7979)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    p = sub.add_parser("launch")
    p.add_argument("file", nargs="?")
    p.add_argument("--sample", choices=["budget", "sales", "grades"])
    p.set_defaults(fn=cmd_launch)
    p = sub.add_parser("call")
    p.add_argument("method")
    p.add_argument("params", nargs="?")
    p.set_defaults(fn=cmd_call)
    p = sub.add_parser("batch")
    p.add_argument("file")
    p.set_defaults(fn=cmd_batch)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
