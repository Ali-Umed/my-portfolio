"""Font lookup and Sorani Kurdish checks for GridCraft work (stdlib + Pillow).

GridCraft's own PDF/PNG export only has the 14 standard PDF fonts, so this module is used by the
critic (does the cell font cover Kurdish letters?) and by rtl_render.py (draw shaped Kurdish).

  python3 -I fonts.py find "Noto Naskh Arabic UI"     path and face index of an installed family
  python3 -I fonts.py cover "Tahoma"                    which Kurdish test characters the font has
  python3 -I fonts.py list [--arabic]                   installed families (with Arabic-script cover)
"""
import os
import struct
import sys

FONT_DIRS = ["/System/Library/Fonts", "/System/Library/Fonts/Supplemental", "/Library/Fonts",
             os.path.expanduser("~/Library/Fonts")]
KURDISH_TEST = "سڵاو، ئەمە تاقیکردنەوەیە بۆ کوردی: ێ ۆ ڵ ڕ ە ڤ ـ ١٢٣ 123 ArtCraft"
# Letters Sorani needs beyond basic Arabic: ڵ ڕ ێ ۆ ە ڤ ی ک گ چ پ ژ ه ئ, Kurdish/Arabic-Indic digits.
KURDISH_LETTERS = "ڵڕێۆەڤیکگچپژهئ"
ARABIC_DIGITS = "٠١٢٣٤٥٦٧٨٩"
# How GridCraft's PDF export picks a standard font (crates/pdf/src/lib.rs, verified on 0.5.0).
_SERIF = ["times", "cambria", "georgia", "garamond", "serif", "book", "palatino", "baskerville", "tinos", "caladea"]
_MONO = ["courier", "consolas", "mono", "menlo", "lucida console", "cousine", "code", "typewriter"]


def pdf_family(name):
    """'Helvetica', 'Times' or 'Courier': the face GridCraft's PDF export uses for a font name."""
    n = (name or "").lower()
    if any(m in n for m in _MONO):
        return "Courier"
    if any(s in n for s in _SERIF) and "sans" not in n:
        return "Times"
    return "Helvetica"


def is_arabic_script(text):
    return any("؀" <= ch <= "ۿ" or "ݐ" <= ch <= "ݿ" or "ﭐ" <= ch <= "﷿"
               or "ﹰ" <= ch <= "﻿" for ch in str(text or ""))


# ------------------------------------------------------------------ sfnt parsing

def _faces(data):
    """Offsets of each face's table directory (one for .ttf/.otf, several for .ttc)."""
    if data[:4] == b"ttcf":
        n = struct.unpack(">I", data[8:12])[0]
        return list(struct.unpack(f">{n}I", data[12:12 + 4 * n]))
    return [0]


def _tables(data, off):
    num = struct.unpack(">H", data[off + 4:off + 6])[0]
    t = {}
    for i in range(num):
        rec = data[off + 12 + 16 * i: off + 28 + 16 * i]
        tag, _, toff, tlen = struct.unpack(">4sIII", rec)
        t[tag.decode("latin-1")] = (toff, tlen)
    return t


def _names(data, tables):
    """(family, subfamily, full, typographic family) from the 'name' table."""
    if "name" not in tables:
        return {}
    off, _ = tables["name"]
    _, count, soff = struct.unpack(">HHH", data[off:off + 6])
    out = {}
    for i in range(count):
        pid, eid, lid, nid, ln, noff = struct.unpack(">HHHHHH", data[off + 6 + 12 * i: off + 18 + 12 * i])
        if nid not in (1, 2, 4, 16, 17):
            continue
        raw = data[off + soff + noff: off + soff + noff + ln]
        if pid == 3 or pid == 0:
            try:
                s = raw.decode("utf-16-be")
            except UnicodeDecodeError:
                continue
            pref = (pid == 3 and lid == 0x409)
        elif pid == 1:
            s, pref = raw.decode("mac_roman", "replace"), False
        else:
            continue
        if nid not in out or pref:
            out[nid] = s
    return out


def _cmap(data, tables):
    """Set of code points the face maps (formats 4 and 12)."""
    if "cmap" not in tables:
        return set()
    off, _ = tables["cmap"]
    n = struct.unpack(">H", data[off + 2:off + 4])[0]
    best = None
    for i in range(n):
        pid, eid, sub = struct.unpack(">HHI", data[off + 4 + 8 * i: off + 12 + 8 * i])
        fmt = struct.unpack(">H", data[off + sub: off + sub + 2])[0]
        rank = {12: 2, 4: 1}.get(fmt, 0)
        if (pid, eid) in ((3, 10), (0, 4), (0, 6)) and fmt == 12:
            rank = 3
        if rank and (best is None or rank > best[0]):
            best = (rank, off + sub, fmt)
    if not best:
        return set()
    _, s, fmt = best
    cps = set()
    if fmt == 4:
        segx2 = struct.unpack(">H", data[s + 6:s + 8])[0]
        seg = segx2 // 2
        ends = struct.unpack(f">{seg}H", data[s + 14: s + 14 + segx2])
        starts = struct.unpack(f">{seg}H", data[s + 16 + segx2: s + 16 + 2 * segx2])
        deltas = struct.unpack(f">{seg}h", data[s + 16 + 2 * segx2: s + 16 + 3 * segx2])
        roff_pos = s + 16 + 3 * segx2
        roffs = struct.unpack(f">{seg}H", data[roff_pos: roff_pos + segx2])
        for k in range(seg):
            for c in range(starts[k], ends[k] + 1):
                if c == 0xFFFF:
                    continue
                if roffs[k] == 0:
                    g = (c + deltas[k]) & 0xFFFF
                else:
                    gpos = roff_pos + 2 * k + roffs[k] + 2 * (c - starts[k])
                    g = struct.unpack(">H", data[gpos:gpos + 2])[0] if gpos + 2 <= len(data) else 0
                    if g:
                        g = (g + deltas[k]) & 0xFFFF
                if g:
                    cps.add(c)
    else:  # format 12
        ngroups = struct.unpack(">I", data[s + 12:s + 16])[0]
        for k in range(ngroups):
            a, b, _g = struct.unpack(">III", data[s + 16 + 12 * k: s + 28 + 12 * k])
            if b - a < 0x30000:
                cps.update(range(a, b + 1))
    return cps


_INDEX = None


def index():
    """[{family, style, full, path, face}] for every installed font face (names only, cheap)."""
    global _INDEX
    if _INDEX is not None:
        return _INDEX
    out = []
    for d in FONT_DIRS:
        try:
            files = sorted(os.listdir(d))
        except OSError:
            continue
        for f in files:
            if not f.lower().endswith((".ttf", ".otf", ".ttc")):
                continue
            p = os.path.join(d, f)
            try:
                with open(p, "rb") as fh:
                    data = fh.read()
                for i, off in enumerate(_faces(data)):
                    t = _tables(data, off)
                    nm = _names(data, t)
                    fam = nm.get(16) or nm.get(1) or os.path.splitext(f)[0]
                    out.append({"family": fam, "family1": nm.get(1, fam), "style": nm.get(17) or nm.get(2, ""),
                                "full": nm.get(4, fam), "path": p, "face": i})
            except Exception:  # unreadable or exotic font: skip it, never crash a check
                continue
    _INDEX = out
    return out


def find(name, bold=False, italic=False):
    """(path, face index) for a family/full name as typed in a cell's font, or None."""
    n = (name or "").strip().lower()
    if not n:
        return None
    hits = [f for f in index() if n in (f["family"].lower(), f["family1"].lower(), f["full"].lower(),
                                         os.path.splitext(os.path.basename(f["path"]))[0].lower())]
    if not hits:
        return None
    want = ("bold",) if bold else ("regular", "roman", "book", "normal", "medium", "light")

    def rank(f):
        st = f["style"].lower()
        slanted = "italic" in st or "oblique" in st
        weight_ok = any(w == st or st.startswith(w) for w in want) or (bold and "bold" in st and not italic) \
            or (italic and slanted and ("bold" in st) == bold)
        return (0 if weight_ok else 1, slanted != italic, f["face"])
    best = sorted(hits, key=rank)[0]
    return best["path"], best["face"]


def coverage(name):
    """{'found': bool, 'missing': 'chars', 'path': ...} for the Kurdish test characters."""
    loc = find(name)
    if not loc:
        return {"found": False, "missing": None, "path": None}
    path, face = loc
    with open(path, "rb") as fh:
        data = fh.read()
    cps = _cmap(data, _tables(data, _faces(data)[face]))
    need = set(KURDISH_TEST.replace(" ", "")) | set(KURDISH_LETTERS)
    missing = "".join(sorted(ch for ch in need if ord(ch) not in cps))
    return {"found": True, "missing": missing, "path": path, "face": face}


def coverage_chars(loc, chars):
    """Characters of `chars` that the face at loc=(path, face) does not map."""
    path, face = loc
    with open(path, "rb") as fh:
        data = fh.read()
    cps = _cmap(data, _tables(data, _faces(data)[face]))
    return "".join(c for c in chars if ord(c) not in cps)


def main():
    a = sys.argv[1:]
    if not a:
        print(__doc__)
        return
    if a[0] == "find":
        print(find(" ".join(a[1:])))
    elif a[0] == "cover":
        print(coverage(" ".join(a[1:])))
    elif a[0] == "list":
        fams = {}
        for f in index():
            fams.setdefault(f["family"], f)
        for fam in sorted(fams):
            if "--arabic" in a:
                c = coverage(fam)
                if c["found"] and c["missing"] is not None and not set(KURDISH_LETTERS) & set(c["missing"]):
                    print(f"{fam:<40} missing: {c['missing'] or '-'}")
            else:
                print(fam)


if __name__ == "__main__":
    main()

