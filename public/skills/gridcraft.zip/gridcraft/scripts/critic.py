"""Design and correctness critic for GridCraft workbooks (.xlsx/.xlsm).

  python3 -I critic.py BOOK.xlsx [--json] [--min 85] [--no-probe] [--no-render] [--sheet NAME]

Prints a score out of 100, PASS/FAIL (score >= --min and no severe issue), the recalculation proof
and every issue with the exact GridCraft command that fixes it. Every check is documented in
references/design-guide.md ("What the critic checks"). Data sources: the engine (recalculated
values, display text, error cells, print pages, accessibility), the .xlsx XML (styles, widths,
merges, conditional formats, charts) and GridCraft's own PDF export (text actually printed).
"""
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import fonts  # noqa: E402
import xlsxinfo as X  # noqa: E402

CLI = shutil.which("gridcraft-cli") or os.path.expanduser("~/.local/bin/gridcraft-cli")
POINTS = {"severe": 12, "major": 5, "minor": 2, "tip": 0}
CAPS = {"formulas": 45, "display": 30, "type": 12, "colour": 15, "layout": 15, "charts": 12, "print": 10,
        "doc": 6, "rtl": 10}
UNIT_CONSTANTS = {24, 30, 31, 52, 60, 100, 360, 365, 366, 1000, 3600, 10000, 100000, 1000000}
ARG_FUNCS = {"DATE", "TIME", "TEXT", "ROUND", "ROUNDUP", "ROUNDDOWN", "MROUND", "SUBTOTAL", "AGGREGATE",
             "INDEX", "CHOOSE", "OFFSET", "LARGE", "SMALL", "VLOOKUP", "HLOOKUP", "LEFT", "RIGHT", "MID",
             "REPT", "SEQUENCE", "RANDBETWEEN", "PERCENTILE", "PERCENTILE.INC", "PERCENTILE.EXC", "QUARTILE",
             "QUARTILE.INC", "CHAR", "UNICHAR", "FIXED", "DOLLAR", "BASE", "EDATE", "EOMONTH", "WORKDAY",
             "WEEKDAY", "WEEKNUM", "DATEDIF", "TAKE", "DROP", "CHOOSECOLS", "CHOOSEROWS", "XMATCH", "MATCH",
             "FLOOR", "CEILING", "FLOOR.MATH", "CEILING.MATH", "TRUNC", "INT", "MOD", "POWER", "LOG"}
HEADER_DATE = re.compile(r"date|day\b|due|start|end\b|deadline|month|بەروار|ڕۆژ", re.I)
HEADER_PCT = re.compile(r"%|٪|share|rate\b|margin|growth|used|ratio|pct|percent|ڕێژە", re.I)
HEADER_IDS = re.compile(r"\bid\b|code|year|\bno\b|number|zip|phone|#|ساڵ|ژمارە", re.I)
TOTAL_LABEL = re.compile(r"^\s*(grand\s+|sub-?)?totals?\s*:?\s*$|^\s*net\s+(total|income|profit|pay|cash)\b|"
                         r"^\s*کۆ(ی\s*گشتی)?\s*:?\s*$", re.I)
NUMERIC_TEXT = re.compile(r"^\s*[-+(]?\s*[$€£¥]?\s*\d[\d,]*(\.\d+)?\s*%?\)?\s*$")
REF = re.compile(r"(?<![A-Za-z0-9_.\]\[$])(\$?)([A-Z]{1,3})(\$?)(\d{1,7})(?![A-Za-z0-9_(\[])")
QREF = re.compile(r"((?:'(?:[^']|'')+'|[A-Za-z_][\w.]*)!)?(\$?[A-Z]{1,3}\$?\d{1,7})(?::(\$?[A-Z]{1,3}\$?\d{1,7}))?(?![A-Za-z0-9_(\[])")


# ------------------------------------------------------------------ engine access

def cli(*args):
    p = subprocess.run([CLI, *args], capture_output=True, text=True)
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout).strip())
    return p.stdout


def run_cmds(path, cmds):
    """Run commands on PATH (in memory, nothing saved); return the result of each command in order."""
    with tempfile.NamedTemporaryFile("w", suffix=".jsonl", delete=False) as fh:
        for c, p in cmds:
            fh.write(json.dumps({"command": c, "params": p}, ensure_ascii=False) + "\n")
    try:
        out = cli("run", "--in", path, "--script", fh.name)
    finally:
        os.unlink(fh.name)
    res, it = [], iter(json.loads(l) for l in out.splitlines() if l.startswith("{"))
    by_cmd = list(it)
    # results are printed only for non-null results; align by command id in order
    k = 0
    for c, _ in cmds:
        if k < len(by_cmd) and by_cmd[k].get("command") == c:
            res.append(by_cmd[k].get("result"))
            k += 1
        else:
            res.append(None)
    return res


def grid(rows, r0, c0):
    out = {}
    for i, row in enumerate(rows or []):
        for j, v in enumerate(row):
            if v is not None and v != "":
                out[(r0 + i, c0 + j)] = v
    return out


# ------------------------------------------------------------------ text measurement

_FONT_CACHE = {}


def text_width(text, name, size, bold=False):
    """Width in points as GridCraft's PDF export draws it (Helvetica/Times/Courier metrics)."""
    fam = fonts.pdf_family(name)
    key = (fam, bold)
    if key not in _FONT_CACHE:
        try:
            from PIL import ImageFont
            path = {"Helvetica": "/System/Library/Fonts/Helvetica.ttc", "Times": "/System/Library/Fonts/Times.ttc",
                    "Courier": "/System/Library/Fonts/Courier.ttc"}[fam]
            _FONT_CACHE[key] = ImageFont.truetype(path, 1000, index=1 if bold else 0)
        except Exception:
            _FONT_CACHE[key] = None
    f = _FONT_CACHE[key]
    if f is None:
        return len(text) * size * (0.6 if fam == "Courier" else 0.53)
    return f.getlength(text) * size / 1000.0


def chars_for(width_pt):
    """Excel column width (characters) that gives at least width_pt points."""
    return max(4, math.ceil((width_pt / 0.75 - 5) / 7) + 1)


# ------------------------------------------------------------------ formula helpers

def strip_strings(f):
    return re.sub(r'"(?:[^"]|"")*"', '""', f)


def rel_sig(formula, r, c):
    """Formula with relative references written as offsets (Excel R1C1 idea) for consistency checks."""
    body = strip_strings(formula)

    def sub(m):
        cabs, col, rabs, row = m.group(1), m.group(2), m.group(3), int(m.group(4))
        cc = X.col_index(col)
        cs = f"C{cc}" if cabs else f"C[{cc - c}]"
        rs = f"R{row}" if rabs else f"R[{row - r}]"
        return rs + cs
    return re.sub(r"\s+", "", REF.sub(sub, body))


def refs_of(formula, sheet_name, names=None):
    """[(sheet, r1, c1, r2, c2)] for the A1 references in a formula (defined names resolved)."""
    out = []
    body = strip_strings(formula)
    if names:
        for nm, target in names.items():
            if re.search(r"(?<![\w.!$])" + re.escape(nm) + r"(?![\w(!\[])", body, re.I):
                out += refs_of("=" + target, sheet_name)
    for m in QREF.finditer(body):
        sh = m.group(1)
        sh = sh[:-1].strip("'").replace("''", "'") if sh else sheet_name
        try:
            a = X.parse_cell(m.group(2))
            b = X.parse_cell(m.group(3)) if m.group(3) else a
        except ValueError:
            continue
        out.append((sh, min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])))
    return out


def magic_numbers(formula):
    """Numeric literals that look like hard-coded business values (not unit constants or arguments)."""
    body = strip_strings(formula.lstrip("="))
    body = QREF.sub("R", body)
    out, stack, i = [], [], 0
    tok = re.compile(r"([A-Za-z_][\w.]*)\s*\(|(\()|(\))|(?<![A-Za-z_\d.])(\d+\.?\d*(?:[eE][+-]?\d+)?)(%?)")
    for m in tok.finditer(body):
        if m.group(1):
            stack.append(m.group(1).upper())
        elif m.group(2):
            stack.append("")
        elif m.group(3):
            if stack:
                stack.pop()
        elif m.group(4):
            v = float(m.group(4)) / (100 if m.group(5) else 1)
            if stack and stack[-1] in ARG_FUNCS:
                continue
            if v == int(v) and (abs(v) <= 12 or abs(v) in UNIT_CONSTANTS):
                continue
            if v in (0.5, 0.25, 0.75):
                continue
            out.append(m.group(4) + m.group(5))
    return out


def is_num(v):
    return isinstance(v, (int, float)) and not isinstance(v, bool)


# ------------------------------------------------------------------ the critic

class Critic:
    def __init__(self, path, probe=True, render=True, only_sheet=None):
        self.path, self.probe, self.render, self.only = path, probe, render, only_sheet
        self.issues, self.notes = [], []
        self.proof = {}

    def add(self, sev, cat, where, msg, fix=""):
        self.issues.append({"severity": sev, "points": POINTS[sev], "category": cat, "where": where,
                            "message": msg, "fix": fix})

    # -- data
    def load(self):
        self.wb = X.open_workbook(self.path)
        info = json.loads(cli("info", self.path, "--json"))
        self.info = info
        self.used = {s["name"]: s.get("usedRange") for s in info.get("sheets", [])}
        cmds = []
        for s in self.wb.sheets:
            u = self.used.get(s.name)
            if not u:
                continue
            for extra in ({"formatted": True}, {}, {"formulas": True}):
                cmds.append(("sheet.read", dict({"sheet": s.name, "range": u}, **extra)))
        cmds += [("formulas.errorChecking", {}), ("file.printPreview", {"sheets": "all"}),
                 ("review.checkAccessibility", {})]
        res = run_cmds(self.path, cmds)
        k = 0
        self.disp, self.vals, self.fml = {}, {}, {}
        for s in self.wb.sheets:
            u = self.used.get(s.name)
            if not u:
                self.disp[s.name] = self.vals[s.name] = self.fml[s.name] = {}
                continue
            r0, c0, _, _ = X.parse_range(u)
            self.disp[s.name] = grid(res[k]["values"], r0, c0)
            self.vals[s.name] = grid(res[k + 1]["values"], r0, c0)
            self.fml[s.name] = {rc: v for rc, v in grid(res[k + 2]["values"], r0, c0).items()
                                if isinstance(v, str) and v.startswith("=")}
            k += 3
        self.errors = res[k] or {}
        self.pages = (res[k + 1] or {}).get("pageList", [])
        self.access = res[k + 2] or []

    def sheets(self):
        return [s for s in self.wb.sheets if s.state == "visible" and (not self.only or s.name == self.only)]

    # -- formulas
    def check_formulas(self):
        errs = self.errors.get("errors") or []
        for e in errs[:12]:
            self.add("severe", "formulas", f"{e.get('sheet')}!{e.get('cell')}",
                     f"{e.get('error')} after recalculation in {e.get('formula')}",
                     "trace it with formulas.tracePrecedents; fix the reference/name/division instead of hiding it "
                     "(IFERROR only for errors you expect, e.g. lookups of optional items)")
        if len(errs) > 12:
            self.add("severe", "formulas", "workbook", f"{len(errs) - 12} more error cells", "")
        if self.errors.get("circular"):
            self.add("severe", "formulas", ", ".join(map(str, self.errors["circular"][:5])), "circular reference",
                     "break the loop; GridCraft only iterates if formulas.calculationOptions iterative=true")
        if str(self.info.get("calcMode", "Automatic")).lower().startswith("manual") or self.wb.calc_mode == "manual":
            self.add("major", "formulas", "workbook", "calculation mode is manual (recipients see stale numbers)",
                     'formulas.calculationOptions {"mode":"automatic"}')
        stale, missing = [], []
        for s in self.sheets():
            vals = self.vals[s.name]
            for (r, c), cell in s.cells.items():
                if cell["f"] is None or s.in_spill(r, c):
                    continue
                ev = vals.get((r, c))
                if cell["v"] is None and ev is not None:
                    missing.append(f"{s.name}!{X.addr(r, c)}")
                elif is_num(cell["v"]) and is_num(ev) and abs(cell["v"] - ev) > 1e-6 * max(1, abs(ev)):
                    stale.append(f"{s.name}!{X.addr(r, c)} (file {cell['v']:g}, recalculated {ev:g})")
        if stale:
            self.add("major", "formulas", ", ".join(stale[:4]),
                     f"{len(stale)} cached results differ from a fresh recalculation; viewers that don't "
                     "recalculate (previews, phones) show the old numbers",
                     "re-save through GridCraft: gridcraft.py apply NEW.xlsx --in THIS.xlsx --steps '[]'")
        if missing:
            self.add("minor", "formulas", ", ".join(missing[:4]),
                     f"{len(missing)} formulas have no saved result (blank in previews)",
                     "re-save through GridCraft (apply with no steps)")
        for s in self.sheets():
            self._formula_runs(s)
            self._empty_refs(s)
            self._sum_ranges(s)
            self._magic(s)
            self._text_numbers(s)

    def _formula_runs(self, s):
        """In each row/column run of filled cells, the dominant formula pattern (>= 3 cells and half
        the run) defines the block; typed numbers or odd formulas inside its span are flagged."""
        fml, vals = self.fml[s.name], self.vals[s.name]
        sig = {rc: rel_sig(f, *rc) for rc, f in fml.items()}
        total_like = re.compile(r"^=\s*(SUM|SUBTOTAL|AGGREGATE)\(", re.I)
        hard, odd, seen = [], [], set()
        for axis in (0, 1):
            lines = {}
            for (r, c) in vals:
                lines.setdefault(c if axis == 0 else r, []).append(r if axis == 0 else c)
            for key, idx in lines.items():
                idx.sort()
                runs, cur = [], [idx[0]]
                for i in idx[1:]:
                    if i == cur[-1] + 1:
                        cur.append(i)
                    else:
                        runs.append(cur)
                        cur = [i]
                runs.append(cur)
                for run in runs:
                    cells = [(i, key) if axis == 0 else (key, i) for i in run]
                    counts = {}
                    for rc in cells:
                        if rc in sig:
                            counts[sig[rc]] = counts.get(sig[rc], 0) + 1
                    if not counts:
                        continue
                    dom, n = max(counts.items(), key=lambda kv: kv[1])
                    calc = [rc for rc in cells if rc in fml or is_num(vals.get(rc))]
                    if n < 3 or n * 2 < len(calc):
                        continue
                    pos = [i for i, rc in enumerate(cells) if sig.get(rc) == dom]
                    for rc in cells[pos[0] + 1:pos[-1]]:
                        if rc in seen:
                            continue
                        if rc not in fml and is_num(vals.get(rc)) and not s.in_spill(*rc):
                            hard.append((rc, cells[pos[0]]))
                            seen.add(rc)
                        elif rc in fml and sig[rc] != dom and not total_like.match(fml[rc]):
                            odd.append((rc, cells[pos[0]]))
                            seen.add(rc)
        for (r, c), a in hard[:4]:
            self.add("severe", "formulas", f"{s.name}!{X.addr(r, c)}",
                     f"typed number {vals[(r, c)]:g} inside a block of formulas like {fml[a]} - it won't update",
                     f'cell.set {{"cell":"{X.addr(r, c)}","input":"<the formula>"}} or edit.fillDown over the block')
        for (r, c), a in odd[:4]:
            self.add("major", "formulas", f"{s.name}!{X.addr(r, c)}",
                     f"formula {fml[(r, c)]} breaks the pattern of its block ({fml[a]})",
                     "if it is a mistake, re-fill the block with edit.fillDown/edit.fillRight; if intended, "
                     "add a note (review.newNote) saying why")

    def _empty_refs(self, s):
        """Formulas whose references all point at empty cells (a fill/copy that shifted), and runs of
        identical relative formulas (a copy that didn't adjust)."""
        fml = self.fml[s.name]
        filled = {sh: set(v) | set(self.fml.get(sh, {})) for sh, v in self.vals.items()}
        empty_hits = []
        for (r, c), f in fml.items():
            if '""' in f or re.search(r"ISBLANK|ISERROR|IFERROR|ROW\(|COLUMN\(|INDIRECT|OFFSET", f, re.I):
                continue
            refs = refs_of(f, s.name)
            if not refs:
                continue
            cells_filled = False
            for sh, r1, c1, r2, c2 in refs:
                got = filled.get(sh)
                if got is None:
                    cells_filled = True  # another workbook or unknown sheet: don't judge
                    break
                if (r2 - r1 + 1) * (c2 - c1 + 1) > 20000 or any(r1 <= rr <= r2 and c1 <= cc <= c2 for rr, cc in got):
                    cells_filled = True
                    break
            if not cells_filled:
                empty_hits.append((r, c, f))
        for r, c, f in empty_hits[:3]:
            self.add("severe" if len(empty_hits) >= 3 else "major", "formulas", f"{s.name}!{X.addr(r, c)}" + (f" (+{len(empty_hits) - 1})" if len(empty_hits) > 1 else ""),
                     f"{f} only refers to empty cells - a fill or copy probably shifted the references",
                     "re-enter the first formula with cell.set and copy it with edit.fillDown/edit.fillRight "
                     "(range.fill shifts references by the active cell, still in 0.6.1: selection.set the range first)")
            break
        same = {}
        for (r, c), f in fml.items():
            if REF.search(strip_strings(f)) and re.search(r"(?<!\$)\b[A-Z]{1,3}\d", strip_strings(f)):
                same.setdefault((c, f), []).append(r)
        for (c, f), rows in same.items():
            rows.sort()
            run = 1
            for a, b in zip(rows, rows[1:]):
                run = run + 1 if b == a + 1 else 1
                if run >= 3:
                    self.add("major", "formulas", f"{s.name}!{X.addr(rows[0], c)}:{X.addr(rows[-1], c)}",
                             f"every row repeats {f} - relative references did not move down",
                             f'cell.set the first cell, then edit.fillDown {{"range":"{X.addr(rows[0], c)}:{X.addr(rows[-1], c)}"}}')
                    break

    def _sum_ranges(self, s):
        fml, vals = self.fml[s.name], self.vals[s.name]
        pat = re.compile(r"^=\s*SUM\(\s*\$?([A-Z]{1,3})\$?(\d+)\s*:\s*\$?([A-Z]{1,3})\$?(\d+)\s*\)\s*$", re.I)

        def numeric_cell(rc):
            v = vals.get(rc)
            f = fml.get(rc, "")
            return is_num(v) and not re.match(r"^=\s*(SUM|SUBTOTAL|AGGREGATE)\(", f, re.I)

        def year_like(rc):
            v = vals.get(rc)
            return is_num(v) and v == int(v) and 1900 <= v <= 2100
        for (r, c), f in fml.items():
            m = pat.match(f)
            if not m:
                continue
            c1, r1, c2, r2 = X.col_index(m.group(1)), int(m.group(2)), X.col_index(m.group(3)), int(m.group(4))
            miss = None
            if c1 == c2 == c and r2 < r:
                if r2 + 1 < r and numeric_cell((r2 + 1, c)):
                    miss = X.addr(r2 + 1, c)
                elif numeric_cell((r1 - 1, c)) and not year_like((r1 - 1, c)) and (r1 - 1, c) not in fml:
                    miss = X.addr(r1 - 1, c)
            elif r1 == r2 == r and c2 < c:
                if c2 + 1 < c and numeric_cell((r, c2 + 1)):
                    miss = X.addr(r, c2 + 1)
            if miss:
                self.add("severe", "formulas", f"{s.name}!{X.addr(r, c)}",
                         f"{f} leaves out the adjacent number in {miss}",
                         f'cell.set {{"cell":"{X.addr(r, c)}","input":"=SUM(<range including {miss}>)"}}')

    def _magic(self, s):
        found = []
        for (r, c), f in self.fml[s.name].items():
            for lit in magic_numbers(f):
                found.append((r, c, lit, f))
        seen = set()
        for r, c, lit, f in found:
            key = (rel_sig(f, r, c), lit)
            if key in seen:
                continue
            seen.add(key)
            if len(seen) > 3:
                break
            self.add("minor", "formulas", f"{s.name}!{X.addr(r, c)}",
                     f"hard-coded {lit} in {f}",
                     "put it in a labelled input cell (blue input style) and refer to it, or name it with "
                     "formulas.defineName, so a change happens in one place")

    def _text_numbers(self, s):
        vals = self.vals[s.name]
        hits = [(r, c) for (r, c), v in vals.items() if isinstance(v, str) and NUMERIC_TEXT.match(v)
                and is_num(vals.get((r - 1, c))) and is_num(vals.get((r + 1, c)))]
        for r, c in hits[:3]:
            self.add("major", "formulas", f"{s.name}!{X.addr(r, c)}",
                     f"number stored as text ({vals[(r, c)]!r}); SUM and charts skip it",
                     f'range.setValues {{"range":"{X.addr(r, c)}","values":[[<number>]]}}')

    def recalc_probe(self):
        """Change real inputs in memory and prove dependent formulas recalculate (file untouched)."""
        deps = {}
        names = {d["name"]: d["ref"] for d in self.wb.defined if d["local"] is None and not d["name"].startswith("_xlnm")}
        for s in self.wb.sheets:
            for (r, c), f in self.fml[s.name].items():
                for sh, r1, c1, r2, c2 in refs_of(f, s.name, names):
                    if (r2 - r1 + 1) * (c2 - c1 + 1) > 5000:
                        continue
                    for rr in range(r1, r2 + 1):
                        for cc in range(c1, c2 + 1):
                            deps.setdefault((sh, rr, cc), []).append((s.name, r, c, r1 == r2 and c1 == c2))
        cand = []
        for (sh, r, c), ds in deps.items():
            sheet = next((x for x in self.wb.sheets if x.name == sh), None)
            v = self.vals.get(sh, {}).get((r, c))
            if sheet is None or not is_num(v) or (r, c) in self.fml.get(sh, {}) or sheet.in_spill(r, c):
                continue
            single = any(d[3] for d in ds)
            cand.append((not single, -len(ds), sh, r, c, v))
        cand.sort()
        picked, seen_sheets = [], {}
        for _, _, sh, r, c, v in cand:
            if seen_sheets.get(sh, 0) >= 6:
                continue
            seen_sheets[sh] = seen_sheets.get(sh, 0) + 1
            picked.append((sh, r, c, v))
            if len(picked) >= 8:
                break
        n_formulas = sum(len(v) for v in self.fml.values())
        if not picked:
            self.proof = {"inputs": 0, "formulas": n_formulas, "note": "no numeric inputs feed formulas"}
            return
        base_err = {(e.get("sheet"), e.get("cell")) for e in (self.errors.get("errors") or [])}
        dead, new_err, updated_total = [], set(), 0
        for sh, r, c, v in picked:
            nv = v + 1 if v == int(v) else v * 1.05
            if v == 0:
                nv = 1
            cmds = [("cell.set", {"sheet": sh, "cell": X.addr(r, c), "input": repr(nv)})]
            for s in self.wb.sheets:
                if self.used.get(s.name):
                    cmds.append(("sheet.read", {"sheet": s.name, "range": self.used[s.name]}))
            cmds.append(("formulas.errorChecking", {}))
            try:
                res = run_cmds(self.path, cmds)
            except RuntimeError as e:
                self.notes.append(f"probe {sh}!{X.addr(r, c)} failed: {e}")
                continue
            changed, k = 0, 1
            for s in self.wb.sheets:
                if not self.used.get(s.name):
                    continue
                r0, c0, _, _ = X.parse_range(self.used[s.name])
                after = grid(res[k]["values"], r0, c0)
                k += 1
                before = self.vals[s.name]
                for rc in self.fml[s.name]:
                    a, b = before.get(rc), after.get(rc)
                    if a != b and not (is_num(a) and is_num(b) and abs(a - b) <= 1e-12 * max(1, abs(a))):
                        changed += 1
            for e in (res[k] or {}).get("errors") or []:
                if (e.get("sheet"), e.get("cell")) not in base_err:
                    new_err.add(f"{e.get('sheet')}!{e.get('cell')} {e.get('error')} when {sh}!{X.addr(r, c)}={nv:g}")
            updated_total += changed
            conditional = re.compile(r"\b(IFS?|IFERROR|COUNTIFS?|SUMIFS?|AVERAGEIFS?|MAXIFS|MINIFS|MIN|MAX|LARGE|SMALL|"
                                     r"RANK(\.EQ|\.AVG)?|X?MATCH|[XVH]LOOKUP|INDEX|CHOOSE|SWITCH|FILTER|SORT|UNIQUE|ROUND\w*)\(", re.I)
            direct = [self.fml[d[0]].get((d[1], d[2]), "") for d in deps.get((sh, r, c), [])]
            if changed == 0 and not any(conditional.search(f) for f in direct):
                dead.append(f"{sh}!{X.addr(r, c)}")
        self.proof = {"inputs": len(picked), "inputs_list": [f"{sh}!{X.addr(r, c)}" for sh, r, c, _ in picked],
                      "formulas": n_formulas, "updates": updated_total, "dead_inputs": dead,
                      "new_errors": sorted(new_err)}
        if dead and len(dead) == len(picked):
            self.add("severe", "formulas", ", ".join(dead[:4]),
                     "changing the inputs changes no formula result - the model doesn't recalculate",
                     'formulas.calculationOptions {"mode":"automatic"}; check the formulas reference these cells')
        elif dead:
            self.add("minor", "formulas", ", ".join(dead[:4]),
                     "changing this input changes no result (dead input, or only feeds MIN/MAX/lookups)",
                     "check that the formulas that should use it actually refer to it")
        if new_err:
            self.add("minor", "formulas", "; ".join(sorted(new_err)[:2]),
                     f"{len(new_err)} formulas break when an input changes slightly (fragile)",
                     "guard the division/lookup (IF(x=0,0,...), IFERROR with a stated fallback)")

    # -- display: number formats, ####, clipped text
    def check_display(self):
        for s in self.sheets():
            disp, vals, fml = self.disp[s.name], self.vals[s.name], self.fml[s.name]
            hashes, clipped, general_dec, general_big, sci, negzero = [], [], {}, {}, [], []
            for (r, c), v in vals.items():
                st = s.style(r, c)
                font = st["font"]
                text = str(disp.get((r, c), v))
                m = s.merge_at(r, c)
                if m and (m[0], m[1]) != (r, c):
                    continue
                avail = (sum(s.width(cc) for cc in range(m[1], m[3] + 1)) if m else s.width(c)) - 3
                avail -= st.get("indent", 0) * 6.75  # one indent level = 9 px in GridCraft's renderer
                if avail <= 0:
                    continue
                w = text_width(text, font["name"], font["size"], font["bold"])
                if is_num(v):
                    fmt = st["numfmt"] or "General"
                    if fmt == "General":
                        if re.search(r"\dE[+-]\d", text) and 1e-4 <= abs(v) < 1e15:
                            sci.append((r, c))
                        elif v != int(v) and re.search(r"\.\d{3,}", text):
                            general_dec.setdefault(c, []).append(r)
                        elif abs(v) >= 10000 and "," not in text and not (v == int(v) and 1900 <= v <= 2100):
                            general_big.setdefault(c, []).append(r)
                    elif w > avail + 0.5 and not st["wrap"]:
                        hashes.append((r, c, w))
                    if re.match(r"^\s*-0([.,]0+)?%?\s*$", text):
                        negzero.append((r, c))
                elif isinstance(v, str) and not st["wrap"] and w > avail + 0.5 and not fonts.is_arabic_script(text):
                    h = st["h"] or "general"
                    if m:
                        nb = [(r, m[3] + 1)]
                    elif h in ("right",):
                        nb = [(r, c - 1)]
                    elif h in ("center", "centerContinuous"):
                        nb = [(r, c - 1), (r, c + 1)]
                    else:
                        nb = [(r, c + 1)]
                    if any(x in vals for x in nb):
                        clipped.append((r, c, w))
            for r, c, w in hashes[:5]:
                L = X.col_letters(c)
                self.add("severe", "display", f"{s.name}!{X.addr(r, c)}",
                         f"shows ##### - '{disp.get((r, c))}' needs {w + 3:.0f} pt, column {L} is {s.width(c):.0f} pt",
                         f'home.columnWidth {{"cols":"{L}:{L}","chars":{chars_for(w + 3)}}} (set widths after number formats)')
            # text that spills past the last used column runs off the printed page
            last_col = max([cc for (_, cc) in vals] + [ch["box"][3] for ch in s.charts if ch["box"]], default=0)
            for (r, c), v in vals.items():
                st = s.style(r, c)
                if not isinstance(v, str) or st["wrap"] or s.merge_at(r, c) or (st["h"] or "general") not in ("general", "left"):
                    continue
                w = text_width(v, st["font"]["name"], st["font"]["size"], st["font"]["bold"])
                span = sum(s.width(cc) for cc in range(c, last_col + 1)) - 3
                if w > span + 1 and not fonts.is_arabic_script(v) and not any((r, cc) in vals for cc in range(c + 1, last_col + 1)):
                    self.add("minor", "display", f"{s.name}!{X.addr(r, c)}",
                             f"text runs {w - span:.0f} pt past the last column and is cut off in print",
                             f'split it into two cells, shorten it, or home.wrapText {{"range":"{X.addr(r, c)}:{X.col_letters(last_col)}{r}","on":true}} over a merged area')
            for r, c, w in clipped[:5]:
                L = X.col_letters(c)
                is_head = self._is_header_row(s, r)
                self.add("major" if is_head else "minor", "display", f"{s.name}!{X.addr(r, c)}",
                         f"text '{str(vals[(r, c)])[:30]}' is cut off by the next cell",
                         f'home.columnWidth {{"cols":"{L}:{L}","chars":{chars_for(w + 3)}}} or home.wrapText {{"range":"{X.addr(r, c)}","on":true}}')
            for (r, c) in sci[:3]:
                self.add("major", "display", f"{s.name}!{X.addr(r, c)}",
                         f"General format shows {disp.get((r, c))} (scientific notation)",
                         f'home.numberFormat {{"range":"{X.addr(r, c)}","code":"#,##0"}} and widen the column')
            for c, rows in list(general_dec.items())[:4]:
                where = self._run_label(s, c, rows)
                self.add("major", "display", where,
                         f"unformatted decimals such as {disp.get((rows[0], c))} (General format)",
                         f'home.numberFormat {{"range":"{where.split("!")[1]}","code":"#,##0.00"}} '
                         '(or "0.0%" for ratios, "#,##0" for counts)')
            for c, rows in list(general_big.items())[:3]:
                where = self._run_label(s, c, rows)
                head = self._header_above(s, c, min(rows))
                if head and (HEADER_IDS.search(head) or HEADER_DATE.search(head)):
                    continue
                self.add("minor", "display", where, f"large numbers without thousands separators ({disp.get((rows[0], c))})",
                         f'home.numberFormat {{"range":"{where.split("!")[1]}","code":"#,##0"}}')
            for r, c in negzero[:2]:
                self.add("minor", "display", f"{s.name}!{X.addr(r, c)}", f"shows {disp.get((r, c))} (negative zero)",
                         "wrap the formula in ROUND(...,2) so tiny float leftovers become 0")
            self._header_formats(s)

    def _header_formats(self, s):
        vals = self.vals[s.name]
        for (r, c), v in vals.items():
            if not isinstance(v, str) or not is_num(vals.get((r + 1, c))):
                continue
            run = []
            rr = r + 1
            while is_num(vals.get((rr, c))):
                run.append(rr)
                rr += 1
            if len(run) < 2:
                continue
            fmts = {s.style(x, c)["numfmt"] or "General" for x in run}
            nums = [vals[(x, c)] for x in run]
            rg = f"{X.addr(run[0], c)}:{X.addr(run[-1], c)}"
            if HEADER_DATE.search(v) and all(f == "General" for f in fmts) and all(20000 <= n <= 80000 for n in nums):
                self.add("major", "display", f"{s.name}!{rg}", f"dates under '{v}' show as serial numbers ({nums[0]:g})",
                         f'home.numberFormat {{"range":"{rg}","code":"d mmm yyyy"}}')
            elif HEADER_PCT.search(v) and not any("%" in f for f in fmts) and all(abs(n) <= 1.5 for n in nums) \
                    and any(n != int(n) for n in nums):
                self.add("major", "display", f"{s.name}!{rg}", f"ratios under '{v}' are not formatted as percentages",
                         f'home.numberFormat {{"range":"{rg}","code":"0.0%"}}')

    def _run_label(self, s, c, rows):
        rows = sorted(rows)
        return f"{s.name}!{X.addr(rows[0], c)}" + (f":{X.addr(rows[-1], c)}" if len(rows) > 1 else "")

    def _header_above(self, s, c, r):
        vals = self.vals[s.name]
        rr = r - 1
        while rr >= 1 and is_num(vals.get((rr, c))):
            rr -= 1
        v = vals.get((rr, c))
        return v if isinstance(v, str) else None

    def _is_header_row(self, s, r):
        """A row of typed labels (no formulas) with numbers under at least two of them."""
        vals, fml = self.vals[s.name], self.fml[s.name]
        row = [(c, v) for (rr, c), v in vals.items() if rr == r]
        texts = [c for c, v in row if isinstance(v, str) and (r, c) not in fml]
        return len(texts) >= 2 and len(texts) == len(row) and sum(is_num(vals.get((r + 1, c))) for c in texts) >= 2

    # -- typography and hierarchy
    def check_type(self):
        for s in self.sheets():
            vals = self.vals[s.name]
            fams, sizes, small, centred = {}, set(), [], []
            for (r, c), v in vals.items():
                st = s.style(r, c)
                f = st["font"]
                fams.setdefault(f["name"], []).append((r, c))
                sizes.add(f["size"])
                if f["size"] < 8:
                    small.append((r, c, f["size"]))
                if is_num(v) and st["h"] == "center" and not s.merge_at(r, c) and \
                        (v != int(v) or abs(v) >= 1000 or re.search(r"0\.0|\$|%", st["numfmt"] or "")):
                    centred.append((r, c))
            if len(fams) > 3:
                self.add("minor", "type", s.name, f"{len(fams)} fonts ({', '.join(sorted(fams))}); use one family, two at most",
                         'home.fontName {"range":"A:Z","name":"Arial"} first, then only the title in a display face')
            if len(sizes) > 5:
                self.add("minor", "type", s.name, f"{len(sizes)} font sizes ({', '.join(f'{x:g}' for x in sorted(sizes))})",
                         "keep to a scale: body 10-11, headers 11 bold, section 13-14, title 16-20")
            for r, c, sz in small[:2]:
                self.add("major", "type", f"{s.name}!{X.addr(r, c)}", f"{sz:g} pt text is unreadable in print",
                         f'home.fontSize {{"range":"{X.addr(r, c)}","size":9}} (8 pt is the floor for footnotes)')
            if len(centred) >= 3:
                rr, cc = centred[0]
                self.add("minor", "type", f"{s.name}!{X.addr(rr, cc)}",
                         f"{len(centred)} numbers are centred; decimals stop lining up",
                         f'home.alignRight {{"range":"<the number range>"}}')
            self._hierarchy(s)

    def _hierarchy(self, s):
        vals = self.vals[s.name]
        rows = sorted({r for (r, _) in vals})
        flagged = 0
        for r in rows:
            if not self._is_header_row(s, r):
                continue
            cells = [c for (rr, c) in vals if rr == r]
            if any(s.in_table(r, c) for c in cells):
                continue
            body = s.style(r + 1, cells[0])["font"]["size"]
            ok = any(s.style(r, c)["font"]["bold"] or s.style(r, c)["fill"] or s.style(r, c)["border"].get("bottom")
                     or s.style(r, c)["font"]["size"] > body for c in cells)
            if not ok and flagged < 2:
                flagged += 1
                rg = f"{X.addr(r, min(cells))}:{X.addr(r, max(cells))}"
                self.add("major", "type", f"{s.name}!{rg}", "header row looks like data (no bold, fill or rule)",
                         f'home.bold {{"range":"{rg}","on":true}} + home.borders {{"range":"{rg}","preset":"bottom"}} '
                         'or insert.table')
        for (r, c), v in vals.items():
            if not (isinstance(v, str) and TOTAL_LABEL.match(v)) or s.in_table(r, c):
                continue
            row = [cc for (rr, cc), f in self.fml[s.name].items()
                   if rr == r and re.search(r"\b(SUM|SUBTOTAL|AGGREGATE)\(", f, re.I)]
            if not row:
                continue
            cells = [c] + row
            ok = any(s.style(r, x)["font"]["bold"] or s.style(r, x)["border"].get("top")
                     or s.style(r - 1, x)["border"].get("bottom") or s.style(r, x)["fill"] for x in cells)
            if not ok:
                rg = f"{X.addr(r, min(cells))}:{X.addr(r, max(cells))}"
                self.add("minor", "type", f"{s.name}!{rg}", f"total row '{v}' is not set apart",
                         f'home.cellStyle {{"range":"{rg}","name":"Total"}} (bold + rule above)')

    # -- colour
    def check_colour(self):
        for s in self.sheets():
            vals = self.vals[s.name]
            pairs, fills, neon = {}, {}, 0
            for (r, c), v in vals.items():
                st = s.style(r, c)
                fill = st["fill"]
                if fill:
                    fills[fill] = fills.get(fill, 0) + 1
                    rr, gg, bb = (int(fill[i:i + 2], 16) / 255 for i in (0, 2, 4))
                    mx, mn = max(rr, gg, bb), min(rr, gg, bb)
                    if mx > 0.9 and mx > 0 and (mx - mn) / mx > 0.8:
                        neon += 1
                if s.in_table(r, c) and not fill:
                    continue
                fg = st["font"]["color"] or "000000"
                bg = fill or "FFFFFF"
                if fg == bg and not str(v).strip():
                    continue
                large = st["font"]["size"] >= 18 or (st["font"]["size"] >= 14 and st["font"]["bold"])
                pairs.setdefault((fg, bg, large), []).append((r, c))
            for (fg, bg, large), cells in pairs.items():
                cr = X.contrast(fg, bg)
                need = 3.0 if large else 4.5
                if cr < need:
                    r, c = cells[0]
                    sev = "severe" if cr < 3 else "major"
                    self.add(sev, "colour", f"{s.name}!{X.addr(r, c)}" + (f" (+{len(cells) - 1})" if len(cells) > 1 else ""),
                             f"text #{fg} on #{bg} has contrast {cr:.1f}:1 (needs {need}:1)",
                             "darken the text or lighten the fill (home.fontColor/home.fillColor); "
                             "see the palettes in design-guide.md")
            for d in s.cf:
                if d["dxf"] is None or d["dxf"] >= len(self.wb.dxfs):
                    continue
                dx = self.wb.dxfs[d["dxf"]]
                if dx["fill"] or dx["font_color"]:
                    cr = X.contrast(dx["font_color"] or "000000", dx["fill"] or "FFFFFF")
                    if cr < 4.5:
                        self.add("major", "colour", f"{s.name}!{d['sqref']}",
                                 f"conditional format colours have contrast {cr:.1f}:1",
                                 'use a preset such as "lightRedFillDarkRedText" or a darker font colour')
            real = {k: n for k, n in fills.items() if k not in ("FFFFFF",)}
            if len(real) > 6:
                self.add("minor", "colour", s.name, f"{len(real)} different fill colours; the eye can't tell what matters",
                         "use one accent, one light tint for bands/tiles and one input colour (60-30-10)")
            if neon > 3:
                self.add("minor", "colour", s.name, f"{neon} cells use fully saturated fills",
                         "replace with a light tint of the accent (e.g. #EEF2F7) and keep strong colour for one highlight")
            reds = [d for d in s.cf if d["type"] == "colorScale" and d.get("colors") and len(d["colors"]) >= 2]
            if reds:
                self.add("tip", "colour", f"{s.name}!{reds[0]['sqref']}",
                         "red-green colour scale: about 1 in 12 men can't separate it",
                         "add numbers or icons, or use a single-hue scale (white to accent)")

    # -- layout and charts
    def check_layout(self):
        for s in self.sheets():
            vals = self.vals[s.name]
            rows = sorted({r for (r, _) in vals})
            for r in rows:
                if not self._is_header_row(s, r):
                    continue
                cells = [c for (rr, c) in vals if rr == r]
                n, rr = 0, r + 1
                while any((rr, c) in vals for c in cells):
                    n += 1
                    rr += 1
                if n >= 25 and (not s.freeze or s.freeze[0] < r):
                    self.add("minor", "layout", f"{s.name}!{X.addr(r, min(cells))}",
                             f"{n} rows under this header but the header doesn't stay visible",
                             f'view.freezePanes {{"cell":"{X.addr(r + 1, 1)}"}}')
                    break
            for m in s.merges:
                if any(t for t in s.tables if not (m[2] < t["ref"][0] or m[0] > t["ref"][2] or m[3] < t["ref"][1] or m[1] > t["ref"][3])):
                    self.add("minor", "layout", f"{s.name}!{X.rng(*m)}", "merged cells inside a table block break sort and filter",
                             'home.unmergeCells and use home.alignCenter across the header instead')
            occupied = set(vals)
            for i, ch in enumerate(s.charts):
                if not ch["box"]:
                    continue
                r1, c1, r2, c2 = ch["box"]
                cov = sorted((r, c) for (r, c) in occupied if r1 <= r <= r2 and c1 <= c <= c2)
                if cov:
                    self.add("severe", "layout", f"{s.name} chart '{ch['title'] or i + 1}'",
                             f"chart covers {len(cov)} filled cells ({X.addr(*cov[0])}...)",
                             f'chart.set {{"at":"{X.addr(r1, max(c for _, c in occupied) + 2)}"}} or move it below the data')
                for j, other in enumerate(s.charts[i + 1:], i + 1):
                    if other["box"] and not (r2 < other["box"][0] or r1 > other["box"][2] or c2 < other["box"][1] or c1 > other["box"][3]):
                        self.add("major", "layout", f"{s.name} charts {i + 1}/{j + 1}", "charts overlap each other",
                                 'chart.set {"at": ...} so each sits on its own cell block')
                self._chart(s, ch, i)

    def _chart(self, s, ch, i):
        name = f"{s.name} chart '{ch['title'] or i + 1}'"
        kind = ch["kind"] or ""
        if not ch["title"]:
            self.add("major", "charts", name, "chart has no title", 'chart.set {"title":"What the reader should see"}')
        if ch["legend"] and ch["series"] == 1 and kind not in ("pieChart", "doughnutChart"):
            self.add("minor", "charts", name, "legend for a single series repeats the title",
                     'chart.set {"legend":"none"}')
        if kind in ("pieChart", "doughnutChart") and ch["points"] > 6:
            self.add("minor", "charts", name, f"pie with {ch['points']} slices is unreadable",
                     'chart.changeType {"type":"bar"} sorted descending, or group small items into "Other"')
        if ch["three_d"]:
            self.add("minor", "charts", name, "3-D chart distorts values", 'chart.changeType {"type":"column"}')
        if ch["series"] > 6:
            self.add("minor", "charts", name, f"{ch['series']} series; more than 6 colours can't be told apart",
                     "split into small multiples or highlight one series in the accent and grey the rest")
        if ch["size"] and (ch["size"][0] < 180 or ch["size"][1] < 110):
            self.add("minor", "charts", name, f"chart is only {ch['size'][0]:.0f}x{ch['size'][1]:.0f} pt",
                     'chart.set {"width":400,"height":260} (pixels; 0.75 pt each)')
        if ch["data_labels"] and ch["gridlines"]:
            self.add("tip", "charts", name, "data labels and gridlines both shown", 'chart.set {"gridlines":false}')

    # -- print
    def check_print(self):
        titles = {d["local"] for d in self.wb.defined if d["name"] == "_xlnm.Print_Titles"}
        for s in self.sheets():
            pl = [p for p in self.pages if p.get("sheet") == s.name]
            if not pl:
                continue
            wide = len({p["columns"] for p in pl})
            tall = len({p["rows"] for p in pl})
            if wide > 1:
                self.add("minor", "print", s.name, f"prints {wide} pages wide ({len(pl)} pages); charts and columns split",
                         f'pageLayout.pageSetup {{"sheet":"{s.name}","orientation":"landscape","fitToPage":true,"fitWidth":1,"fitHeight":0}}')
            if tall > 1 and str(s.index) not in titles:
                self.add("minor", "print", s.name, f"{tall} pages tall without repeating header rows",
                         f'pageLayout.pageSetup {{"sheet":"{s.name}","titleRows":"<header row>:<header row>"}}')
            low = [p["scale"] for p in pl if p.get("scale") and p["scale"] < 55]
            if low:
                self.add("minor", "print", s.name, f"printed at {min(low):.0f}% - too small to read",
                         "fit to 1 page wide only (fitHeight 0) or switch to landscape/A3")
            if len(pl) > 1 and "&P" not in s.footer:
                self.add("tip", "print", s.name, "multi-page print without page numbers",
                         f'pageLayout.pageSetup {{"sheet":"{s.name}","footer":"&L&A&RPage &P of &N"}}')

    # -- document
    def check_doc(self):
        if not (self.wb.props.get("title") or "").strip():
            self.add("tip", "doc", "workbook", "no document title (shown by viewers, screen readers, PDF)",
                     'file.properties {"title":"..."}')
        names = [s.name for s in self.wb.sheets]
        if len(names) > 1 and any(re.match(r"^Sheet\d+$", n) for n in names):
            self.add("minor", "doc", ", ".join(n for n in names if re.match(r"^Sheet\d+$", n)),
                     "default sheet names in a multi-sheet workbook", 'sheet.rename {"sheet":"Sheet1","name":"Summary"}')
        for a in (self.access or [])[:3]:
            self.add("minor", "doc", str(a.get("where", a.get("cell", "workbook")) if isinstance(a, dict) else "workbook"),
                     f"accessibility: {a.get('issue', a) if isinstance(a, dict) else a}", "follow review.checkAccessibility")

    # -- Kurdish / RTL
    def check_rtl(self):
        for s in self.sheets():
            vals = self.vals[s.name]
            texts = [(rc, v) for rc, v in vals.items() if isinstance(v, str) and v.strip()]
            ar = [(rc, v) for rc, v in texts if fonts.is_arabic_script(v)]
            if not ar:
                continue
            if len(ar) >= 0.3 * len(texts) and not s.rtl:
                self.add("minor", "rtl", s.name, "mostly Kurdish/Arabic text but the sheet runs left-to-right",
                         'view.rightToLeft {"on":true} (column A moves to the right edge)')
            left = [rc for rc, _ in ar if s.style(*rc)["h"] == "left"]
            if len(left) * 2 > len(ar):  # a few left-aligned headers over numbers are deliberate
                self.add("minor", "rtl", f"{s.name}!{X.addr(*left[0])}", f"{len(left)} right-to-left cells forced left",
                         'home.alignRight on Kurdish text (or leave General alignment)')
            seen = set()
            for rc, _ in ar:
                name = s.style(*rc)["font"]["name"]
                if name in seen:
                    continue
                seen.add(name)
                cov = fonts.coverage(name)
                if not cov["found"]:
                    if name.lower() in ("calibri", "aptos", "cambria", "aptos narrow"):
                        self.add("minor", "rtl", f"{s.name}!{X.addr(*rc)}",
                                 f"Kurdish text in {name}, which has no Kurdish letters; each viewer substitutes a different font",
                                 'home.fontName {"range":...,"name":"Tahoma"} (Windows+Mac) - see kurdish-rtl.md')
                    else:
                        self.add("tip", "rtl", f"{s.name}!{X.addr(*rc)}",
                                 f"font {name} is not installed on this Mac; recipients need it too", "")
                else:
                    miss = [ch for ch in fonts.KURDISH_LETTERS if ch in (cov["missing"] or "")]
                    if miss:
                        self.add("major", "rtl", f"{s.name}!{X.addr(*rc)}",
                                 f"font {name} lacks Kurdish letters {' '.join(miss)}",
                                 'home.fontName with a font that passes kurdish-rtl.md (Tahoma, Arial, Rabar_016, Speda...)')
            self.add("tip", "rtl", s.name, "GridCraft's PDF/PNG export prints Kurdish as '?'",
                     "keep the .xlsx for editing; make the PDF/PNG with: gridcraft.py rtl-render BOOK.xlsx OUT.pdf")

    # -- what GridCraft actually prints
    def check_render(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf = os.path.join(tmp, "c.pdf")
            try:
                run_cmds(self.path, [("file.exportPdf", {"path": pdf, "sheets": "all"})])
                data = open(pdf, "rb").read()
            except Exception as e:  # rendering is a bonus check; never fail the critic on it
                self.notes.append(f"render check skipped: {e}")
                return
        runs = [t.decode("latin-1") for t in re.findall(rb"\(((?:[^()\\]|\\.)*)\) Tj", data)]
        hashes = sum(1 for t in runs if t.strip() and set(t.strip()) == {"#"})
        predicted = sum(1 for i in self.issues if "#####" in i["message"])
        if hashes > predicted:
            self.add("severe", "display", "printed PDF", f"{hashes} cells print as ##### in GridCraft's export",
                     "widen those number columns (home.columnWidth chars) after setting formats")
        self.proof["printed_runs"] = len(runs)

    # -- run
    def run(self):
        self.load()
        self.check_formulas()
        if self.probe:
            self.recalc_probe()
        self.check_display()
        self.check_type()
        self.check_colour()
        self.check_layout()
        self.check_print()
        self.check_doc()
        self.check_rtl()
        if self.render:
            self.check_render()
        lost = {}
        for i in self.issues:
            lost[i["category"]] = lost.get(i["category"], 0) + i["points"]
        total = sum(min(v, CAPS.get(k, 20)) for k, v in lost.items())
        self.score = max(0, 100 - total)
        self.severe = sum(1 for i in self.issues if i["severity"] == "severe")
        return self

    def report(self, minimum=85):
        ok = self.score >= minimum and not self.severe
        lines = [f"critic: {os.path.basename(self.path)}  score {self.score}/100  "
                 f"{'PASS' if ok else 'FAIL'} (needs >= {minimum} and no severe issue)"]
        n_err = len(self.errors.get("errors") or [])
        p = self.proof
        probe = ""
        if p.get("inputs"):
            probe = (f"; probe: {p['inputs']} inputs changed one at a time -> {p['updates']} formula results updated"
                     + (f", dead inputs {p['dead_inputs']}" if p.get("dead_inputs") else "")
                     + (f", {len(p['new_errors'])} new errors" if p.get("new_errors") else ", no new errors"))
        elif p:
            probe = f"; probe: {p.get('note')}"
        lines.append(f"formulas: {sum(len(v) for v in self.fml.values())}, errors after recalculation: {n_err}{probe}")
        order = {"severe": 0, "major": 1, "minor": 2, "tip": 3}
        real = sorted([i for i in self.issues if i["severity"] != "tip"], key=lambda i: order[i["severity"]])
        tips = [i for i in self.issues if i["severity"] == "tip"]
        lines.append(f"issues ({len(real)}):" if real else "issues: none")
        for i in real:
            lines.append(f"  [{i['severity']:<6} -{i['points']:<2}] {i['category']:<8} {i['where']}: {i['message']}")
            if i["fix"]:
                lines.append(f"      fix: {i['fix']}")
        if tips:
            lines.append(f"tips ({len(tips)}):")
            for i in tips:
                lines.append(f"  - {i['where']}: {i['message']}" + (f" -> {i['fix']}" if i["fix"] else ""))
        for n in self.notes:
            lines.append(f"note: {n}")
        return "\n".join(lines), ok

    def as_json(self, minimum=85):
        return {"file": self.path, "score": self.score, "pass": self.score >= minimum and not self.severe,
                "severe": self.severe, "proof": self.proof, "issues": self.issues, "notes": self.notes}


def critique(path, probe=True, render=True, sheet=None):
    return Critic(path, probe, render, sheet).run()


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--min", type=int, default=85)
    ap.add_argument("--no-probe", action="store_true")
    ap.add_argument("--no-render", action="store_true")
    ap.add_argument("--sheet")
    a = ap.parse_args(argv)
    if not a.file.lower().endswith((".xlsx", ".xlsm")):
        print("critic: works on .xlsx/.xlsm (save other formats as .xlsx with apply first)", file=sys.stderr)
        sys.exit(2)
    c = critique(a.file, not a.no_probe, not a.no_render, a.sheet)
    if a.json:
        print(json.dumps(c.as_json(a.min), indent=1, ensure_ascii=False))
        ok = c.as_json(a.min)["pass"]
    else:
        text, ok = c.report(a.min)
        print(text)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
