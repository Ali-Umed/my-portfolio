"""Build and edit spreadsheets through GridCraft's own engine (gridcraft-cli), with checks.

Commands
  gridcraft.py apply OUT [--in SRC | --sample budget|sales|grades] (--steps JSON | --recipe FILE)
                     [--export pdf,png,csv,html] [--force]
      Validates the steps, runs them on SRC (or a sample, or a blank workbook) and writes OUT
      (.xlsx by default; .xlsm/.csv/.tsv/.json/.html by extension), OUT's .recipe.json sidecar and
      the requested exports. Refuses to write over SRC, and over an existing OUT unless --force.
      Prints the workbook structure and every formula error found after recalculation.
  gridcraft.py check (--steps JSON | --recipe FILE)
      Only validate: command ids, parameter keys (GridCraft silently ignores unknown keys) and the
      function names used in formulas (unknown functions silently become #NAME?).
  gridcraft.py describe ID [ID ...]        Exact parameter docs of commands.
  gridcraft.py search WORD                 Commands whose id, label or ribbon path contains WORD.
  gridcraft.py functions [--search X] [--category C] [--names] [--json]
                                           Worksheet functions this CLI version knows.
  gridcraft.py eval FORMULA [--in FILE] [--sheet S] [--cell A1]
                                           Evaluate a formula (function names checked first).
  gridcraft.py cat FILE [--range A1:F20] [--sheet S] [--formulas] [--csv]
                                           Aligned table of displayed values (or formulas).
  gridcraft.py preview FILE OUT.png [--sheet NAME | --all] [--portrait] [--as-printed] [--crop]
                                           Render sheets to PNG (fit-to-page PDF, then macOS sips);
                                           --as-printed keeps the sheet's own page setup (page 1).
  gridcraft.py verify FILE --expect JSON [--set CELL=INPUT ...] [--tol 1e-9]
                                           Recalculation test: optionally change inputs (in memory,
                                           the file is not touched) and compare cells with expected
                                           values, e.g. --set Data!B2=900 --expect '{"F15": 4300}'.
  gridcraft.py critic FILE [--json] [--min 85] [--no-probe] [--no-render]
                                           Design + formula check: score /100, issues with fixes,
                                           recalculation probe (see references/design-guide.md).
  gridcraft.py template list | show ID | apply ID OUT [--var k=v ...] [--export png,pdf] [--force]
                                           Parameterised templates (templates/*.json, palettes.json).
  gridcraft.py palettes                    Palettes with their WCAG contrast ratios.
  gridcraft.py rtl-render FILE OUT.png|OUT.pdf [--sheet S] [--font NAME]
                                           Kurdish/Arabic-safe render (GridCraft's PDF prints '?').

Steps: [[id, params], ...] or [{"command": id, "params": {...}}, ...] or "id={json}" strings.
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
CLI = shutil.which("gridcraft-cli") or os.path.expanduser("~/.local/bin/gridcraft-cli")
# Parameters whose values are formulas (checked for unknown function names).
FORMULA_KEYS = {"input", "formula", "formula1", "formula2", "refersTo"}
EXPORTS = {"pdf", "png", "csv", "html", "tsv", "json"}


def die(msg, code=2):
    print(f"gridcraft: {msg}", file=sys.stderr)
    sys.exit(code)


def cli(*args, check=True):
    if not os.path.exists(CLI):
        die("gridcraft-cli not found. Install gridcraft-cli-<ver>-macos-universal.zip from "
            "https://github.com/storytold/gridcraft/releases and put gridcraft-cli on PATH.")
    p = subprocess.run([CLI, *args], capture_output=True, text=True)
    if check and p.returncode != 0:
        die(f"gridcraft-cli {' '.join(args[:1])} failed:\n{(p.stderr or p.stdout).strip()}", 1)
    return p


def version():
    return cli("version").stdout.strip()


# ------------------------------------------------------------------ registries

_REG = None
_FUN = None


def registry():
    global _REG
    if _REG is None:
        _REG = {c["id"]: c for c in json.loads(cli("commands", "--json").stdout)}
    return _REG


def functions():
    global _FUN
    if _FUN is None:
        _FUN = {f["name"].upper(): f for f in json.loads(cli("functions", "--json").stdout)}
    return _FUN


def param_keys(doc):
    """Keys named in a params doc such as '{range?, on?: bool}' or '{rows?: "2:5" | cols?: "B:C"}'.
    Quoted examples are removed first; a name counts as a key when it starts a field (after '{' or
    ',') and is followed by ':', '?', ',' or '}', or follows '|' and is followed by '?' or ':'."""
    d = re.sub(r'"(?:[^"\\]|\\.)*"', '""', doc or "").split("→")[0]
    d = re.sub(r"\([^(){}]*\)", "", d)  # notes such as "(xlsx, xlsm, csv)" or "(inches)"
    keys = set()
    for chain in re.findall(r"[{,]\s*([A-Za-z_]\w*\??(?:\s*\|\s*[A-Za-z_]\w*\??)*)\s*(?=[:,}])", d):
        keys |= {k.strip().rstrip("?") for k in chain.split("|")}  # "{path | text}" alternatives
    keys |= set(re.findall(r"\|\s*([A-Za-z_]\w*)\s*(?=\?|:)", d))  # "{rows?: .. | cols?: ..}"
    return keys


def open_ended(doc):
    """A top-level key list that ends with an ellipsis lists only some keys: warn, don't fail."""
    depth, d = 0, re.sub(r'"(?:[^"\\]|\\.)*"', '""', doc or "")
    for i, ch in enumerate(d):
        depth += ch in "{["
        depth -= ch in "}]"
        if depth == 1 and d.startswith(("…", ".."), i) and re.match(r"(…|\.\.)\s*\}", d[i:]):
            return True
    return False


def param_enums(doc):
    """Closed value lists such as 'type?: column|bar|line' (lists ending in '…' are open)."""
    d = re.sub(r"\([^(){}]*\)", "", (doc or "").split("→")[0])
    out = {}
    for key, vals in re.findall(r"[{,]\s*([A-Za-z_]\w*)\??\s*:\s*([A-Za-z_][\w-]*(?:\s*\|\s*[A-Za-z_][\w-]*)+)(?=\s*[,}])", d):
        vs = {v.strip() for v in vals.split("|")}
        if not vs & PLACEHOLDERS:  # "{sheet: index | name}" describes a type, not values
            out[key] = vs
    return out


PLACEHOLDERS = {"index", "name", "number", "text", "cell", "range", "id", "hex", "bool", "string", "path"}

# Values the docs don't list but the engine needs (it silently falls back on others). The Excel-style
# aliases lessThan / greaterThan / lessThanOrEqual were tested correct in 0.6.1 (wrong in 0.5.0).
NESTED_ENUMS = {("home.conditionalFormat", "rule", "operator"):
                {"between", "notBetween", "equal", "notEqual", "greater", "less", "greaterOrEqual", "lessOrEqual",
                 "lessThan", "greaterThan", "lessThanOrEqual"}}

# Keys a params doc names only in prose ("range tools take `range`; regression: inputY, ..."), so
# param_keys() can't find them. Checked against `describe` of gridcraft-cli 0.6.1.
EXTRA_KEYS = {"data.analysisToolPak": {"range", "range1", "range2", "inputY", "inputX", "summary", "kthSmallest",
                                       "kthLargest", "bins", "pareto", "cumulative", "normalProbability",
                                       "interval", "standardErrors", "damping", "hypothesizedDifference"}}


def known_keys(cid, doc):
    return param_keys(doc) | EXTRA_KEYS.get(cid, set())


def similar(name, pool, n=5):
    import difflib
    return difflib.get_close_matches(name, list(pool), n=n, cutoff=0.6)


# ------------------------------------------------------------------ steps

def normalise(steps):
    if isinstance(steps, dict):
        steps = steps.get("steps", [])
    out = []
    for s in steps:
        if isinstance(s, str):
            t = s.strip()
            m = re.match(r"^([\w.]+)\s*(?:[= ]\s*(.*))?$", t, re.S)
            if not m:
                die(f"cannot parse step {s!r}")
            out.append({"command": m.group(1), "params": json.loads(m.group(2)) if m.group(2) else {}})
        elif isinstance(s, list):
            out.append({"command": s[0], "params": s[1] if len(s) > 1 else {}})
        else:
            out.append({"command": s.get("command") or s.get("id"), "params": s.get("params") or {}})
    return out


def formula_functions(f):
    """Function names called in a formula (string literals and quoted sheet names stripped)."""
    body = re.sub(r'"(?:[^"]|"")*"', '""', f)
    body = re.sub(r"'(?:[^']|'')*'!", "S!", body)
    names = re.findall(r"(?<![\w.$!])([A-Za-z_][A-Za-z0-9_.]*)\s*\(", body)
    return [re.sub(r"^_xl(fn|ws)\.", "", n, flags=re.I).upper() for n in names]


def formulas_in(cmd, params):
    out = []
    for k, v in params.items():
        if k in FORMULA_KEYS and isinstance(v, str) and v.startswith("="):
            out.append(v)
        elif k == "values" and isinstance(v, list):
            for row in v:
                for c in row if isinstance(row, list) else [row]:
                    if isinstance(c, str) and c.startswith("="):
                        out.append(c)
        elif k == "rule" and isinstance(v, dict) and isinstance(v.get("formula"), str):
            out.append(v["formula"] if v["formula"].startswith("=") else "=" + v["formula"])
    return out


def check(steps):
    reg, problems, warnings = registry(), [], []
    defined = {str(s["params"].get("name", "")).upper() for s in steps if s["command"] == "formulas.defineName"}
    for i, s in enumerate(steps):
        cid, params = s["command"], s["params"]
        if cid not in reg:
            problems.append(f"step {i}: unknown command {cid!r}; similar: {similar(cid, reg)}")
            continue
        if not isinstance(params, dict):
            problems.append(f"step {i} {cid}: params must be a JSON object")
            continue
        doc = reg[cid]["params"]
        known = known_keys(cid, doc)
        for k in params:
            if k in known:
                continue
            msg = f"step {i} {cid}: unknown param {k!r} (similar: {similar(k, known, 3)}); documented: {doc}"
            (warnings if open_ended(doc) and not __import__('difflib').get_close_matches(k, sorted(known), n=1, cutoff=0.8) else problems).append(msg)
        for k, allowed in param_enums(doc).items():
            v = params.get(k)
            if isinstance(v, str) and v not in allowed:
                warnings.append(f"step {i} {cid}: {k}={v!r} is not one of {sorted(allowed)}")
        for (ncid, outer, inner), allowed in NESTED_ENUMS.items():
            v = params.get(outer, {}).get(inner) if ncid == cid and isinstance(params.get(outer), dict) else None
            if v is not None and v not in allowed:
                problems.append(f"step {i} {cid}: {outer}.{inner}={v!r} is not accepted by this engine; "
                                f"use one of {sorted(allowed)}")
        if cid == "range.setValues" and not (isinstance(params.get("values"), list)
                                             and all(isinstance(r, list) for r in params["values"])):
            problems.append(f"step {i} range.setValues: 'values' must be a list of rows (a 2-D list)")
        for f in formulas_in(cid, params):
            for name in formula_functions(f):
                if name in functions() or name in defined:
                    continue
                msg = f"step {i} {cid}: unknown function {name}() in {f!r} (GridCraft shows #NAME?)"
                if re.search(r"\b(LET|LAMBDA)\s*\(", f, re.I):
                    warnings.append(msg + " - fine if it is a LET/LAMBDA name")
                else:
                    near = similar(name, functions(), 3)
                    problems.append(msg + (f"; similar: {near}" if near else ""))
    return problems, warnings


def load_steps(a):
    if a.recipe:
        with open(a.recipe) as f:
            data = json.load(f)
    else:
        data = json.loads(a.steps)
    return data, normalise(data)


def report_check(problems, warnings):
    for w in warnings:
        print("warning (verify the result): " + w, file=sys.stderr)
    if problems:
        die("recipe rejected before running:\n  " + "\n  ".join(problems), 1)


# ------------------------------------------------------------------ apply

def run_steps(src, sample, steps, out):
    with tempfile.TemporaryDirectory() as tmp:
        script = os.path.join(tmp, "steps.jsonl")
        with open(script, "w") as f:
            for s in steps:
                f.write(json.dumps({"command": s["command"], "params": s["params"]}, ensure_ascii=False) + "\n")
        args = ["run"]
        if src:
            args += ["--in", src]
        elif sample:
            args += ["--sample", sample]
        args += ["--script", script, "--out", out]
        p = cli(*args)
    return [json.loads(l) for l in p.stdout.splitlines() if l.startswith("{")]


def formula_errors(path):
    p = cli("run", "--in", path, "--cmd", "formulas.errorChecking")
    for line in p.stdout.splitlines():
        if line.startswith("{"):
            return json.loads(line).get("result") or {}
    return {}


def summary(path):
    print(cli("info", path).stdout.rstrip())
    errs = formula_errors(path)
    bad = errs.get("errors") or []
    if bad:
        print(f"formula errors after recalculation ({len(bad)}):")
        for e in bad[:30]:
            print(f"  {e.get('sheet')}!{e.get('cell')}: {e.get('error')}  {e.get('formula')}")
    else:
        print("formula errors after recalculation: none")
    if errs.get("circular"):
        print(f"circular references: {errs['circular']}")


def export(path, stem, kinds, force):
    made = []
    for k in kinds:
        out = f"{stem}.{k}"
        if os.path.exists(out) and not force:
            die(f"{out} exists; pass --force to replace it")
        if k == "pdf":
            cli("run", "--in", path, "--cmd",
                "file.exportPdf=" + json.dumps({"path": os.path.abspath(out), "sheets": "all"}), "--quiet")
        elif k == "png":
            # a workbook with its own fit-to-page setup is previewed as it prints, otherwise landscape-fit
            try:
                import xlsxinfo
                printed = any(sh.page.get("fitToPage") for sh in xlsxinfo.open_workbook(path).sheets)
            except Exception:
                printed = False
            preview(path, out, all_sheets=True, as_printed=printed, crop=printed)
        else:
            cli("convert", path, out)
        made.append(out)
    return made


def cmd_apply(a):
    data, steps = load_steps(a)
    src, sample = a.src, a.sample
    if isinstance(data, dict) and not (src or sample):
        src, sample = data.get("source"), data.get("sample")
    if src and sample:
        die("give --in or --sample, not both")
    if src and not os.path.exists(src):
        die(f"{src}: not found")
    report_check(*check(steps))
    out = a.out if os.path.splitext(a.out)[1] else a.out + ".xlsx"
    if src and os.path.exists(out) and os.path.samefile(src, out):
        die("refusing to overwrite the source workbook; write a new file and keep the original")
    if os.path.exists(out) and not a.force:
        die(f"{out} exists; pass --force to replace it (never the user's original)")
    results = run_steps(src, sample, steps, out)
    for r in results:
        text = json.dumps(r, ensure_ascii=False)
        print(text if len(text) < 300 else text[:300] + " …")
    print(f"\nworkbook: {out}")
    stem = os.path.splitext(out)[0]
    with open(stem + ".recipe.json", "w") as f:
        json.dump({"source": os.path.abspath(src) if src else None, "sample": sample,
                   "engine": version(), "steps": steps}, f, indent=2, ensure_ascii=False)
    print(f"recipe: {stem}.recipe.json")
    kinds = [k for k in (a.export or "").split(",") if k]
    bad = [k for k in kinds if k not in EXPORTS]
    if bad:
        die(f"unknown export {bad}; use {sorted(EXPORTS)}")
    for m in export(out, stem, kinds, a.force):
        print(f"export: {m}")
    print()
    summary(out)
    if not getattr(a, "no_critic", False) and out.lower().endswith((".xlsx", ".xlsm")):
        critic_summary(out)


def critic_summary(path):
    import critic as C
    try:
        c = C.critique(path)
    except Exception as e:  # the critic must never block a build
        print(f"critic: skipped ({e})")
        return
    text, ok = c.report()
    lines = text.splitlines()
    print("\n" + "\n".join(lines[:2]))
    real = [i for i in c.issues if i["severity"] != "tip"]
    for i in real[:8]:
        print(f"  [{i['severity']}] {i['where']}: {i['message']}" + (f"\n      fix: {i['fix']}" if i["fix"] else ""))
    if len(real) > 8:
        print(f"  ... {len(real) - 8} more: gridcraft.py critic {path}")


# ------------------------------------------------------------------ preview / verify

def sheet_names(path):
    info = json.loads(cli("info", path, "--json").stdout)
    return [s["name"] for s in info.get("sheets", []) if s.get("visibility", "Visible") == "Visible"], info


def preview(path, out_png, sheet=None, all_sheets=False, portrait=False, as_printed=False, crop=False):
    names, info = sheet_names(path)
    if sheet:
        names = [sheet]
    elif not all_sheets:
        names = [info["sheets"][info.get("activeSheet", 0)]["name"]]
    if not shutil.which("sips"):
        die("preview needs macOS sips; open the PDF export instead")
    pngs = []
    with tempfile.TemporaryDirectory() as tmp:
        for i, name in enumerate(names):
            pdf = os.path.join(tmp, f"{i}.pdf")
            setup = {"orientation": "portrait" if portrait else "landscape", "fitToPage": True,
                     "fitWidth": 1, "fitHeight": 1}
            cmds = ["--cmd", "sheet.activate=" + json.dumps({"sheet": name})]
            if not as_printed:
                cmds += ["--cmd", "pageLayout.pageSetup=" + json.dumps(setup)]
            cmds += ["--cmd", "file.exportPdf=" + json.dumps(dict({"path": pdf, "sheets": "active"},
                                                                    **({} if as_printed else {"fitToPage": True})))]
            cli("run", "--in", path, *cmds, "--quiet")
            png = os.path.join(tmp, f"{i}.png")
            subprocess.run(["sips", "-Z", "1800", "-s", "format", "png", pdf, "--out", png],
                           capture_output=True, check=True)
            pngs.append((name, png))
        try:
            from PIL import Image, ImageDraw
        except ImportError:  # sips PNGs keep the PDF's transparent page; fine in most viewers
            Image = None
        if Image is None:
            base = os.path.splitext(out_png)[0]
            for k, (name, p) in enumerate(pngs):
                safe = re.sub(r"[^\w-]+", "_", name)
                shutil.copyfile(p, out_png if len(pngs) == 1 else f"{base}_{safe}.png")
            if len(pngs) > 1:
                print(f"preview: {base}_<sheet>.png (Pillow missing, one file per sheet)")
                return
        else:
            def flat(p):  # the PDF page is transparent: put it on white paper
                im = Image.open(p).convert("RGBA")
                bg = Image.new("RGBA", im.size, "white")
                im = Image.alpha_composite(bg, im).convert("RGB")
                if crop:  # trim the empty paper, keep a margin
                    from PIL import ImageChops
                    box = ImageChops.difference(im, Image.new("RGB", im.size, "white")).getbbox()
                    if box:
                        m = 24
                        im = im.crop((max(0, box[0] - m), max(0, box[1] - m),
                                      min(im.width, box[2] + m), min(im.height, box[3] + m)))
                return im
            ims = [(n, flat(p)) for n, p in pngs]
            if len(ims) == 1:
                ims[0][1].save(out_png)
            else:
                w = max(im.width for _, im in ims)
                sheet_img = Image.new("RGB", (w, sum(im.height + 40 for _, im in ims)), "white")
                y, d = 0, ImageDraw.Draw(sheet_img)
                for n, im in ims:
                    d.rectangle([0, y, w, y + 39], fill=(31, 157, 85))
                    d.text((12, y + 12), f"Sheet: {n}", fill="white")
                    sheet_img.paste(im, (0, y + 40))
                    y += im.height + 40
                sheet_img.save(out_png)
    print(f"preview: {out_png} ({', '.join(names)})")


def split_cell(ref):
    if "!" in ref:
        sh, c = ref.rsplit("!", 1)
        return sh.strip("'"), c
    return None, ref


def cmd_verify(a):
    expect = json.loads(a.expect)
    args = ["run", "--in", a.file]
    for s in a.set or []:
        ref, _, val = s.partition("=")
        sh, c = split_cell(ref)
        p = {"cell": c, "input": val}
        if sh:
            p["sheet"] = sh
        args += ["--cmd", "cell.set=" + json.dumps(p)]
    order = list(expect)
    for ref in order:
        sh, c = split_cell(ref)
        p = {"range": c}
        if sh:
            p["sheet"] = sh
        args += ["--cmd", "sheet.read=" + json.dumps(p)]
    res = [json.loads(l)["result"] for l in cli(*args).stdout.splitlines() if l.startswith("{")]
    reads = [r for r in res if isinstance(r, dict) and "values" in r][-len(order):]
    fails = 0
    show = lambda v: f"{v:.12g}" if isinstance(v, float) else json.dumps(v, ensure_ascii=False)
    print(f"{'cell':<16}{'expected':>20}  {'actual':>20}  ok")
    for ref, r in zip(order, reads):
        actual = (r["values"] or [[None]])[0][0]
        want = expect[ref]
        if isinstance(want, (int, float)) and isinstance(actual, (int, float)):
            ok = abs(actual - want) <= a.tol * max(1.0, abs(want))
        else:
            ok = actual == want
        fails += not ok
        print(f"{ref:<16}{show(want):>20}  {show(actual):>20}  {'yes' if ok else 'NO'}")
    if a.set:
        print(f"(after setting {', '.join(a.set)} in memory; {a.file} unchanged)")
    sys.exit(1 if fails else 0)


# ------------------------------------------------------------------ small wrappers

def cmd_check(a):
    _, steps = load_steps(a)
    problems, warnings = check(steps)
    for w in warnings:
        print("warning: " + w)
    print("\n".join(problems) if problems else f"ok ({len(steps)} steps)")
    sys.exit(1 if problems else 0)


def cmd_describe(a):
    reg = registry()
    for cid in a.ids:
        c = reg.get(cid)
        if not c:
            print(f"{cid}: not found; similar: {similar(cid, reg, 8)}")
            continue
        sc = f"  [{c['shortcut']}]" if c.get("shortcut") else ""
        print(f"{cid}  ({' > '.join(c.get('menu') or [])}) {c['label']}{sc}\n  {c['params']}\n"
              f"  keys: {sorted(known_keys(cid, c['params']))}\n")


def cmd_search(a):
    q = a.word.lower()
    for cid, c in registry().items():
        if q in cid.lower() or q in c["label"].lower() or any(q in m.lower() for m in c.get("menu") or []):
            print(f"{cid:<32} {c['label']}\n{'':<32} {c['params']}")


def cmd_functions(a):
    fs = list(functions().values())
    if a.search:
        fs = [f for f in fs if a.search.lower() in (f["name"] + " " + f["description"]).lower()]
    if a.category:
        fs = [f for f in fs if f["category"].lower() == a.category.lower()]
    if a.json:
        print(json.dumps(fs, indent=1))
    elif a.names:
        print(" ".join(sorted(f["name"] for f in fs)))
    else:
        for f in fs:
            print(f"{f['signature']}\n    {f['category']}: {f['description']}")
    print(f"{len(fs)} functions ({version()})", file=sys.stderr)


def cmd_eval(a):
    f = a.formula if a.formula.startswith("=") else "=" + a.formula
    unknown = [n for n in formula_functions(f) if n not in functions()]
    if unknown and not re.search(r"\b(LET|LAMBDA)\s*\(", f, re.I):
        print(f"warning: unknown to {version()}: {unknown} (result will be #NAME?)", file=sys.stderr)
    args = ["eval", f] + sum([[f"--{k}", v] for k, v in (("in", a.src), ("sheet", a.sheet), ("cell", a.cell)) if v], [])
    print(cli(*args).stdout.rstrip())


def cmd_cat(a):
    args = ["cat", a.file] + sum([[f"--{k}", v] for k, v in (("range", a.range), ("sheet", a.sheet)) if v], [])
    args += ["--formulas"] * a.formulas + ["--csv"] * a.csv
    print(cli(*args).stdout.rstrip())


def cmd_critic(a):
    import critic as C
    argv = [a.file] + ["--json"] * a.json + ["--min", str(a.min)] + ["--no-probe"] * a.no_probe + \
        ["--no-render"] * a.no_render + (["--sheet", a.sheet] if a.sheet else [])
    C.main(argv)


def cmd_palettes(a):
    import templating as T
    from xlsxinfo import contrast
    pals = T.palettes()
    print(f"{'palette':<10} {'head':<8} {'accent':<8} {'band':<8} {'ink':<8}  text/bg  head  muted  input  dark  use")
    for n, p in pals.items():
        h = lambda k: p[k].lstrip("#")
        print(f"{n:<10} {p['head']:<8} {p['accent']:<8} {p['band']:<8} {p['ink']:<8}  "
              f"{contrast(h('ink'), 'FFFFFF'):5.1f}  {contrast(h('head_text'), h('head')):5.1f}  "
              f"{contrast(h('muted'), 'FFFFFF'):5.1f}  {contrast(h('input_text'), h('input_fill')):5.1f}  "
              f"{contrast(h('dark_text'), h('dark_bg')):5.1f}  {p['use']}")


def cmd_template(a):
    import templating as T
    if a.action == "list":
        for t in T.list_templates():
            print(f"{t['id']:<18} {t['title']}\n{'':<18} {t['use']}")
        return
    if not a.id:
        die("template show|apply needs a template id (gridcraft.py template list)")
    if a.action == "show":
        print(T.describe(T.load(a.id)))
        return
    if not a.out:
        die("template apply ID OUT.xlsx")
    overrides = {}
    for kv in a.var or []:
        k, sep, v = kv.partition("=")
        if not sep:
            die(f"--var {kv!r}: use key=value")
        overrides[k.strip()] = T.parse_value(v)
    tpl, vals, steps = T.build(a.id, overrides)
    a.steps, a.recipe, a.src = json.dumps(steps, ensure_ascii=False), None, None
    a.sample = tpl.get("sample")
    print(f"template {a.id} (palette {vals['palette']})")
    cmd_apply(a)


def thumb_from_page(png, out, max_w=1400):
    """Crop a rendered page to its content (dropping the footer band) and downscale."""
    from PIL import Image, ImageChops
    im = Image.open(png).convert("RGB")
    body = im.crop((0, 0, im.width, int(im.height * 0.93)))
    box = ImageChops.difference(body, Image.new("RGB", body.size, "white")).getbbox() or (0, 0, im.width, im.height)
    m = 28
    im = im.crop((max(0, box[0] - m), max(0, box[1] - m), min(im.width, box[2] + m), min(im.height, box[3] + m)))
    if im.height > im.width * 0.75:  # long tables: show the top, where the design decisions are
        im = im.crop((0, 0, im.width, int(im.width * 0.75)))
    if im.width > max_w:
        im = im.resize((max_w, round(im.height * max_w / im.width)), Image.LANCZOS)
    im.save(out)


def cmd_thumbs(a):
    """Apply every template with its defaults, critic it, render templates/thumbs/<id>.png and gallery.png."""
    import critic as C
    import templating as T
    from PIL import Image, ImageDraw, ImageFont
    thumbs = os.path.join(T.TEMPLATES, "thumbs")
    os.makedirs(thumbs, exist_ok=True)
    try:
        with open(os.path.join(thumbs, "scores.json")) as fh:
            scores = json.load(fh)
    except (OSError, ValueError):
        scores = {}
    ids = a.ids or [t["id"] for t in T.list_templates()]
    with tempfile.TemporaryDirectory() as tmp:
        for tid in ids:
            tpl, vals, steps = T.build(tid, {})
            out = os.path.join(tmp, f"{tid}.xlsx")
            run_steps(None, tpl.get("sample"), normalise(steps), out)
            c = C.critique(out)
            real = [i for i in c.issues if i["severity"] != "tip"]
            scores[tid] = {"score": c.score, "severe": c.severe, "issues": [f"{i['severity']}: {i['where']}: {i['message']}" for i in real]}
            page = os.path.join(tmp, f"{tid}_page.png")
            import xlsxinfo
            wb = xlsxinfo.open_workbook(out)
            first = next(s for s in wb.sheets if s.state == "visible")
            arabic = any(isinstance(v["v"], str) and __import__("fonts").is_arabic_script(v["v"]) for v in first.cells.values())
            if first.rtl or arabic:
                import rtl_render
                rtl_render.render(out, os.path.join(thumbs, f"{tid}.png"), sheet=first.name, scale=2.0)
                thumb_from_page(os.path.join(thumbs, f"{tid}.png"), os.path.join(thumbs, f"{tid}.png"))
            else:
                preview(out, page, sheet=first.name, as_printed=True)
                thumb_from_page(page, os.path.join(thumbs, f"{tid}.png"))
            print(f"{tid:<18} score {c.score:>3}  severe {c.severe}  issues {len(real)}")
    with open(os.path.join(thumbs, "scores.json"), "w") as fh:
        json.dump(scores, fh, indent=1, ensure_ascii=False)
    # contact sheet: 2 columns, numbered labels
    order = [t["id"] for t in T.list_templates()]
    tiles = [(i + 1, tid, Image.open(os.path.join(thumbs, f"{tid}.png"))) for i, tid in enumerate(order)
             if os.path.exists(os.path.join(thumbs, f"{tid}.png"))]
    cw, ch, cols, lab = 760, 520, 2, 46
    rows = (len(tiles) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * cw + (cols + 1) * 20, rows * (ch + lab) + (rows + 1) * 20), "#E9ECF1")
    d = ImageDraw.Draw(sheet)
    f = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Bold.ttf", 22)
    fs = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", 18)
    for k, (n, tid, im) in enumerate(tiles):
        x = 20 + (k % cols) * (cw + 20)
        y = 20 + (k // cols) * (ch + lab + 20)
        d.rectangle((x, y, x + cw, y + ch + lab), fill="white")
        im = im.copy()
        im.thumbnail((cw - 20, ch - 10), Image.LANCZOS)
        sheet.paste(im, (x + (cw - im.width) // 2, y + lab + (ch - 10 - im.height) // 2))
        d.ellipse((x + 10, y + 8, x + 40, y + 38), fill="#1F3A5F")
        d.text((x + 25, y + 23), str(n), font=f, fill="white", anchor="mm")
        sc = scores.get(tid, {}).get("score")
        d.text((x + 52, y + 12), tid, font=f, fill="#1F2933")
        if sc is not None:
            d.text((x + cw - 12, y + 14), f"critic {sc}/100", font=fs, fill="#18794E", anchor="ra")
    sheet.save(os.path.join(T.TEMPLATES, "gallery.png"))
    print(f"gallery: {os.path.join(T.TEMPLATES, 'gallery.png')}")


def cmd_rtl_render(a):
    import rtl_render as R
    R.render(a.file, a.out, sheet=a.sheet, font=a.font, scale=a.scale)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)

    def steps_args(p):
        g = p.add_mutually_exclusive_group(required=True)
        g.add_argument("--steps")
        g.add_argument("--recipe")

    p = sub.add_parser("apply")
    p.add_argument("out")
    p.add_argument("--in", dest="src")
    p.add_argument("--sample", choices=["budget", "sales", "grades"])
    steps_args(p)
    p.add_argument("--export", default="")
    p.add_argument("--force", action="store_true")
    p.add_argument("--no-critic", action="store_true")
    p.set_defaults(fn=cmd_apply)
    p = sub.add_parser("critic")
    p.add_argument("file")
    p.add_argument("--json", action="store_true")
    p.add_argument("--min", type=int, default=85)
    p.add_argument("--no-probe", action="store_true")
    p.add_argument("--no-render", action="store_true")
    p.add_argument("--sheet")
    p.set_defaults(fn=cmd_critic)
    p = sub.add_parser("template")
    p.add_argument("action", choices=["list", "show", "apply"])
    p.add_argument("id", nargs="?")
    p.add_argument("out", nargs="?")
    p.add_argument("--var", action="append")
    p.add_argument("--export", default="")
    p.add_argument("--force", action="store_true")
    p.add_argument("--no-critic", action="store_true")
    p.set_defaults(fn=cmd_template)
    p = sub.add_parser("thumbs", help="maintenance: rebuild template thumbnails, scores and gallery")
    p.add_argument("ids", nargs="*")
    p.set_defaults(fn=cmd_thumbs)
    p = sub.add_parser("palettes")
    p.set_defaults(fn=cmd_palettes)
    p = sub.add_parser("rtl-render")
    p.add_argument("file")
    p.add_argument("out")
    p.add_argument("--sheet")
    p.add_argument("--font")
    p.add_argument("--scale", type=float, default=2.5)
    p.set_defaults(fn=cmd_rtl_render)
    p = sub.add_parser("check")
    steps_args(p)
    p.set_defaults(fn=cmd_check)
    p = sub.add_parser("describe")
    p.add_argument("ids", nargs="+")
    p.set_defaults(fn=cmd_describe)
    p = sub.add_parser("search")
    p.add_argument("word")
    p.set_defaults(fn=cmd_search)
    p = sub.add_parser("functions")
    p.add_argument("--search")
    p.add_argument("--category")
    p.add_argument("--names", action="store_true")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_functions)
    p = sub.add_parser("eval")
    p.add_argument("formula")
    p.add_argument("--in", dest="src")
    p.add_argument("--sheet")
    p.add_argument("--cell")
    p.set_defaults(fn=cmd_eval)
    p = sub.add_parser("cat")
    p.add_argument("file")
    p.add_argument("--range")
    p.add_argument("--sheet")
    p.add_argument("--formulas", action="store_true")
    p.add_argument("--csv", action="store_true")
    p.set_defaults(fn=cmd_cat)
    p = sub.add_parser("preview")
    p.add_argument("file")
    p.add_argument("out_png")
    p.add_argument("--sheet")
    p.add_argument("--all", action="store_true")
    p.add_argument("--portrait", action="store_true")
    p.add_argument("--as-printed", action="store_true")
    p.add_argument("--crop", action="store_true")
    p.set_defaults(fn=lambda a: preview(a.file, a.out_png, a.sheet, a.all, a.portrait, a.as_printed, a.crop))
    p = sub.add_parser("verify")
    p.add_argument("file")
    p.add_argument("--expect", required=True)
    p.add_argument("--set", action="append")
    p.add_argument("--tol", type=float, default=1e-9)
    p.set_defaults(fn=cmd_verify)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
