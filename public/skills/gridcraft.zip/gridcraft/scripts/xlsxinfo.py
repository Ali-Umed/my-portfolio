"""Read an .xlsx/.xlsm package with the standard library: cells, styles, layout, charts, print setup.

Used by critic.py and rtl_render.py. The engine (gridcraft-cli) supplies recalculated values and
display text; this module supplies everything the engine's JSON doesn't expose (resolved styles,
column widths in points, merges, conditional formats, chart anchors and chart XML details).
"""
import posixpath
import re
import zipfile
import xml.etree.ElementTree as ET

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "rel": "http://schemas.openxmlformats.org/package/2006/relationships",
      "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
      "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
      "c": "http://schemas.openxmlformats.org/drawingml/2006/chart",
      "dc": "http://purl.org/dc/elements/1.1/",
      "cp": "http://schemas.openxmlformats.org/package/2006/metadata/core-properties"}
RID = "{%s}id" % NS["r"]

BUILTIN_FMT = {0: "General", 1: "0", 2: "0.00", 3: "#,##0", 4: "#,##0.00", 9: "0%", 10: "0.00%",
               11: "0.00E+00", 12: "# ?/?", 13: "# ??/??", 14: "m/d/yyyy", 15: "d-mmm-yy", 16: "d-mmm",
               17: "mmm-yy", 18: "h:mm AM/PM", 19: "h:mm:ss AM/PM", 20: "h:mm", 21: "h:mm:ss",
               22: "m/d/yyyy h:mm", 37: "#,##0 ;(#,##0)", 38: "#,##0 ;[Red](#,##0)",
               39: "#,##0.00;(#,##0.00)", 40: "#,##0.00;[Red](#,##0.00)", 45: "mm:ss", 46: "[h]:mm:ss",
               47: "mmss.0", 48: "##0.0E+0", 49: "@"}
DEFAULT_THEME = ["FFFFFF", "000000", "E7E6E6", "44546A", "4472C4", "ED7D31", "A5A5A5", "FFC000", "5B9BD5",
                 "70AD47", "0563C1", "954F72"]


# ------------------------------------------------------------------ references

def col_index(letters):
    n = 0
    for ch in letters.upper():
        n = n * 26 + ord(ch) - 64
    return n


def col_letters(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def parse_cell(ref):
    m = re.match(r"^\$?([A-Za-z]{1,3})\$?(\d+)$", ref.strip())
    if not m:
        raise ValueError(ref)
    return int(m.group(2)), col_index(m.group(1))


def parse_range(ref):
    """'B2:D9' or 'B2' -> (r1, c1, r2, c2); whole columns/rows are clamped to the sheet limits."""
    ref = ref.split("!")[-1].replace("$", "")
    a, _, b = ref.partition(":")
    b = b or a
    def one(x, lo):
        if re.match(r"^[A-Za-z]+$", x):
            return (1 if lo else 1048576), col_index(x)
        if re.match(r"^\d+$", x):
            return int(x), (1 if lo else 16384)
        return parse_cell(x)
    r1, c1 = one(a, True)
    r2, c2 = one(b, False)
    return min(r1, r2), min(c1, c2), max(r1, r2), max(c1, c2)


def addr(r, c):
    return f"{col_letters(c)}{r}"


def rng(r1, c1, r2, c2):
    return addr(r1, c1) if (r1, c1) == (r2, c2) else f"{addr(r1, c1)}:{addr(r2, c2)}"


# ------------------------------------------------------------------ colours

def _tint(hex6, tint):
    if not tint:
        return hex6
    r, g, b = (int(hex6[i:i + 2], 16) / 255 for i in (0, 2, 4))
    import colorsys
    h, l, s = colorsys.rgb_to_hls(r, g, b)
    l = l * (1 + tint) if tint < 0 else l * (1 - tint) + tint
    r, g, b = colorsys.hls_to_rgb(h, max(0, min(1, l)), s)
    return "".join(f"{round(v * 255):02X}" for v in (r, g, b))


def luminance(hex6):
    def ch(v):
        v = v / 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = (int(hex6[i:i + 2], 16) for i in (0, 2, 4))
    return 0.2126 * ch(r) + 0.7152 * ch(g) + 0.0722 * ch(b)


def contrast(a, b):
    la, lb = sorted((luminance(a), luminance(b)), reverse=True)
    return (la + 0.05) / (lb + 0.05)


# ------------------------------------------------------------------ workbook

class Workbook:
    def __init__(self, path):
        self.path = path
        self.z = zipfile.ZipFile(path)
        self.names = set(self.z.namelist())
        self.theme = self._theme()
        self._styles()
        self.strings = self._shared_strings()
        self.props = self._props()
        self.defined = []
        self.sheets = []
        wb = self._xml("xl/workbook.xml")
        rels = self._rels("xl/workbook.xml")
        for dn in wb.findall(".//m:definedName", NS):
            self.defined.append({"name": dn.get("name"), "local": dn.get("localSheetId"), "ref": dn.text or ""})
        calc = wb.find("m:calcPr", NS)
        self.calc_mode = (calc.get("calcMode") if calc is not None else None) or "auto"
        for i, s in enumerate(wb.findall(".//m:sheets/m:sheet", NS)):
            target = rels.get(s.get(RID))
            if target:
                self.sheets.append(Sheet(self, i, s.get("name"), target, s.get("state") or "visible"))

    # -- helpers
    def _xml(self, name):
        return ET.fromstring(self.z.read(name)) if name in self.names else None

    def _rels(self, part):
        d, f = posixpath.split(part)
        rp = posixpath.join(d, "_rels", f + ".rels")
        out = {}
        x = self._xml(rp)
        if x is None:
            return out
        for r in x.findall("rel:Relationship", NS):
            t = r.get("Target")
            out[r.get("Id")] = t.lstrip("/") if t.startswith("/") else posixpath.normpath(posixpath.join(d, t))
        return out

    def _theme(self):
        x = self._xml("xl/theme/theme1.xml")
        cols = list(DEFAULT_THEME)
        if x is None:
            return cols
        cs = x.find(".//a:clrScheme", NS)
        if cs is None:
            return cols
        order = ["lt1", "dk1", "lt2", "dk2", "accent1", "accent2", "accent3", "accent4", "accent5", "accent6",
                 "hlink", "folHlink"]
        for i, nm in enumerate(order):
            el = cs.find(f"a:{nm}", NS)
            if el is None:
                continue
            srgb, sysc = el.find("a:srgbClr", NS), el.find("a:sysClr", NS)
            if srgb is not None:
                cols[i] = srgb.get("val").upper()
            elif sysc is not None and sysc.get("lastClr"):
                cols[i] = sysc.get("lastClr").upper()
        return cols

    def color(self, el, default=None):
        """Hex 'RRGGBB' for a <color>/<fgColor> element, or default for auto/none."""
        if el is None:
            return default
        if el.get("rgb"):
            v = el.get("rgb").upper()
            return v[-6:]
        if el.get("theme") is not None:
            i = int(el.get("theme"))
            base = self.theme[i] if i < len(self.theme) else "000000"
            return _tint(base, float(el.get("tint") or 0))
        if el.get("indexed") is not None:
            idx = int(el.get("indexed"))
            legacy = {8: "000000", 9: "FFFFFF", 10: "FF0000", 11: "00FF00", 12: "0000FF", 13: "FFFF00",
                      64: None, 65: None}
            return legacy.get(idx, default) or default
        return default

    def _styles(self):
        x = self._xml("xl/styles.xml")
        self.numfmts, self.fonts, self.fills, self.borders, self.xfs, self.dxfs = {}, [], [], [], [], []
        if x is None:
            self.xfs = [{"font": {"name": "Calibri", "size": 11, "bold": False, "italic": False, "color": None},
                         "fill": None, "border": {}, "numfmt": "General", "h": None, "v": "bottom", "wrap": False,
                         "indent": 0}]
            return
        for nf in x.findall("m:numFmts/m:numFmt", NS):
            self.numfmts[int(nf.get("numFmtId"))] = nf.get("formatCode")
        for f in x.findall("m:fonts/m:font", NS):
            self.fonts.append(self._font(f))
        for f in x.findall("m:fills/m:fill", NS):
            self.fills.append(self._fill(f))
        for b in x.findall("m:borders/m:border", NS):
            self.borders.append(self._border(b))
        for xf in x.findall("m:cellXfs/m:xf", NS):
            al = xf.find("m:alignment", NS)
            nid = int(xf.get("numFmtId") or 0)
            fid, flid, bid = int(xf.get("fontId") or 0), int(xf.get("fillId") or 0), int(xf.get("borderId") or 0)
            self.xfs.append({"font": self.fonts[fid] if fid < len(self.fonts) else self.fonts[0],
                             "fill": self.fills[flid] if flid < len(self.fills) else None,
                             "border": self.borders[bid] if bid < len(self.borders) else {},
                             "numfmt": self.numfmts.get(nid, BUILTIN_FMT.get(nid, "General")),
                             "h": al.get("horizontal") if al is not None else None,
                             "v": (al.get("vertical") if al is not None else None) or "bottom",
                             "wrap": (al is not None and al.get("wrapText") in ("1", "true")),
                             "indent": int(al.get("indent") or 0) if al is not None else 0})
        for d in x.findall("m:dxfs/m:dxf", NS):
            f = d.find("m:font", NS)
            fl = d.find("m:fill", NS)
            self.dxfs.append({"font_color": self.color(f.find("m:color", NS)) if f is not None else None,
                              "bold": f is not None and f.find("m:b", NS) is not None,
                              "fill": self._fill(fl) if fl is not None else None})

    def _font(self, f):
        g = lambda t: f.find(f"m:{t}", NS)
        b, i = g("b"), g("i")
        return {"name": g("name").get("val") if g("name") is not None else "Calibri",
                "size": float(g("sz").get("val")) if g("sz") is not None else 11.0,
                "bold": b is not None and b.get("val") not in ("0", "false"),
                "italic": i is not None and i.get("val") not in ("0", "false"),
                "color": self.color(g("color"))}

    def _fill(self, f):
        p = f.find("m:patternFill", NS)
        if p is None or (p.get("patternType") or "none") == "none":
            return None
        fg = p.find("m:fgColor", NS)
        bg = p.find("m:bgColor", NS)
        return self.color(fg) or self.color(bg)

    def _border(self, b):
        out = {}
        for side in ("left", "right", "top", "bottom"):
            e = b.find(f"m:{side}", NS)
            if e is not None and e.get("style"):
                out[side] = (e.get("style"), self.color(e.find("m:color", NS), "000000"))
        return out

    def _shared_strings(self):
        x = self._xml("xl/sharedStrings.xml")
        if x is None:
            return []
        return ["".join(t.text or "" for t in si.iter(f"{{{NS['m']}}}t")) for si in x.findall("m:si", NS)]

    def _props(self):
        x = self._xml("docProps/core.xml")
        if x is None:
            return {}
        t = x.find("dc:title", NS)
        c = x.find("dc:creator", NS)
        return {"title": (t.text or "") if t is not None else "", "creator": (c.text or "") if c is not None else ""}

    def style(self, idx):
        return self.xfs[idx] if 0 <= idx < len(self.xfs) else self.xfs[0]


class Sheet:
    def __init__(self, wb, index, name, part, state):
        self.wb, self.index, self.name, self.part, self.state = wb, index, name, part, state
        self.cells = {}            # (r, c) -> {"v", "t", "f", "s", "array_ref"}
        self.col_pt = {}           # c -> width in points (customised columns)
        self.col_style = {}        # c -> xf index of the column
        self.row_pt = {}
        self.hidden_cols, self.hidden_rows = set(), set()
        self.merges, self.cf, self.tables, self.charts = [], [], [], []
        self.validations = 0
        self.sparklines = 0
        self.spills = []           # (r1, c1, r2, c2) of dynamic-array results
        x = wb._xml(part)
        if x is None:
            return
        fmt = x.find("m:sheetFormatPr", NS)
        self.default_row_pt = float(fmt.get("defaultRowHeight") or 15) if fmt is not None else 15.0
        dcw = fmt.get("defaultColWidth") if fmt is not None else None
        self.default_col_pt = round(float(dcw) * 7) * 0.75 if dcw else 48.0
        sv = x.find("m:sheetViews/m:sheetView", NS)
        self.rtl = sv is not None and sv.get("rightToLeft") in ("1", "true")
        self.show_grid = not (sv is not None and sv.get("showGridLines") in ("0", "false"))
        pane = sv.find("m:pane", NS) if sv is not None else None
        self.freeze = None
        if pane is not None and pane.get("state") in ("frozen", "frozenSplit"):
            self.freeze = (int(float(pane.get("ySplit") or 0)), int(float(pane.get("xSplit") or 0)))
        for col in x.findall("m:cols/m:col", NS):
            lo, hi = int(col.get("min")), int(col.get("max"))
            for c in range(lo, min(hi, lo + 200) + 1):
                if col.get("width"):
                    self.col_pt[c] = round(float(col.get("width")) * 7) * 0.75
                if col.get("style"):
                    self.col_style[c] = int(col.get("style"))
                if col.get("hidden") in ("1", "true"):
                    self.hidden_cols.add(c)
        for row in x.findall("m:sheetData/m:row", NS):
            r = int(row.get("r"))
            if row.get("ht"):
                self.row_pt[r] = float(row.get("ht"))
            if row.get("hidden") in ("1", "true"):
                self.hidden_rows.add(r)
            for c in row.findall("m:c", NS):
                rr, cc = parse_cell(c.get("r"))
                t = c.get("t") or "n"
                v = c.find("m:v", NS)
                f = c.find("m:f", NS)
                val = v.text if v is not None else None
                if t == "s" and val is not None:
                    val = wb.strings[int(val)]
                elif t == "inlineStr":
                    val = "".join(e.text or "" for e in c.iter(f"{{{NS['m']}}}t"))
                    t = "str"
                elif t == "n" and val is not None:
                    try:
                        val = float(val)
                    except ValueError:
                        pass
                elif t == "b" and val is not None:
                    val = val in ("1", "true")
                cell = {"v": val, "t": t, "f": None, "s": int(c.get("s") or 0), "array_ref": None}
                if f is not None:
                    cell["f"] = f.text or ""
                    if f.get("t") == "array" and f.get("ref"):
                        cell["array_ref"] = f.get("ref")
                        try:
                            rg = parse_range(f.get("ref"))
                            if rg[0] != rg[2] or rg[1] != rg[3]:
                                self.spills.append(rg)
                        except ValueError:
                            pass
                if val is None and f is None and not c.get("s"):
                    continue
                self.cells[(rr, cc)] = cell
        for m in x.findall("m:mergeCells/m:mergeCell", NS):
            self.merges.append(parse_range(m.get("ref")))
        for cf in x.findall("m:conditionalFormatting", NS):
            for rule in cf.findall("m:cfRule", NS):
                d = {"sqref": cf.get("sqref"), "type": rule.get("type"), "operator": rule.get("operator"),
                     "dxf": int(rule.get("dxfId")) if rule.get("dxfId") else None,
                     "formula": [e.text for e in rule.findall("m:formula", NS)]}
                cs = rule.find("m:colorScale", NS)
                if cs is not None:
                    d["colors"] = [wb.color(e) for e in cs.findall("m:color", NS)]
                db = rule.find("m:dataBar", NS)
                if db is not None:
                    d["colors"] = [wb.color(db.find("m:color", NS))]
                self.cf.append(d)
        dv = x.find("m:dataValidations", NS)
        self.validations = len(dv.findall("m:dataValidation", NS)) if dv is not None else 0
        ps = x.find("m:pageSetup", NS)
        spr = x.find("m:sheetPr/m:pageSetUpPr", NS)
        self.page = {k: ps.get(k) for k in ("orientation", "paperSize", "fitToWidth", "fitToHeight", "scale")} if ps is not None else {}
        self.page["fitToPage"] = spr is not None and spr.get("fitToPage") in ("1", "true")
        hf = x.find("m:headerFooter", NS)
        self.footer = "".join((e.text or "") for e in hf) if hf is not None else ""
        self.sparklines = len(re.findall(rb"<x14:sparkline>", wb.z.read(part)))
        rels = wb._rels(part)
        for tp in x.findall("m:tableParts/m:tablePart", NS):
            t = wb._xml(rels.get(tp.get(RID), ""))
            if t is not None:
                si = t.find("m:tableStyleInfo", NS)
                self.tables.append({"name": t.get("displayName") or t.get("name"), "ref": parse_range(t.get("ref")),
                                    "style": si.get("name") if si is not None else None,
                                    "totals": t.get("totalsRowCount") not in (None, "0")})
        dr = x.find("m:drawing", NS)
        if dr is not None and rels.get(dr.get(RID)):
            self._drawing(rels[dr.get(RID)])

    def _drawing(self, part):
        x = self.wb._xml(part)
        if x is None:
            return
        rels = self.wb._rels(part)
        for anc in list(x):
            tag = anc.tag.split("}")[1]
            if tag not in ("twoCellAnchor", "oneCellAnchor", "absoluteAnchor"):
                continue
            fr = anc.find("xdr:from", NS)
            to = anc.find("xdr:to", NS)
            box = None
            if fr is not None:
                c1 = int(fr.find("xdr:col", NS).text) + 1
                r1 = int(fr.find("xdr:row", NS).text) + 1
                if to is not None:
                    c2 = int(to.find("xdr:col", NS).text) + 1
                    r2 = int(to.find("xdr:row", NS).text) + 1
                    if int(to.find("xdr:colOff", NS).text or 0) == 0:
                        c2 -= 1
                    if int(to.find("xdr:rowOff", NS).text or 0) == 0:
                        r2 -= 1
                    box = (r1, c1, max(r1, r2), max(c1, c2))
                else:
                    ext = anc.find("xdr:ext", NS)
                    w = int(ext.get("cx")) / 12700 if ext is not None else 360
                    h = int(ext.get("cy")) / 12700 if ext is not None else 216
                    box = self._span(r1, c1, w, h)
            ch = anc.find(".//c:chart", NS)
            xfrm = anc.find(".//a:ext", NS)
            size = (int(xfrm.get("cx")) / 12700, int(xfrm.get("cy")) / 12700) if xfrm is not None else None
            if ch is not None:
                info = self._chart(rels.get(ch.get(RID), ""))
                info.update(box=box, size=size)
                self.charts.append(info)

    def _span(self, r1, c1, w, h):
        c, acc = c1, 0.0
        while acc + self.width(c) < w - 0.5:
            acc += self.width(c)
            c += 1
        r, acc = r1, 0.0
        while acc + self.height(r) < h - 0.5:
            acc += self.height(r)
            r += 1
        return (r1, c1, r, c)

    def _chart(self, part):
        x = self.wb._xml(part)
        info = {"part": part, "kind": None, "title": None, "series": 0, "legend": False, "points": 0,
                "three_d": False, "data_labels": False, "gridlines": False}
        if x is None:
            return info
        pa = x.find(".//c:plotArea", NS)
        kinds = [e.tag.split("}")[1] for e in pa if e.tag.endswith("Chart")] if pa is not None else []
        info["kind"] = kinds[0] if kinds else None
        info["three_d"] = any("3D" in k for k in kinds) or x.find(".//c:view3D", NS) is not None
        t = x.find(".//c:chart/c:title", NS)
        if t is not None:
            info["title"] = "".join(e.text or "" for e in t.iter(f"{{{NS['a']}}}t")) or "(auto)"
        atd = x.find(".//c:autoTitleDeleted", NS)
        if info["title"] is None and atd is not None and atd.get("val") == "0" and len(x.findall(".//c:ser", NS)) == 1:
            info["title"] = "(series name)"
        sers = x.findall(".//c:ser", NS)
        info["series"] = len(sers)
        if sers:
            pc = sers[0].find(".//c:cat//c:ptCount", NS) or sers[0].find(".//c:val//c:ptCount", NS)
            info["points"] = int(pc.get("val")) if pc is not None else 0
        info["legend"] = x.find(".//c:legend", NS) is not None
        info["data_labels"] = any(e.get("val") == "1" for e in x.findall(".//c:dLbls/c:showVal", NS))
        info["gridlines"] = x.find(".//c:majorGridlines", NS) is not None
        info["colors"] = [e.get("val").upper() for e in x.findall(".//c:ser/c:spPr/a:solidFill/a:srgbClr", NS)]
        return info

    # -- geometry
    def width(self, c):
        if c in self.hidden_cols:
            return 0.0
        return self.col_pt.get(c, self.default_col_pt)

    def height(self, r):
        if r in self.hidden_rows:
            return 0.0
        return self.row_pt.get(r, self.default_row_pt)

    def merge_at(self, r, c):
        for m in self.merges:
            if m[0] <= r <= m[2] and m[1] <= c <= m[3]:
                return m
        return None

    def in_table(self, r, c):
        for t in self.tables:
            a = t["ref"]
            if a[0] <= r <= a[2] and a[1] <= c <= a[3]:
                return t
        return None

    def in_spill(self, r, c):
        return any(a[0] <= r <= a[2] and a[1] <= c <= a[3] and (r, c) != (a[0], a[1]) for a in self.spills)

    def style(self, r, c):
        cell = self.cells.get((r, c))
        if cell is not None:
            return self.wb.style(cell["s"])
        return self.wb.style(self.col_style.get(c, 0))


def open_workbook(path):
    return Workbook(path)
