# TextureCraft skill for Claude

Lets Claude texture 3D models in TextureCraft (Substance Painter-style) with code: projects from a mesh, baked mesh
maps, fill and image layers with masks, smart materials, cameras, path-traced renders and PBR texture export.

Install (Claude Code): copy this folder to `~/.claude/skills/texturecraft/`. Claude apps: upload the zip under
Settings > Capabilities > Skills. Needs TextureCraft with `texturecraft-cli`.

`examples/episode-06/` is from "One car, 17 apps", Episode 6: the prompt, the car (`moon-r1.glb` from Episode 4),
Claude's own `build.json` (35 steps: Episode 5's paint and carbon maps as named, masked layers), the hero render
`moon-r1.png`, the six exported textures, and `sun.json`, the one-command change that adds twenty years of sun
(`moon-r1-sun-faded.png`). The Episode 5 maps are on the MaterialCraft skill page. To rebuild the project:
`texturecraft-cli new moon-r1.glb moon-r1.tcraft --resolution 2048 && texturecraft-cli bake moon-r1.tcraft && texturecraft-cli batch build.json`
(with the maps in a `maps` folder next to it).
Video: https://youtu.be/_PcE42gnBzQ
