---
name: texturecraft
description: "Paint and texture 3D models with code through TextureCraft, the ArtCraft open-source Substance Painter clone (texturecraft-cli). New projects from a mesh (glTF/GLB, FBX, USD, OBJ, Alembic...) or a built-in mesh, bake mesh maps, smart materials, layers with masks, render (path traced) and export PBR texture sets (PNG/EXR, UDIM). Use it when the user mentions TextureCraft or a .tcraft file, wants a 3D model textured, mesh maps baked or textures exported with the ArtCraft apps. Sibling - MaterialCraft makes the procedural materials it paints with."
---

# TextureCraft (texturecraft-cli)

```bash
texturecraft-cli new <mesh | builtin:crate> out.tcraft [--resolution 1024] [--sample]   # --sample: bake + a smart material
texturecraft-cli info project.tcraft                     # texture sets, layers, UV report (JSON)
texturecraft-cli commands --filter fill                  # engine command ids + params
texturecraft-cli run project.tcraft <command-id> '{...}' -o out.tcraft
texturecraft-cli batch script.json                       # {"open": in, "steps": [{"id","params"}...], "save": out}
texturecraft-cli bake project.tcraft [--resolution 2048] [--maps id,id]
texturecraft-cli render project.tcraft out.png --size 1080x1080 [--view 3d|2d] [--yaw 30 --pitch -10] [--samples 256]
texturecraft-cli export project.tcraft textures/ [--preset <name>] [--format png|exr] [--size 2048]
```

Built-in meshes: material_ball, sphere, cube, rounded_cube, cylinder, torus, plane, crate, udim_plane.
Tested: `new builtin:crate crate.tcraft --resolution 512 --sample` (2 s) then `render ... --size 480x480` (3 s on GPU).

- `--samples` path traces (slow, beautiful); without it the render is the fast viewport.
- MaterialCraft `.mcmat` materials paint like built-in ones (their inputs stay editable).
- Live app: `texturecraft --control 7878`; MCP: `texturecraft-cli mcp --read-root DIR --write-root DIR`
  (adding it to Claude's config is a lasting change - ask first).
- Always render and look before sending.

## Lessons from the Craft series Episode 6 (2026-11-28, CLI 0.6.1)
- MaterialCraft hand-off: `material.load` reads `.mcmat`/`.mcraft`, not `.sbs`, and MaterialCraft 0.4.1 writes `.mcmat`
  version 2 while TextureCraft 0.6.1 reads version 1. Until they match, use MaterialCraft's exported maps:
  `resource.import {path}` each PNG, `layer.add.image {name: "<resource>", channel: baseColor, projection: triplanar, scale}`,
  then `layer.fill.set {channel: roughness|normal|metallic, image: "<resource>"}` on the same layer.
- Meshes from SolidCraft: export `.glb` (Y-up, comes in upright); its OBJ is Z-up and lies on its side. Each colour
  becomes a texture set; restrict a layer to parts with `layer.set {geometryMask: [part names]}` (`textureSet.parts`).
- A mesh without UVs gets an automatic unwrap (hundreds of charts): project tiling materials triplanar to hide seams.
- `bake` before smart materials; `material.apply {material: "paint_sun_faded"}` (or rust, mud, plastic_dusty...) adds
  one ageing layer on the selected texture set. Recolour a fill layer with `layer.fill.set {layer, channel: baseColor, color}`.
- Cameras: yaw 0 = side (nose left), 90 = rear, about -45 = front three-quarter; `camera.add {name}` then
  `render --camera NAME --samples 256` path-traces 1920x1080 in ~7 s on an M1 Pro. Turntable: `--yaw` steps with `--samples 64`
  (~3 s per 1600x1000 frame).
- A saved project with 2048 sets and baked maps is large (~250 MB): keep it out of zips; share textures + the build script.
