# VectorCraft skill for Claude

Lets Claude make and edit vector art in VectorCraft (the open-source Illustrator-style app from the ArtCraft suite)
with code: logos, badges, app icons, posters, global swatches, Pathfinder, type incl. Kurdish/Arabic, SVG/PDF/AI/EPS
export, and a critic that scores each result.

Install (Claude Code): copy this folder to `~/.claude/skills/vectorcraft/`. Claude apps: upload the zip under
Settings > Capabilities > Skills. Needs VectorCraft with `vectorcraft-cli` and Python 3.

`examples/episode-03/` is from "One car, 17 apps", Episode 3: the prompt, the input (`moon-blueprint.dxf` from
Episode 2), the logo kit Claude made (`moon-logo.vectorcraft`, `moon-logo.svg`, `moon-logo.pdf`, preview `kit.png`)
and the blue version (`moon-logo-blue.*`, `kit-blue.png`), made with one `swatch.edit` on the global "Moon Orange" swatch.
Video: https://youtu.be/_W20uApqubo
