# VectorCraft engine reference (vectorcraft-cli 0.10.0; desktop app still 0.9.0)

Sources: the storytold/vectorcraft docs (AGENTS.md, README.md, docs/mcp.md, docs/control-protocol.md,
docs/gaps.md, docs/target-app-parity.md, docs/file-format-parity.md, docs/effects-parity.md,
docs/type-parity.md, docs/development.md) and the **live registry** of the installed CLI
(`vectorcraft-cli commands`: 743 commands; `effect.list`: 80 live effects; `document.formats`). Rows
re-checked against the 0.10.0 registry on 2026-10-13.
The live registry is the source of truth: run `scripts/vectorcraft.py describe <id>` before using
anything not listed here, and `scripts/vectorcraft.py search <word>` to find ids.

## How the engine works

- **Everything is a command.** Every menu item, tool gesture and dialog is an engine command (id + JSON
  params). The CLI, MCP and the desktop control channel all run the same registry, so a result made
  headless is what the app would make. Each command is one undo step; `command.batch` makes many one step.
- **Commands act on the selection.** A new object becomes the selection, so `shape.star` followed by
  `paint.setFill` paints the star. Most commands also take `ids`. Re-select with `select.set {ids}`;
  ids come from each step's result (`{"id": 4}`, `{"ids": [8]}`) or `document.find {name|kind|text}`.
- **Paint commands also set the default for the next object.** New art starts with a white fill and a
  1 pt black stroke; set `paint.setStroke {"none": true}` when you want none. Lines start stroke-only.
- **Coordinates:** points, y down, origin at the first artboard's top-left; a new document is 612 x 792
  (US Letter) unless `file.new {width, height}`. At 72 ppi one point is one pixel. Lengths in params are
  points (some also take `"5 mm"`). Angles in `object.rotate` are counter-clockwise degrees; the shape
  commands' `rotation` turns the same way (−30 tilts the top to the right).
- **Paint values:** `"#rrggbb"`, `[r,g,b]` 0..1, `{"c","m","y","k"}`, `{"gray"}`, `{"l","a","b"}`,
  `{"none": true}`, `{"swatch": name}` or `{"gradient": {kind: linear|radial|freeform, stops: [{offset,
  color, opacity?}], angle?, start?, end?}}`. Gradient `angle: -90` runs the first stop at the top.
- **Type:** `text.create {x, y}` is the baseline anchor of point type; `text.setStyle {justify: "center"}`
  then centres the line on x. With `tracking` too, CLI 0.24.1 lands the line tracking/2 to the right
  (size × tracking / 2000 pt; 0.22.0 did not), so follow it with `object.setBounds {x, reference: 4}` to
  centre the drawn text on x — works on every version. `area: {width, height}` makes area type. Arabic, Persian, Kurdish and Hebrew
  shape right to left (bidi) on canvas, PNG and PDF; check the font has the letters (Geeza Pro covers
  Kurdish ڤ ۆ ە). `text.fontList` lists families; `text.fontList {family}` lists its styles.
- **Unknown parameter keys are silently ignored** (`{"radus": 20}` succeeds and does nothing). Missing
  required values do fail (`paint.setFill {}` → "give color, none, swatch or gradient"). Validate with
  `vectorcraft.py check` (it also checks effect ids and effect params against `effect.list`).
- **Results can feed later steps:** a param string `"$N.path"` takes a value from step N's result
  (0-based, in run order; `run --in`'s open isn't a step): `"$3.id"`, `"$5.ids.0"`, `"$8.matches.0.id"`,
  `"$last.id"`. `"$$"` escapes a literal `$`. A reference that names nothing fails the step.

## Transports (best first)

| Path | Use | Notes |
|---|---|---|
| `vectorcraft-cli run [--in FILE] --cmd ID [--params JSON] … [--export FILE]… [--scale N]` | default; one headless session per call (~50 ms) | trusted local: any path. Prints one JSON line per step, exits non-zero at the first failure (nothing later runs, so no partial exports). `--params` belongs to the `--cmd` before it. Host commands `file.open`, `file.save`, `file.export`, `file.exportForScreens`, `tool.select` also work. |
| `vectorcraft-cli convert IN OUT [--scale N] [--artboard I \| --range R] [--outline-text] [--replace-lossy]` | quick format conversion / PNG render | a PDF gets every artboard; other formats the first (or `--artboard`). |
| `vectorcraft-cli info FILE` | summary: import warnings, artboards, object counts by kind, fonts (missing/substituted) | |
| `vectorcraft-cli mcp --headless --automation-read-root DIR --automation-write-root DIR` | MCP over stdio for long interactive sessions | tools: `draw_shape`, `draw_path`, `set_paint`, `add_text`, `apply_effect`, `pathfinder`, `transform`, `create_graph`, `export`, `screenshot`, `run_command`, `command_batch` (`atomic`), `inspect_document`, `render_preview`… Paths outside the roots are refused (tool error). Registering it (`claude mcp add`) is a persistent config change: only when the user asks. |
| Desktop control channel `VectorCraft --control 7979` | live in the user's window | JSON lines on 127.0.0.1, **no authentication**; `engine.execute {command, params}`, `document.inspect`, `ui.inspect`, `app.open/save/export {path}`, `ui.render`, `ui.screenshot`, `ui.menu.invoke`, `ui.dialog.*`, `ui.pointer`, `ui.key`. Client: `scripts/vectorcraft_control.py`. |

Control-channel limits and rules (control-protocol.md): one JSON object per line, ≤ 4 MiB; any other
line gets an error and the connection is closed; ≤ 16 connections. Control is only on when the app is
launched with `--control PORT` (or `VECTORCRAFT_CONTROL_PORT`); sibling ArtCraft apps default to the same
port 7979, so check who answers. `--automation-read-root/--automation-write-root DIR` confine every path a
request reads or writes (absolute paths; links followed; a root left out grants nothing; roots must exist
or the app won't start). `ui.screenshot` needs a visible, drawn window (fails after ~8 s when the screen is
locked or the window minimised); `ui.render` works regardless. A command without `path` that needs a
file opens a native file dialog and returns `"cancelled"` at once on macOS: always pass `path`. With
background save on (default), `app.save` returns `{background: true}` before the file exists; `ui.inspect`
lists running jobs under `background`. `app.quit`, `file.close` open `saveChanges` dialogs for modified
documents (`ui.dialog.confirm` saves, `{field: "discard", value: true}` + confirm discards). MCP server:
one line in, one reply out, so no progress, cancellation or subscriptions; exports are synchronous.

## Recommended step order

1. `file.new {width, height, units?, artboards?, colorMode?}` (or start from the user's file with `--in`).
   Name/size artboards (`artboard.setProps {index, name}`, `artboard.new {x, y, width, height, name}`;
   put extra artboards side by side with a gap so art doesn't straddle two).
2. Layers when the piece has parts (`layer.setProps {name}` renames the current one, `layer.new {name}`
   adds one above and makes it current).
3. Back-to-front: backgrounds, shapes, then details. After each shape: `paint.setFill`, `paint.setStroke`,
   `stroke.set`, `object.setProps {name}` (names make `document.find` and the Layers panel useful).
4. Constructive geometry: `object.path.outlineStroke`, `object.pathfinder.*`, `shapeBuilder.merge`,
   `object.compoundPath.make`, `object.clippingMask.make` (select the operands with `select.set` first).
5. Live effects last (`effect.apply`), so Pathfinder and transforms don't bake them.
6. Type on its own layer; keep it live in the native file; outline only in exports (`svg: outlineText`)
   or with `type.createOutlines` when the user asks.
7. Save native, then export. Check text bounds in the tree against the artboard before rendering.

## Saving and exporting

- **Native `.vectorcraft`**: versioned JSON, lossless, every object, effect and layer editable;
  `document.export {path: "x.vectorcraft"}` writes it without changing the document's path. Old
  `.drawcraft` files open. CLI 0.10.0 writes format `version: 4` by default (`3|2|1` for older builds);
  tested 2026-10-13: the 0.9.0 engine (same as the installed 0.9.0 desktop app) opens a v4 file from the
  kurdish-post template with no warnings and renders it pixel-identical, so no `version` is needed.
- **`document.export {path, format?, …}`** picks the format by extension: svg, svgz, pdf, ai, eps, dxf,
  emf, wmf, png, png8, jpg, webp, gif, tiff, bmp, tga, psd, txt, vectorcraft, template. It writes the
  first artboard (`artboard: i`), or with `useArtboards: true` one file per artboard named
  `<stem>-<artboard name>.<ext>` (a PDF puts every artboard on its own page by default).
  **It does not create folders** ("No such file or directory"); `vectorcraft.py apply` creates them.
- Raster options: `ppi` (72 = 1 px per pt; wins over `scale`), `background` (`transparent` default,
  `white`, `#rrggbb`; JPEG flattens on white), `antiAlias` (`art`/`type`/`none`). WebP is lossless only.
- SVG options (flat or `svg: {…}`): `outlineText`, `embedFonts`, `styling`, `decimals`, `minify`,
  `responsive`, `preserveEditing` (SVG reopens as the full native document), `profile: "tiny12"`.
  Right-to-left lines are written as outlines in SVG (with a warning) until SVG direction support lands.
  Live effects export as SVG filters (glows, shadows, blurs).
- PDF: `preset` ("VectorCraft Default" preserves editing, "High Quality Print", "Press Quality",
  "Smallest File Size", PDF/X-1a/3/4), `standard`, `compatibility`, `marks`, `bleed`, `createLayers`,
  `advanced: {outlineText}`. Type is real, searchable text in embedded subsets by default.
- `.ai` output is a PDF-compatible file carrying the native document (VectorCraft reopens it exactly;
  Illustrator opens it as plain art without its own editing data). DWG can't be written: export DXF.
- `document.exportForScreens {folder, formats: [{format, scale: 1|"2x"|"512w"|"100h"|"72ppi", suffix?}],
  prefix?, artboards?|range?}` writes `<prefix><artboard name>@<size>.<ext>` per artboard and row.
- **Lossy sources are protected:** writing over a file whose import left something out (hidden text,
  unreadable art) is refused unless `acknowledgeLoss: true` / `convert --replace-lossy`. Never use them on
  the user's original; write a new file.
- **Preferences:** in a CLI run, `prefs.set`, saved presets (`pdf.preset.save`, `flattener.presets.save`,
  `file.newPresets.save`…), colour themes and user libraries would go to the user's VectorCraft settings;
  `vectorcraft.py` runs with `VECTORCRAFT_NO_PREFS=1` so they stay in the session. In the live app they
  persist: ask first.

## Reading files

`document.open` / `--in` / `file.place` read .vectorcraft/.drawcraft, .svg/.svgz, .pdf, .ai/.ait, .eps,
.dxf (ASCII), .emf/.wmf, .psd/.psb (merged image), PNG, JPEG, GIF, WebP, TIFF, BMP, Affinity .af/.afdesign/
.afpub (read only). SVG `id`s become object names; images open as a document of their pixel size.
`file.place {path, link: false, rect: [x, y, w, h]}` places another file's art as one editable group
(`link: true` keeps a linked placed document or image). PDF/`.ai` options: `pages`, `cropTo`, `textAs:
"outlines"`, `layers`, `editingData`. Always read `info`'s `warnings` after opening someone's file.

## Commands for common tasks (from the live registry)

### Document, open, save, export

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `file.new` | {preset?: a name from file.newPresets (start from it; the other params change it), name?\|title?: document name (default Untitled-N), width?: pt=612\|"210 mm", height?: pt=792, units?: "Pixels"\|"Points"\|"Picas"\|"Inches"\|"Millimeters"\|"Centimeters"\|"Feet"\|"Yards"\|"Meters"\|"Feet & Inches" (default: prefs unitsGeneral, as print … |
| `document.open` | {path} or {name, dataBase64}, PDF/.ai: pages?: "2-3, 5" (1-based, default all; one artboard each) \| page?: n, cropTo?: bounding\|art\|crop (default)\|trim\|bleed\|media (the box each artboard gets; bounding: the art's bounds; trim: the bleed box round it becomes the document's bleed; a PDF-compatible .ai opens on its trim boxes for … |
| `document.save` | {path?, format?: vectorcraft\|template\|pdf\|svg\|svgz\|ai (default: the path's extension, else the document's own format), options?: {…the format's options, see file.formatOptions; default: as last saved}, svg?: {…SVG options} (SVG options may also be given flat; an SVG save keeps hidden layers, display:none, unless hiddenLayers is … |
| `document.export` | {path?, format?: svg\|svgz\|pdf\|png\|jpg\|webp\|gif\|png8\|txt\|dxf\|eps\|emf\|wmf\|tiff\|bmp\|tga\|psd\|vectorcraft\|template (default: from the path's extension, else png; png8 writes an indexed .png), selectedOnly?: false (the selected objects alone, in their layers), artboard?: 0, artboards?: [i…], range?: "1-3, 5" \| "all" (1-based; PDF … |
| `document.exportPdf` | {path?, preset?: "VectorCraft Default" (built-in or saved: pdf.preset.list), artboard? \| artboards?: [i…] \| range?: "1-3, 5" (1-based; default all, one page each), standard?: none\|pdfA2b\|pdfX1a (CMYK, grey and spot colours only: colours and images converted to output.destination or the CMYK output intent, untagged; transparency … |
| `document.exportForScreens` | {folder?, zip?: false (one store-only .zip of every file: no folder → {name, dataBase64, bytes, files: [name…]}; with a folder it is written there → {path, bytes, files}), artboards?: [index…] \| range?: "1-3" (default all), assets?: [asset id…] (instead of artboards: each asset's art alone, cropped to its bounds and named after … |
| `file.place` | {path \| name+dataBase64, link?: true (a raster image keeps its file's path; a VectorCraft document at path becomes one locked placed document showing artboard `page`, linked to the file and read again when it changes (links.update; saving it in this app updates it at once), drawn as vectors in every output; false: an editable … |
| `artboard.new` | {x?, y?, width?, height?, name?} (default: right of the last) |
| `artboard.setProps` | {index, name?, x?, y?, width?, height?, moveArt?: bool (default false; a position-only change moves the contained art with its artboard), scaleArt?: bool (Scale Artwork with Artboard: resized, the artboard takes the art fully inside it (locked and hidden art only with lockedAndHidden?: bool, default prefs … |
| `artboard.fitToArt` | {index?} the artboard fits the art that shows (with its strokes and effects; hidden objects and layers, guides and template layers don't count) |
| `document.setup` | {units?: "Points"\|"Inches"\|"Millimeters"\|…, bleed?: pt (all sides)\|[top, bottom, left, right]\|{top?, bottom?, left?, right?} (0–72 pt), outlineImages?: bool (show images in Outline mode), highlightSubstitutedFonts?: bool, highlightSubstitutedGlyphs?: bool, gridSize?: "small"\|"medium"\|"large", gridColors?: … |

### Shapes and paths

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `shape.rectangle` | {x, y, width, height, radius?: pt, rotation?: deg (about centre)} → {id} |
| `shape.ellipse` | {x, y, width, height, rotation?: deg (about centre)} → {id} |
| `shape.polygon` | {cx, cy, radius, sides=6, rotation?: deg} → {id} |
| `shape.star` | {cx, cy, radius1, radius2, points=5, rotation?: deg} → {id} |
| `shape.line` | {x1, y1, x2, y2} → {id} |
| `shape.arc` | {x1, y1, x2, y2, closed?} → {id} |
| `shape.spiral` | {cx, cy, radius, decay=80 (%), segments=10, clockwise?} → {id} |
| `path.create` | {anchors: [{x, y, in?: [x,y], out?: [x,y]}], closed?: bool, d?: SVG path data} → {id} |
| `object.setLiveShape` | {id?, ids?, radius?: pt, kind?: "round"\|"invertedRound"\|"chamfer", corners?: [i…], items?: [{id, corners?: [i…]}] (several objects, each with its own corners, in place of ids and corners: the canvas's corner widgets across a selection), sides?: n, polygonAngle?: degrees (counterclockwise from its first vertex straight up), … |

### Paint, stroke, appearance

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `paint.setFill` | {color?: "#rrggbb"\|[r,g,b]\|{c,m,y,k}\|{gray}\|{l,a,b} (CIE Lab), none?: true, swatch?: name (a global or spot colour stays linked, so swatch edits recolour it; a tint swatch links to its base at its tint; a gradient swatch is recorded as the gradient's swatch and fits each object, keeping its aspect; the built-in "[Registration]" … |
| `paint.setStroke` | same as paint.setFill, for the stroke (item?: the stroke item to set) |
| `paint.editGradient` | {stroke?: bool (default: the targeted item's kind, else the active proxy), kind?: linear\|radial\|freeform (freeform places points on each object, coloured along the stops), mode?: points\|lines (freeform: how the Gradient tool adds points), stops?: [{offset 0..1, color? (needed without swatch), opacity? 0..1 (or 0..100), … |
| `stroke.set` | {weight?: pt, cap?: butt\|round\|square, join?: miter\|round\|bevel, miterLimit?, align?: center\|inside\|outside, dash?: [d,g,…]\|null (a 0 dash with a round or projecting cap draws dots or squares; a new pattern keeps the current offset and alignment), dashOffset? (exact dashes only), alignDashes?: bool (true: dashes fitted to … |
| `transparency.set` | {ids?\|id?, opacity?: 0..100, blend?: name, isolate?, knockout?: "on"\|"off"\|"neutral"\|bool (true = on, false = neutral), knockoutShape?: bool, item?: appearance item index\|null} for `ids`, the selection, or the object whose opacity mask is being edited; opacity and blend go to the targeted fill/stroke item (omitted: the … |
| `appearance.addFill` | {ids?, target?: "object"\|"contents"} add a fill on top of each selected object's own stack (a copy of its top fill; type without one: its characters' fill; else the default fill) |
| `appearance.addStroke` | {ids?, target?} add a stroke on top of each selected object's own stack (a copy of its top stroke, else the default stroke) |
| `effect.apply` | {effect: id (see effect.list, e.g. "stylize.dropShadow", "distort.roughen", "warp.arc", or "plugin.<id>" for an installed effect plug-in), params?: {…} (missing keys take the dialog defaults), item?: appearance item index\|null (apply to that fill/stroke only; omitted: the Appearance panel's active item, else the whole object), … |
| `effect.setParams` | {index: int, params?: {…} (merged into the current parameters), visible?: bool, item?: appearance item index\|null (as effect.remove), ids?: [..]} → {ids} |
| `effect.expandAppearance` | {ids?: [..], target?} turn each object's appearance into objects: every fill and stroke becomes an object of its own (strokes outlined, brushed strokes their brush art) grouped in paint order under the object's id and transparency, geometry effects are baked, raster effects become an embedded image (shadows and outer glows … |
| `graphicStyle.apply` | {name, add?: bool, ids? (layers too), target?: "object"\|"contents"} give the objects (default: the selection; a group or layer itself, its fills and strokes painting its members and its effects applying to them as one piece; target contents: the objects inside instead) the style's appearance, opacity, blend mode, isolate and … |

### Type

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `text.create` | {x, y, text, vertical?: bool = false, size?: pt, font?: family, style?, color?, area?: {width, height, fit?: none\|autoHeight\|shrinkText, fitMinPercent?}, placeholder?: bool (fill it with placeholder text instead, as the Type tools do with prefs placeholderText), leadingModel?: "romanBaseline"\|"emBoxTop", charAlign?: … |
| `text.setStyle` | {ids?\|id?, font?, style?, size?: pt, leading?: pt\|"auto", tracking?: 1/1000 em, justify?: "auto" (the start of each paragraph's direction)\|"left"\|"center"\|"right"\|"justifyAll", fill?: colour, features?: ["dlig", "-liga", …] OpenType, start?: byte, end?: byte} (size/leading are document points after object scaling; with a range: … |
| `text.setFormat` | {ids?\|id?, kerning?: 1/1000 em\|"auto", baselineShift?: pt, hScale?: %, vScale?: %, rotation?: deg, underline?, strikethrough?, allCaps?, smallCaps?: bool, position?: "normal"\|"superscript"\|"subscript" (sizes from Document Setup), leftIndent?, rightIndent?, firstLineIndent?, spaceBefore?, spaceAfter?: pt (±1296), hyphenate?: … |
| `text.setRangeStyle` | {id? (default: the one selected type object), start?: byte, end?: byte (default: all text), font?, style?, size?: pt, leading?: pt\|"auto", tracking?, kerning?: 1/1000 em\|"auto", baselineShift?: pt, hScale?: %, vScale?: %, rotation?: deg, fill?: colour\|"none", stroke?: colour\|"none", strokeWidth?: pt, strokeOptions?: {weight?, … |
| `text.createInPath` | {path: id, mode: "area"\|"onPath", text?: "", vertical?: bool = false, at?: [x, y] (on-path start: nearest point), size?, font?, style?, color? (as text.create), fit?: none\|autoHeight\|shrinkText, fitMinPercent? (area: as text.areaOptions; default autoHeight when the autoSizeAreaType preference is on), placeholder?: bool … |
| `text.setText` | {id?\|ids?, text} replace the contents of text objects (keeps the first run's style) |
| `text.areaOptions` | {ids?, width?: pt, height?: pt, rows?, columns?, gutter?: pt, inset?: pt, firstBaseline?: ascent\|capHeight\|xHeight\|leading\|fixed, firstBaselineMin?: pt, verticalAlign?: top\|center\|bottom\|justify, fit?: none\|autoHeight\|shrinkText, fitMinPercent?: 10..100} set the selected area type's options; width and height size the type area … |
| `type.createOutlines` | {} convert the selected text to groups of compound paths (one per glyph) → {ids} |
| `text.fontList` | {family?} → {families: [names]} sorted: the bundled fonts, fonts added and the fonts installed on the system (none on the web), each the family's English (canonical) name for `text.setStyle` and documents (without the system's hidden families, whose names start with a dot; they still resolve by name). Preferences › Type › Show … |

### Select, arrange, transform

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `select.all` | {} → {count}; while the Type tool edits text, all of that text instead → {editing, start, end} (byte offsets) |
| `select.none` | {} |
| `select.set` | {ids: [id…]} all ids must be non-negative integers naming existing objects → {count, ids} (resulting selection) |
| `document.find` | {name?: substring of the Layers panel name, kind?: panel label such as Group, Path, Type or Image (exact), text?: substring of type content, limit?: max matches (default 100, 0 counts only)} → {matches: [{id, name, kind, path}], total} |
| `object.setProps` | {ids?\|id?, name?, visible?, locked? (visible: false or locked: true deselects every selected object hidden or locked after the call, the key object included), opacity?: 0..100, blend?: "Multiply"…, isolate?, knockout?: "on"\|"off"\|"neutral"\|bool (true = on, false = neutral), knockoutShape?: bool, data?: {key: "value" \| null (removes it)} (the object's own data, SVG data-* attributes: {pivot: "100,180"} is data-pivot; document.node → attrs.data)} |
| `object.group` | {} → {id} |
| `object.ungroup` | {} |
| `object.arrange.bringToFront` | {} |
| `object.arrange.sendToBack` | {} |
| `object.move` | {dx, dy, copy?, patterns?: bool (Transform Patterns: pattern fills and strokes transform with the art; default: prefs transformPatternTiles)} |
| `object.rotate` | {angle: deg (counter-clockwise), absolute?: bool (angle is the bounding box's new angle, not an amount), origin?: [x,y] (default: the bounding box centre), copy?, patterns?: bool (Transform Patterns: pattern fills and strokes transform with the art; default: prefs transformPatternTiles)} → {ids} |
| `object.scale` | {sx: %, sy?: %, origin?: [x,y], copy?, strokes?: bool (Scale Strokes & Effects: stroke weights, dashes and effect distances scale; off keeps them, type strokes included), corners?: bool (Scale Corners: live corner radii scale), patterns?: bool (Transform Patterns: pattern fills and strokes transform with the art; default: prefs … |
| `object.reflect` | {axis: "vertical"\|"horizontal"\|deg, origin?, copy?, patterns?: bool (Transform Patterns: pattern fills and strokes transform with the art; default: prefs transformPatternTiles)} |
| `object.align` | {horizontal?: "left"\|"center"\|"right", vertical?: "top"\|"center"\|"bottom", to?: "selection"\|"artboard"\|"key" (default: the key object when the selection has one, select.key, else the selection), artboard?: index (0-based; with to: "artboard", the artboard to align to; the app passes the active one; default: the artboard under the center of the selection, else the first), bounds?: "preview"\|"geometric" (default: the Use Preview Bounds preference; preview bounds take in strokes), patterns?: bool (Transform Patterns: pattern fills and strokes transform with the art; default: prefs transformPatternTiles)} With anchor points selected (Direct Selection), the points align instead: to their own bounds, or to the artboard (#1180) |
| `object.distribute` | {horizontal?: "left"\|"center"\|"right", vertical?: "top"\|"center"\|"bottom", bounds?: "preview"\|"geometric" (default: the Use Preview Bounds preference; preview bounds take in strokes), patterns?: bool (Transform Patterns: pattern fills and strokes transform with the art; default: prefs transformPatternTiles)} |
| `object.setBounds` | {x?, y?, width?, height?, reference?: 0..8 (9-point grid), proportional?, strokes?, corners?} (Transform panel; width/height and the reference point follow the bounding box, rotated with rotated objects; x, y are page coordinates; with Use Preview Bounds the values measure the visual bounds; strokes/corners as object.scale) |
| `edit.duplicate` | {dx?, dy?} duplicate the selection in place (offset optional) |
| `edit.clear` | {ids?} delete the objects `ids`, else the selection (direct-selected anchors, else objects, else ruler guides) |

### Path operations

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `object.pathfinder.unite` | {} operate on the selected objects (back → front) → {ids} |
| `object.pathfinder.minusFront` | {} operate on the selected objects (back → front) → {ids} |
| `object.pathfinder.intersect` | {} operate on the selected objects (back → front) → {ids} |
| `object.pathfinder.exclude` | {} operate on the selected objects (back → front) → {ids} |
| `object.pathfinder.divide` | {} operate on the selected objects (back → front) → {ids} |
| `shapeBuilder.merge` | {ids?: [id…] (default: selection), points: [[x,y]…] (drag path; one point = click), erase?: bool (erase mode, Alt: deletes the regions touched, and the pieces of unfilled open paths and the edges (outline pieces between the points where paths meet; see shapeBuilder.regions) within tolerance; a deleted edge opens its path there, … |
| `object.compoundPath.make` | {} |
| `object.clippingMask.make` | {} the topmost selected object (a path, compound path or text, which loses its paint) clips the others: compound holes, even-odd fills and glyph outlines clip as drawn. Paint given to the clipping path later (paint commands with its id) shows: its fill behind the clipped art, its stroke over it → {id} of the clip group |
| `object.path.offsetPath` | {offset: pt (negative insets), joins?: "miter"\|"round"\|"bevel", miterLimit?: 4} → {ids} (new objects above the originals) |
| `object.path.outlineStroke` | {} replace stroked paths with filled outlines → {ids} |
| `object.path.simplify` | {tolerance?: pt (1), cornerAngle?: deg (30), straightLines?: bool} → {ids, before, after} anchor counts |
| `object.expand` | {object?: true (type → outlines, live shapes → paths, effects baked, blends → groups of their steps, envelopes → their distorted content, placed documents → editable copies of their art, as placing the file without link gives, its symbols, patterns, swatches and images joining the document), fill?: true (gradient fills → … |

### Colour

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `swatch.new` | {name?, color? \| colors?: [colour] (one swatch each, in one undo step) \| swatch? \| gradient? \| pattern?: name (default: the current fill), tint?: 0..100 (% of the global or spot `swatch`, or of the one the current fill links to), mode?: "gray"\|"rgb"\|"hsb"\|"lab"\|"cmyk"\|"web" (convert the colour; lab: CIE L*a*b*, how spot colours … |
| `swatch.newGroup` | {name?, swatches?: [names] (solid colours move into the group; gradients, patterns and None stay), colors?: [colour] (added as new swatches), fromArtwork?: false (add the unique colours of the selected art: fills, strokes, text, gradient stops and mesh points; a colour linked to a global swatch moves that swatch into the … |
| `recolor.colors` | {} → {colors: [{key: colour identity ("rgb 255 0 0", "cmyk 0 100 100 0", "gray 40", "lab 55 60 -40"), hex, count, swatch?: the global swatch it is linked to}]} unique colours used by the selection (fills, strokes, gradient stops, text, mesh points and the tiles of pattern fills and strokes), most used first |
| `recolor.apply` | {map: rows [{from: [colour keys (recolor.colors) or "#rrggbb" (every colour shown as that hex)], to: colour (hex, key, {c,m,y,k} or {l,a,b}) \| null, exclude?: false (the row's colours are kept)}] \| {"key or #rrggbb": colour, …} (one row per colour), method?: "exact" … |
| `recolor.reduce` | {colors?: n (rows; default: one per colour, with the tints of a global swatch in its row), method?: as recolor.apply, default scaleTints (picks each row's colour), preserve?: {white?: true, black?: true, grays?: false} (left out of the rows), limitTo?: as recolor.apply (new colours snap to it)} group the selection's colours … |
| `edit.colors.invert` | {fill?: true, stroke?: true, includeImages?: true, includePatterns?: true, ids?} replace each colour by its RGB inverse (keeps the colour model) in fills, strokes, text, gradient meshes (with fills), embedded images (a recoloured copy) and pattern tiles (a new pattern swatch; the original stays), as one undo step → {changed} |
| `edit.colors.toGrayscale` | {fill?, stroke?, includeImages?, includePatterns?, ids?} (as edit.colors.invert) → {changed} |
| `color.harmony` | {color, rule: complementary\|complementary2\|splitComplementary\|leftComplement\|rightComplement\|analogous\|analogous2\|monochromatic\|shades\|triad\|triad2\|triad3\|tetrad\|tetrad2\|tetrad3\|compound\|compound2\|highContrast\|highContrast2\|highContrast3\|pentagram (or its label), steps?: 1..20 (4), variation?: … |
| `file.documentColorMode` | {mode: "cmyk"\|"rgb", convert?: true (convert every colour of the art, symbols, pattern tiles and swatches through the colour settings; swatch links kept; Gray colours stay Gray, on the black plate), intent?, grays?: "profile" (default: RGB greys separate through the CMYK profile like any colour, into four-colour greys and a … |

### Layers

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `layer.new` | {name?, top?: bool, color?, template?, locked?, visible?, printable?, preview?, dimImages?} a layer directly above the current layer, at its level (a sublayer beside a current sublayer); `top`: above all layers (Ctrl-click the button). Options as layer.setProps → {id} |
| `layer.setProps` | {ids?\|id? (default: the highlighted rows, else the current layer), name?, visible?, locked?, template?, printable?, preview?, dimImages?: 0..100\|false, color?: index 0..26\|"#rrggbb"\|preset name} Layer Options; rows that are not layers take name, visible and locked. Template on also locks the layer and dims its images to 50% … |
| `layer.setCurrent` | {id} click a row: it alone is highlighted, and the layer it is (or the layer it is in) becomes the current layer, where new art goes. Not an undo step → {id, layer} |
| `layer.move` | {ids, target, place?: "above"\|"below"\|"inside" (default inside), copy?: bool} drag rows in the Layers panel: above or below the target row (beside it, in its layer or group), or inside a layer or group (on top of its contents). Layers go only in layers or at the top level, objects in layers and groups; an object placed beside a … |

### Live objects and tracing

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `object.blend.make` | {ids?, steps?: n \| distance?: pt \| smooth?: bool, orientation?: page\|path (default: the Blend Options set with nothing selected, else smooth colour and page), starts?: [anchor index \| null, …] (per object of `ids`, else of the selection in paint order: the anchor of its first subpath the blend starts from; an open path's last … |
| `object.repeat.radial` | {ids?, instances?: n (8), radius?: pt} radial repeat of the selection (or switch the selected repeat to radial) → {id} |
| `object.repeat.grid` | {ids?, hSpacing?: pt, vSpacing?: pt (¼ of the art size), rows?: n (3), cols?: n (3)} grid repeat of the selection → {id} |
| `object.envelope.makeWithWarp` | {ids?, style?: arc\|arcLower\|arcUpper\|arch\|bulge\|shellLower\|shellUpper\|flag\|wave\|fish\|rise\|fisheye\|inflate\|squeeze\|twist (arc), bend?: % -100..100 (50), h?: horizontal distortion % -100..100 (0), v?: vertical distortion % (0), horizontal?: bool (true) \| orientation?: horizontal\|vertical} envelope the selected objects with a warp … |
| `symbol.new` | {name?, ids?} make a symbol from the selection and replace it with an instance → {name, id} |
| `symbol.place` | {name?, x?, y?} place an instance centred at (x, y) (default: artboard centre; name default: current) → {id} |
| `imageTrace.make` | {id?: image or Image Trace group (default: selection), preset?: name (imageTrace.presets), params?: {mode: "blackAndWhite"\|"grayscale"\|"color"\|"logo", threshold: 0-255, palette: "limited"\|"fullTone"\|"automatic"\|"documentLibrary" (color mode; limited: the `colors` best colours, fullTone: as many as the tones need, more with … |
| `imageTrace.makeAndExpand` | same as imageTrace.make, then expand → {id, paths, anchors, colors} |
| `graph.create` | {type: column\|stackedColumn\|bar\|stackedBar\|line\|area\|scatter\|pie\|radar, x, y, width, height, series?: [..], categories?: [..], rows?: [[number\|null]], csv?} → {id}; an empty CSV cell or a null is a blank value, a number in straight quotes is a label |
| `object.vectorHalftone` | {shape?: "circle"\|"ellipse"\|"square"\|"diamond"\|"line" (circle), frequency?: lines per inch 1–300 (20), angle?: deg (45; CMYK: the black screen's, cyan −30°, magenta +30°, yellow −45° from it), mode?: "mono"\|"cmyk" (mono), color?: mono dot colour ("#000000"), invert?: bool (dots for light tones), clip?: true (clip the dots to … |

### Inspection

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `document.inspect` | {depth?, childLimit?} → layer tree, artboards, selection, history (a sliced tree reports childCount) |
| `document.node` | {id, summary?: compact summary, depth?: child levels in the summary (default all), childLimit?: children shown per node (default all; a level that shows fewer reports childCount)} → one object |
| `document.formats` | {} → {formats: [{id, label, extensions, mime, read, write, raster, options: {name: {type, default, description}}}], readable: [id…], writable: [id…], openExtensions: [ext…], unsupported: [{id, label, extensions, hint}] (formats asked for that can be neither opened nor written, such as DWG and PICT, with what to use instead)} |
| `effect.list` | {} → {catalog: [{id, label, menu, params, defaults, raster, lengths: {always, absolute (while relative is false)} (distance params Scale Strokes & Effects scales)}] (installed effect plug-ins last: id plugin.<plug-in id>, menu Effect › Plug-ins), applied: [{id, effects, items: [{index, kind: fill\|stroke, effects}]}], … |
| `command.batch` | {label?, commands: [{command, params}], artboard?: index (the active artboard; the app passes it: each edit.pasteInPlace, edit.pasteInFront, edit.pasteInBack, object.align or select.allOnArtboard step that names none gets it, or the last artboard of a document with fewer)} run several commands as ONE undo step (one in each document they edit: steps may open, switch, close or revert documents); stops at the first error and rolls everything back, documents included |

### New in 0.10.0 (not in the 0.9.0 desktop app: CLI/MCP only until the app is updated)

| id | params (live registry, shortened; `describe ID` prints all) |
|---|---|
| `edit.undoGroup.begin` | {label?: string} until `edit.undoGroup.end`, the edits in the active document are one undo step |
| `edit.undoGroup.end` | {cancel?: bool} close the group: one undo step, or with `cancel` the edits are undone |
| `file.list` | {path} → {path, entries: [{name, kind: file\|folder\|link, size?}], truncated} (held to the automation read root; >5000 entries truncates) |
| `document.rulerOrigin` | {} → {x, y} the rulers' zero point in absolute document points |
| `document.setRulerOrigin` | {x, y} move the rulers' zero point; art, guides and **command coordinates stay absolute** |
| `document.resetRulerOrigin` | {artboard?: 0} back to that artboard's top-left |
| `select.segments` | {id, segments: [[subpath, segment]…]} select path segments (endpoints move with them; Delete removes only the connections) |
| `object.blend.spine.reshapeSegment` | {id?, segment, t: 0..1, dx, dy} bend a blend's spine segment (as path.reshapeSegment) |
| `graph.design` | {new?: name\|true, rename?, to?, paste?: name, delete?: name\|[names]}; no params → {designs, unused} (Illustrator graph designs) |
| `graph.marker` | {id?, seriesIndexes?: [i], design?: name\|null} draw line/scatter/radar data points with a graph design |
| `links.findFiles` | {folder?: absolute path, ids?, maxSeconds?: 60, stop?} search a folder for missing linked files |

Other 0.10.0 changes that matter for recipes:

- `text.setFormat` / `text.setRangeStyle` take **`digits: "default"|"arabic"|"hindi"|"farsi"`** (draws
  every digit in that numeral system whatever was typed: `"hindi"` gives Eastern Arabic ٠١٢٣ for Sorani;
  tested) and `proportionalMetrics: bool` (`palt`/`vpal`, CJK).
- `text.setStyle` size/leading and `text.setRangeStyle` size/leading/baselineShift are **document points
  after the object's scaling** (a scaled type object now reports and takes its visible size).
- `object.align` gains `artboard: index` (with `to: "artboard"`; default the artboard under the
  selection's centre, else the first) and `patterns`; it needs a direction (`horizontal` or `vertical`),
  and unknown choices are errors. With anchors Direct-Selected it aligns the points.
  `object.distribute` gains `patterns`. `command.batch` gains `artboard` (passed to align/paste steps).
- `select.key {id}` must name a selected top-level object of a selection of two or more; any other id is
  an error. `object.setProps {visible: false | locked: true}` and `layer.move` into a hidden/locked
  layer now **deselect** those objects: re-`select.set` before the next selection-based step.
- `paint.setFill`: while the Type tool has characters selected (live app), the colour goes to them only.
- `object.setLiveShape` corners also round where curved sides meet at an angle.
- `file.place {crop}` on an SVG frames it by its viewBox; `document.open` of a PDF-compatible .ai uses its
  trim boxes for `cropTo: crop`.

## Live effects (`effect.apply {effect, params}`; params not given take these defaults)

`effect.apply` appends to the selection's appearance (`ids`, `item` for one fill/stroke, `target:
"contents"`). Edit later with `effect.setParams {index, params}`; bake with `effect.expandAppearance`.
Raster effects (glows, shadows, blurs, Photoshop-style filters) render at
`document.rasterEffectsSettings {resolution}` (72 by default for new documents: raise it, e.g.
`file.new {rasterEffectsPpi: 300}`, for print).

| effect id | raster | defaults (= every param key) |
|---|:-:|---|
| `threeD.revolve` |  | `{"ambient": 25.0, "angle": 360.0, "edge": "left", "expandVisibleOnly": true, "lightAzimuth": -45.0, "lightElevation": 45.0, "lightIntensity": 80.0, "offset": 0.0, "perspective": 0.0, "rotationX": 0.0, …}` |
| `convertToShape.rectangle` |  | `{"extraH": 18.0, "extraW": 18.0, "height": 100.0, "relative": true, "width": 100.0}` |
| `convertToShape.roundedRectangle` |  | `{"extraH": 18.0, "extraW": 18.0, "height": 100.0, "radius": 9.0, "relative": true, "width": 100.0}` |
| `convertToShape.ellipse` |  | `{"extraH": 18.0, "extraW": 18.0, "height": 100.0, "relative": true, "width": 100.0}` |
| `distort.freeDistort` |  | `{"corners": [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]}` |
| `distort.puckerBloat` |  | `{"amount": 0.0}` |
| `distort.roughen` |  | `{"detail": 10.0, "points": "smooth", "relative": true, "seed": 0, "size": 5.0}` |
| `distort.transform` |  | `{"copies": 0, "moveH": 0.0, "moveV": 0.0, "random": false, "reference": 4, "reflectX": false, "reflectY": false, "rotate": 0.0, "scaleH": 100.0, "scaleV": 100.0}` |
| `distort.tweak` |  | `{"anchors": true, "h": 10.0, "in": true, "out": true, "relative": true, "seed": 0, "v": 10.0}` |
| `distort.twist` |  | `{"angle": 10.0}` |
| `distort.zigZag` |  | `{"points": "smooth", "relative": false, "ridges": 4, "size": 10.0}` |
| `path.offsetPath` |  | `{"joins": "miter", "miterLimit": 4.0, "offset": 10.0}` |
| `path.outlineStroke` |  | `{}` |
| `stylize.roundCorners` |  | `{"radius": 10.0}` |
| `stylize.scribble` |  | `{"angle": 30.0, "curviness": 5.0, "overlap": 0.0, "seed": 0, "spacing": 5.0, "strokeWidth": 3.0, "variation": 0.5}` |
| `stylize.dropShadow` | yes | `{"blur": 5.0, "color": "#000000", "mode": "multiply", "opacity": 75.0, "x": 7.0, "y": 7.0}` |
| `stylize.innerGlow` | yes | `{"blur": 5.0, "color": "#ffffff", "mode": "screen", "opacity": 75.0, "source": "edge"}` |
| `stylize.outerGlow` | yes | `{"blur": 5.0, "color": "#ffff00", "mode": "screen", "opacity": 75.0}` |
| `stylize.feather` | yes | `{"radius": 5.0}` |
| `blur.gaussian` | yes | `{"radius": 5.0}` |
| `blur.radial` | yes | `{"amount": 10.0, "method": "spin", "quality": "good"}` |
| `blur.smart` | yes | `{"quality": "medium", "radius": 3.0, "threshold": 25.0}` |
| `brushStrokes.accentedEdges` | yes | `{"edgeBrightness": 38.0, "edgeWidth": 2.0, "smoothness": 5.0}` |
| `brushStrokes.angledStrokes` | yes | `{"directionBalance": 50.0, "sharpness": 3.0, "strokeLength": 15.0}` |
| `brushStrokes.crosshatch` | yes | `{"sharpness": 6.0, "strength": 1.0, "strokeLength": 9.0}` |
| `brushStrokes.darkStrokes` | yes | `{"balance": 5.0, "blackIntensity": 6.0, "whiteIntensity": 2.0}` |
| `brushStrokes.inkOutlines` | yes | `{"darkIntensity": 20.0, "lightIntensity": 10.0, "strokeLength": 4.0}` |
| `brushStrokes.spatter` | yes | `{"smoothness": 5.0, "sprayRadius": 10.0}` |
| `brushStrokes.sprayedStrokes` | yes | `{"sprayRadius": 7.0, "strokeDirection": "rightDiagonal", "strokeLength": 12.0}` |
| `brushStrokes.sumiE` | yes | `{"contrast": 16.0, "strokePressure": 2.0, "strokeWidth": 10.0}` |
| `distort.diffuseGlow` | yes | `{"clearAmount": 15.0, "glowAmount": 10.0, "graininess": 6.0}` |
| `distort.glass` | yes | `{"distortion": 5.0, "invert": false, "scaling": 100.0, "smoothness": 3.0, "texture": "frosted"}` |
| `distort.oceanRipple` | yes | `{"rippleMagnitude": 9.0, "rippleSize": 9.0}` |
| `sharpen.unsharpMask` | yes | `{"amount": 50.0, "radius": 1.0, "threshold": 0.0}` |
| `stylize.glowingEdges` | yes | `{"edgeBrightness": 6.0, "edgeWidth": 2.0, "smoothness": 5.0}` |
| `pixelate.colorHalftone` | yes | `{"channel1": 108.0, "channel2": 162.0, "channel3": 90.0, "channel4": 45.0, "maxRadius": 8.0}` |
| `pixelate.crystallize` | yes | `{"cellSize": 10.0}` |
| `pixelate.mezzotint` | yes | `{"type": "fineDots"}` |
| `pixelate.pointillize` | yes | `{"cellSize": 5.0}` |
| `texture.craquelure` | yes | `{"crackBrightness": 9.0, "crackDepth": 6.0, "crackSpacing": 15.0}` |
| `texture.grain` | yes | `{"contrast": 50.0, "grainType": "regular", "intensity": 40.0}` |
| `texture.mosaicTiles` | yes | `{"groutWidth": 3.0, "lightenGrout": 9.0, "tileSize": 12.0}` |
| `texture.patchwork` | yes | `{"relief": 8.0, "squareSize": 4.0}` |
| `texture.stainedGlass` | yes | `{"borderThickness": 4.0, "cellSize": 10.0, "lightIntensity": 3.0}` |
| `texture.texturizer` | yes | `{"invert": false, "lightDirection": "top", "relief": 4.0, "scaling": 100.0, "texture": "canvas"}` |
| `artistic.filmGrain` | yes | `{"grain": 4.0, "highlightArea": 0.0, "intensity": 10.0}` (new in 0.10.0) |
| `video.deinterlace` | yes | `{"create": "duplication", "eliminate": "odd"}` |
| `video.ntscColors` | yes | `{}` |
| `adjust.brightnessContrast` |  | `{"brightness": 0.0, "contrast": 0.0}` |
| `adjust.curves` |  | `{"channel": "rgb", "points": "0,0 128,128 255,255"}` |
| `adjust.hueSaturation` |  | `{"colorize": false, "hue": 0.0, "lightness": 0.0, "saturation": 0.0}` |
| `adjust.levels` |  | `{"channel": "rgb", "gamma": 1.0, "inputBlack": 0.0, "inputWhite": 255.0, "outputBlack": 0.0, "outputWhite": 255.0}` |
| `adjust.shiftToColor` |  | `{"amount": 50.0, "color": "#ff8000", "preserveLightness": true}` |
| `adjust.temperatureTint` |  | `{"temperature": 0.0, "tint": 0.0}` |
| `warp.arc` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.arcLower` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.arcUpper` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.arch` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.bulge` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.shellLower` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.shellUpper` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.flag` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.wave` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.fish` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.rise` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.fisheye` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.inflate` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.squeeze` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `warp.twist` |  | `{"bend": 50.0, "horizontal": 0.0, "orientation": "horizontal", "vertical": 0.0}` |
| `pathfinder.add` |  | `{}` |
| `pathfinder.intersect` |  | `{}` |
| `pathfinder.exclude` |  | `{}` |
| `pathfinder.subtract` |  | `{}` |
| `pathfinder.minusBack` |  | `{}` |
| `pathfinder.divide` |  | `{}` |
| `pathfinder.trim` |  | `{}` |
| `pathfinder.merge` |  | `{}` |
| `pathfinder.crop` |  | `{}` |
| `pathfinder.outline` |  | `{}` |
| `cropMarks` |  | `{}` |

## Image Trace (vectorize a raster logo or sketch)

Open the image (`--in logo.png`) or place it, `select.all`, then `imageTrace.makeAndExpand {params:
{mode: "logo", ignoreWhite: true}}` for flat logos (≤ 10 colours, snaps lines and circles; refuses
photos and gradients), or `preset` from `imageTrace.presets` (Default, High/Low Fidelity Photo, 3/6/16
Colors, Shades of Gray, Black and White Logo, Sketched Art, Silhouettes, Line Art, Technical Drawing, Flat
Logo). `imageTrace.make` keeps it live (editable trace); `…AndExpand` gives paths. Tested: a 3-colour flat
PNG traced to 4 exact paths (circle with a hole, rectangle, triangle).

## Known gaps and "not yet implemented" (docs/gaps.md, parity docs, 2026-10-12)

- **Stage alpha.** ~88% of Illustrator's menu items/tools exist, depth ~75%. Self-assessed numbers.
- **`.ai` exchange (G9):** real Illustrator files may open with the wrong layer structure (109 layers
  instead of 14, #951), lose guides (#779), open slowly (#758); live effects, brushes and symbols in `.ai`
  come in as their drawn look (#637). VectorCraft never writes Illustrator's own editing data.
- **Not implemented:** 3D beyond an initial Revolve (no Extrude & Bevel, Inflate, Rotate, materials,
  3D export); 28 of 57 Photoshop-style filters (most Artistic, all Sketch) and the Effect Gallery; SVG
  Filters submenu; Effect › Rasterize as a live effect; Outline Object; Pathfinder Hard Mix/Soft Mix/Trap;
  scripting (JavaScript) and Batch; image/graph variables and dataset import/export; generative AI (Text
  to Vector, Generative Recolor…); Touch Type, Retype, spell check, Snap to Glyph, Optical Margin
  Alignment, Hyphenation/Justification options; CJK ruby and manual tate-chu-yoko; Middle Eastern
  Character Direction, kashidas and composers; variable-font axis sliders; DWG, HEIC, JPEG 2000, CorelDRAW,
  FreeHand import; Affinity export; PSD placed as layers; lossy WebP; gradient dither/perceptual blending,
  tangent/perpendicular snapping, artboard locking and the Blend panel (Illustrator 30.x additions);
  Dimension tool; multiple windows.
- **Known bugs (G11):** Shape Builder misses planar regions in some files (#937; Pathfinder gives the
  same results reliably); Transform effect dialog options (#885); PDF text boxes moving on open (#722);
  SVG units reverting to points (#864); Asset Export ghost borders with anti-aliasing (#983).
- **Platform:** no pen pressure on macOS (#852); ~17 Preferences options are stored but do nothing
  (#394); the app may fail to start on some Windows machines (not macOS).
- **Performance:** CPU rendering; budgets not re-verified at 50k paths on an idle machine.

## Behaviour found while testing the design upgrade (2026-10-12)

- `object.setBounds` without `reference` positions the **centre** (reference 4); 0 = top-left … 8 =
  bottom-right. With only `x`/`y` it moves without resizing; width + height together ignore proportions.
- Area type `fit: "shrinkText"` stops at `fitMinPercent` (default 50) and then leaves the text **overset**
  (cut off, no warning). Pass `"fitMinPercent": 30`. Overset text shows up as fewer glyphs after
  `type.createOutlines` (the critic's overset check).
- `text.areaOptions {"verticalAlign": "top"|"center"|"bottom"|"justify"}` works for centring labels in pills.
- In a CMYK document, hex fills convert to CMYK (#111111 → K93) but `text.create` colours stay RGB:
  give CMYK objects for both. `recolor.colors` keys show each colour's model ("rgb …" / "cmyk …").
- `object.envelope.makeWithWarp` and the `warp.*` effects distort type badly (Latin and Kurdish); type on a
  path (`text.createInPath` onPath) drew Kurdish/Arabic unshaped in 0.9.0 (still true in the 0.9.0 desktop
  app) but **is shaped and joined in CLI 0.10.0** (re-tested 2026-10-13 on a curve, Noto Naskh Arabic UI); tracking and
  `justify: "justifyAll"` break Arabic-script joining. Details: `references/kurdish-rtl.md`.
- `document.export {selectedOnly: true, background: "transparent"}` renders one object alone (the critic
  uses it to find each text's ink box and colour).
- PDF export embeds font subsets with ToUnicode maps (Kurdish stays searchable); `standard: "pdfX4"` adds
  GTS_PDFX, TrimBox and BleedBox (`bleed: {"useDocument": true}`, `marks: {"trim": true}`).
