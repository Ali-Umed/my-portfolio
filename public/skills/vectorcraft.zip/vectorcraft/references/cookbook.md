# VectorCraft cookbook: user wording → recipe

Each recipe is a step list for `scripts/vectorcraft.py apply`. Ids and params are from the live
registry of vectorcraft-cli 0.9.0 (re-validated against 0.10.0 on 2026-10-13); the tested ones are marked. `$N` = result of step N (0-based over
your steps). Coordinates are points, y down, origin at the artboard's top-left.

## "Make me a logo / badge for X" (tested: craft-tests/vectorcraft/01-logo)

```json
{"new": {"width": 800, "height": 800, "name": "X logo"},
 "export": ["svg", "png", "pdf"], "exportOptions": {"svg": {"outlineText": true}},
 "steps": [
  ["layer.setProps", {"name": "Badge"}],
  ["shape.ellipse", {"x": 100, "y": 100, "width": 600, "height": 600}],
  ["paint.setFill", {"gradient": {"kind": "radial", "stops": [{"offset": 0, "color": "#5b3a27"}, {"offset": 1, "color": "#24160d"}]}}],
  ["paint.setStroke", {"none": true}],
  ["shape.star", {"cx": 400, "cy": 205, "radius1": 58, "radius2": 20, "points": 8}],
  ["paint.setFill", {"color": "#f2a33a"}],
  ["effect.apply", {"effect": "stylize.outerGlow", "params": {"color": "#ffcf6b", "blur": 18, "opacity": 70}}],
  ["layer.new", {"name": "Type"}],
  ["text.create", {"x": 400, "y": 548, "text": "NOVA", "size": 82, "font": "Avenir Next", "style": "Heavy", "color": "#f6e7d2"}],
  ["text.setStyle", {"justify": "center", "tracking": 80}]]}
```
Offer 2–3 colour or layout variants as separate stems, then a contact sheet (`vectorcraft.py sheet`).

## "Cut a shape out of another" (Pathfinder; tested in 01-logo)

Draw both, then `["select.set", {"ids": ["$A.id", "$B.id"]}]`, `["object.pathfinder.minusFront", {}]`
(front cuts the back), `unite`, `intersect`, `exclude`, `divide`, `trim`, `merge`, `crop`, `outline`,
`minusBack`. A stroked line as the cutter: `stroke.set {weight}` → `object.path.outlineStroke` first
(its result is `{"ids": [...]}`, so use `"$N.ids.0"`).

## "Recolour this SVG/logo to our brand colours" (tested: 02-recolor-icon)

```json
[["select.all", {}],
 ["recolor.colors", {}],
 ["recolor.apply", {"map": {"#f5b700": "#ffc857", "#9aa5b1": "#ffffff"}}]]
```
Run `recolor.colors` first (or `check`-only run) to see the exact colours. `recolor.reduce {colors: 2}`
→ edit `to` → `recolor.apply {map: rows, method: "scaleTints"}` for "make it two-colour".
`edit.colors.toGrayscale {}` / `edit.colors.invert {}` for mono and inverted versions.

## "Turn it into an app icon / give it a rounded background" (tested in 02)

```json
[["shape.rectangle", {"x": 8, "y": 8, "width": 240, "height": 240, "radius": 52}],
 ["paint.setFill", {"gradient": {"kind": "linear", "angle": -90, "stops": [{"offset": 0, "color": "#1f3a5f"}, {"offset": 1, "color": "#2bb3a3"}]}}],
 ["paint.setStroke", {"none": true}],
 ["object.arrange.sendToBack", {}],
 ["document.exportForScreens", {"folder": "/abs/out/screens", "prefix": "icon-",
   "formats": [{"format": "png", "scale": "512w"}, {"format": "png", "scale": "1024w"}, {"format": "svg"}]}]]
```
`preset: "mobile"` gives PNG 1x/2x/3x; `preset: "density"` Android ldpi…xxxhdpi folders.

## "Add a drop shadow / glow / blur" (tested)

`["effect.apply", {"effect": "stylize.dropShadow", "params": {"x": 0, "y": 6, "blur": 10, "opacity": 35, "color": "#0b1a2b"}}]`
on the selection (`document.find {name}` → `select.set`). Glow: `stylize.outerGlow` / `innerGlow`;
soft edges: `stylize.feather`; `blur.gaussian`. Raise `document.rasterEffectsSettings {resolution: 300}`
for print.

## "Social media kit / several sizes in one file" (tested: 03-social-kit)

```json
{"new": {"width": 1080, "height": 1080},
 "steps": [
  ["artboard.setProps", {"index": 0, "name": "Post"}],
  ["artboard.new", {"x": 1180, "y": 0, "width": 1080, "height": 1920, "name": "Story"}],
  ["artboard.new", {"x": 2360, "y": 0, "width": 1500, "height": 500, "name": "Banner"}],
  ["file.place", {"path": "/abs/logo.vectorcraft", "link": false, "rect": [290, 120, 500, 500]}],
  ["document.export", {"path": "/abs/out/png/kit.png", "useArtboards": true, "ppi": 72}]]}
```
Files come out as `kit-Post.png`, `kit-Story.png`, `kit-Banner.png`; the runner's PDF export puts each
artboard on its own page. Compare each text object's bounds in the tree with its artboard: a headline
that runs past the edge is clipped (this happened in testing; size 78 → 64 fixed it).

## "Vectorize / trace this PNG logo" (tested: 05-trace-check)

```bash
python3 -I scripts/vectorcraft.py apply logo.png out/logo-vector --export svg,png \
  --steps '[["select.all",{}],["imageTrace.makeAndExpand",{"params":{"mode":"logo","ignoreWhite":true}}]]'
python3 -I scripts/vectorcraft.py compare logo.png out/logo-vector.svg out/before-after.png
```
Photos: `{"preset": "16 Colors"}` or `"High Fidelity Photo"`; line art: `"Line Art"` / `"Black and White Logo"`.

## Smaller asks

| User says | Steps |
|---|---|
| "Rounded corners on that box" | `object.setLiveShape {"id": N, "radius": 16}` (or `shape.rectangle {radius}` when drawing) |
| "Dashed outline / arrows" | `stroke.set {"dash": [12, 6], "cap": "round"}`; `stroke.set {"endArrow": "Arrow"}` |
| "Make the text follow a circle" | `shape.ellipse` → `text.createInPath {"path": "$N.id", "mode": "onPath", "text": "…", "size": 24}` |
| "Text inside a box" | `text.create {x, y, text, area: {width, height, fit: "shrinkText"}}` |
| "Convert text to outlines" | select it → `type.createOutlines {}` (or SVG export option `outlineText`) |
| "Centre it on the page" | `object.align {"horizontal": "center", "vertical": "center", "to": "artboard"}` |
| "Repeat it in a circle / pattern" | `object.repeat.radial {"instances": 12, "radius": 150}`, `object.repeat.grid`, `object.repeat.mirror` |
| "Blend between two shapes" | `select.set` both → `object.blend.make {"steps": 8}` |
| "Bend the text like a flag/arc" | `object.envelope.makeWithWarp {"style": "flag", "bend": 40}` |
| "Make it CMYK for print" | `file.documentColorMode {"mode": "cmyk"}`; PDF `{"preset": "Press Quality"}` or `standard: "pdfX4"` |
| "Laser-cut / CAD file" | export `.dxf` (`unit`, `scale`, `preserve`); DWG isn't writable |
| "Bar/pie chart" | `graph.create {"type": "pie", "x": 50, "y": 50, "width": 300, "height": 300, "csv": "A,B\\n30,70"}` |
| "Open their .ai/.pdf and change X" | `apply their.ai out/edited …`; read `info` warnings first (`.ai` layer structure can differ) |

## Start from a template (tested, critic-clean)

Before writing a recipe from scratch, check `scripts/vectorcraft.py template list`: logo-badge,
logo-lockup, app-icon, icon-set, social-post, social-story, social-banner, event-poster, kurdish-post
(`references/templates.md`). `template apply ID OUT --var key=value --palette NAME [--dark] --critic`
writes `OUT.template.json`, the full recipe, which you can edit and re-run with `apply --recipe`.
