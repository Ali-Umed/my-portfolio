# VectorCraft template gallery

Nine tested starting points in `templates/`. Each is a recipe with `{{variables}}`, sensible defaults and
a palette from the design guide; all nine render and pass the critic with their defaults (100/100, no
issues) and with the variants in `craft-tests/vectorcraft/templates-test/variants/`. Contact sheet:
`templates/gallery.png`; one preview per template in `templates/thumbs/<id>.png`.

```bash
python3 -I scripts/vectorcraft.py template list
python3 -I scripts/vectorcraft.py template show social-post          # variables, defaults, preview path
python3 -I scripts/vectorcraft.py template palettes                  # the 8 palettes, light and dark
python3 -I scripts/vectorcraft.py template apply social-post out/post \
    --var "headline=Grand opening this Friday" --var cta="Join us · 9 AM" \
    --palette espresso [--dark] --critic
python3 -I scripts/vectorcraft.py template gallery                   # rebuild thumbs/ and gallery.png
```

`apply` fills the variables (template defaults < palette roles < `--var`), expands the optional blocks,
writes `OUT.template.json` (the exact recipe used: edit it and `apply --recipe` it for one-off tweaks),
then runs it like any recipe: `OUT.vectorcraft` + the template's exports, and the critic with `--critic`.
Any palette role can be overridden: `--var accent=#e4572e`. A misspelled variable is refused. Values that
start with `{` or `[` are JSON (CMYK colours: `--var 'accentc={"c":0,"m":80,"y":95,"k":0}'`). `symbol`
names one of the marks in `templates/symbols.json`: star, spark, sun, leaf, mountain, drop, heart, bolt,
bean, flame. An empty value (`--var kurdish=`) leaves an optional element out.

| # | id | Use case | Size | Variables (default palette) | Preview |
|---|---|---|---|---|---|
| 1 | `app-icon` | App / favicon icon: gradient rounded tile, one symbol, sheen and soft shadow; writes 1024/512/180/120/64 px PNGs + SVG to `OUT-sizes/` | 1024 px | symbol, glyph (colour), mode, name (midnight, dark) | `thumbs/app-icon.png` |
| 2 | `event-poster` | Print poster: big sun + symbol, rule, 1–3 line title, date/place, optional Kurdish subtitle; CMYK, 3 mm bleed, 300 ppi effects, PDF/X-4 with trim marks | A3 + bleed | title, kurdish, date, place, note, symbol, font, kfont, paper / inkc / richblack / accentc / mutedc (CMYK) | `thumbs/event-poster.png` |
| 3 | `icon-set` | Eight UI line icons (home, search, heart, bell, user, mail, calendar, sliders) on 24 px artboards, 2 px round strokes; SVG + 1x/2x/3x PNG per icon in `OUT-icons/` | 8 × 24 px | stroke, name (ink) | `thumbs/icon-set.png` |
| 4 | `kurdish-post` | **Kurdish RTL** feed post (default: Newroz greeting): Kurdish brand line, symbol, headline, text and date pill on the right margin, small Latin line left, optional flag bar | 1080 × 1350 | brand, headline, sub, date, latin, symbol, flagbar, kfont, kfont2, font, mode (newroz, dark) | `thumbs/kurdish-post.png` |
| 5 | `logo-badge` | Round emblem: gradient disc, dashed ring, symbol, name (auto-shrinks), divider, tagline, optional Kurdish line | 800 × 800 | name, tagline, kurdish, symbol, font, kfont, mode (espresso, dark) | `thumbs/logo-badge.png` |
| 6 | `logo-lockup` | Horizontal logo: symbol tile + wordmark + tagline, on a light and a dark artboard | 2 × 1200 × 400 | name, tagline, symbol, font (midnight) | `thumbs/logo-lockup.png` |
| 7 | `social-banner` | X/Twitter header with headline, sub and handle kept clear of the avatar; big watermark symbol or a placed logo | 1500 × 500 | headline, sub, handle, logo (path), symbol, font, mode (forest, dark) | `thumbs/social-banner.png` |
| 8 | `social-post` | Square announcement: brand line (+ optional Kurdish brand), 2–3 line headline, sub, CTA pill, handle | 1080 × 1080 | brand, headline, sub, cta, handle, kurdish, kfont, symbol, font (clay) | `thumbs/social-post.png` |
| 9 | `social-story` | Story / reel cover: symbol halo or placed logo, eyebrow, headline, date, place, CTA, all inside the safe zones | 1080 × 1920 | eyebrow, headline, date, place, cta, logo (path), symbol, font, mode (midnight, dark) | `thumbs/social-story.png` |

Copy limits that keep the layouts clean: headlines ≤ 40 characters (posts) / 36 (stories) / 32
(banner, poster); subs ≤ 70; CTA ≤ 22; logo names ≤ 8 letters (longer names shrink); taglines ≤ 24
uppercase characters; Kurdish lines ≤ 18 characters on the badge. Area type shrinks longer copy instead
of cutting it, and the critic reports anything that still doesn't fit.

## Template file format (for new templates)

```json
{"id": "my-template", "title": "…", "size": "…", "use": "…", "palette": "espresso", "criticKind": "auto",
 "vars": {"headline": {"default": "…", "help": "…"}},
 "recipe": {"new": {…}, "export": ["png"], "exportOptions": {…},
            "steps": [["text.create", {"text": "{{headline}}", "color": "{{ink}}"}, "title"],
                      {"when": "kurdish", "steps": [ … ]},
                      {"when": {"var": "logo", "is": ""}, "steps": [ … ]}]}}
```

- `"{{name}}"` as a whole string keeps the variable's type (numbers, CMYK objects); inside text it's
  substituted as text. Palette roles (`bg surface ink muted accent accent2 highlight onAccent`, plus
  `light_*` and `dark_*`), `symbol_d` (the chosen symbol's path data), `out_dir` and `out_name` are
  always available.
- `{"when": …}` blocks: a variable name (non-empty), `{"var", "is"}` or `{"var", "not"}`.
- Name steps (third list item) and reference them as `"$name.id"`: optional blocks change step numbers.
- Place symbols with `object.scale` + `object.move`, then `object.setBounds {x, y, reference}` to align
  their real bounds (see design guide §5).
- Run `template apply NEW out/x --critic`, look at the PNG, fix until it passes, then `template gallery`.
