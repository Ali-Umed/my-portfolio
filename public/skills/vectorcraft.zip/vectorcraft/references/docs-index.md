# storytold/vectorcraft: every markdown file in the repo

All 33 `.md` files in the repo tree (HEAD on 2026-10-12) were fetched with `gh api` and read (the long
internal ones skimmed). "Automation" says whether the file matters when driving VectorCraft with code.
Agent-directed instructions inside them (pick work from gaps.md, follow the repo's autonomous protocol,
credit contributors in `people.toml`, run `cargo xtask ci`) are for repo contributors, not for this skill.

| Path | What it covers | Automation |
|---|---|---|
| `AGENTS.md` | Contributor/agent rules: clean-room (never use Adobe software), asset policy, no panics, "everything is a command", how to run the app with `--control 7979`, port collision with sibling apps, `vectorcraft-cli perf/bench`, contributor credits | **yes**: control port, command model |
| `CLAUDE.md` | Same text as AGENTS.md minus the contributor-credits section | yes (same as above) |
| `README.md` | Product overview, status (alpha, ~88% breadth), formats, quick start, `claude mcp add vectorcraft -- vectorcraft-cli mcp [--automation-read-root …]`, downloads (CLI is a separate macOS zip) | **yes** |
| `ROADMAP.md` | Stage alpha, readiness numbers by audience/dimension, languages, upcoming work, progress log | context only |
| `ASSETS.md` | Attribution table for every bundled asset; bundled Latin fonts (Inter, Source Sans 3, Source Serif 4, JetBrains Mono) | minor: bundled fonts |
| `.github/pull_request_template.md` | PR checklist (xtask ci, no panics, clean-room, ASSETS rows) | no |
| `assets/app-icon/README.md` | App icon design, palette (#e8573f), files and how they reach each OS | no |
| `crates/affinity/README.md` | Affinity `.af/.afdesign/.afpub` reader: what imports, what becomes a warning, clean-room provenance; never writes Affinity | yes: Affinity import limits |
| `crates/pathops/README.md` | Booleans, Pathfinder ops and their key rules (which colour wins), Shape Builder, Live Paint, offset/outline | **yes**: Pathfinder semantics |
| `docs/affinity-validation.md` | Audit of `.af` test corpus (33 files), validation boundaries | minor |
| `docs/architecture.md` | Crate layers L0–L7, ~710 commands, CPU renderer, native format, agent control surfaces | yes: overview |
| `docs/contributors.md` | About-window credits (`contributors.json`, `people.toml`) | no (contributor instructions, not followed) |
| `docs/control-protocol.md` | Desktop control channel: methods, **no authentication**, 4 MiB lines, 16 connections, automation roots, dialogs (`ui.dialog.*`), file dialogs returning `cancelled`, background saves, export/PSD/TIFF/EPS/DXF options, Print, Save for Web | **yes, read in full** |
| `docs/development.md` | Web build, GPU choice, logs location, env vars (`VECTORCRAFT_NO_PREFS`, `VECTORCRAFT_CONTROL_PORT`, `RUST_LOG`; `VECTORCRAFT_CONFIG_DIR` is in control-protocol.md), fonts (craft-fonts), localisation, never-crash design, fuzzing, bidi type | **yes**: env vars, bidi/RTL behaviour |
| `docs/effects-parity.md` | Effect menu vs Illustrator: 44/50 Illustrator effects, 29/57 Photoshop effects, Revolve only in 3D | **yes**: what effects exist |
| `docs/file-format-parity.md` | Every format, `.ai` reading/writing scope and known failures, lossy-overwrite protection | **yes** |
| `docs/gaps.md` | Ranked list of shortfalls G1–G19 with issues (interaction fidelity, `.ai` files, stability, bugs, type, filters, 3D…) | **yes**: known gaps |
| `docs/hardware-parity.md` | GPU, pen, touch, displays per platform (no macOS pen pressure) | minor |
| `docs/localization-parity.md` | UI languages and catalog completeness (no Arabic/Kurdish UI; document text is fine) | minor |
| `docs/mcp.md` | MCP server: modes, roots, protocol, tools, resources, prompts, and long-tail command docs (selection, guides, styles, swatches, recolor, layers, appearance, type, exports, print, place, links, envelopes, blends, perspective, liquify…) plus the headless `run` CLI and `$N` references | **yes, read in full** |
| `docs/plugins.md` | WebAssembly plug-in ABI v1: `plugin.install/run/list`, sandbox limits, manifest, input/output JSON | yes (plug-ins) |
| `docs/releasing.md` | Release workflow, artifacts per platform (CLI zip for macOS), version bumping | minor: where the CLI comes from |
| `docs/revolve.md` | The initial 3D Revolve effect: params, dialog, limits | yes (`threeD.revolve`) |
| `docs/roadmap.md` | Milestones M0–M14, alpha gate, current focus | context only |
| `docs/shaper.md` | Shaper tool behaviour and Shaper Groups | minor (`shaper.*`) |
| `docs/target-app-parity.md` | Authoritative parity assessment by area, readiness method, calibration, long evidence list of what ships | yes: gaps per area |
| `docs/type-parity.md` | Type features checklist (done/partial/missing): RTL/bidi done, hyphenation/justification, spell check, Touch Type missing | **yes** |
| `docs/ui-parity.md` | Tool-by-tool interaction checklist (Pen, Direct Selection, snapping, shortcuts, panels) | minor (GUI behaviour) |
| `docs/windows7.md` | Experimental Windows 7 build | no |
| `packaging/macos/dmg/README.md` | DMG window artwork and generation | no |
| `packaging/web/README.md` | Hosting the WASM web build | no |
| `vendor/windows-link/VECTORCRAFT-PATCH.md` | Windows 7 import patch note | no |
| `vendor/windows-link/readme.md` | Upstream windows-link crate readme | no |

Also read (pointed to by the docs): `apps/vectorcraft-cli/tests/cli.rs` (how `run`, `--params` and
`--export` are used), the `examples/*.vectorcraft` list (art built only through the command API).
