# VectorCraft design guide

The rules a professional designer applies to logos, icons, social graphics and posters, written as numbers
and tied to VectorCraft commands. Every font named here was rendered through vectorcraft-cli 0.9.0 on this
Mac (`craft-tests/vectorcraft/design-upgrade/type-pairings.png`), every palette was contrast-checked, and
the critic (`vectorcraft.py critic FILE`) measures most rules. Each project gets its own style: pick a
pairing and a palette that fit the brief; there is no shared brand kit.

## 1. Before drawing: settle five things

1. **Medium and size**: logo master (800 × 800 pt), icon (24 px grid / 1024 px tile), social (table in §6),
   print (A4 595 × 842 pt, A3 842 × 1191 pt, plus 3 mm = 8.5 pt bleed). Set it in `file.new`.
2. **One focal point**: the thing seen first (headline, symbol or photo). Everything else is quieter.
3. **Palette** (§3) and its variant: light (default) or dark. Templates take `--palette NAME [--dark]`.
4. **Type pairing** (§2) with a Kurdish partner when the piece is bilingual.
5. **Alignment axis**: left for Latin layouts, right for Kurdish layouts, centre for badges and stories.
   One axis per composition; mixing three reads as accidental.

## 2. Typography

### Verified pairings (display / text / Kurdish)

| Mood | Display (styles) | Text | Kurdish |
|---|---|---|---|
| Modern, default | Avenir Next Heavy / Bold / Demi Bold | Avenir Next Regular / Medium | Rabar_031 (bold) + Rabar_016 (text) |
| Bold posters, sport, events | Futura Bold / Condensed ExtraBold | Seravek Regular | Speda (Bold only) |
| Fashion, beauty, luxury | Didot Bold | Avenir Next Regular | Noto Naskh Arabic UI (Bold only) |
| Refined, light, weddings | Bodoni 72 Book | Gill Sans Light | K24 Kurdish Light |
| Friendly food, cafés, kids | Superclarendon Bold | Source Sans 3 Regular | Rabar_031 |
| Industrial, tech, sport | DIN Condensed Bold | Helvetica Neue Regular | Peshang Des 2 |
| Editorial, culture, books | Iowan Old Style Bold | Charter Roman | Noto Naskh Arabic UI |
| Classic, institutions | Baskerville SemiBold | Optima Regular | UniQAIDAR_Hewal 011 |

Bundled with VectorCraft (always present): Inter (Regular, Medium, SemiBold), Source Sans 3, Source Serif 4,
JetBrains Mono. Check a family's styles with `text.fontList {"family": "…"}`: asking for a style that
doesn't exist silently substitutes (the critic reports it). Fonts with one style: Speda (Bold), Rabar_031
(style "Rabar_031"), K24 Kurdish Light (Light), Noto Naskh Arabic UI (Bold), DIN Condensed (Bold).

### Scale, leading, tracking, measure

- **Type scale**: a 1.25 ratio for social and screen work; 1.333–1.5 for posters and logos (more contrast).
  On a 1080 px canvas: 22 · 28 · 34 · 44 · 56 · 72 · 88 · 104 · 120. Use 3–4 sizes per artboard; sizes
  closer than 1.12× read as a mistake (critic: hierarchy). Headline : body ≥ 2.5 : 1.
- **Leading** (`text.setStyle {"leading": pt}`): Latin headlines 1.0–1.1 × size (104 → 112), body
  1.3–1.5 ×. Kurdish/Arabic needs more room for dots and descenders: headlines 1.35–1.4 × (124 → 172),
  text 1.6 × (40 → 66).
- **Tracking** (1/1000 em): uppercase labels +150 to +300 at ≤ 34 px (`"tracking": 250`); headlines 0 to
  −20; body 0. **Never track Kurdish/Arabic**: tracking pulls joined letters apart (tested; critic severe).
- **Measure**: 45–75 characters per line for text; area-type width ≈ size × 0.5 × characters. A headline
  breaks best at a phrase boundary ("Grown slowly, / sold fresh").
- **Minimum sizes**: screens ≥ 2% of the artboard's short side (22 px on 1080, 12 px floor); banners
  ≥ 12 px; print ≥ 7 pt (body 8–12 pt, A3 poster details ≥ 16 pt, titles ≥ 72 pt); logo taglines ≥ 2.5%
  of the logo width; icons carry no text. Kurdish runs 10–15% larger than Latin of the same role
  (Latin label 28 → Kurdish 32–34).
- **Families**: one Latin family (two at most: display + text) plus one Kurdish family. Vary weight, not
  typeface (critic: fonts).
- **Area type** (`text.create {…, "area": {"width", "height", "fit": "shrinkText", "fitMinPercent": 30}}`):
  shrinkText gives up at its 50% default and leaves text cut off without a warning, so always pass
  `fitMinPercent` 30–40 (critic: overset). `text.areaOptions {"verticalAlign": "center"|"bottom"}` centres
  a label in a pill or keeps a headline sitting on its baseline above the next block.
- **Point type**: `y` is the baseline; `justify: center` centres on x, `right` ends at x. Kurdish point
  type with `justify` auto also ends at x.

## 3. Colour

### Palettes (`templates/palettes.json`; roles: bg · surface · ink · muted · accent · accent2 · highlight · onAccent)

| Palette | Mood | Light: bg / ink / muted / accent | Dark: bg / ink / muted / accent | Contrast ink·muted·accent on bg, onAccent on accent (light / dark) |
|---|---|---|---|---|
| espresso | coffee, bakery, crafts | #f6efe4 / #24160d / #6b4b33 / #a8551f | #1f140c / #f6e7d2 / #d2b48c / #f2a33a | 15.4 · 6.9 · 4.6 · 5.3 / 14.8 · 9.2 · 8.7 · 8.7 |
| midnight | tech, apps, finance | #f4f7fb / #0b1b33 / #4a5b73 / #2459d6 | #0b1220 / #eef3ff / #9fb0cc / #5b93ff | 16.0 · 6.4 · 5.6 · 6.0 / 16.9 · 8.5 · 6.3 · 6.3 |
| forest | eco, outdoor, wellbeing | #f3f1e7 / #13261a / #4b5e4f / #2f6b3f | #0f1f15 / #eef2e3 / #a9bea6 / #86c46f | 14.1 · 6.2 · 5.6 · 6.4 / 15.0 · 8.6 · 8.3 · 8.3 |
| newroz | Kurdish culture, Newroz | #fffaf0 / #1d1712 / #5c4a38 / #c8102e | #0f2a1b / #fff7e6 / #e6d6b0 / #f7b500 | 17.1 · 8.1 · 5.7 · 5.9 / 14.4 · 10.7 · 8.5 · 8.5 |
| clay | lifestyle, ceramics, food | #f7f1ea / #2b1d16 / #6e5546 / #b4502b | #2a1a14 / #f7ebe1 / #d7b9a5 / #ee8a5f | 14.5 · 6.1 · 4.5 · 5.1 / 14.3 · 9.1 · 6.7 · 6.7 |
| ink | editorial, minimal | #ffffff / #111111 / #555555 / #d70a00 | #0e0e0e / #f5f5f2 / #a8a8a3 / #ff453a | 18.9 · 7.5 · 5.3 · 5.3 / 17.7 · 8.1 · 5.7 · 5.7 |
| lagoon | health, travel, kids | #f2fbfa / #0d2b2e / #3f6467 / #0b7a7c | #062a2c / #e9fbf9 / #9fd1cc / #2ec4b6 | 14.2 · 6.2 · 4.9 · 5.1 / 14.3 · 9.1 · 7.0 · 7.0 |
| plum | beauty, weddings, events | #fbf6f8 / #2a1230 / #6b4f6e / #7b2d6e | #1e0d22 / #fbeff5 / #cfb3cf / #e08ac2 | 16.0 · 6.6 · 8.0 · 8.6 / 16.5 · 9.7 · 7.6 · 7.6 |

All 16 variants pass AA: ink ≥ 14:1, muted ≥ 4.5:1, accent ≥ 4.5:1 on bg (usable for large text and
buttons), onAccent ≥ 5:1 on accent. `surface` is a quiet panel/decor colour (ink on surface ≥ 11:1).
`accent2` and `highlight` are decoration only: several sit under 3:1 on bg, so never set text in them.

- **60-30-10**: bg (and big quiet shapes) ≈ 60% of the area, surface/secondary ≈ 30%, accent ≈ 10% (the CTA,
  the symbol, one word). Two accents compete; keep the second (accent2/highlight) to small details.
- **WCAG**: text ≥ 4.5:1; large text (≥ 24 px, or ≥ 18.7 px bold) ≥ 3:1; meaningful graphics ≥ 3:1. The
  critic measures the real rendered pixels under each glyph, gradients and effects included.
- **Gradients**: two stops, neighbouring hues or one hue light→dark (`"angle": -60` or `-90`); a
  white→transparent "sheen" stop pair (`"opacity": 0.22 → 0`) adds polish to app tiles.
- **Dark variants**: don't invert; use the palette's dark set (lighter, less saturated accent) and raise
  muted text to ≥ 7:1, because thin light-on-dark type blooms.
- **Hue families**: ≤ 3 per piece (critic: palette flags 4 as minor, 5+ as a warning).
- **Print colour**: in a CMYK document (`file.new {"colorMode": "cmyk"}`) give CMYK values
  (`{"c":0,"m":0,"y":0,"k":100}`), not hex. Tested: hex fills convert to K-only greys (#111111 → K93,
  prints like #3c3b3c) while text keeps RGB, so a hex-built poster mixes two blacks. Small text K100; large
  black areas rich black C60 M40 Y40 K100 (≤ 300% total ink). The critic flags RGB colours in CMYK files.

## 4. Layout

- **Spacing**: multiples of 8 (4 for icons): 8 · 16 · 24 · 32 · 48 · 64 · 80 · 96 · 128.
- **Margins**: screens: critic minimum 4% of the short side, design to 7.5% (80 px on 1080, 96 on stories);
  print: critic minimum 5 mm safety from trim, design to 15 mm (≈ 42–48 pt on A3) plus 3 mm bleed on
  every background; logos: clear space ≥ the height of the symbol's largest round element (≥ 25% of the
  mark height) on every side.
- **Safe zones**: stories (1080 × 1920): nothing important in the top or bottom 250 px (13%); X header
  (1500 × 500): keep text between x 440 and 1100 and y 100–420 (the avatar covers bottom-left, crops trim
  the edges); YouTube 2560 × 1440: text inside the central 1546 × 423.
- **Grids**: 1080 posts: 4 columns, 80 px margins, 24 px gutters; A3 posters: 12 columns inside 48 pt
  margins, 746 pt measure; logos and icons: an 8-unit (or 24 px) construction grid.
- **Alignment**: align frames numerically (`object.align {"horizontal": …, "to": "artboard"}`,
  `object.setBounds {"x", "y", "reference": 0–8}`), then check the ink: large type has side bearings, so a
  104 px headline's ink starts 3–4 px right of its frame (the critic notes it; nudge with `object.move`).
  Near-misses of 1–5 pt read as mistakes; the critic finds them.
- **Optical balance**: circles and triangles must be 3–8% larger than a square to look equal; text blocks
  inside a badge sit 2–3% above the geometric centre; place symbols by their real bounds
  (`object.setBounds {"x", "y", "reference": 4}` after scaling) rather than by their drawing box.
- **Whitespace**: leave ≥ 30% of a social canvas empty; crowding is the most common amateur tell
  (critic: crowding over 40 words on a post).

## 5. Vector domain standards

- **Logo system**: deliver the master (symbol + wordmark), a horizontal lockup (`logo-lockup`), a
  symbol-only mark, mono and reversed versions (`edit.colors.toGrayscale`, the palette's dark set) and an
  SVG with outlined type (`"exportOptions": {"svg": {"outlineText": true}}`). Test the symbol at 32 px and
  16 px (`render --scale`): taglines vanish there, so small uses get the symbol alone. Keep glows and
  shadows out of the master; offer them as a variant.
- **Construction**: build marks from circles, rounded rectangles and Pathfinder (`object.pathfinder.*`);
  keep corner radii consistent (one radius per mark), and stroke weights from one scale.
- **Symbols**: `templates/symbols.json` holds ten tested marks (star, spark, sun, leaf, mountain, drop,
  heart, bolt, bean, flame) drawn in a 100 × 100 box. Place them with `object.scale {"sx": size, "sy":
  size, "origin": [0, 0]}` + `object.move {dx, dy}`: `object.setBounds` with width and height stretches
  non-square marks (tested: the mountain's sun became an oval).
- **Icons**: 24 px artboards, 2 px padding (live area 2–22), 2 px strokes with round caps and joins
  (`stroke.set {"weight": 2, "cap": "round", "join": "round"}`), 2 px corner radius, coordinates on whole
  or half pixels, one stroke weight per set (critic: strokes, icon-grid). Export SVG + 1x/2x/3x PNG with
  `document.exportForScreens`.
- **App icons**: 1024 px tile, corner radius 22.3% (228 px), art inside a 10–20% keyline (critic: keyline
  flags art within 6% of the tile edge), one symbol, no words, a soft shadow (y 14, blur 30, opacity ≤ 22%).
- **Strokes**: ≥ 0.25 pt for print, ≥ 1 px for screens (critic warns under 0.5 pt); scale with
  `"strokes": true` only when the stroke is part of the drawing.
- **Raster effects**: shadows, glows and blurs render at the document's raster-effects resolution: 72 ppi
  for screens is fine, print needs `file.new {"rasterEffectsPpi": 300}` (critic: print).

## 6. Sizes and exports

| Use | Size | Export |
|---|---|---|
| Instagram/Facebook post | 1080 × 1080, portrait 1080 × 1350 | PNG (`--png-ppi 72` = 1:1; 144 = 2x) |
| Story / reel cover | 1080 × 1920 (safe 250 top/bottom) | PNG |
| X header | 1500 × 500 | PNG |
| LinkedIn banner | 1584 × 396 | PNG |
| YouTube channel art | 2560 × 1440 (text in 1546 × 423) | PNG/JPG |
| Logo master | 800 × 800 pt, transparent | SVG (outlined type), PDF, PNG 2x |
| App icon | 1024 px | PNG 1024/512/180/120/64 + SVG |
| Poster | A3 842 × 1191 pt + 8.5 pt bleed, CMYK | PDF/X-4 (`"standard": "pdfX4", "bleed": {"useDocument": true}, "marks": {"trim": true}`) |

PDFs embed font subsets with ToUnicode maps (text stays searchable, Kurdish included); SVG writes
Kurdish/Arabic lines as outlines (export warning) because SVG direction support isn't there yet.

## 7. Common mistakes and the fix

| Mistake | Fix with |
|---|---|
| Headline cut off in an area box | `text.areaOptions {"fit": "shrinkText", "fitMinPercent": 30}` or a taller area |
| Light grey text on cream "for elegance" | the palette's `muted` (≥ 4.5:1) via `text.setStyle {"fill"}` |
| Five fonts | one family, weights for hierarchy |
| Text touching the edge / in the story's UI zones | `object.move` inward to the 7.5% margin; story text between y 250 and 1670 |
| Sizes 44, 40, 36, 34 on one artboard | snap to the scale (44 / 32) |
| Shapes almost aligned (2–3 pt off) | `select.set` both → `object.align` |
| Symbol stretched | scale + move (§5), never `setBounds` width+height on non-square art |
| Kurdish letters disconnected or boxes | a font from `references/kurdish-rtl.md`; tracking 0; no justifyAll |
| Kurdish curved on a path / warped | straight point type: type on a path draws Kurdish unshaped in 0.9.0 (the desktop app); CLI 0.10.0 shapes it |
| Envelope warp on any type | avoid: `object.envelope.makeWithWarp` distorts type badly in 0.9.0 (tested on Latin too) |
| Art crowding an app-icon tile | `object.scale {"sx": 80}` about the tile centre |
| Hex colours in a print poster | CMYK values; K100 text |
| Glowing logo master | keep effects in a variant, export the flat master |

## 8. The critic: what it measures

`vectorcraft.py critic FILE [--kind auto|logo|icon|social|story|banner|print] [--json]` (also `apply …
--critic` and `template apply … --critic`). It reads `info`, `document.inspect`, `document.node`,
`text.fonts`, `recolor.colors`, `effect.list`, renders every text object alone plus each artboard with
and without type, and scores 100 − 15 per severe − 6 per warning − 2 per minor (alignment capped at −10,
hygiene −4, hierarchy −4, palette −8, strokes −8, icon grid −4, fonts −12). **Pass = ≥ 85 and no
severe issue.** Artboard kind is inferred: ≤ 64 px icon; CMYK, mm/inch units or a paper size print;
"logo/badge/mark" in the name logo; h/w ≥ 1.7 story; w/h ≥ 2.5 banner; otherwise screen.

| Check | Measures | Threshold → severity |
|---|---|---|
| contrast | rendered glyph colour vs the pixels under and around the glyphs, 10th percentile | < 4.5:1 (3:1 large) warning; < 3:1 (2:1 large) severe; invisible severe. Skipped for objects named `~…`, `decor…`, `watermark…` |
| occlusion | text whose pixels are covered by other art | warning |
| type-size | smallest run × object scale | screen < 2% short side warning, < 60% of that severe; print < 7 pt warning, < 6 severe; icon text minor; type inside a placed/grouped logo only minor below 60% |
| overset | glyph count of outlined area type vs characters | < 80% shown → severe |
| margins | text frame past the artboard (severe); ink closer than 4% of short side (5 mm print, 1/12 icon) | warning |
| safe-zone | story text in top/bottom 13% | warning |
| collision | two texts' ink boxes overlapping | > 10% warning, > 35% severe |
| hierarchy | sizes per script closer than 1.12×; > 5 sizes | minor |
| fonts | missing family (severe), substituted style (warning), missing glyphs, > 2 Latin or > 3 total families | warning |
| kurdish | Arabic-script text: font lacking Kurdish letters (severe), tracking ≠ 0 (severe), type on a path (warning since CLI 0.10.0 shapes it), justifyAll, envelope, known flawed fonts, Arabic ك ي ة in Kurdish text, Latin-first paragraph without `direction: rightToLeft` | as listed, else warning |
| crowding | words per artboard: screen 40, story 45, banner 20, logo 12 | warning |
| alignment | near-miss (0.75 pt–0.5% of short side) between edges/centres of top-level objects, ink edges for type; frames that align but ink doesn't → note only | minor |
| palette | distinct colour clusters (ΔE < 12 merged) and hue families (chroma ≥ 18) | 4 families minor, ≥ 5 warning, > 14 colours minor |
| strokes | hairlines (< 0.25 pt print, < 0.5 pt screen); > 2 weights in an icon | warning |
| icon-grid | > 30% of icon edges off the half-pixel grid | minor |
| keyline | art within 6% of a square app tile / round badge edge | warning |
| print | RGB colours in a CMYK document; raster effects < 300 ppi in print | warning |
| hygiene | import warnings, objects off every artboard, empty text, paths with no fill and no stroke | minor |

## 9. Designer checklist (before delivering)

1. `critic` passes (≥ 85, no severe); read the notes too (optical alignment).
2. Look at the PNG yourself at 100% and at phone size; for logos also at 32 px.
3. One focal point; 3–4 type sizes; one alignment axis; ≥ 30% whitespace on social pieces.
4. Palette roles respected: text only in ink/muted/onAccent; accent ≈ 10%.
5. Kurdish: tested font, no tracking, right-aligned, Kurdish ک ی ە, leading ≥ 1.35×.
6. Exports match the medium (§6); print in CMYK with bleed and 300 ppi effects; logos as outlined SVG.
7. Objects named, type on its own layer, recipe saved (`stem.recipe.json` / `stem.template.json`).
