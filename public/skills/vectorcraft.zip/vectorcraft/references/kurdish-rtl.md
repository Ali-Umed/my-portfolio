# Kurdish (Sorani) and right-to-left type in VectorCraft 0.9.0

Tested on 2026-10-12 with vectorcraft-cli 0.9.0 on this Mac. Evidence (zoomed renders, one per font, plus
`matrix.json` with each font's missing characters): `./craft-tests/vectorcraft/kurdish/`
(`matrix-pass.png`, `matrix-caveats.png`, `matrix-fail.png`, `rtl/*.png`).

Test lines, 60 pt, right-aligned point type:
1. `سڵاو، ئەمە تاقیکردنەوەیە بۆ کوردی: ێ ۆ ڵ ڕ ە ڤ ـ ١٢٣ 123 ArtCraft` (the standard string)
2. `لا ڵا بەڵام کۆڵان گوڵ ڕێگا ڤیان ئێوە` (lam-alef, the Kurdish ڵا ligature, ێ ۆ ڵ ڕ ڤ in initial,
   medial and final positions)

Checked per font: every letter joins, the special letters ێ ۆ ڵ ڕ ە ڤ keep their marks, `لا` and `ڵا`
form the lam-alef ligature, Eastern Arabic ١٢٣ and Latin 123 + ArtCraft sit in the right bidi order, and
`text.fonts {selectionOnly}` per character lists what the font lacks (a fallback font draws it, and a
fallback letter never joins its neighbours).

## Font matrix

**Pass: recommended**

| Font | Styles | Character | Notes |
|---|---|---|---|
| Rabar_031 | one (bold) | clean modern sans | best default headline font; has Latin and digits |
| Rabar_016 | one (regular) | same family, text weight | pair with Rabar_031 |
| Speda | Bold only | strong display sans | posters, big titles |
| Peshang Des 2 | Regular | geometric | tech, sport; pairs with DIN/Helvetica |
| K24 Kurdish Light | Light | light, airy, wide | refined pieces; generous word spacing |
| RudawRegular | Regular | news sans | Latin glyphs are heavier than the Arabic |
| Unikurd Web | Regular | plain naskh-sans | long text |
| UniQAIDAR_Hewal 011 | Regular | sturdy naskh | institutions |
| Noto Naskh Arabic UI | Bold only | classic naskh | no Latin: Latin falls back (keep Latin separate) |
| Geeza Pro | Regular, Bold | Apple's Arabic | no Latin letters or ASCII digits (fallback); Kurdish perfect |
| IRANSharp, IRRoya | Regular | Persian sans / serif | full Kurdish coverage |
| Arial, Tahoma, Times New Roman, Microsoft Sans Serif | Regular (+Bold for Arial/Tahoma/Times) | system workhorses | correct, plain |

**Pass for display only** (correct shaping, decorative): Sarchia_Makka, Sarchia_Qaisy (bold display),
Sarchia_Halab, Sarchia_Iraq, Sarchia_Honrawa (hand-drawn), Nizar Nastaliq Kurdish (Nastaliq: needs
leading ≥ 1.8×, Latin falls back), UniMahan Nurhan and UniMahan Baxan (calligraphic), IRYakout (italic).

**Caveats**

| Font | Problem seen |
|---|---|
| Damascus | medial ێ loses its two dots (ڕێگا reads wrong) |
| shasenem-wefayi | Latin digits 123 are drawn as ١٢٣, so mixed numbers lie |
| Nizar Aldhabi | tatweel ـ drawn as a swash; small optical size |
| UniMahan Saria, UniMahan GamayZhian | tatweel drawn as a dot |
| UniMahan Mohammed | the Arabic comma ، looks like a colon |
| Courier New | joins correctly but monospaced: technical use only |

**Fail**

| Font | Why |
|---|---|
| Arial Unicode MS | ڵا doesn't ligate and medial ێ breaks the join |
| KFGQPC HAFS Uthmanic Script | Kurdish letters draw as dotted-circle placeholders |
| System Font (SF) | no Arabic at all: everything falls back |
| Al Bayan, Al Nile, Al Tarikh, Baghdad, Beirut, DecoType Naskh, Diwan Kufi, Diwan Thuluth, Farah, Farisi, KufiStandardGK, Mishafi, Mishafi Gold, Muna, Nadeem, Sana, Waseem | lack ڕ ڵ ۆ ێ ە (some also ک ی ڤ گ): those letters fall back and stop joining |
| Noto Nastaliq Urdu | lacks ڕ ڵ ێ |

The critic knows this matrix: a font outside the pass list that misses characters of Kurdish text is a
severe issue, and the flawed fonts above raise a warning.

## Recommended Kurdish + English pairs

| Use | Latin | Kurdish |
|---|---|---|
| Modern brands, social posts (default) | Avenir Next | Rabar_031 + Rabar_016 |
| Posters, events, sport | Futura Bold / DIN Condensed | Speda / Peshang Des 2 |
| Elegant, culture, editorial | Didot, Iowan Old Style | Noto Naskh Arabic UI |
| Light and refined | Gill Sans Light, Bodoni 72 Book | K24 Kurdish Light |
| Institutional, documents-like | Baskerville, Optima | UniQAIDAR_Hewal 011, Unikurd Web |

Set Kurdish 10–15% larger than the Latin of the same role (Latin 28 → Kurdish 32–34) so x-heights match.
Proof: `craft-tests/vectorcraft/design-upgrade/type-pairings.png`.

## Direction and alignment in this version

- Bidi is automatic: a paragraph takes the direction of its first strong letter. Kurdish point type with
  `justify` auto (default) ends at `x` and grows left; `justify: "center"` centres on x; `"right"` ends at
  x. Area type with Kurdish text right-aligns and wraps correctly.
- A Kurdish line that **starts with a Latin word** ("ArtCraft بۆ کوردی") becomes a left-to-right
  paragraph and runs off to the right of its anchor. Fix: `text.setFormat {"direction": "rightToLeft"}`
  plus `text.setStyle {"justify": "right"}` (tested: the word order then reads correctly, Latin at the
  right end). The critic warns about Latin-first Kurdish lines.
- Mixed numbers render in the right order: `٢١ی ئاداری ٢٠٢٦`, `١٢٣ 123`, `٪٥٠ — 50%` all tested.
- Mirrored punctuation (brackets) and the Arabic comma ، are handled.
- Leading: 1.35–1.4 × size for headlines, 1.6 × for text (`text.setStyle {"leading": …}`).

## Known RTL bugs in 0.9.0 and workarounds (all reproduced in `kurdish/rtl/`)

| Bug | Workaround |
|---|---|
| **Tracking** splits joined Kurdish letters apart | tracking 0 on Arabic-script text; space with size and leading |
| **justifyAll** letter-spaces the last line and breaks its joins | `justify: "right"` (no "justify, last line right" option exists yet) |
| **Type on a path** draws Kurdish unshaped, isolated and in the wrong order (0.9.0, incl. the 0.9.0 desktop app) | **fixed in CLI 0.10.0** (shaped, joined, right order on a curve; tested 2026-10-13); keep Kurdish straight for files the user edits in the 0.9.0 app |
| **Envelope warps** (`object.envelope.makeWithWarp`, `warp.*` effects) shred Kurdish and distort Latin type badly | no warps on type; draw a curved shape behind straight text instead |
| **SVG export** writes RTL lines as outlines (warning "bidirectional text is outlined…") | fine for logos; for editable SVG text deliver the PDF or the .vectorcraft |
| No kashida justification, no Middle Eastern composer | ragged right alignment |

`type.createOutlines` converts Kurdish correctly (good for logos), and PDF exports embed Kurdish font
subsets with ToUnicode maps, so the text stays searchable and copyable.

## Kurdish orthography to check

Sorani uses ک (U+06A9) not Arabic ك, ی (U+06CC) not ي, and ە (U+06D5) not ة or ه+ZWNJ. Text pasted from
Arabic keyboards often mixes them; the critic flags ك ي ة inside Kurdish text. Digits may be Eastern
Arabic (٠١٢٣٤٥٦٧٨٩) or Latin; keep one system per piece. CLI 0.10.0: `text.setFormat {"digits": "hindi"}`
(or `text.setRangeStyle` for a range) draws every digit as Eastern Arabic whatever was typed (tested);
`"default"` restores what was typed.
