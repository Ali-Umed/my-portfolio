---
name: vectorcraft
description: "Make and edit vector art with code through VectorCraft, the ArtCraft open-source Adobe Illustrator clone (vectorcraft-cli), keeping editable objects in a .vectorcraft file. Logos, badges, app icons, icon sets, posters, social posts, stories and banners; shapes, paths, Pathfinder, gradients, live effects, type incl. Kurdish/Arabic right-to-left text; recolouring an SVG; vectorizing a PNG logo; export SVG, PDF/PDF-X, AI, EPS, DXF, PNG and 1x/2x icons. Designer-grade - design guide, a critic that scores each result, tested templates (logo badge and lockup, app icon, icon set, social post/story/banner, print poster, Kurdish post). Use it whenever the user mentions VectorCraft (formerly DrawCraft), has a file open in it, or wants Illustrator-style vector work done with the ArtCraft apps (\"make a logo\", \"vectorize this\", \"recolour this SVG\"). Siblings - PhotoCraft for photos, DesignCraft for page layout, EffectCraft for animation, CADCraft for drafting, PdfCraft for existing PDFs."
---

# VectorCraft (vector art with code, made like a designer would)

VectorCraft (`ai.storyteller.vectorcraft`; CLI 0.10.0, desktop app 0.9.0) is a clean-room Rust reimplementation
of Illustrator.
Every menu item, tool and dialog is an engine **command** (id + JSON params); the CLI, MCP and the desktop
app run the same registry, so art made headless is exactly what the app would make, saved as a
`.vectorcraft` file whose objects, layers, effects and type stay editable when the user opens it.

The goal is work that looks professionally designed, not merely correct: a clear focal point, a type
scale, a palette with real contrast, margins and safe zones, and Kurdish that shapes perfectly. The
design guide holds the rules, the templates encode them, and the critic measures them.

## Engine paths (pick in this order)

1. **CLI one-shot through `scripts/vectorcraft.py`** (default): `~/.local/bin/vectorcraft-cli` runs a
   headless session per call in ~50 ms. The runner validates the recipe, runs it from the original file (or
   a new document), writes the native file, exports and a `.recipe.json`, and prints the object tree.
2. **MCP headless** (`vectorcraft-cli mcp --headless --automation-read-root DIR --automation-write-root DIR`)
   for a long interactive session. Registering it with `claude mcp add` is a persistent config change:
   only when the user asks.
3. **The live app (control mode)**, only when the user wants to watch it happen in their window. See
   "Live app" below. To just show a result, `open -a VectorCraft out/x.vectorcraft`.

## Workflow

1. **Understand the brief.** Settle medium and size, the one focal point, the copy, the language(s), the
   mood (→ palette) and where it will be used (→ export). For a user's file, inspect first:
   `python3 -I scripts/vectorcraft.py tree FILE` and `render FILE /tmp/x.png`, then Read the PNG and report
   any import warnings (`.ai`/EPS can arrive with a different layer structure).
2. **Pick a template or apply the design guide.** `scripts/vectorcraft.py template list` shows nine
   tested layouts (`references/templates.md`, previews in `templates/gallery.png`). When one fits, use it
   with the user's copy and a palette that suits the project:
   ```bash
   python3 -I scripts/vectorcraft.py template apply logo-badge OUT/nova --var name=NOVA \
       --var "tagline=COFFEE ROASTERS" --var "kurdish=قاوەی نۆڤا" --var symbol=bean --palette espresso --dark --critic
   ```
   Otherwise build from `references/design-guide.md`: a verified font pairing (§2), a palette (§3), the
   8-pt spacing scale and margins (§4), the vector standards (§5) and the size table (§6). Each project
   gets its own fitting style; there is no house brand.
3. **Build the recipe** (a JSON step list or `{"new": {...}, "steps": [...], "export": [...],
   "exportOptions": {...}}`). Ids and params: `references/vectorcraft-engine.md`, `references/cookbook.md`,
   `vectorcraft.py search WORD`, `describe ID`. Name objects (`object.setProps {name}`), put type on its own
   layer, and name steps you refer back to (`["shape.ellipse", {...}, "ring"]` → `"$ring.id"`).
4. **Validate and run from the original**:
   ```bash
   python3 -I scripts/vectorcraft.py check --recipe r.json        # unknown keys are silently ignored by the engine
   python3 -I scripts/vectorcraft.py apply [SRC] OUT/stem --recipe r.json [--new '{"width":1080,"height":1080}'] \
       [--export svg,png,pdf] [--export-options '{"svg":{"outlineText":true}}'] [--png-ppi 144] [--critic]
   ```
   It writes `stem.vectorcraft`, each export and `stem.recipe.json`. A change request means editing the
   recipe and running again from SRC, never editing an export. SRC is never overwritten.
5. **Run the critic and fix until clean**: `vectorcraft.py critic OUT/stem.vectorcraft [--kind …]` (or
   `--critic` on apply). It prints the measured text sizes and contrasts, issues with the exact command and
   param to change, and a score; aim for **≥ 85 with no severe issue**, then read its notes. Then Read the
   PNG yourself: the critic can't judge taste, balance or whether the symbol suits the brand. Check
   SVG/PDF outside VectorCraft too (`qlmanage -t -s 800 -o DIR file.svg`).
6. **Deliver**: the paths (native + exports), a preview (or `compare BEFORE AFTER out.png` for edits), the
   critic score, a short table of what was made or changed and why (step → values → design reason), and
   2–3 next ideas (a dark or mono variant, the lockup or icon size set, a print PDF, a Kurdish version).
   Mention `open -a VectorCraft stem.vectorcraft` to keep editing in the app.

## Design rules that matter most (details and numbers in the guide)

- One focal point; 3–4 type sizes from one scale (1.25 on screens); headline ≥ 2.5 × body.
- Text only in the palette's `ink`, `muted` or `onAccent` (≥ 4.5:1; large text ≥ 3:1); accent ≈ 10%.
- Margins ≥ 7.5% of the short side on screens; stories keep the top and bottom 250 px clear; print gets
  3 mm bleed, 5–15 mm safety, CMYK values (K100 text) and 300 ppi effects.
- One Latin family (two at most) plus one Kurdish family; vary weight, not typeface.
- Kurdish: a font from `references/kurdish-rtl.md` (Rabar_031/016, Speda, Peshang Des 2, K24 Kurdish Light,
  Noto Naskh Arabic UI…), 10–15% larger than the Latin, leading ≥ 1.35 ×, right-aligned, tracking 0,
  straight lines only, Kurdish ک ی ە.
- Logos: symbol + wordmark, clear space, outlined-type SVG, mono/reversed versions, readable at 32 px.
- Icons: 24 px grid, 2 px padding, one 2 px stroke weight, round caps; app tiles keep art inside the keyline.

## Gotchas

- **CLI is 0.24.1 now** (notes below were written on 0.10.0). Tested 2026-11-18: `swatch.new {name, color, global: true}`
  + `paint.setFill {swatch}` links fills and text; one `swatch.edit {name, color}` recolours every linked object
  (`run --in x.vectorcraft --cmd swatch.edit ... --export y.png`). `run --in drawing.dxf` opens a DXF with its
  layers (a CADCraft A2 sheet came in at 25,694 x 12,960 pt: export with `--scale 0.06`). Raster exports cap at 32,768 px.

- **Commands act on the selection**, and each new object becomes the selection. Paint commands also set
  the default for the next object: new art starts with a white fill and a black 1 pt stroke, so give
  `paint.setStroke {"none": true}` when you want no outline, and give `text.create` an explicit `color`.
- Coordinates are points, y down, origin at the first artboard's top-left; a new document is 612 x 792
  unless `--new` says otherwise. `text.create {x, y}` is the **baseline** anchor; `justify: center` centres
  on x. Positive rotation turns counter-clockwise.
- `object.setBounds` positions by its **centre** unless `reference` (0 top-left … 4 centre … 8
  bottom-right) says otherwise, and width + height stretch non-square art: scale symbols with
  `object.scale {"sx", "sy", "origin": [0, 0]}` + `object.move`, then align by `setBounds {x, y, reference}`.
- Area type `fit: "shrinkText"` silently gives up at its 50% default and leaves text cut off: pass
  `"fitMinPercent": 30`. The critic catches overset text.
- In a CMYK document hex fills become K-only greys while text keeps RGB: give `{"c","m","y","k"}` values.
- Envelope warps distort type badly: keep type unwarped. Type on a path drew Kurdish unshaped in 0.9.0 (still
  so in the 0.9.0 desktop app); CLI 0.10.0 shapes it correctly (tested 2026-10-13), but straight Kurdish
  stays safest if the user will edit it in the app.
- Since CLI 0.10.0: hiding or locking objects (`object.setProps`) deselects them, `object.align` needs
  `horizontal` or `vertical`, and `select.key` errors on an invalid id. Sorani digits: `text.setFormat
  {"digits": "hindi"}` draws ٠١٢٣ whatever was typed. New commands (undo groups, `file.list`, ruler
  origin…) are CLI-only until the app is updated: see the engine reference.
- Reuse results with `"$name.id"` (named steps), `"$N.id"`, `"$last.ids.0"`, `"$N.matches.0.id"`.
  Pathfinder needs its operands selected (`select.set`).
- `document.export` writes the **first artboard** unless `artboard` or `useArtboards: true`
  (`stem-<artboard>.png`). The engine doesn't create folders; the runner does.
- Raster effects render at the document's raster-effects resolution (72 ppi by default): use
  `file.new {"rasterEffectsPpi": 300}` for print.
- SVG export outlines right-to-left lines (warning); PDF keeps them as searchable embedded text.
- `.ai` export is PDF-compatible with VectorCraft's data inside: Illustrator opens it as plain art. DWG
  can't be written (use DXF). WebP is lossless only.
- Runs use `VECTORCRAFT_NO_PREFS=1`, so `prefs.set`, saved presets and libraries stay in the session. In the
  live app they persist: ask first.
- Not available yet: 3D beyond Revolve, half the Photoshop-style filters, scripting, generative AI, spell
  check, hyphenation options, optical margin alignment, Touch Type. Shape Builder can miss regions; use
  Pathfinder. Full list in the engine reference.

## Live app (control mode) — verified on VectorCraft 0.9.0

The control channel exists only when VectorCraft is **launched** with `--control PORT`; it has **no
authentication** and sibling ArtCraft apps default to the same port 7979.

1. **Ask before (re)starting the app.** If it runs (`scripts/vectorcraft_control.py status`), the user saves
   and quits it themselves, or tells you to; never quit it with unsaved work.
2. **Launch confined to one folder**: `python3 -I scripts/vectorcraft_control.py launch --root DIR [FILE]`.
   The app starts with **no document**: `document.inspect` fails ("no document open") until you run
   `exec file.new '{"width":800,"height":800}'` (or `call app.open '{"path":"/abs/x"}'`).
3. **Drive it**: `exec shape.ellipse '{…}'` (validated like the runner), `call document.inspect`,
   `call ui.render '{"path":"/abs/shot.png"}'`, `call ui.screenshot '{"path":"/abs/s.png"}'`,
   `call app.save '{"path":"/abs/x.vectorcraft"}'`, or `batch steps.json`. Always pass `path`: without it
   a native dialog opens and the call returns `"cancelled"`.
4. **Finish**: save first. `call app.quit '{"force":true}'` with unsaved changes only answers
   `{"pending":"saveChanges"}` and opens a dialog (`ui.dialog.confirm` saves). To discard a throwaway test
   session: `osascript -e 'tell application "VectorCraft" to quit saving no'`. Don't leave the port open.

## References

- `references/design-guide.md`: pairings, type scale, palettes with contrast, layout, vector standards,
  sizes, common mistakes, every critic check, the delivery checklist.
- `references/templates.md`: the nine templates, their variables and copy limits, the template format.
- `references/kurdish-rtl.md`: the tested Sorani font matrix, direction and alignment, RTL bugs and
  workarounds, Kurdish + English pairs.
- `references/vectorcraft-engine.md`: transports, step order, saving/export, ~100 command ids with params,
  all 80 live effects, what's new in 0.10.0, Image Trace, known gaps.
- `references/cookbook.md`: user wording → tested recipes. `references/docs-index.md`: the repo's docs.
- Tests and proofs: `./craft-tests/vectorcraft/` (`templates-test/`,
  `kurdish/`, `design-upgrade/`).

## Installing the CLI (only if `~/.local/bin/vectorcraft-cli` is missing)

The macOS app bundle doesn't contain it: it is the release asset
`vectorcraft-cli-<ver>-macos-universal.zip` at github.com/storytold/vectorcraft/releases. Ask before
downloading, verify it against `SHA256SUMS.txt`, unzip it into its own folder under `~/Applications/`,
check `codesign -dv`, and symlink it to `~/.local/bin/vectorcraft-cli`.

The complete, always-current command list is `references/vectorcraft-commands.md` (generated from the installed CLI; prefer it when it disagrees with hand-written references).
