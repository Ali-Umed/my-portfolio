#!/usr/bin/env python3
"""Design critic for VectorCraft files: measure a document and score it out of 100.

  critic.py FILE [--kind auto|logo|icon|social|story|banner|print|screen] [--json] [--keep DIR]

Reads the document's own structure (vectorcraft-cli info, document.inspect, document.node,
text.fonts, recolor.colors, effect.list) and two renders per artboard (with and without type) to
measure what a designer would check: text contrast (WCAG), type sizes, safe margins and story safe
zones, text collisions, near-miss alignment, type hierarchy, font count and font coverage, Kurdish /
Arabic-script shaping hazards, palette discipline, hairline strokes, icon grid, raster-effect
resolution for print and file hygiene. Every issue names the command and param that fixes it.
Score: 100 - 15 per severe - 6 per warning - 2 per minor (some checks capped). Pass = score >= 85 and
no severe issue. Every check is documented in references/design-guide.md ("The critic").
Needs Pillow and numpy; only stdlib otherwise.
"""
import argparse
import colorsys
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile

try:
    import numpy as np
    from PIL import Image
except ImportError:  # pragma: no cover
    np = Image = None

CLI = shutil.which("vectorcraft-cli") or os.path.expanduser("~/.local/bin/vectorcraft-cli")
ENV = {**os.environ, "VECTORCRAFT_NO_PREFS": "1"}

# Fonts tested with Sorani Kurdish on this Mac (references/kurdish-rtl.md, craft-tests/vectorcraft/kurdish).
KURDISH_PASS = {
    "Rabar_031", "Rabar_016", "Speda", "K24 Kurdish Light", "Peshang Des 2", "RudawRegular", "Unikurd Web",
    "UniQAIDAR_Hewal 011", "Noto Naskh Arabic UI", "Geeza Pro", "Arial", "Tahoma", "Times New Roman",
    "Microsoft Sans Serif", "IRANSharp", "IRRoya", "IRYakout", "Sarchia_Makka", "Sarchia_Qaisy",
    "Sarchia_Halab", "Sarchia_Iraq", "Sarchia_Honrawa", "Nizar Nastaliq Kurdish", "Nizar Aldhabi",
    "UniMahan Nurhan", "UniMahan Baxan", "UniMahan GamayZhian", "UniMahan Saria", "UniMahan Mohammed",
    "Courier New",
}
KURDISH_FLAWED = {
    "Damascus": "medial ێ loses its two dots",
    "Arial Unicode MS": "ڵا has no lam-alef ligature and ێ doesn't join",
    "shasenem-wefayi": "Latin digits 123 are drawn as Eastern Arabic ١٢٣",
    "KFGQPC HAFS Uthmanic Script": "Kurdish letters draw as dotted-circle placeholders",
}
ARABIC_RE = re.compile(r"[؀-ۿݐ-ݿﭐ-﷿ﹰ-﻿]")
KURDISH_RE = re.compile(r"[ڕڵۆێەڤ]")
ARABIC_ONLY_LETTERS = {"ك": ("ك", "ک (U+06A9)"), "ي": ("ي", "ی (U+06CC)"), "ة": ("ة", "ە (U+06D5)")}
ART_RE = re.compile(r"logo|badge|emblem|lockup|mark|symbol|\.(vectorcraft|svg|ai|pdf|eps)$", re.I)
LATIN_RE = re.compile(r"[A-Za-zÀ-ɏ]")
BOLD_RE = re.compile(r"bold|heavy|black|semi|demi|extra|ultra", re.I)
RASTER_EFFECTS = ("stylize.dropShadow", "stylize.innerGlow", "stylize.outerGlow", "stylize.feather", "blur.")
PAPER = [(595.3, 841.9), (841.9, 1190.6), (1190.6, 1683.8), (419.5, 595.3), (612, 792), (612, 1008), (792, 1224)]

SEVERITY_COST = {"severe": 15, "warning": 6, "minor": 2}
CAPS = {"alignment": 10, "hygiene": 4, "hierarchy": 4, "palette": 8, "strokes": 8, "icon-grid": 4, "fonts": 12}


# ------------------------------------------------------------------ engine access

def _run(args):
    p = subprocess.run([CLI, *args], capture_output=True, text=True, env=ENV)
    return p


def run_steps(path, steps):
    args = ["run", "--in", path]
    for c, p in steps:
        args += ["--cmd", c]
        if p:
            args += ["--params", json.dumps(p, ensure_ascii=False)]
    p = _run(args)
    out = []
    for line in p.stdout.splitlines():
        line = line.strip()
        if line.startswith("{"):
            try:
                o = json.loads(line)
            except json.JSONDecodeError:
                continue
            if o.get("step") == "cmd":
                out.append(o.get("result"))
    if p.returncode != 0:
        raise RuntimeError((p.stderr or p.stdout).strip()[:500])
    return out


# ------------------------------------------------------------------ colour maths

def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def lin(c):
    c = np.asarray(c, dtype=float)
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def luminance(rgb):
    r = lin(rgb)
    return 0.2126 * r[..., 0] + 0.7152 * r[..., 1] + 0.0722 * r[..., 2]


def contrast(l1, l2):
    hi, lo = np.maximum(l1, l2), np.minimum(l1, l2)
    return (hi + 0.05) / (lo + 0.05)


def to_lab(rgb):
    r = lin(np.asarray(rgb, dtype=float))
    m = np.array([[0.4124, 0.3576, 0.1805], [0.2126, 0.7152, 0.0722], [0.0193, 0.1192, 0.9505]])
    xyz = m @ r / np.array([0.95047, 1.0, 1.08883])
    f = np.where(xyz > 0.008856, np.cbrt(xyz), 7.787 * xyz + 16 / 116)
    return np.array([116 * f[1] - 16, 500 * (f[0] - f[1]), 200 * (f[1] - f[2])])


def hexs(rgb):
    return "#" + "".join(f"{int(round(max(0, min(1, v)) * 255)):02x}" for v in rgb)


# ------------------------------------------------------------------ document model

def walk(node, out, layer, parents, hidden=False):
    vis = node.get("visible", True) and not hidden
    kind = node.get("kind")
    rec = {"id": node.get("id"), "kind": kind, "name": node.get("name") or "", "bounds": node.get("bounds"),
           "fill": node.get("fill"), "stroke": node.get("stroke"), "strokeWidth": node.get("strokeWidth") or 0,
           "visible": vis, "text": node.get("text"), "layer": layer, "parents": list(parents),
           "children": [c.get("id") for c in node.get("children") or []], "opacity": node.get("opacity")}
    out.append(rec)
    if kind == "Layer":
        layer = node.get("id")
    for c in node.get("children") or []:
        walk(c, out, layer, parents + [(node.get("id"), kind)], hidden=not vis)


def rect(b):
    return (b["x"], b["y"], b["x"] + b["width"], b["y"] + b["height"]) if b else None


def overlap(a, b):
    w = min(a[2], b[2]) - max(a[0], b[0])
    h = min(a[3], b[3]) - max(a[1], b[1])
    return max(0.0, w) * max(0.0, h)


def classify(ab, info, kind_hint, title):
    w, h = ab["width"], ab["height"]
    if kind_hint != "auto":
        return kind_hint
    units = str(info.get("info", {}).get("units", ""))
    cmode = str(info.get("info", {}).get("colorMode", "")).lower()
    name = f"{ab.get('name', '')} {title}".lower()
    if max(w, h) <= 64:
        return "icon"
    if cmode == "cmyk" or units in ("Millimeters", "Centimeters", "Inches", "Picas") or \
            any(abs(w - a) < 3 and abs(h - b) < 3 or abs(w - b) < 3 and abs(h - a) < 3 for a, b in PAPER):
        return "print"
    if re.search(r"logo|badge|emblem|mark|lockup", name):
        return "logo"
    if h / w >= 1.7:
        return "story"
    if w / h >= 2.5:
        return "banner"
    return "screen"


# ------------------------------------------------------------------ the critic

class Report:
    def __init__(self):
        self.issues = []
        self.notes = []

    def add(self, sev, check, msg, fix, where=None):
        self.issues.append({"severity": sev, "check": check, "message": msg, "fix": fix, "where": where})

    def score(self):
        cost, spent = 0, {}
        for i in self.issues:
            c = SEVERITY_COST[i["severity"]]
            cap = CAPS.get(i["check"])
            if cap is not None and i["severity"] != "severe":
                room = cap - spent.get(i["check"], 0)
                c = max(0, min(c, room))
                spent[i["check"]] = spent.get(i["check"], 0) + c
            cost += c
        return max(0, 100 - cost)


def label(t):
    s = (t.get("text") or t.get("name") or "").replace("\n", " ")
    return f"'{s[:28]}{'…' if len(s) > 28 else ''}' (id {t['id']})"


def critique(path, kind="auto", keep=None):
    if np is None:
        raise SystemExit("critic needs numpy and Pillow")
    rep = Report()
    info = json.loads(_run(["info", path]).stdout or "{}")
    title = str(info.get("info", {}).get("title") or os.path.basename(path))
    r = run_steps(path, [("document.inspect", {"depth": 64, "childLimit": 100000}),
                         ("document.rasterEffectsSettings", {}), ("select.all", {}), ("recolor.colors", {}),
                         ("effect.list", {})])
    doc, rset, _, colors, efl = r
    boards = doc.get("artboards") or []
    nodes = []
    for layer in doc.get("layers", []):
        walk(layer, nodes, layer.get("id"), [])
    byid = {n["id"]: n for n in nodes}
    types = [n for n in nodes if n["kind"] == "Type" and n["visible"]]
    for w in info.get("warnings") or []:
        rep.add("minor", "hygiene", f"import warning: {w}", "open the source, check what was lost, rebuild that part")

    # which artboard does an object belong to
    abr = [(b["x"], b["y"], b["x"] + b["width"], b["y"] + b["height"]) for b in boards]

    def board_of(n):
        rr = rect(n["bounds"])
        if not rr:
            return None
        rr = (rr[0] - 0.5, rr[1] - 0.5, rr[2] + 0.5, rr[3] + 0.5)  # lines have zero width or height
        best = max(range(len(abr)), key=lambda i: overlap(rr, abr[i])) if abr else None
        return best if best is not None and overlap(rr, abr[best]) > 0 else None

    for n in nodes:
        n["board"] = board_of(n)
    kinds = [classify(b, info, kind, title) for b in boards]

    # per-type details: node, fonts
    steps = []
    for t in types:
        steps += [("document.node", {"id": t["id"]}), ("select.set", {"ids": [t["id"]]}),
                  ("text.fonts", {"selectionOnly": True})]
    res = run_steps(path, steps) if steps else []
    for i, t in enumerate(types):
        node, fonts = res[3 * i], res[3 * i + 2]
        k = (node or {}).get("kind") or {}
        runs = k.get("runs") or []
        xf = k.get("xf") or [1, 0, 0, 1, 0, 0]
        scale = math.sqrt(abs(xf[0] * xf[3] - xf[1] * xf[2])) or 1.0
        t["runs"] = runs
        tk = ((k.get("kind") or {}).get("kind")) if isinstance(k.get("kind"), dict) else k.get("kind")
        t["typeKind"] = str(tk or "").lower()  # point | area | onpath
        t["para"] = k.get("para") or {}
        t["sizes"] = [r_["style"].get("size", 0) * scale for r_ in runs if r_.get("style")]
        t["size"] = min(t["sizes"]) if t["sizes"] else 0
        t["maxsize"] = max(t["sizes"]) if t["sizes"] else 0
        t["fonts"] = fonts or []
        t["families"] = sorted({r_["style"].get("font_family") for r_ in runs if r_.get("style")})
        t["bold"] = any(BOLD_RE.search(str(r_["style"].get("font_style", ""))) for r_ in runs if r_.get("style"))
        t["tracking"] = max([abs(r_["style"].get("tracking", 0)) for r_ in runs if r_.get("style")] or [0])
        t["in_envelope"] = any(pk == "Envelope" for _, pk in t["parents"])
        # type inside a placed/grouped logo is artwork: judged as a mark, not as reading text
        t["artwork"] = any(pk == "Clip Group" or (pk == "Group" and ART_RE.search(byid.get(pid, {}).get("name", "")))
                           for pid, pk in t["parents"])

    # ---------------------------------------------------------- overset area type (text that doesn't fit is hidden)
    areas = [t for t in types if t["typeKind"] == "area" and (t.get("text") or "").strip()]
    if areas:
        osteps = []
        for t in areas:
            osteps += [("select.set", {"ids": [t["id"]]}), ("type.createOutlines", {}),
                       ("document.node", {"id": f"${len(osteps) + 1}.ids.0", "summary": True, "depth": 1})]
        try:
            ores = run_steps(path, osteps)
            for j, t in enumerate(areas):
                node = ores[3 * j + 2] or {}
                glyphs = node.get("childCount") or len(node.get("children") or [])
                chars = len(re.sub(r"\s", "", t.get("text") or ""))
                if chars and glyphs < 0.8 * chars:
                    rep.add("severe", "overset", f"area text {label(t)} shows only {glyphs} of {chars} characters: the rest is cut off",
                            f"text.areaOptions {{\"ids\": [{t['id']}], \"fit\": \"shrinkText\", \"fitMinPercent\": 30}}, a taller area (text.areaOptions height) or shorter copy", t["board"])
        except RuntimeError as e:
            rep.notes.append(f"overset check skipped: {e}")

    # ---------------------------------------------------------- renders: each text alone, full art, art without type
    tmp = keep or tempfile.mkdtemp(prefix="vc-critic-")
    os.makedirs(tmp, exist_ok=True)
    scales = []
    rsteps = []
    for i, b in enumerate(boards):
        long_side = max(b["width"], b["height"])
        s = min(2.0, 1600 / long_side)
        smallest = min([t["size"] for t in types if t.get("board") == i and t["size"] > 0] or [100])
        s = max(s, min(16.0, 22 / smallest))
        s = min(s, 4000 / long_side)
        scales.append(s)
    hide = set()
    for t in types:
        env = [pid for pid, pk in t["parents"] if pk == "Envelope"]
        t["handle"] = env[-1] if env else t["id"]
        hide.add(t["handle"])
        if t["board"] is not None:
            rsteps += [("select.set", {"ids": [t["handle"]]}),
                       ("document.export", {"path": os.path.join(tmp, f"txt_{t['id']}.png"), "artboard": t["board"],
                                            "ppi": 72 * scales[t["board"]], "selectedOnly": True, "background": "transparent"})]
    rsteps.append(("select.none", {}))
    for i, b in enumerate(boards):
        rsteps.append(("document.export", {"path": os.path.join(tmp, f"full_{i}.png"), "artboard": i,
                                           "ppi": 72 * scales[i], "background": "white"}))
    if hide:
        rsteps.append(("object.setProps", {"ids": sorted(hide), "visible": False}))
        for i, b in enumerate(boards):
            rsteps.append(("document.export", {"path": os.path.join(tmp, f"bg_{i}.png"), "artboard": i,
                                               "ppi": 72 * scales[i], "background": "white"}))
    try:
        run_steps(path, rsteps)
    except RuntimeError as e:
        rep.notes.append(f"render failed, pixel checks skipped: {e}")
    full, bg = {}, {}
    for i in range(len(boards)):
        fp, bp = os.path.join(tmp, f"full_{i}.png"), os.path.join(tmp, f"bg_{i}.png")
        if os.path.exists(fp):
            full[i] = np.asarray(Image.open(fp).convert("RGB"), dtype=float) / 255
        if os.path.exists(bp):
            bg[i] = np.asarray(Image.open(bp).convert("RGB"), dtype=float) / 255

    # ---------------------------------------------------------- text: ink box, colour, contrast, occlusion
    for t in types:
        i = t["board"]
        t["ink"] = None
        tp = os.path.join(tmp, f"txt_{t['id']}.png")
        if i is None or i not in full or i not in bg or not os.path.exists(tp):
            continue
        b, s = boards[i], scales[i]
        T = np.asarray(Image.open(tp).convert("RGBA"), dtype=float) / 255
        F, B = full[i], bg[i]
        if T.shape[:2] != F.shape[:2]:
            continue
        alpha = T[..., 3]
        mask = alpha > 0.5
        if mask.sum() < 4:
            continue
        ys, xs = np.nonzero(alpha > 0.1)
        t["ink"] = (b["x"] + xs.min() / s, b["y"] + ys.min() / s, b["x"] + (xs.max() + 1) / s, b["y"] + (ys.max() + 1) / s)
        core = alpha > 0.9
        if core.sum() < 4:
            core = mask
        # what the viewer sees where the glyphs are (catches opacity, blend modes and art on top)
        seen = np.median(F[core], axis=0)
        own = np.median(T[..., :3][core], axis=0)
        under = B[core]
        if np.abs(F[core] - T[..., :3][core]).sum(axis=1).mean() > 0.6 and \
                np.abs(F[core] - B[core]).sum(axis=1).mean() < 0.1:
            rep.add("warning", "occlusion", f"text {label(t)} doesn't show: other art covers it",
                    "object.arrange.bringToFront with the text selected, or move the covering shape", i)
            continue
        m2 = mask.copy()
        for dy, dx in ((2, 0), (-2, 0), (0, 2), (0, -2), (4, 0), (-4, 0), (0, 4), (0, -4)):
            m2 |= np.roll(np.roll(mask, dy, 0), dx, 1)
        ring = m2 & ~mask
        bpx = np.concatenate([under, B[ring]]) if ring.any() else under
        tl = float(luminance(seen))
        cr = contrast(tl, luminance(bpx))
        eff = float(np.quantile(cr, 0.10))
        med = float(np.median(cr))
        t["contrast"] = eff
        t["textColor"] = hexs(seen)
        t["bgColor"] = hexs(np.median(bpx, axis=0))
        name = (t.get("name") or "").lower()
        if name.startswith("~") or "decor" in name or "watermark" in name:
            continue
        large = t["size"] >= 24 or (t["size"] >= 18.66 and t["bold"])
        need = 3.0 if large else 4.5
        hard = 2.0 if large else 3.0
        where = f"{t['textColor']} on {t['bgColor']}"
        if eff < hard:
            rep.add("severe", "contrast", f"text {label(t)} contrast {eff:.1f}:1 ({where}; median {med:.1f}:1), needs {need}:1",
                    f"text.setStyle {{\"ids\": [{t['id']}], \"fill\": \"<darker or lighter ink>\"}} or change the shape behind it (paint.setFill)", i)
        elif eff < need:
            rep.add("warning", "contrast", f"text {label(t)} contrast {eff:.1f}:1 ({where}), needs {need}:1 for {'large' if large else 'small'} text",
                    f"text.setStyle {{\"ids\": [{t['id']}], \"fill\": …}} toward the palette's ink, or enlarge it to ≥ 24 pt (large-text rule 3:1)", i)

    # ---------------------------------------------------------- type size, margins, safe zones, collisions
    for i, b in enumerate(boards):
        k = kinds[i]
        short = min(b["width"], b["height"])
        bt = [t for t in types if t["board"] == i]
        bx0, by0, bx1, by1 = abr[i]
        for t in bt:
            sz = t["size"]
            if not sz:
                continue
            if k == "icon":
                rep.add("minor", "type-size", f"text {label(t)} in a {b['width']:.0f} px icon",
                        "icons read better without type: draw a glyph or move the word next to the icon", i)
                continue
            if t["artwork"]:
                floor = 5 if k == "print" else 0.6 * max(12.0, 0.02 * short)
                if sz < floor:
                    rep.add("minor", "type-size", f"logo text {label(t)} is only {sz:.1f} pt here: it turns to mush at this size",
                            "place a simpler logo variant (symbol or wordmark only) at small sizes, or scale the logo up", i)
            elif k == "print":
                if sz < 6:
                    rep.add("severe", "type-size", f"text {label(t)} is {sz:.1f} pt: unreadable in print (min 6, body 8–12)",
                            f"text.setStyle {{\"ids\": [{t['id']}], \"size\": 8}}", i)
                elif sz < 7:
                    rep.add("warning", "type-size", f"text {label(t)} is {sz:.1f} pt: below the 7 pt print minimum",
                            f"text.setStyle {{\"ids\": [{t['id']}], \"size\": 8}}", i)
            else:
                mn = max(12.0, 0.02 * short)
                if sz < 0.6 * mn:
                    rep.add("severe", "type-size", f"text {label(t)} is {sz:.1f} px on a {short:.0f} px artboard (min {mn:.0f})",
                            f"text.setStyle {{\"ids\": [{t['id']}], \"size\": {math.ceil(mn)}}}", i)
                elif sz < mn:
                    rep.add("warning", "type-size", f"text {label(t)} is {sz:.1f} px: under {mn:.0f} px (2% of the short side) it won't read on a phone",
                            f"text.setStyle {{\"ids\": [{t['id']}], \"size\": {math.ceil(mn)}}}", i)
            # crossing the edge (em box horizontally, generous vertically)
            x0, y0, x1, y1 = rect(t["bounds"])
            hgt = y1 - y0
            if t.get("typeKind") != "onpath" and (x0 < bx0 - 1 or x1 > bx1 + 1 or y0 < by0 - 0.3 * hgt or y1 > by1 + 0.3 * hgt):
                rep.add("severe", "margins", f"text {label(t)} runs past the artboard edge: {x0:.0f}–{x1:.0f} × {y0:.0f}–{y1:.0f} vs artboard {bx0:.0f}–{bx1:.0f} × {by0:.0f}–{by1:.0f}",
                        f"smaller size (text.setStyle size), area type with fit shrinkText, or move it (object.move)", i)
                continue
            ink = t.get("ink")
            if not ink:
                continue
            m = 14.17 if k == "print" else (short / 12 if k == "icon" else 0.04 * short)
            gaps = {"left": ink[0] - bx0, "top": ink[1] - by0, "right": bx1 - ink[2], "bottom": by1 - ink[3]}
            close = {s_: g_ for s_, g_ in gaps.items() if g_ < m}
            if close:
                side = min(close, key=close.get)
                rep.add("warning", "margins", f"text {label(t)} is {close[side]:.0f} pt from the {side} edge (safe margin {m:.0f})",
                        f"object.move {{\"ids\": [{t['id']}], …}} inward or reduce size; keep type ≥ {m:.0f} from every edge", i)
            if k == "story":
                top_z, bot_z = by0 + 0.13 * b["height"], by1 - 0.13 * b["height"]
                if ink[1] < top_z or ink[3] > bot_z:
                    rep.add("warning", "safe-zone", f"text {label(t)} sits in the story's top/bottom 13% (covered by the app's UI)",
                            f"keep type between y={top_z - by0:.0f} and y={bot_z - by0:.0f} on the artboard", i)
        # collisions (ink boxes)
        inks = [t for t in bt if t.get("ink")]
        for a_ in range(len(inks)):
            for b_ in range(a_ + 1, len(inks)):
                A, Bb = inks[a_]["ink"], inks[b_]["ink"]
                ov = overlap(A, Bb)
                small = min((A[2] - A[0]) * (A[3] - A[1]), (Bb[2] - Bb[0]) * (Bb[3] - Bb[1])) or 1
                if ov / small > 0.10:
                    sev = "severe" if ov / small > 0.35 else "warning"
                    rep.add(sev, "collision", f"text {label(inks[a_])} and {label(inks[b_])} overlap ({100 * ov / small:.0f}% of the smaller)",
                            "object.move one of them, or reduce the size / leading so the lines clear each other", i)
        # hierarchy
        # each script has its own scale (Kurdish/Arabic runs ~10–20% larger than the Latin of the same role)
        for script in (True, False):
            ss = sorted({round(t["maxsize"] * 2) / 2 for t in bt if t["maxsize"] and not t["artwork"]
                         and bool(ARABIC_RE.search(t.get("text") or "")) == script}, reverse=True)
            for a_, b_ in zip(ss, ss[1:]):
                if a_ / b_ < 1.12 and a_ - b_ >= 1:
                    rep.add("minor", "hierarchy", f"{'Kurdish/Arabic' if script else 'Latin'} type sizes {a_:g} and {b_:g} are too close to read as two levels",
                            "use one size, or step by ≥ 1.25× (e.g. 24 → 30 → 38 → 48)", i)
        sizes = sorted({round(t["maxsize"] * 2) / 2 for t in bt if t["maxsize"] and not t["artwork"]}, reverse=True)
        if len(sizes) > 5:
            rep.add("minor", "hierarchy", f"{len(sizes)} different type sizes on one artboard",
                    "limit to 3–4 sizes from one scale (design guide: type scale)", i)
        # fonts per artboard
        fams = {f for t in bt if not t["artwork"] for f in t["families"]}
        arabic_f = {f for t in bt if not t["artwork"] and ARABIC_RE.search(t.get("text") or "") for f in t["families"]}
        latin_f = fams - arabic_f
        if len(latin_f) > 2 or len(fams) > 3:
            rep.add("warning", "fonts", f"{len(fams)} font families on one artboard: {', '.join(sorted(fams))}",
                    "use one Latin family (two at most) plus one Kurdish/Arabic family; vary weight instead", i)
        # words (crowding)
        words = sum(len((t.get("text") or "").split()) for t in bt if not t["artwork"])
        limit = {"screen": 40, "story": 45, "banner": 20, "logo": 12}.get(k)
        if limit and words > limit:
            rep.add("warning", "crowding", f"{words} words on a {k} artboard (aim for ≤ {limit})",
                    "cut the copy to a headline, one supporting line and a call to action", i)

    # ---------------------------------------------------------- fonts and Kurdish / Arabic-script hazards
    for t in types:
        i = t["board"]
        txt = t.get("text") or ""
        has_ar = bool(ARABIC_RE.search(txt))
        for f in t["fonts"]:
            fam = f.get("family")
            if f.get("status") == "missing":
                rep.add("severe", "fonts", f"font '{fam}' is missing for {label(t)}: a fallback font draws it",
                        f"text.setStyle {{\"ids\": [{t['id']}], \"font\": \"<installed family>\"}} (text.fontList lists them)", i)
            elif f.get("status") == "substitute" and str(f.get("style")) not in ("Regular", "None", ""):
                rep.add("warning", "fonts", f"style '{f.get('style')}' of '{fam}' doesn't exist; '{(f.get('resolved') or {}).get('style')}' stands in",
                        f"text.setStyle {{\"ids\": [{t['id']}], \"style\": \"{(f.get('resolved') or {}).get('style')}\"}} (text.fontList {{family}} lists styles)", i)
            mg = f.get("missingGlyphs") or 0
            if mg:
                if has_ar and fam not in KURDISH_PASS:
                    rep.add("severe", "kurdish", f"font '{fam}' lacks {mg} characters of {label(t)}: Kurdish letters fall back and stop joining",
                            f"text.setStyle {{\"ids\": [{t['id']}], \"font\": \"Rabar_031\"}} (or another font from references/kurdish-rtl.md)", i)
                elif has_ar:
                    rep.add("minor", "fonts", f"'{fam}' has no Latin/digits for {mg} characters of {label(t)} (drawn by a fallback font)",
                            "keep Latin in its own text object with a Latin font, or use a Kurdish font with Latin (Rabar_031, Speda, K24 Kurdish Light)", i)
                else:
                    rep.add("warning", "fonts", f"font '{fam}' lacks {mg} characters of {label(t)} (drawn by a fallback font)",
                            f"text.setStyle {{\"ids\": [{t['id']}], \"font\": …}} with a font that covers them", i)
        if not has_ar:
            continue
        fams = t["families"]
        for fam in fams:
            if fam in KURDISH_FLAWED and KURDISH_RE.search(txt):
                rep.add("warning", "kurdish", f"'{fam}' renders Kurdish imperfectly ({KURDISH_FLAWED[fam]}) in {label(t)}",
                        f"text.setStyle {{\"ids\": [{t['id']}], \"font\": \"Rabar_031\"}}", i)
        if t["tracking"] > 0:
            rep.add("severe", "kurdish", f"tracking {t['tracking']:g} on Arabic-script text {label(t)} pulls the joined letters apart",
                    f"text.setStyle {{\"ids\": [{t['id']}], \"tracking\": 0}} (space Kurdish with size and leading, never tracking)", i)
        if str(t["para"].get("justify", "")).lower() in ("justifyall", "justify_all", "justifyalllines", "all"):
            rep.add("warning", "kurdish", f"justifyAll on Kurdish text {label(t)} letter-spaces the last line and breaks joining",
                    f"text.setStyle {{\"ids\": [{t['id']}], \"justify\": \"right\"}}", i)
        if t.get("typeKind") == "onpath":
            rep.add("warning", "kurdish", f"Kurdish/Arabic type on a path {label(t)} is drawn unshaped by the VectorCraft 0.9.0 app (CLI 0.10.0 shapes it)",
                    "check the render; use straight point type (text.create) if the file will be edited in the 0.9.0 app", i)
        if t["in_envelope"]:
            rep.add("warning", "kurdish", f"envelope warp on {label(t)} distorts the letters badly in 0.9.0",
                    "object.envelope.release, then keep the line straight", i)
        if KURDISH_RE.search(txt) or "ی" in txt or "ک" in txt:
            bad = [f"{v[0]}→{v[1]}" for k_, v in ARABIC_ONLY_LETTERS.items() if k_ in txt]
            if bad:
                rep.add("warning", "kurdish", f"Arabic letters in Kurdish text {label(t)}: {', '.join(bad)}",
                        f"text.setText {{\"ids\": [{t['id']}], \"text\": …}} with Kurdish ک ی ە", i)
        strong = re.search(r"[A-Za-z؀-ۿ]", txt)
        n_ar, n_lat = len(ARABIC_RE.findall(txt)), len(LATIN_RE.findall(txt))
        direction = str(t["para"].get("direction", "")).lower()
        if strong and LATIN_RE.match(strong.group()) and n_ar > n_lat and "right" not in direction and "rtl" not in direction:
            rep.add("warning", "kurdish", f"{label(t)} starts with a Latin word, so the paragraph runs left-to-right",
                    f"text.setFormat {{\"ids\": [{t['id']}], \"direction\": \"rightToLeft\"}}", i)

    # ---------------------------------------------------------- envelope on Latin type
    for t in types:
        if t["in_envelope"] and not ARABIC_RE.search(t.get("text") or ""):
            rep.add("minor", "type", f"envelope warp on {label(t)}: check the render, warps distort type unevenly in 0.9.0",
                    "prefer type on a path (text.createInPath mode onPath) for curved Latin lines", t["board"])

    # ---------------------------------------------------------- near-miss alignment
    for i, b in enumerate(boards):
        short = min(b["width"], b["height"])
        tol = max(1.5, 0.005 * short)
        cand = []
        for n in nodes:
            if not n["visible"] or n["board"] != i or n["kind"] in ("Layer",) or not n["bounds"]:
                continue
            if not n["parents"] or n["parents"][-1][1] != "Layer":
                continue
            rr = rect(n["bounds"])
            if rr[2] - rr[0] >= 0.9 * b["width"] and rr[3] - rr[1] >= 0.9 * b["height"]:
                continue
            if rr[0] < abr[i][0] - 0.5 or rr[2] > abr[i][2] + 0.5 or rr[1] < abr[i][1] - 0.5 or rr[3] > abr[i][3] + 0.5:
                continue
            cand.append(n)
        if len(cand) > 40:
            cand = [n for n in cand if n["kind"] in ("Type", "Group")]
        cx = b["x"] + b["width"] / 2
        lo = 0.3 if short <= 64 else max(0.75, 0.001 * short)

        def edges(n, ink=True):
            x0, y0, x1, y1 = rect(n["bounds"])
            c = (x0 + x1) / 2  # advance centre: what justify center lines up
            if ink and n["kind"] == "Type" and n.get("ink"):
                x0, x1 = n["ink"][0], n["ink"][2]  # visual (ink) edges for left/right alignment
            return x0, y0, x1, y1, c

        def pairs_of(ra, rb, both_shapes):
            ps = [("left edges", ra[0], rb[0]), ("right edges", ra[2], rb[2]), ("centres", ra[4], rb[4])]
            if both_shapes:
                ps += [("tops", ra[1], rb[1]), ("bottoms", ra[3], rb[3]), ("vertical centres", (ra[1] + ra[3]) / 2, (rb[1] + rb[3]) / 2)]
            return ps
        optical = []

        def nm(n):
            return label(n) if n["kind"] == "Type" else f"'{n['name']}' (id {n['id']})"
        found = []
        for n in cand:
            d = abs(edges(n)[4] - cx)
            if lo < d <= tol:
                found.append((d, f"{nm(n)} is {d:.1f} pt off the artboard's centre line",
                              f"select.set {{\"ids\": [{n['id']}]}} → object.align {{\"horizontal\": \"center\", \"to\": \"artboard\"}}"))
        for a_ in range(len(cand)):
            for b_ in range(a_ + 1, len(cand)):
                A, Bn = cand[a_], cand[b_]
                shapes = A["kind"] != "Type" and Bn["kind"] != "Type"
                pairs = pairs_of(edges(A), edges(Bn), shapes)
                if any(abs(p - q) <= lo for _, p, q in pairs):
                    continue  # aligned on one edge already: a deliberate relationship
                frames = pairs_of(edges(A, False), edges(Bn, False), shapes)
                same = [(w, abs(p - q)) for (w, p, q), (_, fp, fq) in zip(pairs, frames) if abs(fp - fq) <= lo and abs(p - q) <= 2 * tol]
                if same:  # frames share an edge; only the glyphs' side bearings differ (no optical margin in 0.9.0)
                    optical.append((same[0][1], f"optical: {same[0][0]} of {nm(A)} and {nm(Bn)} share a frame edge, the ink differs by {same[0][1]:.1f} pt "
                                    f"(side bearing of large type); nudge the bigger text with object.move dx ±{same[0][1]:.1f} if it shows"))
                    continue
                for what, va, vb in pairs:
                    d = abs(va - vb)
                    if lo < d <= tol:
                        found.append((d, f"{what} of {nm(A)} and {nm(Bn)} differ by {d:.1f} pt (near-miss)",
                                      f"select.set {{\"ids\": [{A['id']}, {Bn['id']}]}} → object.align {{\"horizontal\": \"left|center|right\"}} or object.move by {d:.1f}"))
                        break
        for d, msg, fix in sorted(found)[:6]:
            rep.add("minor", "alignment", msg, fix, i)
        for d, msg in sorted(optical, reverse=True)[:3]:
            rep.notes.append(msg)

    # ---------------------------------------------------------- palette
    cols = []
    for c in (colors or {}).get("colors", []):
        hx = c.get("hex")
        if isinstance(hx, str) and hx.startswith("#") and len(hx) == 7:
            cols.append((hx, c.get("count", 1)))
    labs = [(hx, to_lab(hex_rgb(hx))) for hx, _ in cols]
    clusters = []
    for hx, lab in labs:
        for cl in clusters:
            if np.linalg.norm(cl[1] - lab) < 12:
                break
        else:
            clusters.append((hx, lab))
    hues = []
    for hx, lab in clusters:
        chroma = math.hypot(lab[1], lab[2])
        if chroma < 18:
            continue
        h = math.degrees(math.atan2(lab[2], lab[1])) % 360
        if not any(min(abs(h - q), 360 - abs(h - q)) < 30 for q in hues):
            hues.append(h)
    if len(hues) >= 5:
        rep.add("warning", "palette", f"{len(hues)} separate hue families in the artwork: reads as unplanned",
                "pick a palette from references/design-guide.md (1 dominant, 1 secondary, 1 accent) and recolor.apply the rest")
    elif len(hues) == 4:
        rep.add("minor", "palette", "4 hue families: make one dominate (60-30-10) or drop one",
                "recolor.apply the least important hue to a tint of the dominant one")
    if len(clusters) > 14:
        rep.add("minor", "palette", f"{len(clusters)} distinguishable colours",
                "merge near-duplicates: recolor.reduce {colors: 6} then recolor.apply")

    # ---------------------------------------------------------- strokes, icon grid
    for i, b in enumerate(boards):
        k = kinds[i]
        objs = [n for n in nodes if n["board"] == i and n["visible"] and n["kind"] not in ("Layer", "Type", "Group")]
        stroked = [n for n in objs if n["stroke"] not in (None, "None", "") and n["strokeWidth"] > 0]
        hair = [n for n in stroked if n["strokeWidth"] < (0.25 if k == "print" else 0.5)]
        if hair:
            rep.add("warning", "strokes", f"{len(hair)} hairline stroke(s) under {0.25 if k == 'print' else 0.5} pt (e.g. '{hair[0]['name']}' id {hair[0]['id']}): they vanish when printed or scaled down",
                    f"stroke.set {{\"ids\": [{hair[0]['id']}], \"weight\": {0.5 if k == 'print' else 1}}}", i)
        if k == "icon":
            weights = sorted({round(n["strokeWidth"], 2) for n in stroked})
            if len(weights) > 2:
                rep.add("warning", "strokes", f"icon uses {len(weights)} stroke weights {weights}: icon sets use one (2 px at 24 px)",
                        "stroke.set {\"weight\": 2} on every stroked path", i)
            off = 0
            tot = 0
            for n in objs:
                rr = rect(n["bounds"])
                for v in rr:
                    tot += 1
                    if abs(v * 2 - round(v * 2)) > 0.05:
                        off += 1
            if tot and off / tot > 0.3:
                rep.add("minor", "icon-grid", f"{off} of {tot} edges sit off the half-pixel grid: the icon renders blurry at 1x",
                        "round coordinates to whole/half pixels (object.setBounds) and keep strokes on the 24 px grid", i)
    # keyline: art on an app-icon tile or round badge must keep clear of the tile's edge
    for i, b in enumerate(boards):
        if not (0.9 <= b["width"] / b["height"] <= 1.1) or max(b["width"], b["height"]) > 1100:
            continue
        objs = [n for n in nodes if n["board"] == i and n["visible"] and n["bounds"]]
        tiles = [n for n in objs if n["kind"] in ("Rounded Rectangle", "Ellipse") and n["fill"] not in (None, "None")
                 and n["bounds"]["width"] >= 0.85 * b["width"] and n["bounds"]["height"] >= 0.85 * b["height"]]
        if not tiles:
            continue
        tile = max(tiles, key=lambda n: n["bounds"]["width"] * n["bounds"]["height"])
        tr = rect(tile["bounds"])
        size = min(tr[2] - tr[0], tr[3] - tr[1])
        worst = None
        for n in objs:
            if n is tile or n["kind"] in ("Layer", "Group", "Clip Group", "Type") or \
                    any(pk == "Compound Path" for _, pk in n["parents"]):
                continue
            rr = rect(n["bounds"])
            if (rr[2] - rr[0]) >= 0.9 * size or (n["fill"] in (None, "None") and n["kind"] in ("Ellipse", "Rounded Rectangle")):
                continue  # sheens, rings and borders that follow the tile
            gap = min(rr[0] - tr[0], rr[1] - tr[1], tr[2] - rr[2], tr[3] - rr[3])
            if worst is None or gap < worst[0]:
                worst = (gap, n)
        if worst and worst[0] < 0.06 * size:
            g_, n = worst
            rep.add("warning", "keyline", f"'{n['name']}' (id {n['id']}) comes within {max(g_, 0):.0f} px of the tile edge ({100 * max(g_, 0) / size:.1f}%; keep ≥ 8%, icons ~10–20%)",
                    f"scale the artwork down about its centre (object.scale {{\"sx\": 85, \"origin\": [{(tr[0] + tr[2]) / 2:.0f}, {(tr[1] + tr[3]) / 2:.0f}]}}) so it sits inside the keyline", i)

    # RGB colours inside a CMYK (print) document
    if str(info.get("info", {}).get("colorMode", "")).lower() == "cmyk":
        rgbs = [c.get("hex") for c in (colors or {}).get("colors", []) if str(c.get("key", "")).startswith("rgb")]
        if rgbs:
            rep.add("warning", "print", f"{len(rgbs)} RGB colour(s) in a CMYK document ({', '.join(rgbs[:4])}): they shift when separated",
                    "give CMYK values ({\"c\":0,\"m\":0,\"y\":0,\"k\":100} for text), or file.documentColorMode {\"mode\": \"cmyk\", \"convert\": true}")
    # raster effects resolution for print
    applied = (efl or {}).get("applied") or []
    has_raster = any(any(str(e.get("id") if isinstance(e, dict) else e).startswith(RASTER_EFFECTS) for e in (a.get("effects") or []))
                     for a in applied)
    res_ppi = (rset or {}).get("resolution", 72)
    if has_raster and "print" in kinds and res_ppi < 300:
        rep.add("warning", "print", f"raster effects (shadows/glows/blurs) render at {res_ppi:g} ppi in a print document",
                "document.rasterEffectsSettings {\"resolution\": 300} (or file.new {rasterEffectsPpi: 300})")

    # ---------------------------------------------------------- hygiene
    stray = [n for n in nodes if n["visible"] and n["kind"] not in ("Layer",) and n["bounds"] and n["board"] is None
             and n["parents"] and n["parents"][-1][1] == "Layer"]
    if stray:
        rep.add("minor", "hygiene", f"{len(stray)} object(s) sit outside every artboard (e.g. '{stray[0]['name']}' id {stray[0]['id']})",
                f"edit.clear {{\"ids\": [{', '.join(str(n['id']) for n in stray[:8])}]}} or move them onto an artboard")
    empty = [t for t in nodes if t["kind"] == "Type" and not (t.get("text") or "").strip()]
    if empty:
        rep.add("minor", "hygiene", f"{len(empty)} empty text object(s)", f"edit.clear {{\"ids\": [{', '.join(str(n['id']) for n in empty[:8])}]}}")
    ghosts = [n for n in nodes if n["visible"] and n["kind"] in ("Path", "Rectangle", "Ellipse", "Polygon", "Star")
              and n["fill"] in ("None", None) and n["stroke"] in ("None", None)
              and not any(pk in ("Compound Path", "Group", "Clip Group") for _, pk in n["parents"])]
    if ghosts:
        rep.add("minor", "hygiene", f"{len(ghosts)} invisible path(s) with no fill and no stroke (e.g. id {ghosts[0]['id']})",
                f"edit.clear {{\"ids\": [{', '.join(str(n['id']) for n in ghosts[:8])}]}}")

    score = rep.score()
    severe = sum(1 for x in rep.issues if x["severity"] == "severe")
    if not keep:
        shutil.rmtree(tmp, ignore_errors=True)
    return {"file": os.path.abspath(path), "score": score, "pass": score >= 85 and severe == 0,
            "artboards": [{"name": b.get("name"), "size": [b["width"], b["height"]], "kind": kinds[i]} for i, b in enumerate(boards)],
            "measured": {"text": [{"id": t["id"], "text": (t.get("text") or "")[:40], "size": round(t["size"], 1),
                                   "fonts": t["families"], "contrast": round(t["contrast"], 2) if t.get("contrast") else None,
                                   "color": t.get("textColor"), "on": t.get("bgColor")} for t in types],
                         "colours": len(clusters), "hueFamilies": len(hues),
                         "fontFamilies": sorted({f for t in types for f in t["families"]})},
            "issues": rep.issues, "notes": rep.notes}


def render_report(r):
    out = [f"critic: {r['file']}",
           "artboards: " + "; ".join(f"{a['name']} {a['size'][0]:g}x{a['size'][1]:g} ({a['kind']})" for a in r["artboards"])]
    m = r["measured"]
    out.append(f"fonts: {', '.join(m['fontFamilies']) or '-'}; colours {m['colours']} ({m['hueFamilies']} hue families)")
    for t in m["text"]:
        c = f"{t['contrast']:.1f}:1 {t['color']} on {t['on']}" if t["contrast"] else "contrast n/a"
        out.append(f"  text id {t['id']}: {t['size']:g} pt, {', '.join(t['fonts'])}, {c}  {t['text']!r}")
    order = {"severe": 0, "warning": 1, "minor": 2}
    if r["issues"]:
        out.append("issues:")
    for x in sorted(r["issues"], key=lambda x: order[x["severity"]]):
        ab = f" [artboard {x['where']}]" if isinstance(x.get("where"), int) else ""
        out.append(f"  [{x['severity']}] {x['check']}{ab}: {x['message']}\n      fix: {x['fix']}")
    for n in r["notes"]:
        out.append(f"  note: {n}")
    out.append(f"score: {r['score']}/100 — {'PASS' if r['pass'] else 'FAIL'} (pass = ≥ 85 and no severe issue)")
    return "\n".join(out)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--kind", default="auto", choices=["auto", "logo", "icon", "social", "screen", "story", "banner", "print"])
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--keep", help="keep the renders in this folder")
    a = ap.parse_args(argv)
    kind = "screen" if a.kind == "social" else a.kind
    r = critique(a.file, kind, a.keep)
    print(json.dumps(r, indent=1, ensure_ascii=False) if a.json else render_report(r))
    return r


if __name__ == "__main__":
    r = main()
    sys.exit(0 if r["pass"] else 2)
