#!/usr/bin/env python3
"""Drive the running VectorCraft desktop app over its JSON control channel (docs/control-protocol.md).

  vectorcraft_control.py status [--port 7979]
      Is VectorCraft running, is the port open, and is it really VectorCraft answering there?
  vectorcraft_control.py launch [--port 7979] [--root DIR] [FILE]
      Start the desktop app in control mode, with file access confined to DIR (read and write).
      Refuses while VectorCraft is already running: ask the user to save and quit it first.
  vectorcraft_control.py exec COMMAND [PARAMS_JSON]
      engine.execute one engine command, after validating its id and parameter keys against the
      live registry (the engine silently ignores unknown keys).
  vectorcraft_control.py call METHOD [PARAMS_JSON]
      Any control method: document.inspect, ui.inspect, app.open {path}, app.save {path},
      app.export {path, ...}, ui.render {path, artboard?, scale?}, ui.screenshot {path},
      ui.menu.invoke, ui.dialog.set/confirm/cancel, ui.pointer, ui.key, app.quit ...
  vectorcraft_control.py batch FILE.json
      Run [{"method": ..., "params": ...}, ...] in order on one connection; stops at the first error.

The channel has NO authentication (any local program can connect), so only run it while you use it and
quit control mode afterwards. Sibling ArtCraft apps use the same default port 7979: every connection
first checks that VectorCraft is the app answering. Paths must be absolute and inside the roots.

Live mode verified on VectorCraft 0.9.0 (2026-10-12, run with the user's OK):
  - `launch --root DIR` starts the app with NO document open, so `call document.inspect` fails with
    "no document open". Run `exec file.new '{"width":800,"height":800}'` (or `call app.open {path}`)
    first; after that `exec shape.ellipse ...`, `call document.inspect` and `call ui.screenshot` work.
  - Quitting with unsaved changes: `call app.quit '{"force":true}'` answers {"pending":"saveChanges"}
    and a dialog opens. Save first (`call app.save '{"path":"/abs/x.vectorcraft"}'`), then quit. Only
    for a throwaway test session whose changes should be discarded:
    osascript -e 'tell application "VectorCraft" to quit saving no'
"""
import argparse
import json
import os
import socket
import subprocess
import sys
import time

APP_BIN = "/Applications/VectorCraft.app/Contents/MacOS/VectorCraft"
HERE = os.path.dirname(os.path.abspath(__file__))


class Conn:
    def __init__(self, port, timeout=70, verify=True):
        try:
            self.s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
        except OSError:
            raise SystemExit(f"nothing listens on 127.0.0.1:{port}: VectorCraft isn't in control mode "
                             "(`launch`, after asking the user) or uses another port (--port)")
        self.f = self.s.makefile("rwb")
        self.n = 0
        if verify:
            r = self.call("engine.execute", {"command": "document.formats"})
            ids = [f.get("id") for f in ((r.get("result") or {}).get("formats") or [])] if r.get("ok") else []
            if "vectorcraft" not in ids:
                raise SystemExit(f"port {port} answers, but not as VectorCraft (another ArtCraft app?). "
                                 "Use the port VectorCraft was launched with.")

    def call(self, method, params=None):
        self.n += 1
        self.f.write((json.dumps({"id": self.n, "method": method, "params": params or {}}) + "\n").encode())
        self.f.flush()
        while True:
            line = self.f.readline()
            if not line:
                raise SystemExit("connection closed by VectorCraft (send one JSON request per line)")
            msg = json.loads(line)
            if msg.get("id") == self.n:
                return msg


def running():
    return subprocess.run(["pgrep", "-x", "VectorCraft"], capture_output=True).returncode == 0


def port_open(port):
    try:
        socket.create_connection(("127.0.0.1", port), timeout=1).close()
        return True
    except OSError:
        return False


def show(reply):
    text = json.dumps(reply, ensure_ascii=False)
    print(text if len(text) < 6000 else text[:6000] + " …(truncated)")


def cmd_status(a):
    print(f"VectorCraft running: {running()}")
    if not port_open(a.port):
        print(f"nothing listens on 127.0.0.1:{a.port} (control mode is off)")
        return
    try:
        c = Conn(a.port)
        ui = c.call("ui.inspect").get("result") or {}
        doc = c.call("document.inspect", {"depth": 0}).get("result") or {}
        print(f"VectorCraft control on 127.0.0.1:{a.port}; tool {ui.get('tool')}; "
              f"document {doc.get('title')!r} (unsaved changes: {doc.get('dirty')}); path {doc.get('path')}")
    except SystemExit as e:
        print(e)


def cmd_launch(a):
    if running():
        sys.exit("VectorCraft is already running. Ask the user to save their documents and quit it "
                 "(or let them choose), then launch again. Never quit it for them with unsaved work.")
    if port_open(a.port):
        sys.exit(f"port {a.port} is already used by another program (a sibling ArtCraft app?); pick --port 7980")
    if not os.path.exists(APP_BIN):
        sys.exit(f"{APP_BIN} not found: is VectorCraft installed in /Applications?")
    root = os.path.abspath(os.path.expanduser(a.root))
    if not os.path.isdir(root):
        sys.exit(f"root folder {root} doesn't exist (the app refuses to start with a missing root)")
    args = [APP_BIN, "--control", str(a.port), "--automation-read-root", root, "--automation-write-root", root]
    if a.file:
        args.append(os.path.abspath(a.file))
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    for _ in range(80):
        time.sleep(0.5)
        if not port_open(a.port):
            continue
        try:
            Conn(a.port)
            print(f"VectorCraft control ready on 127.0.0.1:{a.port}; files confined to {root}")
            if not a.file:
                print("no document is open yet: run `exec file.new '{\"width\":800,\"height\":800}'` "
                      "(or `call app.open '{\"path\":\"/abs/file\"}'`) before document.inspect or drawing")
            return
        except (OSError, SystemExit):
            continue
    sys.exit("VectorCraft did not answer on the control port within 40 s (check ~/Library/Application "
             "Support/VectorCraft/logs/vectorcraft.log)")


def validate(command, params):
    sys.path.insert(0, HERE)
    import vectorcraft as vc  # noqa: E402  (same folder)
    problems, warnings = vc.check([{"command": command, "params": params}])
    for w in warnings:
        print("warning: " + w, file=sys.stderr)
    if problems:
        sys.exit("refused before sending:\n  " + "\n  ".join(problems))


def cmd_exec(a):
    params = json.loads(a.params) if a.params else {}
    if not a.command.startswith("ui."):  # UI-only commands live in the app, not the CLI registry
        validate(a.command, params)
    show(Conn(a.port).call("engine.execute", {"command": a.command, "params": params}))


def cmd_call(a):
    params = json.loads(a.params) if a.params else {}
    if a.method == "engine.execute" and not str(params.get("command", "")).startswith("ui."):
        validate(params.get("command"), params.get("params") or {})
    show(Conn(a.port).call(a.method, params))


def cmd_batch(a):
    steps = json.load(open(a.file))
    for st in steps:
        p = st.get("params") or {}
        if st["method"] == "engine.execute" and not str(p.get("command", "")).startswith("ui."):
            validate(p.get("command"), p.get("params") or {})
    c = Conn(a.port)
    for st in steps:
        r = c.call(st["method"], st.get("params"))
        show(r)
        if not r.get("ok"):
            sys.exit(1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", type=int, default=int(os.environ.get("VECTORCRAFT_CONTROL_PORT", 7979)))
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    p = sub.add_parser("launch")
    p.add_argument("--root", default="~/Pictures")
    p.add_argument("file", nargs="?")
    p.set_defaults(fn=cmd_launch)
    p = sub.add_parser("exec")
    p.add_argument("command")
    p.add_argument("params", nargs="?")
    p.set_defaults(fn=cmd_exec)
    p = sub.add_parser("call")
    p.add_argument("method")
    p.add_argument("params", nargs="?")
    p.set_defaults(fn=cmd_call)
    p = sub.add_parser("batch")
    p.add_argument("file")
    p.set_defaults(fn=cmd_batch)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
