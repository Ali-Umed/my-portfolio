#!/usr/bin/env python3
"""Draw and edit vector art through VectorCraft's own engine (vectorcraft-cli), keeping real objects.

Commands
  vectorcraft.py apply [SRC] OUT_STEM (--steps JSON | --recipe FILE) [--new JSON]
                 [--export svg,png,pdf] [--export-options JSON] [--png-ppi 144]
                 [--background transparent|white|#rrggbb]
                 [--lenient] [--dry-run]
      Validates every step, then runs them in ONE headless vectorcraft-cli session, starting from
      SRC (any readable file: .vectorcraft, .svg, .pdf, .ai, .eps, .dxf, images...) or a new document
      (--new: file.new params, e.g. '{"width":800,"height":800}'). Writes OUT_STEM.vectorcraft
      (native, every object editable in VectorCraft), each export, and OUT_STEM.recipe.json, then
      prints the object tree. SRC is never overwritten.
  vectorcraft.py check (--steps JSON | --recipe FILE) [--lenient]
      Only validate command ids, parameter keys, effect ids and effect parameter keys.
  vectorcraft.py describe ID [ID ...]
      The official params doc of commands (shape.star) or live effects (stylize.dropShadow).
  vectorcraft.py search WORD [--effects]
      Command (or effect) ids, labels and menus containing WORD.
  vectorcraft.py tree FILE [--depth 4]
      Artboards, the layer/object tree (ids, kinds, bounds, paint) and import warnings of FILE.
  vectorcraft.py render FILE OUT.png [--scale 2] [--artboard 0]
      Render one artboard of any readable file to PNG (to look at it with the Read tool).
  vectorcraft.py sheet FILE OUT.png [--scale 1]
      Contact sheet of every artboard, labelled (needs Pillow; falls back to the first artboard).
  vectorcraft.py compare BEFORE AFTER OUT.png
      Side-by-side before/after of two files (any readable formats; needs Pillow).
  vectorcraft.py critic FILE [--kind auto|logo|icon|social|story|banner|print] [--json]
      Design check: measures contrast, type sizes, margins, collisions, alignment, fonts, Kurdish
      shaping hazards, palette, strokes; prints issues with fixes and a score /100 (pass >= 85, no severe).
  vectorcraft.py template list | show ID | palettes | gallery
  vectorcraft.py template apply ID OUT_STEM [--var key=value ...] [--palette NAME] [--dark] [--critic]
      Tested starting points in templates/ (logo, icon set, app icon, social, poster, Kurdish post).

Steps: [[id, params], ...] or [{"command": id, "params": {...}}, ...] or bare ids.
A recipe file is a step list or {"new": {...}, "steps": [...], "export": ["svg","png"]}.
Params may reference earlier results: "$1.id", "$last.ids.0" (step numbers count from 0 over the
steps you wrote; the runner shifts them if it inserts file.new for --new). Safer: name a step with a
third list item or "as" (["shape.ellipse", {...}, "ring"]) and reference it as "$ring.id".

Why validate: VectorCraft silently ignores parameter keys it doesn't know ({"radus": 20} "works"
and does nothing), so this script checks every key against the live registry first.
Runs use VECTORCRAFT_NO_PREFS=1 so presets, recent sizes and prefs.set never touch the user's
preferences (pass --use-prefs to drop that).
"""
import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

CLI = shutil.which("vectorcraft-cli") or os.path.expanduser("~/.local/bin/vectorcraft-cli")
EFFECT_CMDS = {"effect.apply", "appearance.addEffect"}
# Commands whose params doc points at other docs ("…the PDF options of document.exportPdf").
DOC_EXTRAS = {
    "document.export": ["document.exportPdf", "document.exportDxf", "document.exportEps", "@formats"],
    "document.save": ["@formats"],
    "file.saveAs": ["document.save", "@formats"],
    "file.saveCopy": ["document.save", "@formats"],
    "file.export": ["document.export", "document.exportPdf", "@formats"],
}
USE_PREFS = False
# Commands that write files: the runner creates the folders their path/folder params name,
# because the engine doesn't ("No such file or directory").
WRITERS = {"document.export", "document.exportPdf", "document.exportDxf", "document.exportEps",
           "document.exportForScreens", "document.exportForWeb", "document.save", "file.saveAs",
           "file.saveCopy", "file.saveAsTemplate", "file.print", "file.package", "assets.export",
           "css.export", "swatch.library.save", "graphicStyle.saveLibrary", "library.export",
           "links.unembed", "docInfo.save", "document.exportForOffice"}


def die(msg):
    sys.exit(f"vectorcraft: {msg}")


def env():
    e = dict(os.environ)
    if not USE_PREFS:
        e["VECTORCRAFT_NO_PREFS"] = "1"
    return e


def cli(*args, check=True):
    if not os.path.exists(CLI):
        die("vectorcraft-cli not found. Install vectorcraft-cli-<ver>-macos-universal.zip from "
            "https://github.com/storytold/vectorcraft/releases and put it on PATH.")
    p = subprocess.run([CLI, *args], capture_output=True, text=True, env=env())
    if check and p.returncode != 0:
        die(f"vectorcraft-cli {' '.join(args[:3])} failed:\n{(p.stderr or p.stdout).strip()}")
    return p


def lines(stdout):
    out = []
    for l in stdout.splitlines():
        l = l.strip()
        if l.startswith("{"):
            try:
                out.append(json.loads(l))
            except json.JSONDecodeError:
                pass
    return out


def query(cmd, params=None):
    """Run one query command in a fresh headless document and return its result."""
    args = ["run", "--cmd", "file.new", "--cmd", cmd]
    if params:
        args += ["--params", json.dumps(params)]
    for o in lines(cli(*args).stdout):
        if o.get("command") == cmd:
            return o.get("result")
    return None


_REG = _EFF = _FMT = None


def registry():
    global _REG
    if _REG is None:
        _REG = {c["id"]: c for c in json.loads(cli("commands").stdout)}
    return _REG


def effects():
    global _EFF
    if _EFF is None:
        _EFF = {e["id"]: e for e in (query("effect.list") or {}).get("catalog", [])}
    return _EFF


def format_option_keys():
    global _FMT
    if _FMT is None:
        _FMT = set()
        for f in (query("document.formats") or {}).get("formats", []):
            _FMT |= set((f.get("options") or {}).keys())
    return _FMT


# ---------------------------------------------------------------- params-doc parsing

def doc_keys(doc):
    """Top-level keys of a params doc like '{x, y, radius?: pt, ids?|id?, points=5, …}'.
    Returns (keys, open_ended, inherited_command)."""
    doc = (doc or "").strip()
    # "same as X …" at the start, or (0.22.0+) "{…as X, item?: …} same as X, for the stroke"
    m = re.match(r"same as ([\w.]+)", doc) or re.search(r"\{\s*…\s*as ([\w.]+)", doc) \
        or re.search(r"\bsame as ([a-z]\w*\.[\w.]*\w)", doc)
    inherit = m.group(1) if m else None
    start = doc.find("{")
    arrow = doc.find("→")
    if 0 <= arrow < start:
        start = -1
    if start < 0:
        return set(), inherit is None, inherit
    keys, open_ended = set(), False
    depth = paren = brack = 0
    key_pos = False
    quote = None
    i, n = start, len(doc)
    while i < n:
        ch = doc[i]
        if quote:
            if ch == quote:
                quote = None
            i += 1
            continue
        if ch in "\"`":
            quote = ch
        elif ch == "{":
            depth += 1
            key_pos = depth == 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                break
        elif ch == "(":
            paren += 1
        elif ch == ")":
            paren = max(0, paren - 1)
        elif ch == "[":
            brack += 1
        elif ch == "]":
            brack = max(0, brack - 1)
        elif depth == 1 and paren == 0 and brack == 0:
            if ch == "…":
                open_ended = True
                key_pos = False
            elif ch == ",":
                key_pos = True
            elif ch.isalpha() or ch == "_":
                j = i
                while j < n and (doc[j].isalnum() or doc[j] == "_"):
                    j += 1
                word, nxt = doc[i:j], doc[j:j + 1]
                if nxt in ("?", ":") or (key_pos and nxt in (",", "}", "=", "|", " ")):
                    if not (nxt == " " and not re.match(r"\s*[(,}|]", doc[j:])):
                        keys.add(word)
                key_pos = nxt == "|" and key_pos
                i = j
                continue
            elif ch == "|":
                pass
            elif not ch.isspace():
                key_pos = False
        i += 1
    if inherit and re.search(r"\{\s*…\s*as " + re.escape(inherit) + r"\s*,", doc):
        # "{…as X, item?: …}": the "…" is exactly X's keys. Not "{…as X} {own keys}": only the first brace is read.
        open_ended = False
    return keys, open_ended, inherit


def known_keys(cid, seen=None):
    reg = registry()
    seen = seen or set()
    if cid in seen or cid not in reg:
        return set(), False
    seen.add(cid)
    keys, open_ended, inherit = doc_keys(reg[cid].get("params"))
    if inherit:
        k2, o2 = known_keys(inherit, seen)
        keys |= k2
        open_ended = open_ended or o2
    extras = DOC_EXTRAS.get(cid)
    if extras:
        for x in extras:
            keys |= format_option_keys() if x == "@formats" else known_keys(x, seen)[0]
        open_ended = False
    return keys, open_ended


# ---------------------------------------------------------------- steps

def normalise(steps):
    if isinstance(steps, dict):
        steps = steps.get("steps", [])
    out = []
    for s in steps:
        if isinstance(s, str):
            out.append({"command": s, "params": {}})
        elif isinstance(s, list):
            st = {"command": s[0], "params": s[1] if len(s) > 1 and s[1] is not None else {}}
            if len(s) > 2 and isinstance(s[2], str):
                st["as"] = s[2]
            out.append(st)
        elif "steps" in s and "command" not in s:  # a block (templates expand "when" before this)
            out += normalise(s["steps"])
        else:
            st = {"command": s.get("command") or s.get("id"), "params": s.get("params") or {}}
            if s.get("as"):
                st["as"] = s["as"]
            out.append(st)
    return out


def resolve_names(steps):
    """Turn "$name.x" references into "$N.x" using the steps' "as" names (after file.new is inserted)."""
    names = {s["as"]: i for i, s in enumerate(steps) if s.get("as")}
    if not names:
        return steps

    def fix(o):
        if isinstance(o, str) and o.startswith("$") and not o.startswith("$$"):
            head, _, rest = o[1:].partition(".")
            if head in names:
                return f"${names[head]}" + (f".{rest}" if rest else "")
            if head and not head.isdigit() and head != "last":
                die(f"reference {o!r} names no step (named steps: {sorted(names)})")
            return o
        if isinstance(o, list):
            return [fix(x) for x in o]
        if isinstance(o, dict):
            return {k: fix(v) for k, v in o.items()}
        return o
    return [{"command": s["command"], "params": fix(s["params"])} for s in steps]


def similar(word, pool, k=6):
    w = word.split(".")[-1].lower()
    hits = [p for p in pool if w and w in p.lower()]
    if not hits:
        import difflib
        hits = difflib.get_close_matches(word, list(pool), n=k, cutoff=0.6)
    return hits[:k]


def check(steps, lenient=False):
    reg, problems, warnings = registry(), [], []
    for i, s in enumerate(steps):
        cid, params = s["command"], s["params"]
        if cid not in reg:
            problems.append(f"step {i}: unknown command {cid!r} (similar: {similar(cid, reg)})")
            continue
        if not isinstance(params, dict):
            problems.append(f"step {i} {cid}: params must be a JSON object")
            continue
        keys, open_ended = known_keys(cid)
        for k in params:
            if k in keys:
                continue
            msg = f"step {i} {cid}: unknown param {k!r} (known: {sorted(keys)})"
            (warnings if ((open_ended and not __import__('difflib').get_close_matches(k, sorted(keys), n=1, cutoff=0.8)) or lenient) else problems).append(msg)
        if cid in EFFECT_CMDS and "effect" in params:
            eid = params["effect"]
            eff = effects()
            if isinstance(eid, str) and eid.startswith("plugin."):
                continue
            if eid not in eff:
                problems.append(f"step {i} {cid}: unknown effect {eid!r} (similar: {similar(str(eid), eff)})")
                continue
            ekeys = set((eff[eid].get("defaults") or {}).keys()) | doc_keys(eff[eid].get("params"))[0]
            for k in (params.get("params") or {}):
                if k not in ekeys:
                    msg = f"step {i} effect {eid}: unknown effect param {k!r} (known: {sorted(ekeys)})"
                    (warnings if lenient else problems).append(msg)
    return problems, warnings


def shift_refs(obj, by):
    """$N references count steps; inserting file.new in front shifts them."""
    if isinstance(obj, str):
        return re.sub(r"^\$(\d+)", lambda m: f"${int(m.group(1)) + by}", obj) if not obj.startswith("$$") else obj
    if isinstance(obj, list):
        return [shift_refs(x, by) for x in obj]
    if isinstance(obj, dict):
        return {k: shift_refs(v, by) for k, v in obj.items()}
    return obj


def load_steps(a):
    raw = json.load(open(a.recipe)) if getattr(a, "recipe", None) else json.loads(a.steps)
    meta = raw if isinstance(raw, dict) else {}
    return normalise(raw), meta


def report_check(problems, warnings):
    for w in warnings:
        print("warning (verify the result): " + w, file=sys.stderr)
    if problems:
        die("recipe rejected before running:\n  " + "\n  ".join(problems))


# ---------------------------------------------------------------- tree / info

def fmt_bounds(b):
    if not b:
        return ""
    if isinstance(b, dict):
        return f"[{b.get('x', 0):.0f},{b.get('y', 0):.0f} {b.get('width', 0):.0f}x{b.get('height', 0):.0f}]"
    return str(b)


def tree_lines(node, depth=0, out=None):
    out = [] if out is None else out
    paint = []
    for k in ("fill", "stroke"):
        v = node.get(k)
        if v not in (None, "None", ""):
            paint.append(f"{k}={v}")
    extra = []
    if node.get("text"):
        extra.append(repr(node["text"][:40]))
    if node.get("effects"):
        extra.append("effects=" + ",".join(str(e.get("id", e) if isinstance(e, dict) else e) for e in node["effects"]))
    out.append("  " * depth + f"- {node.get('name')} ({node.get('kind')}, id {node.get('id')}) "
               f"{fmt_bounds(node.get('bounds'))} {' '.join(paint)} {' '.join(extra)}".rstrip())
    for c in node.get("children") or []:
        tree_lines(c, depth + 1, out)
    if node.get("childCount") and len(node.get("children") or []) < node["childCount"]:
        out.append("  " * (depth + 1) + f"… {node['childCount'] - len(node.get('children') or [])} more")
    return out


def inspect(path, depth=4, limit=40):
    p = cli("run", "--in", path, "--cmd", "document.inspect", "--params",
            json.dumps({"depth": depth, "childLimit": limit}))
    for o in lines(p.stdout):
        if o.get("command") == "document.inspect":
            return o["result"]
    return {}


def print_tree(path, depth=4):
    info = json.loads(cli("info", path).stdout)
    doc = inspect(path, depth)
    print(f"file: {path}")
    print("artboards: " + "; ".join(f"{a['name']} {a['rect']}" for a in info.get("artboards", [])))
    print(f"colour mode {info['info'].get('colorMode')}, units {info['info'].get('units')}, "
          f"objects by kind {info.get('kinds')}, fonts {info.get('fonts')}")
    for w in info.get("warnings") or []:
        print(f"import warning: {w}")
    for layer in doc.get("layers", []):
        print("\n".join(tree_lines(layer)))


# ---------------------------------------------------------------- commands

def cmd_apply(a):
    steps, meta = load_steps(a)
    new = json.loads(a.new) if a.new else meta.get("new")
    exports = [e.strip().lstrip(".") for e in (a.export or ",".join(meta.get("export", ["svg", "png"]))).split(",") if e.strip()]
    xopts = json.loads(a.export_options) if a.export_options else meta.get("exportOptions", {})
    src = a.src
    if src and not os.path.exists(src):
        die(f"source not found: {src}")
    stem = re.sub(r"\.(vectorcraft|drawcraft)$", "", a.out_stem)
    stem = os.path.abspath(stem)
    native = stem + ".vectorcraft"
    targets = [native] + [f"{stem}.{e}" for e in exports if e not in ("vectorcraft", "none")]
    if src and any(os.path.abspath(t) == os.path.abspath(src) for t in targets):
        die("refusing to overwrite the source file: pick another OUT_STEM")

    all_steps = list(steps)
    if not src and new is not None and not (steps and steps[0]["command"] == "file.new"):
        all_steps = [{"command": "file.new", "params": new}] + [
            {**s, "params": shift_refs(s["params"], 1)} for s in steps]
    all_steps = resolve_names(all_steps)
    tail = [{"command": "document.export", "params": {"path": native}}]
    for e in exports:
        if e in ("vectorcraft", "none"):
            continue
        p = {"path": f"{stem}.{e}"}
        if e in ("png", "jpg", "webp", "tiff", "tif"):
            p["ppi"] = a.png_ppi
            if a.background:
                p["background"] = a.background
        p.update(xopts.get(e, {}))
        tail.append({"command": "document.export", "params": p})

    problems, warnings = check(steps, a.lenient)
    for label, extra in (("--new", all_steps[:len(all_steps) - len(steps)]), ("export", tail)):
        p2, w2 = check(extra, a.lenient)
        problems += [f"{label} {x}" for x in p2]
        warnings += [f"{label} {x}" for x in w2]
    report_check(problems, warnings)
    os.makedirs(os.path.dirname(stem), exist_ok=True)
    if a.dry_run:
        print("ok (dry run): " + json.dumps(all_steps + tail, ensure_ascii=False)[:2000])
        return

    for s in all_steps + tail:
        if s["command"] in WRITERS:
            pr = s["params"]
            if isinstance(pr.get("path"), str) and not pr["path"].startswith("$"):
                os.makedirs(os.path.dirname(os.path.abspath(pr["path"])), exist_ok=True)
            if isinstance(pr.get("folder"), str) and not pr["folder"].startswith("$"):
                os.makedirs(os.path.abspath(pr["folder"]), exist_ok=True)
            if src and isinstance(pr.get("path"), str) and os.path.abspath(pr["path"]) == os.path.abspath(src):
                die(f"refusing: step {s['command']} would overwrite the source file {src}")

    args = ["run"] + (["--in", src] if src else [])
    for s in all_steps + tail:
        args += ["--cmd", s["command"]]
        if s["params"]:
            args += ["--params", json.dumps(s["params"], ensure_ascii=False)]
    p = cli(*args, check=False)
    results = lines(p.stdout)
    n_user = len(all_steps)
    for i, r in enumerate(results):
        if r.get("step") == "open":
            print("open: " + json.dumps(r.get("result"), ensure_ascii=False)[:300])
            continue
        print(f"{r.get('command')}: " + json.dumps(r.get("result"), ensure_ascii=False)[:300])
    if p.returncode != 0:
        done = sum(1 for r in results if r.get("step") == "cmd")
        failed = all_steps[done]["command"] if done < n_user else (tail[done - n_user]["command"] if done - n_user < len(tail) else "?")
        die(f"step {done} of the run ({failed}; counting from 0, file.new included when --new added it) failed: {(p.stderr or '').strip()}\nnothing was written for this recipe "
            f"(fix the step and run again from the original)")
    if p.stderr.strip():
        print(p.stderr.strip(), file=sys.stderr)
    for r in results:
        res = r.get("result") or {}
        if r.get("command") == "document.export" and isinstance(res, dict) and res.get("warnings"):
            print(f"export warnings for {res.get('path')}: {res['warnings']}", file=sys.stderr)

    with open(stem + ".recipe.json", "w") as f:
        json.dump({"source": os.path.abspath(src) if src else None, "new": new,
                   "engine": cli("--version").stdout.strip(), "steps": steps,
                   "export": exports, "outputs": targets}, f, indent=2, ensure_ascii=False)
    print()
    print_tree(native, a.depth)
    print("\nwrote: " + ", ".join(t for t in targets if os.path.exists(t)) + f", {stem}.recipe.json")
    if getattr(a, "critic", False):
        print()
        run_critic(native, getattr(a, "kind", "auto"))


# ---------------------------------------------------------------- critic

def run_critic(path, kind="auto", as_json=False):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import critic  # noqa: E402  (same folder)
    r = critic.critique(path, "screen" if kind == "social" else kind)
    print(json.dumps(r, indent=1, ensure_ascii=False) if as_json else critic.render_report(r))
    return r


def cmd_critic(a):
    if not os.path.exists(a.file):
        die(f"not found: {a.file}")
    r = run_critic(a.file, a.kind, a.json)
    sys.exit(0 if r["pass"] else 2)


# ---------------------------------------------------------------- templates

TPL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "templates")
ROLES = ("bg", "surface", "ink", "muted", "accent", "accent2", "highlight", "onAccent")
VAR_RE = re.compile(r"\{\{(\w+)\}\}")


def tpl_load(tid):
    p = os.path.join(TPL_DIR, f"{tid}.json")
    if not os.path.exists(p):
        die(f"no template {tid!r}; `vectorcraft.py template list` shows them")
    return json.load(open(p))


def palettes():
    return json.load(open(os.path.join(TPL_DIR, "palettes.json")))


def tpl_vars(t, overrides, palette=None, dark=False, out_stem=None):
    """Template defaults < palette roles < --var overrides; plus symbol path data and output paths."""
    v = {k: d.get("default") for k, d in (t.get("vars") or {}).items()}
    pal = palettes()
    pname = palette or v.get("palette") or t.get("palette")
    if pname:
        if pname not in pal:
            die(f"no palette {pname!r}; known: {', '.join(sorted(pal))}")
        mode = "dark" if (dark or str(v.get("mode", "")).lower() == "dark") else "light"
        v.update(pal[pname][mode])
        for m in ("light", "dark"):  # both variants, for templates that show a light and a dark version
            v.update({f"{m}_{k}": c for k, c in pal[pname][m].items()})
        v["palette"] = pname
    for kv in overrides or []:
        if "=" not in kv:
            die(f"--var needs key=value, got {kv!r}")
        k, val = kv.split("=", 1)
        if t.get("vars") and k not in t["vars"] and k not in ROLES and not k.startswith(("light_", "dark_")):
            die(f"template {t['id']} has no variable {k!r}; it has: {', '.join(sorted(t['vars']))}")
        try:
            v[k] = json.loads(val) if re.fullmatch(r"-?\d+(\.\d+)?|true|false", val) or val[:1] in "{[" else val
        except json.JSONDecodeError:
            v[k] = val
    syms = json.load(open(os.path.join(TPL_DIR, "symbols.json")))
    if "symbol" in v:
        if v["symbol"] not in syms:
            die(f"no symbol {v['symbol']!r}; known: {', '.join(sorted(syms))}")
        v["symbol_d"] = syms[v["symbol"]]["d"]
    if out_stem:
        v["out_dir"] = os.path.dirname(os.path.abspath(out_stem))
        v["out_name"] = os.path.basename(out_stem)
    return v


def tpl_fill(o, v):
    if isinstance(o, str):
        m = VAR_RE.fullmatch(o)
        if m and m.group(1) in v:
            return v[m.group(1)]
        return VAR_RE.sub(lambda m: str(v[m.group(1)]) if m.group(1) in v else m.group(0), o)
    if isinstance(o, list):
        return [tpl_fill(x, v) for x in o]
    if isinstance(o, dict):
        return {k: tpl_fill(x, v) for k, x in o.items()}
    return o


def tpl_steps(steps, v):
    """Expand {"when": "var" | {"var": k, "is": x} | {"var": k, "not": x}, "steps": [...]} blocks."""
    out = []
    for s in steps:
        if isinstance(s, dict) and "when" in s:
            w = s["when"]
            if isinstance(w, str):
                ok = bool(v.get(w))
            elif "is" in w:
                ok = v.get(w["var"]) == w["is"]
            else:
                ok = v.get(w["var"]) != w.get("not")
            if ok:
                out += tpl_steps(s["steps"], v)
        else:
            out.append(s)
    return out


def tpl_thumb(native, out, long_side=720):
    """First artboard, or every artboard side by side (lockups, icon sets), on a neutral backdrop."""
    from PIL import Image
    info = json.loads(cli("info", native).stdout)
    boards = info.get("artboards") or [{"rect": [0, 0, 100, 100]}]
    with tempfile.TemporaryDirectory() as tmp:
        ims = []
        for i, b in enumerate(boards[:8]):
            w, h = b["rect"][2] - b["rect"][0], b["rect"][3] - b["rect"][1]
            scale = max(0.1, min(8.0, (long_side if len(boards) == 1 else 360) / max(w, h)))
            ims.append(Image.open(render(native, os.path.join(tmp, f"{i}.png"), scale, i)).convert("RGBA"))
    gap = 24
    if len(ims) > 1:  # same width for every artboard (the CLI may round scales differently)
        tw = 160 if len(ims) > 2 and all(i.width == i.height for i in ims) else 640
        ims = [i.resize((tw, max(1, round(i.height * tw / i.width))), Image.LANCZOS) for i in ims]
    if len(ims) > 2 and all(i.width == i.height for i in ims):  # icon sets: padded tiles, 4 per row
        cols = 4
        tile = ims[0].width + 48
        rows = (len(ims) + cols - 1) // cols
        sheet = Image.new("RGB", (cols * (tile + gap) + gap, rows * (tile + gap) + gap), (226, 226, 222))
        for k, im in enumerate(ims):
            x, y = gap + (k % cols) * (tile + gap), gap + (k // cols) * (tile + gap)
            sheet.paste(Image.new("RGB", (tile, tile), (255, 255, 255)), (x, y))
            sheet.paste(im, (x + 24, y + 24), im)
    else:
        W = max(i.width for i in ims) + 2 * gap
        H = sum(i.height for i in ims) + gap * (len(ims) + 1)
        sheet = Image.new("RGB", (W, H), (226, 226, 222))
        y = gap
        for im in ims:
            sheet.paste(im, ((W - im.width) // 2, y), im)
            y += im.height + gap
    sheet.thumbnail((long_side, long_side))
    sheet.save(out)
    return out


def tpl_gallery(a):
    """Apply every template with its defaults, write templates/thumbs/<id>.png and templates/gallery.png."""
    from PIL import Image, ImageDraw, ImageFont
    out = a.out_stem or os.path.join(TPL_DIR, "thumbs")
    os.makedirs(out, exist_ok=True)
    ids = sorted(f[:-5] for f in os.listdir(TPL_DIR) if f.endswith(".json") and f not in ("palettes.json", "symbols.json"))
    work = tempfile.mkdtemp(prefix="vc-gallery-")
    thumbs = []
    for n, tid in enumerate(ids, 1):
        stem = os.path.join(work, tid, tid)
        t = tpl_load(tid)
        v = tpl_vars(t, [], None, False, stem)
        rec = tpl_fill(dict(t["recipe"]), v)
        rec["steps"] = tpl_steps(rec["steps"], v)
        os.makedirs(os.path.dirname(stem), exist_ok=True)
        rp = stem + ".template.json"
        json.dump(rec, open(rp, "w"), ensure_ascii=False)
        ns = argparse.Namespace(src=None, out_stem=stem, recipe=rp, steps=None, new=None, export="none",
                                export_options=None, png_ppi=72, background=None, depth=1, lenient=False,
                                dry_run=False, critic=False, kind="auto")
        import contextlib
        import io
        with contextlib.redirect_stdout(io.StringIO()):
            cmd_apply(ns)
        thumbs.append((n, tid, tpl_thumb(stem + ".vectorcraft", os.path.join(out, f"{tid}.png"))))
        print(f"{n}. {tid}: {thumbs[-1][2]}")
    cols, cell = 3, 420
    rows = (len(thumbs) + cols - 1) // cols
    g = Image.new("RGB", (cols * (cell + 24) + 24, rows * (cell + 64) + 24), (245, 244, 240))
    d = ImageDraw.Draw(g)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Avenir Next.ttc", 22)
    except OSError:
        font = ImageFont.load_default()
    for k, (n, tid, path) in enumerate(thumbs):
        im = Image.open(path).convert("RGB")
        im.thumbnail((cell, cell))
        x = 24 + (k % cols) * (cell + 24)
        y = 24 + (k // cols) * (cell + 64)
        d.rectangle([x - 1, y - 1, x + cell, y + cell], fill=(226, 226, 222))
        g.paste(im, (x + (cell - im.width) // 2, y + (cell - im.height) // 2))
        d.text((x, y + cell + 12), f"{n}  {tid}", fill=(30, 30, 30), font=font)
    gp = os.path.join(os.path.dirname(out), "gallery.png")
    g.save(gp)
    shutil.rmtree(work, ignore_errors=True)
    print(gp)


def cmd_template(a):
    if a.action == "list":
        for f in sorted(os.listdir(TPL_DIR)):
            if f.endswith(".json") and f not in ("palettes.json", "symbols.json"):
                t = json.load(open(os.path.join(TPL_DIR, f)))
                print(f"{t['id']:16s} {t.get('size', ''):22s} {t['title']}")
        return
    if a.action == "palettes":
        for name, p in palettes().items():
            print(f"{name:10s} {p.get('mood', '')}\n   light {p['light']}\n   dark  {p['dark']}")
        return
    if a.action == "gallery":
        return tpl_gallery(a)
    if not a.id:
        die(f"template {a.action} needs an ID")
    t = tpl_load(a.id)
    if a.action == "show":
        print(f"{t['id']}: {t['title']} ({t.get('size')})\n{t.get('use', '')}\npalette: {t.get('palette')}  "
              f"preview: templates/thumbs/{t['id']}.png\nvariables:")
        for k, d in (t.get("vars") or {}).items():
            print(f"  {k:12s} = {json.dumps(d.get('default'), ensure_ascii=False):34s} {d.get('help', '')}")
        print("palette roles (override with --var or --palette NAME [--dark]): " + " ".join(ROLES))
        return
    if a.action != "apply" or not a.out_stem:
        die("usage: template apply ID OUT_STEM [--var k=v ...] [--palette NAME] [--dark]")
    stem = re.sub(r"\.(vectorcraft|drawcraft)$", "", a.out_stem)
    v = tpl_vars(t, a.var, a.palette, a.dark, stem)
    rec = tpl_fill(dict(t["recipe"]), v)
    rec["steps"] = tpl_steps(rec["steps"], v)
    left = sorted(set(VAR_RE.findall(json.dumps(rec, ensure_ascii=False))))
    if left:
        die(f"unfilled template variables: {left}")
    os.makedirs(os.path.dirname(os.path.abspath(stem)) or ".", exist_ok=True)
    rp = os.path.abspath(stem) + ".template.json"
    with open(rp, "w") as f:
        json.dump({"template": t["id"], "vars": {k: x for k, x in v.items() if k != "symbol_d"}, **rec}, f, indent=1, ensure_ascii=False)
    ns = argparse.Namespace(src=None, out_stem=stem, recipe=rp, steps=None, new=None, export=a.export,
                            export_options=None, png_ppi=a.png_ppi, background=a.background, depth=2,
                            lenient=False, dry_run=a.dry_run, critic=a.critic, kind=t.get("criticKind", "auto"))
    cmd_apply(ns)


def cmd_check(a):
    steps, _ = load_steps(a)
    problems, warnings = check(steps, a.lenient)
    for w in warnings:
        print("warning: " + w)
    print("\n".join(problems) if problems else "ok")
    sys.exit(1 if problems else 0)


def cmd_describe(a):
    reg, eff = registry(), None
    for cid in a.ids:
        c = reg.get(cid)
        if c:
            keys, open_ended = known_keys(cid)
            print(f"{cid}  [{' > '.join(c.get('menu') or [])}] {c.get('label')}\n  {c['params']}\n"
                  f"  keys: {sorted(keys)}{' (open-ended doc)' if open_ended else ''}\n")
            continue
        eff = eff or effects()
        e = eff.get(cid)
        if e:
            print(f"effect {cid}  [{' > '.join(e.get('menu') or [])}] {e.get('label')}"
                  f"{' (raster)' if e.get('raster') else ''}\n  {e.get('params')}\n  defaults: {e.get('defaults')}\n"
                  f"  use: [\"effect.apply\", {{\"effect\": \"{cid}\", \"params\": {{...}}}}]\n")
            continue
        print(f"{cid}: not found; similar commands {similar(cid, reg)}, effects {similar(cid, effects())}\n")


def cmd_search(a):
    w = a.word.lower()
    pool = effects() if a.effects else registry()
    for cid, c in pool.items():
        hay = " ".join([cid, str(c.get("label")), " ".join(c.get("menu") or [])]).lower()
        if w in hay:
            print(f"{cid:45s} {c.get('label')}  [{' > '.join(c.get('menu') or [])}]")


def render(path, out, scale=2.0, artboard=0):
    cli("convert", path, out, "--scale", str(scale), "--artboard", str(artboard))
    return out


def cmd_render(a):
    print(render(a.file, a.out, a.scale, a.artboard))


def cmd_tree(a):
    print_tree(a.file, a.depth)


def cmd_sheet(a):
    info = json.loads(cli("info", a.file).stdout)
    boards = info.get("artboards") or [{"name": "Artboard 1"}]
    try:
        from PIL import Image, ImageDraw, ImageFont
    except ImportError:
        print("Pillow missing: rendering the first artboard only")
        print(render(a.file, a.out, a.scale, 0))
        return
    tiles = []
    with tempfile.TemporaryDirectory() as tmp:
        for i, b in enumerate(boards):
            p = render(a.file, os.path.join(tmp, f"{i}.png"), a.scale, i)
            tiles.append((b.get("name", f"Artboard {i + 1}"), Image.open(p).convert("RGBA")))
    tw = max(160, min(420, max(t.width for _, t in tiles)))
    cols = min(len(tiles), a.cols)
    rows = (len(tiles) + cols - 1) // cols
    th = max(round(tw * t.height / t.width) for _, t in tiles)
    sheet = Image.new("RGB", (cols * (tw + 16) + 16, rows * (th + 44) + 16), (236, 236, 236))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 18)
    except OSError:
        font = ImageFont.load_default()
    for i, (name, im) in enumerate(tiles):
        x, y = 16 + (i % cols) * (tw + 16), 16 + (i // cols) * (th + 44)
        h = round(tw * im.height / im.width)
        im = im.resize((tw, h), Image.LANCZOS)
        checker = Image.new("RGB", (tw, h), (255, 255, 255))
        checker.paste(im, (0, 0), im)
        sheet.paste(checker, (x, y))
        d.rectangle([x - 1, y - 1, x + tw, y + h], outline=(180, 180, 180))
        d.text((x, y + h + 8), f"{i}: {name}", fill=(40, 40, 40), font=font)
    sheet.save(a.out)
    print(a.out)


def cmd_compare(a):
    from PIL import Image, ImageDraw, ImageFont
    with tempfile.TemporaryDirectory() as tmp:
        ims = []
        for n, f in (("before", a.before), ("after", a.after)):
            p = f if f.lower().endswith(".png") else render(f, os.path.join(tmp, n + ".png"), a.scale, 0)
            im = Image.open(p).convert("RGBA")
            bg = Image.new("RGB", im.size, (255, 255, 255))
            bg.paste(im, (0, 0), im)
            ims.append((n, bg))
    h = max(i.height for _, i in ims)
    ims = [(n, i.resize((round(i.width * h / i.height), h), Image.LANCZOS)) for n, i in ims]
    W = sum(i.width for _, i in ims) + 48
    out = Image.new("RGB", (W, h + 56), (40, 40, 40))
    d = ImageDraw.Draw(out)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 22)
    except OSError:
        font = ImageFont.load_default()
    x = 16
    for n, i in ims:
        out.paste(i, (x, 16))
        d.text((x, h + 24), n, fill=(240, 240, 240), font=font)
        x += i.width + 16
    out.save(a.out)
    print(a.out)


def main():
    global USE_PREFS
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--use-prefs", action="store_true", help="let runs read/write the user's VectorCraft preferences")
    sub = ap.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("apply")
    p.add_argument("src_or_stem")
    p.add_argument("out_stem", nargs="?")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--steps")
    g.add_argument("--recipe")
    p.add_argument("--new", help="file.new params when there is no SRC")
    p.add_argument("--export", help="comma list: svg,png,pdf,jpg,eps,dxf,ai,psd,emf,... (default svg,png)")
    p.add_argument("--export-options", help='per-format document.export options, e.g. {"svg":{"outlineText":true},"pdf":{"preset":"High Quality Print"}}')
    p.add_argument("--png-ppi", type=float, default=144)
    p.add_argument("--background")
    p.add_argument("--depth", type=int, default=4)
    p.add_argument("--lenient", action="store_true", help="unknown keys warn instead of failing")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--critic", action="store_true", help="run the design critic on the result")
    p.add_argument("--kind", default="auto", help="critic artboard kind (auto|logo|icon|social|story|banner|print)")
    p.set_defaults(fn=cmd_apply)

    p = sub.add_parser("check")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--steps")
    g.add_argument("--recipe")
    p.add_argument("--lenient", action="store_true")
    p.set_defaults(fn=cmd_check)

    p = sub.add_parser("describe")
    p.add_argument("ids", nargs="+")
    p.set_defaults(fn=cmd_describe)

    p = sub.add_parser("search")
    p.add_argument("word")
    p.add_argument("--effects", action="store_true")
    p.set_defaults(fn=cmd_search)

    p = sub.add_parser("tree")
    p.add_argument("file")
    p.add_argument("--depth", type=int, default=4)
    p.set_defaults(fn=cmd_tree)

    p = sub.add_parser("render")
    p.add_argument("file")
    p.add_argument("out")
    p.add_argument("--scale", type=float, default=2)
    p.add_argument("--artboard", type=int, default=0)
    p.set_defaults(fn=cmd_render)

    p = sub.add_parser("sheet")
    p.add_argument("file")
    p.add_argument("out")
    p.add_argument("--scale", type=float, default=1)
    p.add_argument("--cols", type=int, default=4)
    p.set_defaults(fn=cmd_sheet)

    p = sub.add_parser("compare")
    p.add_argument("before")
    p.add_argument("after")
    p.add_argument("out")
    p.add_argument("--scale", type=float, default=2)
    p.set_defaults(fn=cmd_compare)

    p = sub.add_parser("critic")
    p.add_argument("file")
    p.add_argument("--kind", default="auto", choices=["auto", "logo", "icon", "social", "screen", "story", "banner", "print"])
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_critic)

    p = sub.add_parser("template")
    p.add_argument("action", choices=["list", "show", "apply", "palettes", "gallery"])
    p.add_argument("id", nargs="?")
    p.add_argument("out_stem", nargs="?")
    p.add_argument("--var", action="append", help="key=value (repeat)")
    p.add_argument("--palette")
    p.add_argument("--dark", action="store_true", help="the palette's dark variant")
    p.add_argument("--export", help="override the template's export list")
    p.add_argument("--png-ppi", type=float, default=144)
    p.add_argument("--background")
    p.add_argument("--critic", action="store_true")
    p.add_argument("--dry-run", action="store_true")
    p.set_defaults(fn=cmd_template)

    a = ap.parse_args()
    USE_PREFS = a.use_prefs
    if a.cmd == "apply":
        if a.out_stem is None:
            a.src, a.out_stem = None, a.src_or_stem
        else:
            a.src = a.src_or_stem
    a.fn(a)


if __name__ == "__main__":
    main()
