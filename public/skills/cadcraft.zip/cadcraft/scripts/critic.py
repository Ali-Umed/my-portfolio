"""CADCraft design critic: measure a drawing against drafting standards and score it.

    critic.py DRAWING.dxf [--pdf SHEET.pdf] [--scale 1:50] [--json]

Reads the DXF itself (layers, linetypes, styles, dimension styles, entities, layouts and
viewports), plus the plotted PDF when given. Prints a score out of 100 and a list of issues,
each with the fix (which command and param to change). Every check is documented in
references/design-guide.md ("What the critic checks").

Scoring: each failed check costs severe 20 / major 8 / minor 3, plus 1 per extra occurrence
(max +4). Deliver at >= 85 with no severe issue. Exit status 1 when a severe issue is found.
Only stdlib + numpy + Pillow (for --pdf).
"""
import colorsys
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile

ISO_TEXT = [1.8, 2.5, 3.5, 5.0, 7.0, 10.0, 14.0, 20.0]
ISO_LW = [0.13, 0.18, 0.25, 0.35, 0.5, 0.7, 1.0, 1.4, 2.0]
ISO_SCALES = [50, 20, 10, 5, 2, 1, 1 / 2, 1 / 5, 1 / 10, 1 / 20, 1 / 50, 1 / 100, 1 / 200, 1 / 500,
              1 / 1000, 1 / 2000, 1 / 5000, 1 / 10000]
UNIT_MM = {0: None, 1: 25.4, 2: 304.8, 4: 1.0, 5: 10.0, 6: 1000.0}
WEIGHT = {"severe": 20, "major": 8, "minor": 3}
ANNO_LAYER = re.compile(r"DIM|TEXT|ANNO|NOTE|TTLB|SHEET|SYMB|TAG|IDEN|LABL|TITL|VPRT|VPORT|DEFPOINTS"
                        r"|-SRC$", re.I)
SOFT_LAYER = re.compile(r"PATT|HATC|HTCH|FURN|CONT|EXIST|PLNT|TOPO|BGND|EQPM|GRID|FILL", re.I)
CENTER_LAYER = re.compile(r"CENT|CNTR|AXIS|(^|-)CL$", re.I)
HIDDEN_LAYER = re.compile(r"HID|HIDN", re.I)
PLACEHOLDER = re.compile(r"\{\{|\bTBD\b|\bXXX+\b|\?\?\?|<TITLE>|\bLOREM\b", re.I)


# ------------------------------------------------------------------ DXF reading
class Ent(dict):
    """One DXF object: type, ordered (code, value) list, helpers. (A dict only for the
    critic's own tags such as "space"; never test it for truth.)"""

    def __bool__(self):
        return True

    def __init__(self, etype, codes):
        super().__init__()
        self.type = etype
        self.codes = codes

    def get1(self, code, default=None, cast=str):
        for c, v in self.codes:
            if c == code:
                try:
                    return cast(v)
                except ValueError:
                    return default
        return default

    def all(self, code, cast=str):
        out = []
        for c, v in self.codes:
            if c == code:
                try:
                    out.append(cast(v))
                except ValueError:
                    pass
        return out

    def pt(self, cx, cy):
        x, y = self.get1(cx, None, float), self.get1(cy, None, float)
        return None if x is None or y is None else (x, y)

    @property
    def layer(self):
        return self.get1(8, "0")


def read_dxf(path):
    with open(path, "rb") as fh:
        head = fh.read(22)
    if head.startswith(b"AutoCAD Binary DXF") or path.lower().endswith(".dwg"):
        tmp = tempfile.mkdtemp()
        out = os.path.join(tmp, "ascii.dxf")
        cli = shutil.which("cadcraft-cli") or os.path.expanduser("~/.local/bin/cadcraft-cli")
        subprocess.run([cli, "convert", path, out], capture_output=True, check=True)
        path = out
    with open(path, encoding="utf-8", errors="replace") as fh:
        lines = fh.read().splitlines()
    pairs = []
    uni = re.compile(r"\\U\+([0-9A-Fa-f]{4})")
    for i in range(0, len(lines) - 1, 2):
        try:
            code, val = int(lines[i].strip()), lines[i + 1].strip()
        except ValueError:
            continue
        if "\\U+" in val:          # DXF escapes non-ASCII text as \U+XXXX
            val = uni.sub(lambda m: chr(int(m.group(1), 16)), val)
        pairs.append((code, val))
    d = {"header": {}, "layers": {}, "ltypes": {}, "styles": {}, "dimstyles": {}, "blocks": {},
         "block_records": {}, "entities": [], "layouts": []}
    i, sec, n = 0, None, len(pairs)
    cur_block = None
    while i < n:
        c, v = pairs[i]
        if c == 0 and v == "SECTION":
            sec = pairs[i + 1][1]
            i += 2
            continue
        if c == 0 and v == "ENDSEC":
            sec = None
            i += 1
            continue
        if sec == "HEADER" and c == 9:
            name, j, vals = v, i + 1, []
            while j < n and pairs[j][0] not in (9, 0):
                vals.append(pairs[j])
                j += 1
            d["header"][name] = vals
            i = j
            continue
        if c == 0:
            j, codes = i + 1, []
            while j < n and pairs[j][0] != 0:
                codes.append(pairs[j])
                j += 1
            e = Ent(v, codes)
            if sec == "TABLES":
                key = {"LAYER": "layers", "LTYPE": "ltypes", "STYLE": "styles",
                       "DIMSTYLE": "dimstyles", "BLOCK_RECORD": "block_records"}.get(v)
                if key:
                    nm = e.get1(2, "")
                    d[key][nm if key != "block_records" else e.get1(5, "")] = e
            elif sec == "BLOCKS":
                if v == "BLOCK":
                    cur_block = e.get1(2, "")
                    d["blocks"][cur_block] = {"base": e.pt(10, 20) or (0, 0), "ents": []}
                elif v == "ENDBLK":
                    cur_block = None
                elif cur_block is not None:
                    d["blocks"][cur_block]["ents"].append(e)
            elif sec == "ENTITIES":
                d["entities"].append(e)
            elif sec == "OBJECTS" and v == "LAYOUT":
                d["layouts"].append(e)
            i = j
            continue
        i += 1
    return d


def hdr(d, name, default=None, cast=float):
    vals = d["header"].get(name)
    if not vals:
        return default
    try:
        return cast(vals[0][1])
    except ValueError:
        return default


# ------------------------------------------------------------------ colours
def aci_rgb(i):
    if i in (7, 0, 256, 257) or i is None:
        return (0, 0, 0)          # colour 7 plots black on white paper
    base = {1: (255, 0, 0), 2: (255, 255, 0), 3: (0, 255, 0), 4: (0, 255, 255), 5: (0, 0, 255),
            6: (255, 0, 255), 8: (128, 128, 128), 9: (192, 192, 192)}
    if i in base:
        return base[i]
    if 250 <= i <= 255:
        g = round(51 + (i - 250) * 40.8)
        return (g, g, g)
    if 10 <= i <= 249:
        hue = ((i - 10) // 10) * 15 / 360.0
        k = (i - 10) % 10
        val = [1.0, 1.0, 0.8, 0.8, 0.6, 0.6, 0.5, 0.5, 0.3, 0.3][k]
        sat = 1.0 if k % 2 == 0 else 0.5
        r, g, b = colorsys.hsv_to_rgb(hue, sat, val)
        return (round(r * 255), round(g * 255), round(b * 255))
    return (0, 0, 0)


def contrast_on_white(rgb):
    def lin(c):
        c /= 255.0
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(x) for x in rgb)
    lum = 0.2126 * r + 0.7152 * g + 0.0722 * b
    return 1.05 / (lum + 0.05)


def layer_rgb(lay):
    tc = lay.get1(420, None, int)
    if tc is not None:
        return ((tc >> 16) & 255, (tc >> 8) & 255, tc & 255)
    return aci_rgb(abs(lay.get1(62, 7, int)))


# ------------------------------------------------------------------ geometry helpers
def ent_points(e, blocks=None, depth=0):
    """Representative points (for extents / viewport membership)."""
    t = e.type
    if t == "LINE":
        return [p for p in (e.pt(10, 20), e.pt(11, 21)) if p]
    if t in ("LWPOLYLINE",):
        return list(zip(e.all(10, float), e.all(20, float)))
    if t in ("CIRCLE", "ARC"):
        c, r = e.pt(10, 20), e.get1(40, 0, float)
        if not c:
            return []
        return [(c[0] - r, c[1] - r), (c[0] + r, c[1] + r)] if t == "CIRCLE" else arc_points(e)
    if t in ("TEXT", "MTEXT", "ATTRIB", "ATTDEF", "POINT", "INSERT"):
        p = e.pt(10, 20)
        if t == "INSERT" and blocks is not None and depth < 3:
            b = blocks.get(e.get1(2, ""))
            if b and p:
                sx, sy = e.get1(41, 1.0, float), e.get1(42, 1.0, float)
                rot = math.radians(e.get1(50, 0.0, float))
                bx, by = b["base"]
                pts = []
                for be in b["ents"]:
                    for (x, y) in ent_points(be, blocks, depth + 1):
                        x, y = (x - bx) * sx, (y - by) * sy
                        pts.append((p[0] + x * math.cos(rot) - y * math.sin(rot),
                                    p[1] + x * math.sin(rot) + y * math.cos(rot)))
                return pts or [p]
        return [p] if p else []
    if t == "DIMENSION":
        return [p for p in (e.pt(10, 20), e.pt(11, 21), e.pt(13, 23), e.pt(14, 24)) if p]
    if t == "HATCH":   # the first 10/20 pair is the elevation point (0,0), not geometry
        return list(zip(e.all(10, float), e.all(20, float)))[1:]
    if t in ("LEADER", "SPLINE", "SOLID"):
        return list(zip(e.all(10, float), e.all(20, float)))
    if t == "ELLIPSE":
        c, m = e.pt(10, 20), e.pt(11, 21)
        if c and m:
            r = math.hypot(*m)
            return [(c[0] - r, c[1] - r), (c[0] + r, c[1] + r)]
    return []


def arc_points(e):
    c, r = e.pt(10, 20), e.get1(40, 0, float)
    a0, a1 = e.get1(50, 0, float), e.get1(51, 360, float)
    if a1 < a0:
        a1 += 360
    pts = []
    for k in range(9):
        a = math.radians(a0 + (a1 - a0) * k / 8)
        pts.append((c[0] + r * math.cos(a), c[1] + r * math.sin(a)))
    return pts


def ends(e):
    """Open-curve endpoints for gap checks."""
    if e.type == "LINE":
        return [p for p in (e.pt(10, 20), e.pt(11, 21)) if p]
    if e.type == "ARC":
        c, r = e.pt(10, 20), e.get1(40, 0, float)
        a0, a1 = math.radians(e.get1(50, 0, float)), math.radians(e.get1(51, 0, float))
        return [(c[0] + r * math.cos(a0), c[1] + r * math.sin(a0)),
                (c[0] + r * math.cos(a1), c[1] + r * math.sin(a1))]
    if e.type == "LWPOLYLINE" and not (e.get1(70, 0, int) & 1):
        pts = list(zip(e.all(10, float), e.all(20, float)))
        return [pts[0], pts[-1]] if len(pts) >= 2 else []
    return []


def bbox(pts):
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    return (min(xs), min(ys), max(xs), max(ys)) if pts else None


def text_box(e, h, width_factor=0.85):
    """Approximate box of a TEXT/MTEXT/ATTRIB (unrotated only)."""
    p = e.pt(10, 20)
    s = e.get1(1, "") or ""
    if re.search(r"[\u0600-\u06FF]", s):
        width_factor = 0.55          # Arabic script is narrower per character
    if e.type == "MTEXT":
        s = re.sub(r"\\[A-Za-z][^;]*;|\\[PN~]|[{}]", " ", s)
        lines = s.split("\\P") or [s]
        w = max(len(x) for x in lines) * h * width_factor
        ref = e.get1(41, 0, float)
        if ref:
            w = min(w, ref)
        att = e.get1(71, 1, int)
        x0 = p[0] - w * ((att - 1) % 3) / 2
        y1 = p[1] + h * ((att - 1) // 3) / 2 * 2 if att > 3 else p[1]
        return (x0, y1 - h * 1.2 * len(lines), x0 + w, y1)
    w = len(s) * h * width_factor
    hj, vj = e.get1(72, 0, int), e.get1(73, 0, int)
    if (hj or vj) and e.pt(11, 21):
        p = e.pt(11, 21)
    x0 = p[0] - {0: 0, 1: w / 2, 2: w, 4: w / 2}.get(hj, 0)
    y0 = p[1] - {0: 0, 1: 0, 2: h / 2, 3: h}.get(vj, 0)
    return (x0, y0, x0 + w, y0 + h)


def overlap(a, b):
    ix = min(a[2], b[2]) - max(a[0], b[0])
    iy = min(a[3], b[3]) - max(a[1], b[1])
    if ix <= 0 or iy <= 0:
        return 0.0
    sa = max((a[2] - a[0]) * (a[3] - a[1]), 1e-9)
    sb = max((b[2] - b[0]) * (b[3] - b[1]), 1e-9)
    return ix * iy / min(sa, sb)


def dim_measure(e):
    """Measured value of a linear/aligned dimension (group 42, else from its def points)."""
    m = e.get1(42, None, float)
    if m is not None and m > 0:
        return m
    p13, p14 = e.pt(13, 23), e.pt(14, 24)
    if not (p13 and p14):
        return None
    typ = e.get1(70, 0, int) & 7
    if typ == 1:
        return math.hypot(p14[0] - p13[0], p14[1] - p13[1])
    if typ == 0:
        a = math.radians(e.get1(50, 0, float))
        return abs((p14[0] - p13[0]) * math.cos(a) + (p14[1] - p13[1]) * math.sin(a))
    return None


def near_iso(v, series, tol=0.04):
    return any(abs(v - s) <= tol * s for s in series)


def ratio_str(r):
    if r >= 1:
        return f"{r:g}:1"
    return f"1:{1 / r:g}"


# ------------------------------------------------------------------ the critic
class Report:
    def __init__(self):
        self.issues = {}
        self.passed = []
        self.facts = {}

    def add(self, check, severity, msg, fix):
        it = self.issues.setdefault(check, {"check": check, "severity": severity, "count": 0,
                                            "examples": [], "fix": fix})
        it["count"] += 1
        if WEIGHT[severity] > WEIGHT[it["severity"]]:
            it["severity"] = severity
        if len(it["examples"]) < 3:
            it["examples"].append(msg)

    def ok(self, check):
        if check not in self.issues:
            self.passed.append(check)

    def score(self):
        total = 0
        for it in self.issues.values():
            total += WEIGHT[it["severity"]] + min(it["count"] - 1, 4)
        return max(0, 100 - total)


def critique(path, pdf=None, scale_arg=None):
    d = read_dxf(path)
    R = Report()
    layers, blocks = d["layers"], d["blocks"]
    insunits = hdr(d, "$INSUNITS", 0, int)
    unit_mm = UNIT_MM.get(insunits) or (1.0 if hdr(d, "$MEASUREMENT", 1, int) == 1 else 25.4)
    ltscale = hdr(d, "$LTSCALE", 1.0)
    psltscale = hdr(d, "$PSLTSCALE", 1, int)

    # -- layouts: block record handle -> (name, paper w, h)
    lay_by_br = {}
    for lo in d["layouts"]:
        names = lo.all(1)
        name = names[-1] if names else "?"
        w, h = lo.get1(44, 0, float), lo.get1(45, 0, float)
        if lo.get1(73, 0, int) in (1, 3):
            w, h = h, w
        brs = lo.all(330)
        lay_by_br[brs[-1] if brs else ""] = {"name": name, "w": w, "h": h}

    model, paper = [], {}
    last_insert = None
    for e in d["entities"]:
        if e.type in ("ATTRIB", "SEQEND", "VERTEX"):
            if e.type == "ATTRIB" and last_insert is not None:
                last_insert.setdefault("attribs", []).append(e)
                (paper[last_insert["space"]] if last_insert["space"] else model).append(e)
            continue
        owner = e.get1(330, "")
        space = None
        if e.get1(67, 0, int) == 1:
            space = lay_by_br.get(owner, {}).get("name", "Layout")
        e["space"] = space
        if e.type == "INSERT":
            last_insert = e
        (paper.setdefault(space, []) if space else model).append(e)

    def lay(e):
        return layers.get(e.layer)

    def plots(e):
        L = lay(e)
        if L is None:
            return True
        return L.get1(290, 1, int) != 0 and L.get1(62, 7, int) >= 0 and not (L.get1(70, 0, int) & 1)

    # -- viewports
    vps = []
    for space, ents in paper.items():
        for e in ents:
            if e.type == "VIEWPORT" and e.get1(69, 1, int) != 1:
                vh, ph = e.get1(45, 0, float), e.get1(41, 0, float)
                if vh <= 0:
                    continue
                s = ph / vh
                c, vc = e.pt(10, 20), e.pt(12, 22)
                w = e.get1(40, 0, float)
                win = (vc[0] - w / 2 / s, vc[1] - ph / 2 / s, vc[0] + w / 2 / s, vc[1] + ph / 2 / s)
                vps.append({"e": e, "space": space, "scale": s, "win": win,
                            "paper": (c[0] - w / 2, c[1] - ph / 2, c[0] + w / 2, c[1] + ph / 2),
                            "centre": c, "vc": vc})
    sheet_mode = bool(vps)

    # paper mm per model unit for a model entity
    model_only_scale = None
    if not sheet_mode:
        if scale_arg:
            a, b = (float(x) for x in scale_arg.split(":"))
            model_only_scale = a / b * unit_mm
        else:
            dsc = hdr(d, "$DIMSCALE", 1.0) or 1.0
            ds_used = {e.get1(3, "Standard") for e in model if e.type == "DIMENSION"}
            for nm in ds_used:
                st = d["dimstyles"].get(nm)
                if st and st.get1(40, 0, float) > 0:
                    dsc = max(dsc, st.get1(40, 1, float))
            model_only_scale = unit_mm / dsc

    def scale_of(e):
        if e.get("space"):
            return 1.0
        if not sheet_mode:
            return model_only_scale
        pts = ent_points(e)
        if not pts:
            return vps[0]["scale"]
        x = sum(p[0] for p in pts) / len(pts)
        y = sum(p[1] for p in pts) / len(pts)
        for v in vps:
            w = v["win"]
            if w[0] <= x <= w[2] and w[1] <= y <= w[3]:
                return v["scale"]
        return None

    R.facts.update({"units_mm": unit_mm, "sheet": sheet_mode,
                    "viewport_scales": sorted({ratio_str(v["scale"] / unit_mm) for v in vps}),
                    "model_entities": len(model),
                    "paper_entities": sum(len(v) for v in paper.values())})

    all_ents = model + [e for v in paper.values() for e in v]
    visible = [e for e in all_ents if plots(e) and e.type not in ("VIEWPORT",)]

    # ---------------------------------------------------------------- 1 units
    if insunits == 0:
        R.add("units", "minor", "INSUNITS is 0 (unitless)",
              "units {\"insunits\": 4} (mm) or 6 (m) so blocks, scales and other apps read the size right")
    else:
        R.ok("units")

    # ---------------------------------------------------------------- 2 layer 0
    on0 = [e for e in visible if e.layer == "0" and e.type not in ("ATTRIB",)]
    if on0:
        frac = len(on0) / max(len(visible), 1)
        R.add("layers.zero", "major" if frac > 0.1 else "minor",
              f"{len(on0)} of {len(visible)} plotted objects are on layer 0 ({frac:.0%})",
              "create named layers (layer.new {name, color, linetype, lineweight}) and move "
              "objects with laymch {handles, layer}; keep layer 0 for block contents only")
    else:
        R.ok("layers.zero")

    # ---------------------------------------------------------------- 3 lineweights
    used_layers = {}
    for e in visible:
        used_layers.setdefault(e.layer, set()).add(e.type)
    lw_of = {}
    for name in used_layers:
        L = layers.get(name)
        lw = L.get1(370, -3, int) if L else -3
        lw_of[name] = lw / 100.0 if lw >= 0 else None
    default_lw = [n for n, v in lw_of.items() if v is None and n not in ("0", "Defpoints")]
    if default_lw:
        R.add("lineweight.explicit", "minor", f"layers with Default lineweight: {', '.join(sorted(default_lw)[:6])}",
              "layer.set {name, lineweight: 0.25|0.35|0.5|0.7}: ISO 128 weights make the plot read")
    else:
        R.ok("lineweight.explicit")
    odd = [f"{n}={v}" for n, v in lw_of.items() if v is not None and not near_iso(v, ISO_LW, 0.02)]
    if odd:
        R.add("lineweight.series", "minor", "non-ISO 128 lineweights: " + ", ".join(odd[:6]),
              "use 0.13/0.18/0.25/0.35/0.5/0.7/1.0 mm (layer.set {name, lineweight})")
    else:
        R.ok("lineweight.series")
    geo_lw = [lw_of[n] or 0.25 for n, ts in used_layers.items()
              if not ANNO_LAYER.search(n) and not SOFT_LAYER.search(n) and n not in ("0",)
              and ts & {"LINE", "LWPOLYLINE", "CIRCLE", "ARC", "SPLINE", "ELLIPSE"}]
    thin_lw = [lw_of[n] or 0.25 for n in used_layers if re.search(r"DIM", n, re.I)]
    if geo_lw:
        thick = max(geo_lw)
        thin = min(thin_lw) if thin_lw else min(lw_of[n] or 0.25 for n in used_layers)
        if thick / max(thin, 0.01) < 1.39:
            R.add("lineweight.hierarchy", "major",
                  f"object outlines {thick} mm vs thin lines {thin} mm: no wide/narrow contrast",
                  "ISO 128: visible outlines 0.5 (or 0.7), dimensions/centre/hidden/hatch 0.25 (or 0.18); "
                  "layer.set {name: <outline layer>, lineweight: 0.5}")
        else:
            R.ok("lineweight.hierarchy")

    # ---------------------------------------------------------------- 4 linetypes
    for name in used_layers:
        L = layers.get(name)
        lt = (L.get1(6, "Continuous") if L else "Continuous").upper()
        if CENTER_LAYER.search(name) and lt in ("CONTINUOUS", "BYLAYER", ""):
            R.add("linetype.semantics", "major", f"layer {name} looks like centre lines but is Continuous",
                  f"linetype {{\"load\": \"CENTER\"}} then layer.set {{name: \"{name}\", linetype: \"CENTER\"}}")
        if HIDDEN_LAYER.search(name) and lt in ("CONTINUOUS", "BYLAYER", ""):
            R.add("linetype.semantics", "major", f"layer {name} looks like hidden lines but is Continuous",
                  f"linetype {{\"load\": \"HIDDEN\"}} then layer.set {{name: \"{name}\", linetype: \"HIDDEN\"}}")
    R.ok("linetype.semantics")
    # dash period on paper
    for name in used_layers:
        L = layers.get(name)
        lt = L.get1(6, "Continuous") if L else "Continuous"
        T = d["ltypes"].get(lt)
        if not T or T.get1(73, 0, int) == 0:
            continue
        period = T.get1(40, 0, float) * ltscale
        sc = (vps[0]["scale"] if sheet_mode and psltscale == 0 else 1.0) if sheet_mode else model_only_scale
        paper_period = period * sc
        if paper_period > 45 or paper_period < 4:
            R.add("linetype.scale", "minor",
                  f"{lt} on {name}: dash pattern repeats every {paper_period:.1f} mm on paper",
                  f"ltscale {{\"scale\": {round(ltscale * 20 / max(paper_period, 0.01), 3)}}} gives a ~20 mm "
                  "period (ISO 128 long-dash-dot reads at 15-30 mm)")
    R.ok("linetype.scale")

    # ---------------------------------------------------------------- 5 text heights
    styles = d["styles"]
    heights, small, offstd, texts_for_overlap = [], [], [], []
    fonts_used = set()
    # shaped (Kurdish/Arabic) text plots as hatches; its source TEXT sits on a no-plot *-SRC
    # layer with the same height and position, so measure that instead
    src_texts = [e for e in all_ents if e.type == "TEXT" and e.layer.upper().endswith("-SRC")]
    tb_box = {}
    for e in all_ents:
        if e.get("space") and e.layer.upper().startswith("G-TTLB") and plots(e):
            b = bbox(ent_points(e, blocks))
            if b:
                o = tb_box.get(e["space"])
                tb_box[e["space"]] = b if not o else (min(o[0], b[0]), min(o[1], b[1]),
                                                      max(o[2], b[2]), max(o[3], b[3]))

    def in_title_block(e):
        if re.match(r"G-TTLB|G-SHEET", e.layer) or e.type == "ATTRIB":
            return True
        b, p = tb_box.get(e.get("space")), e.pt(10, 20)
        return bool(b and p and b[0] - 0.5 <= p[0] <= b[2] + 0.5 and b[1] - 0.5 <= p[1] <= b[3] + 0.5)

    for e in visible + src_texts:
        if e.type not in ("TEXT", "MTEXT", "ATTRIB"):
            continue
        sc = scale_of(e)
        h = e.get1(40, 0, float)
        if sc is None or h <= 0:
            continue
        ph = h * sc
        heights.append(round(ph, 2))
        st = styles.get(e.get1(7, "Standard"))
        if st:
            fonts_used.add((st.all(1000)[-1] if st.all(1000) else st.get1(3, "")).lower())
        in_tb = in_title_block(e)
        txt = (e.get1(1, "") or "")[:30]
        if ph < 1.75:
            small.append((ph, txt, "severe"))
        elif ph < 2.45 and not in_tb:
            small.append((ph, txt, "major"))
        elif not near_iso(ph, ISO_TEXT):
            offstd.append(f"{ph:.2f} mm '{txt}'")
        if e.get1(50, 0, float) == 0:
            box = text_box(e, h)
            if box:
                texts_for_overlap.append((e, box, e.get("space")))
    for e in visible:     # dimension text
        if e.type != "DIMENSION":
            continue
        st = d["dimstyles"].get(e.get1(3, "Standard"))
        if not st:
            continue
        sc = scale_of(e)
        if sc is None:
            continue
        ph = st.get1(140, 2.5, float) * (st.get1(40, 1, float) or 1) * sc
        heights.append(round(ph, 2))
        if ph < 1.75:
            small.append((ph, "dimension text", "severe"))
        elif ph < 2.45:
            small.append((ph, "dimension text", "major"))
        elif not near_iso(ph, ISO_TEXT):
            offstd.append(f"{ph:.2f} mm (dimension style {e.get1(3)})")
    for ph, txt, sev in small:
        R.add("text.min_height", sev, f"{ph:.2f} mm on paper: '{txt}'",
              "ISO 3098: 2.5 mm minimum for notes and dimensions (1.8 only for title-block labels); "
              "text {height: 2.5*k} / dimstyle {DIMTXT: 2.5|3.5, DIMSCALE: k}, k = model units per paper mm")
    if not small:
        R.ok("text.min_height")
    for o in offstd[:8]:
        R.add("text.iso_series", "minor", o,
              "use ISO 3098 heights 2.5 / 3.5 / 5 / 7 mm on paper (x k for model-space text)")
    if not offstd:
        R.ok("text.iso_series")
    distinct = sorted(set(round(h, 1) for h in heights))
    R.facts["paper_text_heights"] = distinct
    if len(distinct) > 5:
        R.add("text.hierarchy", "minor", f"{len(distinct)} different text heights: {distinct}",
              "keep 3-4 sizes: 7 (title) / 5 (headings, drawing no.) / 3.5 (values, dims) / 2.5 (notes)")
    else:
        R.ok("text.hierarchy")
    fonts_used.discard("")
    if len(fonts_used) > 2:
        R.add("text.fonts", "minor", f"{len(fonts_used)} fonts: {sorted(fonts_used)}",
              "one drafting font (Standard stroke font) plus at most one for the title block")
    else:
        R.ok("text.fonts")
    # overlaps (same space)
    seen = 0
    for i in range(len(texts_for_overlap)):
        ei, bi, si = texts_for_overlap[i]
        for j in range(i + 1, len(texts_for_overlap)):
            ej, bj, sj = texts_for_overlap[j]
            if si != sj or not ei.get1(1, "").strip() or not ej.get1(1, "").strip():
                continue
            if overlap(bi, bj) > 0.25:
                seen += 1
                R.add("text.overlap", "major",
                      f"'{ei.get1(1, '')[:20]}' overlaps '{ej.get1(1, '')[:20]}'",
                      "move one of them (move {handles, delta}) or reduce the height; keep >= 1 text "
                      "height of clear space between labels")
    if not seen:
        R.ok("text.overlap")

    # ---------------------------------------------------------------- 6 dimensions
    geo = [e for e in model if plots(e) and not ANNO_LAYER.search(e.layer) and not SOFT_LAYER.search(e.layer)
           and e.type in ("LINE", "LWPOLYLINE", "CIRCLE", "ARC", "SPLINE", "ELLIPSE")]
    dims = [e for e in model if e.type == "DIMENSION"]
    R.facts["dimensions"] = len(dims)
    if len(geo) >= 4 and not dims:
        R.add("dims.missing", "major", f"{len(geo)} objects and no dimensions",
              "dimension overall sizes and features: dimlinear {p1, p2, at}, dimcontinue {points}, "
              "dimdiameter {handle, at}, dimradius {center, point}")
    else:
        R.ok("dims.missing")
    fake = 0
    for e in dims:
        t = (e.get1(1, "") or "").strip()
        if not t or "<>" in t or "'" in t or '"' in t:
            continue
        meas = dim_measure(e)
        st = d["dimstyles"].get(e.get1(3, "Standard"))
        lfac = st.get1(144, 1.0, float) if st else 1.0
        nums = [float(x) for x in re.findall(r"\d+(?:\.\d+)?", t.replace(",", "."))]
        if meas is None or not nums:
            continue
        m = meas * lfac
        if not any(abs(n - m) <= max(0.01, 0.005 * m) for n in nums):
            fake += 1
            R.add("dims.override", "severe", f"dimension text '{t}' but the geometry measures {m:g}",
                  "never type a value over a dimension: fix the geometry, or use text \"<>\" with a "
                  "prefix/suffix (dimoverride {handles, text: \"<> TYP\"})")
    if not fake:
        R.ok("dims.override")
    # spacing: dimension line distance from its feature points and between parallel dims
    lines = []
    for e in dims:
        typ = e.get1(70, 0, int) & 7
        p10, p13, p14 = e.pt(10, 20), e.pt(13, 23), e.pt(14, 24)
        if typ not in (0, 1) or not (p10 and p13 and p14):
            continue
        sc = scale_of(e)
        if not sc:
            continue
        ang = math.radians(e.get1(50, 0, float))
        if typ == 1:
            ang = math.atan2(p14[1] - p13[1], p14[0] - p13[0])
        ux, uy = math.cos(ang), math.sin(ang)
        nx, ny = -uy, ux
        off_line = p10[0] * nx + p10[1] * ny
        o13 = abs(off_line - (p13[0] * nx + p13[1] * ny)) * sc
        o14 = abs(off_line - (p14[0] * nx + p14[1] * ny)) * sc
        near = min(o13, o14)
        if 0 < near < 5.5:
            R.add("dims.offset", "minor",
                  f"dimension {dim_measure(e) or 0:g}: dimension line {near:.1f} mm from its feature",
                  "ISO 129: first dimension line ~10 mm from the outline (at = feature + 10*k)")
        a = (p13[0] * ux + p13[1] * uy, p14[0] * ux + p14[1] * uy)
        lines.append((round(math.degrees(ang) % 180, 1), off_line, min(a), max(a), sc,
                      round(dim_measure(e) or 0, 3)))
    crowd = 0
    for i in range(len(lines)):
        for j in range(i + 1, len(lines)):
            a, b = lines[i], lines[j]
            if a[0] != b[0]:
                continue
            gap = abs(a[1] - b[1]) * a[4]
            spans = min(a[3], b[3]) - max(a[2], b[2]) > 0
            if spans and 0.5 < gap < 6.0:
                crowd += 1
                R.add("dims.spacing", "minor",
                      f"dimensions {a[5]:g} and {b[5]:g}: parallel dimension lines {gap:.1f} mm apart",
                      "space stacked dimension lines 7-10 mm apart on paper (at offsets 10*k, 18*k, 26*k)")
    if not crowd:
        R.ok("dims.spacing")
    R.ok("dims.offset")

    # ---------------------------------------------------------------- 7 geometry quality
    sc0 = vps[0]["scale"] if sheet_mode else model_only_scale
    tol = 0.5 / (sc0 or 1)
    pts = []
    for idx, e in enumerate(geo):
        for p in ends(e):
            pts.append((p, idx))
    gaps = 0
    if pts and len(pts) < 20000:
        import numpy as np
        A = np.array([p for p, _ in pts])
        owner = np.array([o for _, o in pts])
        for k in range(len(A)):
            dd = np.hypot(A[:, 0] - A[k, 0], A[:, 1] - A[k, 1])
            dd[k] = np.inf
            j = int(np.argmin(dd))
            m = dd[j]
            if 1e-6 < m <= tol and (dd <= 1e-6).sum() == 0:
                gaps += 1
                R.add("geometry.gaps", "major",
                      f"open end at ({A[k, 0]:.2f}, {A[k, 1]:.2f}) misses another end by {m:.3f}",
                      "close it: fillet {h1, p1, h2, p2, radius: 0}, or pedit {handle, option: "
                      "\"close\"}/join so boundaries hatch and offset cleanly")
    if not gaps:
        R.ok("geometry.gaps")
    sig = {}
    dup = 0
    for e in geo:
        key = (e.type, e.layer, tuple(round(v, 4) for p in ent_points(e) for v in p))
        if key in sig:
            dup += 1
        sig[key] = 1
    if dup:
        R.add("geometry.duplicates", "minor", f"{dup} duplicated objects (same type, layer, position)",
              "erase {handles} the copies; they plot darker and double-count in area/length checks")
    else:
        R.ok("geometry.duplicates")

    # ---------------------------------------------------------------- 8 plot colours
    for name, types in used_layers.items():
        L = layers.get(name)
        if not L:
            continue
        cr = contrast_on_white(layer_rgb(L))
        has_text = bool(types & {"TEXT", "MTEXT", "DIMENSION", "ATTRIB", "LEADER", "MULTILEADER"})
        soft = SOFT_LAYER.search(name) or types <= {"HATCH", "SOLID"}
        if has_text and cr < 4.5:
            # model-only drawings are often viewed on the dark canvas; it bites when plotted
            R.add("plot.contrast", "severe" if cr < 2 and sheet_mode else "major",
                  f"layer {name}: text/dimensions plot at {cr:.1f}:1 contrast on white paper",
                  f"layer.set {{name: \"{name}\", color: 7}} (black) or a dark grey (250/251); "
                  "plot uses true colours unless pagesetup sets a CTB (CLI 0.6.2), so yellow/cyan/green wash out")
        elif not soft and not has_text and cr < 3.0:
            R.add("plot.contrast", "major" if cr < 2 else "minor",
                  f"layer {name}: lines plot at {cr:.1f}:1 contrast on white paper",
                  f"layer.set {{name: \"{name}\", color: 7}} for object lines; keep light greys (8/9/253) "
                  "for hatch and context only")
        elif soft and cr < 1.3:
            R.add("plot.contrast", "minor", f"layer {name}: {cr:.2f}:1, nearly invisible on paper",
                  f"layer.set {{name: \"{name}\", color: 8}} or 252")
    R.ok("plot.contrast")

    # ---------------------------------------------------------------- 9 hatch spacing
    for e in visible:
        if e.type != "HATCH" or e.get1(70, 0, int) == 1:      # solid fill
            continue
        offs = list(zip(e.all(45, float), e.all(46, float)))
        sc = scale_of(e)
        if not offs or not sc:
            continue
        sp = min(math.hypot(a, b) for a, b in offs if math.hypot(a, b) > 0) * sc
        if sp < 0.9:
            R.add("hatch.scale", "minor", f"hatch {e.get1(2, '')} lines {sp:.2f} mm apart on paper (prints as grey mush)",
                  "hatchedit {handles, scale}: aim for 1.5-4 mm line spacing on paper")
        elif sp > 12:
            R.add("hatch.scale", "minor", f"hatch {e.get1(2, '')} lines {sp:.1f} mm apart on paper (reads as stray lines)",
                  "hatchedit {handles, scale}: aim for 1.5-4 mm line spacing on paper")
    R.ok("hatch.scale")

    # ---------------------------------------------------------------- 10 sheet
    if not sheet_mode:
        R.add("sheet.missing", "major", "no paper-space sheet: no frame, title block or plot scale",
              "add {\"sheet\": {paper: \"A3\", scale: \"1:…\", fields: {…}}} to the recipe "
              "(scripts/sheet.py: ISO 5457 frame + ISO 7200 title block + scaled viewport)")
    else:
        R.ok("sheet.missing")
        for space, ents in paper.items():
            info = next((v for v in lay_by_br.values() if v["name"] == space), {"w": 420, "h": 297})
            W, H = info["w"], info["h"]
            pv = [e for e in ents if plots(e) and e.type != "VIEWPORT"]
            if not pv and not any(v["space"] == space for v in vps):
                continue
            # frame
            frame = None
            for e in pv:
                if e.type == "LWPOLYLINE" and (e.get1(70, 0, int) & 1):
                    bb = bbox(list(zip(e.all(10, float), e.all(20, float))))
                    if bb and (bb[2] - bb[0]) * (bb[3] - bb[1]) > 0.6 * W * H and bb[0] >= 4 and bb[1] >= 4:
                        frame = bb
            if not frame:
                R.add("sheet.frame", "major", f"{space}: no drawing frame",
                      "ISO 5457: closed frame 20 mm from the left edge, 10 mm elsewhere, 0.7 mm")
            else:
                R.ok("sheet.frame")
            # outside paper
            out = 0
            for e in pv:
                for (x, y) in ent_points(e, blocks):
                    if x < -0.5 or y < -0.5 or x > W + 0.5 or y > H + 0.5:
                        out += 1
                        break
            if out:
                R.add("sheet.bounds", "major", f"{space}: {out} paper-space objects outside the {W:g}x{H:g} sheet",
                      "move them inside the frame, or set pagesetup {paper, landscape} to the intended size")
            # title block
            tb = [e for e in pv if e.layer.upper().startswith(("G-TTLB",)) or
                  (e.type == "INSERT" and any(a.get1(2, "").upper() == "TITLE" for a in e.get("attribs", [])))]
            if not tb:
                R.add("sheet.titleblock", "major", f"{space}: no title block",
                      "ISO 7200 title block bottom-right, 180 mm wide (the sheet step draws one)")
                tbb = None
            else:
                tbb = bbox([p for e in tb for p in ent_points(e, blocks)])
                R.ok("sheet.titleblock")
                if frame and tbb and (abs(tbb[2] - frame[2]) > 2 or abs(tbb[1] - frame[1]) > 2):
                    R.add("sheet.titleblock", "minor", f"{space}: title block is not in the frame's bottom-right corner",
                          "ISO 5457/7200: title block in the bottom-right corner of the frame")
                if tbb and tbb[2] - tbb[0] > 182:
                    R.add("sheet.titleblock", "minor", f"{space}: title block {tbb[2] - tbb[0]:.0f} mm wide",
                          "ISO 7200: 180 mm maximum width")
                vals = [(e.get1(1, "") or "").strip() for e in tb if e.type in ("TEXT", "MTEXT", "ATTRIB")]
                vals += [(e.get1(1, "") or "").strip() for e in ents if e.type == "TEXT" and
                         e.layer.upper().endswith("-SRC")]
                ph = [v for v in vals if PLACEHOLDER.search(v)]
                if ph:
                    R.add("sheet.fields", "major", f"placeholder text in the title block: {ph[:3]}",
                          "fill every field: template apply … --var title=… --var dwg_no=…")
                labels_only = [v for v in vals if v]
                value_layers = [e for e in tb if e.type in ("TEXT", "ATTRIB") and
                                re.search(r"TEXT|TITL", e.layer, re.I) or e.type == "ATTRIB"]
                if len(value_layers) < 4:
                    R.add("sheet.fields", "major", f"{space}: title block has only {len(value_layers)} filled fields",
                          "fill title, drawing number, scale, date and drawn-by at least")
                else:
                    R.ok("sheet.fields")
                # scale text vs viewport scale
                stated = [v for v in vals if re.fullmatch(r"\d+(?:\.\d+)?\s*:\s*\d+(?:\.\d+)?", v)]
                actual = {round(v["scale"] / unit_mm, 9) for v in vps if v["space"] == space}
                for s in stated:
                    a, b = (float(x) for x in s.split(":"))
                    if not any(abs(a / b - x) <= 0.005 * x for x in actual):
                        R.add("sheet.scale_match", "severe",
                              f"title block says {s} but the viewport is {', '.join(ratio_str(x) for x in actual)}",
                              "viewport.set {handle, scale: \"1:…\"} or fix the SCALE field: they must agree")
                if stated:
                    R.ok("sheet.scale_match")
            # viewports on this sheet
            for v in [v for v in vps if v["space"] == space]:
                r = v["scale"] / unit_mm
                if not any(abs(r - s) <= 0.005 * s for s in ISO_SCALES):
                    R.add("sheet.scale_iso", "major", f"viewport scale {ratio_str(r)} is not an ISO 5455 scale",
                          "viewport.set {handle, scale: \"1:1|1:2|1:5|1:10|1:20|1:50|1:100|1:200|1:500\"}")
                else:
                    R.ok("sheet.scale_iso")
                if layers.get(v["e"].layer) is None or layers[v["e"].layer].get1(290, 1, int) != 0:
                    R.add("sheet.viewport_frame", "minor", f"viewport border on plotting layer {v['e'].layer}",
                          "put viewports on a no-plot layer: layer.new {name: \"G-VPRT\"}, layer.set {plot: false}")
                else:
                    R.ok("sheet.viewport_frame")
                # model content shown in this viewport
                inside, clipped = [], 0
                w = v["win"]
                for e in model:
                    if not plots(e):
                        continue
                    ps = ent_points(e, blocks)
                    if not ps:
                        continue
                    ins = [w[0] - 1e-6 <= x <= w[2] + 1e-6 and w[1] - 1e-6 <= y <= w[3] + 1e-6 for x, y in ps]
                    if all(ins):
                        inside += ps
                    elif any(ins):
                        clipped += 1
                if clipped:
                    R.add("sheet.clipped", "severe", f"{clipped} model objects cut by the viewport edge",
                          "use a smaller scale or larger paper; the sheet step refuses content that does not fit")
                else:
                    R.ok("sheet.clipped")
                if inside:
                    mb = bbox(inside)
                    s = v["scale"]
                    pc = v["centre"]

                    def to_paper(x, y):
                        return (pc[0] + (x - v["vc"][0]) * s, pc[1] + (y - v["vc"][1]) * s)
                    pb = to_paper(mb[0], mb[1]) + to_paper(mb[2], mb[3])
                    R.facts.setdefault("content_on_paper_mm", []).append([round(x, 1) for x in pb])
                    if tbb and overlap(pb, tbb) > 0.0:
                        ix = min(pb[2], tbb[2]) - max(pb[0], tbb[0])
                        iy = min(pb[3], tbb[3]) - max(pb[1], tbb[1])
                        if ix > 1 and iy > 1:
                            R.add("sheet.overlap", "severe", "model content runs under the title block",
                                  "re-centre the view (viewport.set {center}) or use a smaller scale")
                    if frame:
                        fa = (frame[2] - frame[0]) * (frame[3] - frame[1])
                        ca = (pb[2] - pb[0]) * (pb[3] - pb[1])
                        if ca / fa < 0.06:
                            R.add("sheet.fill", "minor", f"drawing fills {ca / fa:.0%} of the frame",
                                  "use the next larger ISO scale or a smaller sheet (A4) so the part reads")
                        R.facts["fill"] = round(ca / fa, 3)

    # ---------------------------------------------------------------- 11 plotted PDF
    if pdf and os.path.exists(pdf):
        try:
            raster_checks(pdf, R)
        except Exception as ex:   # never fail the critique on a preview problem
            R.facts["pdf_check_error"] = str(ex)

    return R


def raster_checks(pdf, R):
    import numpy as np
    from PIL import Image
    tmp = tempfile.mkdtemp()
    try:
        try:
            subprocess.run(["qlmanage", "-t", "-s", "1600", "-o", tmp, pdf], capture_output=True, timeout=60)
        except subprocess.TimeoutExpired:
            pass
        png = os.path.join(tmp, os.path.basename(pdf) + ".png")
        if not os.path.exists(png):
            subprocess.run(["sips", "-s", "format", "png", pdf, "--out", png], capture_output=True)
        im = Image.open(png).convert("RGBA")
        bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
        a = np.asarray(Image.alpha_composite(bg, im).convert("RGB")).astype(np.float32) / 255
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    lum = a.mean(axis=2)
    ink = lum < 0.85
    frac = ink.mean()
    R.facts["pdf_ink"] = round(float(frac), 4)
    if frac < 0.002:
        R.add("pdf.blank", "severe", "the plotted sheet is (almost) blank",
              "check the viewport (viewport.set {center, scale}) and that layers plot (layer.set {plot: true})")
        return
    R.ok("pdf.blank")
    mx, mn = a.max(axis=2), a.min(axis=2)
    sat = (mx - mn) / np.maximum(mx, 1e-6)
    coloured = (sat > 0.45) & (mx > 0.35) & (lum < 0.97)
    pale = coloured & (lum > 0.55)
    cf = coloured.sum() / max(ink.sum() + coloured.sum(), 1)
    pf = pale.sum() / max(ink.sum() + pale.sum(), 1)
    R.facts["pdf_coloured_ink"] = round(float(cf), 4)
    if pf > 0.03:
        R.add("pdf.pale_ink", "major", f"{pf:.0%} of the ink is pale colour (yellow/cyan/green on white)",
              "set those layers to colour 7 or a dark grey, or pagesetup {plotStyleTable: \"monochrome.ctb\"} (CLI 0.6.2)")
    else:
        R.ok("pdf.pale_ink")


def format_report(R, path):
    score = R.score()
    sev = [i for i in R.issues.values() if i["severity"] == "severe"]
    out = [f"CADCraft critic: {score}/100  ({os.path.basename(path)})"
           + ("  SEVERE ISSUES" if sev else "")]
    f = R.facts
    out.append(f"  sheet: {'yes, viewport ' + ', '.join(f['viewport_scales']) if f.get('sheet') else 'no (model only)'}"
               f"; dimensions: {f.get('dimensions', 0)}; paper text heights: {f.get('paper_text_heights')}")
    order = {"severe": 0, "major": 1, "minor": 2}
    for it in sorted(R.issues.values(), key=lambda i: (order[i["severity"]], i["check"])):
        more = f" (x{it['count']})" if it["count"] > 1 else ""
        out.append(f"- [{it['severity']}] {it['check']}{more}: {it['examples'][0]}")
        for ex in it["examples"][1:]:
            out.append(f"      also: {ex}")
        out.append(f"      fix: {it['fix']}")
    passed = sorted(set(R.passed) - set(R.issues))
    out.append(f"  passed: {', '.join(passed)}")
    return "\n".join(out)


def main(argv=None):
    import argparse
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--pdf")
    ap.add_argument("--scale")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    R = critique(a.file, a.pdf, a.scale)
    if a.json:
        print(json.dumps({"score": R.score(), "issues": list(R.issues.values()),
                          "passed": sorted(set(R.passed) - set(R.issues)), "facts": R.facts},
                         indent=1, ensure_ascii=False))
    else:
        print(format_report(R, a.file))
    return 1 if any(i["severity"] == "severe" for i in R.issues.values()) else 0


if __name__ == "__main__":
    sys.exit(main())
