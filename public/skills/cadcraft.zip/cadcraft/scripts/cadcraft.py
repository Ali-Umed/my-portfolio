"""Draft and edit CAD drawings through CADCraft's own engine (cadcraft-cli), headless.

Commands
  cadcraft.py apply (SRC.dxf|SRC.dwg | --new [--metric]) OUT_STEM RECIPE [--save dxf,dwg]
              [--export png,svg,pdf] [--window x0,y0,x1,y1] [--light|--mono] [--force]
      Runs the recipe in one headless CADCraft session (`cadcraft-cli mcp`), step by step,
      starting from SRC (never modified) or a new drawing. Writes OUT_STEM.<save formats>,
      OUT_STEM.<export formats> and OUT_STEM.recipe.json, then prints a structure summary.
      RECIPE is one of --recipe FILE.json | --steps JSON | --script TEXT | --script-file F.scr.
      Every step is validated first: unknown command ids and misspelled param keys are errors,
      because CADCraft silently ignores unknown keys. A command-line/script step that prints a
      prompt error ("Point or option keyword required.", "Unknown pattern …") or is left
      waiting at a prompt aborts the run, because the CLI itself would still exit 0.
  cadcraft.py check RECIPE [--src FILE | --metric] [--static]
      Validate only: ids, param keys, $references, then a dry run in a scratch session
      (nothing is written; steps with a "path" param are skipped). --static skips the dry run.
  cadcraft.py oneshot (SRC | --new [--metric]) OUT_STEM RECIPE [--save ...] [--export ...] [--print]
      The same recipe as one `cadcraft-cli run … --script … --cmd 'id {json}' … --save … --export …`
      call (no $references). --print shows the command line without running it.
  cadcraft.py describe ID [ID ...]    Params doc, aliases, menu path of commands.
  cadcraft.py commands [FILTER]       Compact list of ids (filter matches id or label).
  cadcraft.py info FILE               Counts, layers, extents, blocks, styles of a DXF/DWG.
  cadcraft.py render FILE OUT.png [--window x0,y0,x1,y1] [--light | --mono]
      PNG preview (2400x1600, model space, dark canvas like the app). --light recolours it
      like a plot (white paper, colour-7 lines black, colours kept); --mono makes every line
      black. Needs Pillow only for --light/--mono.
  cadcraft.py compare BEFORE.png AFTER.png OUT.png   Side-by-side before/after (Pillow).
  cadcraft.py template list | show ID | apply ID OUT_STEM [--var k=v ...] | test [OUTDIR]
      Parameterized recipes in templates/ (references/templates.md). apply writes
      OUT_STEM.recipe.in.json, the DXF, PNG, plotted PDF, OUT_STEM_sheet.png and runs the critic;
      test rebuilds every template, refreshes templates/thumbs and templates/gallery.png.
  cadcraft.py critic FILE.dxf [--pdf SHEET.pdf] [--scale 1:50] [--json]
      Drafting-standards score /100 with fixes (scripts/critic.py, references/design-guide.md).

Recipe steps (a JSON list, or {"steps": [...]}):
  ["circle", {"center": [0, 0], "radius": 5}]           JSON command (engine.execute)
  {"cmd": "circle", "params": {...}, "as": "hole"}       … and remember its handle as $hole
  ["dimdiameter", {"handle": "$hole", "at": [8, 8]}]     "$name" is replaced by that handle
  ["erase", {"handles": ["$room.all"]}]                  "$name.all": every handle the step returned
  {"script": "RECTANG 0,0 120,80\\nCIRCLE 60,40 15\\n"}  AutoCAD .scr text (space/newline = Enter)
  {"line": "circle 10,10 D 6"}                           one command line, exactly as typed
  {"script_file": "part.scr"}                            a .scr file (path relative to the recipe)
  {"sheet": {"paper": "A3", "scale": "1:1", "fields": {...}}}   ISO frame + title block + viewport
  {"label": "...", "at": [x, y], "height": h}            TEXT, or shaped outlines for Kurdish
  {"shaped_text": "...", "at": [x, y], "height": h, "font": "Rabar_016.ttf", "justify": "R"}
  "ok_if_exists": true on a step                          tolerate "already exists" (layer.new)
"""
import argparse
import base64
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile

CLI = shutil.which("cadcraft-cli") or os.path.expanduser("~/.local/bin/cadcraft-cli")
SAVE_FORMATS = {"dxf", "dwg"}
EXPORT_FORMATS = {"png", "svg", "pdf"}
# Words in command-line output that mean the line was refused (the CLI still exits 0).
PROMPT_ERROR = re.compile(
    r"required|Requires|[Ii]nvalid|[Uu]nknown|not available|[Cc]annot|can't|not found|[Ff]ailed|"
    r"[Ee]rror|out of range|must be|[Nn]othing (selected|found)|[Nn]o objects|not allowed")
# Steps whose params write files: skipped in dry runs, checked against the source in apply.
PATH_WRITERS = {"plot", "exportpdf", "saveas", "qsave", "wblock", "document.bytes"}


def die(msg, code=1):
    print(f"cadcraft: {msg}", file=sys.stderr)
    sys.exit(code)


def cli(*args, check=True):
    if not os.path.exists(CLI):
        die("cadcraft-cli not found. Install the macOS CLI zip (cadcraft-cli-<ver>-macos-universal.zip) "
            "from https://github.com/storytold/cadcraft/releases and put cadcraft-cli on PATH.")
    p = subprocess.run([CLI, *args], capture_output=True, text=True)
    if check and p.returncode != 0:
        die(f"cadcraft-cli {' '.join(args[:2])} failed:\n{(p.stderr or p.stdout).strip()}")
    return p


# ---------------------------------------------------------------- registry and validation
_REG = None


def registry():
    global _REG
    if _REG is None:
        _REG = {c["id"]: c for c in json.loads(cli("commands").stdout)}
    return _REG


def aliases():
    out = {}
    for cid, c in registry().items():
        out[cid.lower()] = cid
        for a in c.get("aliases") or []:
            out.setdefault(a.lower(), cid)
    return out


_KEY = re.compile(r'(?:^|[{,|(+])\s*([A-Za-z_][A-Za-z0-9_]*)\s*\??\s*(?=[:,}|)?(]|$)')
_OPT = re.compile(r'([A-Za-z_][A-Za-z0-9_]*)\?')


def _strip(doc):
    doc = re.sub(r'"[^"]*"', '""', doc or "")
    return re.sub(r'→.*', '', doc)  # return value description


def param_keys(cid):
    """Keys a command's params doc names (lenient: option words count too)."""
    reg = registry()
    doc = reg[cid]["params"] or ""
    same = re.match(r"\s*same as `([\w.\-]+)`", doc)
    if same and same.group(1) in reg:
        return param_keys(same.group(1))
    keys = set(_KEY.findall(_strip(doc))) | set(_OPT.findall(_strip(doc)))
    if cid == "array":
        for sub in ("arrayrect", "arraypolar", "arraypath"):
            keys |= param_keys(sub)
    return keys


def open_ended(cid):
    """Docs like dimstyle "<style fields or DIM* variables>" or properties.set "<geometry
    fields…>" list only some keys: an unlisted key there is a warning, not an error."""
    doc = _strip(registry()[cid]["params"])
    return bool(re.search(r"<[A-Za-z][^>]{3,}>", doc)) or "the parameters of" in doc


def dimvar(cid, key):
    return cid.startswith(("dimstyle", "dimoverride")) and re.fullmatch(r"DIM[A-Z0-9]+", key or "")


def normalise(raw, base="."):
    """Steps -> [{"kind": "cmd"|"script"|"line", …}]. script_file paths are relative to `base`."""
    if isinstance(raw, dict):
        raw = raw.get("steps", [])
    steps = []
    for s in raw:
        if isinstance(s, str):
            steps.append({"kind": "cmd", "cmd": s, "params": {}})
        elif isinstance(s, list):
            steps.append({"kind": "cmd", "cmd": s[0], "params": s[1] if len(s) > 1 else {},
                          "as": s[2] if len(s) > 2 else None})
        elif "script" in s:
            steps.append({"kind": "script", "text": s["script"]})
        elif "script_file" in s:
            path = os.path.join(base, os.path.expanduser(s["script_file"]))
            steps.append({"kind": "script", "text": open(path).read(), "file": os.path.abspath(path)})
        elif "line" in s:
            steps.append({"kind": "line", "text": s["line"]})
        elif "sheet" in s:
            steps.append({"kind": "sheet", "params": s["sheet"]})
        elif "label" in s:
            # Text in either script: Latin -> TEXT (stroke font); Kurdish/Arabic -> shaped_text.
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from shaped_text import is_rtl
            bad = set(s) - {"label", "at", "height", "justify", "layer", "font", "rotation", "if"}
            if bad:
                die(f"label step: unknown keys {sorted(bad)}")
            txt = str(s["label"])
            if is_rtl(txt):
                steps += normalise([{"shaped_text": txt, "at": s["at"], "height": s.get("height", 3.5),
                                     "font": s.get("font"), "justify": s.get("justify", "L"),
                                     "layer": s.get("layer"), "rotation": s.get("rotation", 0)}], base)
            else:
                if s.get("layer"):
                    steps.append({"kind": "cmd", "cmd": "layer.current", "params": {"name": s["layer"]}})
                prm = {"at": s["at"], "text": txt, "height": s.get("height", 3.5)}
                if s.get("justify"):
                    prm["justify"] = s["justify"]
                if s.get("rotation"):
                    prm["rotation"] = s["rotation"]
                steps.append({"kind": "cmd", "cmd": "text", "params": prm})
        elif "shaped_text" in s:
            # Kurdish/Arabic text drawn as filled outlines (0.5.0 TEXT can't shape RTL).
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from shaped_text import shaped_text_steps
            bad = set(s) - {"shaped_text", "at", "height", "font", "justify", "layer",
                            "keep_text", "rotation"}
            if bad:
                die(f"shaped_text step: unknown keys {sorted(bad)}")
            steps += normalise(shaped_text_steps(
                s["shaped_text"], s["at"], s.get("height", 3.5), s.get("font"),
                s.get("justify", "L"), s.get("layer"), s.get("keep_text", True),
                s.get("rotation", 0)), base)
        else:
            steps.append({"kind": "cmd", "cmd": s.get("cmd") or s.get("command") or s.get("id"),
                          "params": s.get("params") or {}, "as": s.get("as"),
                          "ok_if_exists": bool(s.get("ok_if_exists"))})
    return steps


def refs_in(value):
    if isinstance(value, str) and value.startswith("$"):
        yield value[1:].removesuffix(".all")
    elif isinstance(value, list):
        for v in value:
            yield from refs_in(v)
    elif isinstance(value, dict):
        for v in value.values():
            yield from refs_in(v)


def static_check(steps):
    """(errors, warnings) for ids, param keys, $refs and script command words."""
    reg, al = registry(), aliases()
    errors, warnings, named = [], [], set()
    for i, s in enumerate(steps):
        if s["kind"] == "sheet":
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from sheet import SHEET_KEYS, ISO_SCALES
            bad = set(s["params"]) - SHEET_KEYS
            if bad:
                errors.append(f"step {i} sheet: unknown keys {sorted(bad)}; known: {sorted(SHEET_KEYS)}")
            if str(s["params"].get("scale", "1:1")) not in ISO_SCALES:
                errors.append(f"step {i} sheet: scale {s['params'].get('scale')!r} is not an ISO 5455 scale")
            continue
        if s["kind"] in ("script", "line"):
            first = (s["text"].strip().split() or [""])[0].lstrip("_.-'").lower()
            if first and first not in al and not re.match(r"^[\d.,@<#*-]", first):
                errors.append(f"step {i}: script starts with unknown command {first!r}")
            if s["kind"] == "script" and re.search(r"\n\s*\n\s*$", s["text"]):
                warnings.append(f"step {i}: script ends with a blank line after Enter: a blank line "
                                "while idle REPEATS the last command")
            continue
        cid = s["cmd"]
        if cid not in reg:
            hint = al.get(str(cid).lower())
            near = hint and [hint] or [k for k in reg if str(cid).split(".")[-1].lower()[:4] in k][:6]
            errors.append(f"step {i}: unknown command id {cid!r}" +
                          (f" (alias of {hint!r}: JSON steps need the id)" if hint else
                           f" (similar: {near})" if near else ""))
            continue
        if not isinstance(s["params"], dict):
            errors.append(f"step {i} {cid}: params must be a JSON object")
            continue
        known = param_keys(cid)
        for k in s["params"]:
            if k in known or dimvar(cid, k):
                continue
            msg = f"step {i} {cid}: unknown param {k!r}; documented: {reg[cid]['params']}"
            (warnings if open_ended(cid) and not __import__('difflib').get_close_matches(k, sorted(known), n=1, cutoff=0.8) else errors).append(msg)
        for r in refs_in(s["params"]):
            if r not in named:
                errors.append(f"step {i} {cid}: ${r} is not defined by an earlier step's \"as\"")
        if s.get("as"):
            named.add(s["as"])
        if not reg[cid].get("enabled", True) and reg[cid].get("disabledReason") not in (
                "nothing selected", "the clipboard is empty"):
            warnings.append(f"step {i} {cid}: currently disabled ({reg[cid].get('disabledReason')})")
    return errors, warnings


# ---------------------------------------------------------------- headless MCP session
class Session:
    """One headless CADCraft session over `cadcraft-cli mcp` (JSON-RPC on stdio)."""

    def __init__(self):
        self.err = tempfile.TemporaryFile()
        self.p = subprocess.Popen([CLI, "mcp"], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                  stderr=self.err, text=True)
        self.n = 0
        self.sheet = None          # set by a {"sheet": …} step (layout, paper, scale, frame …)
        self.rpc("initialize", {"protocolVersion": "2024-11-05", "capabilities": {},
                                "clientInfo": {"name": "cadcraft-skill", "version": "1"}})
        self.p.stdin.write(json.dumps({"jsonrpc": "2.0", "method": "notifications/initialized"}) + "\n")
        self.p.stdin.flush()

    def rpc(self, method, params):
        self.n += 1
        self.p.stdin.write(json.dumps({"jsonrpc": "2.0", "id": self.n, "method": method,
                                       "params": params}) + "\n")
        self.p.stdin.flush()
        while True:
            line = self.p.stdout.readline()
            if not line:
                self.err.seek(0)
                die("cadcraft-cli mcp exited: " + self.err.read().decode(errors="replace")[-2000:])
            msg = json.loads(line)
            if msg.get("id") == self.n:
                if "error" in msg:
                    raise RuntimeError(msg["error"].get("message"))
                return msg["result"]

    def tool(self, name, args):
        """(ok, parsed text payload)."""
        r = self.rpc("tools/call", {"name": name, "arguments": args})
        text = "".join(c.get("text", "") for c in r.get("content", []) if c.get("type") == "text")
        try:
            data = json.loads(text)
        except ValueError:
            data = text
        return not r.get("isError"), data

    def close(self):
        try:
            self.p.stdin.close()
            self.p.wait(timeout=10)
        except Exception:
            self.p.kill()


def substitute(value, handles):
    """"$name" -> the step's first handle; "$name.all" -> all its handles (spliced into lists)."""
    if isinstance(value, str) and value.startswith("$") and value[1:] in handles:
        return handles[value[1:]][0]
    if isinstance(value, str) and value.endswith(".all") and value[1:-4] in handles:
        return list(handles[value[1:-4]])
    if isinstance(value, list):
        out = []
        for v in value:
            if isinstance(v, str) and v.endswith(".all") and v[1:-4] in handles:
                out += handles[v[1:-4]]
            else:
                out.append(substitute(v, handles))
        return out
    if isinstance(value, dict):
        return {k: substitute(v, handles) for k, v in value.items()}
    return value


def run_steps(sess, steps, dry=False, src=None, quiet=False, handles=None):
    """Run normalised steps; return (log lines, handles). Abort with exit 1 on any error."""
    handles = {} if handles is None else handles
    log = []
    for i, s in enumerate(steps):
        if s["kind"] == "sheet":
            # Built at run time: the viewport is centred on the model content drawn so far.
            sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
            from sheet import sheet_steps
            ok, info = sess.tool("inspect_drawing", {"entities": False})
            ext = info.get("extents") or [[0, 0], [100, 100]]
            try:
                gen, meta = sheet_steps(s["params"], ext)
            except ValueError as e:
                die(f"step {i}: {e}")
            gen = normalise(gen)
            errors, _ = static_check(gen)
            if errors:
                die(f"step {i} sheet generated bad steps:\n  " + "\n  ".join(errors))
            run_steps(sess, gen, dry=dry, src=src, quiet=True, handles=handles)
            sess.sheet = meta
            if not quiet:
                print(f"[{i}] sheet: {json.dumps(meta)}")
            continue
        if s["kind"] in ("script", "line"):
            tool = "script" if s["kind"] == "script" else "command_line"
            ok, data = sess.tool(tool, {"text": s["text"]})
            if not ok:
                die(f"step {i} ({tool}) refused: {data}")
            state = data.get("state", data) if isinstance(data, dict) else {}
            out = (data.get("output") if isinstance(data, dict) else None) or []
            log += out
            bad = [l for l in out if PROMPT_ERROR.search(l)]
            if isinstance(data, dict) and data.get("error"):
                bad.append(data["error"])
            if state.get("running"):
                sess.tool("cancel", {})
                bad.append(f"command {state['running']!r} was left waiting at: {state.get('prompt')!r} "
                           "(end it with a blank line / Enter, or answer the prompt)")
            if bad:
                die(f"step {i} ({tool}) had prompt errors:\n  " + "\n  ".join(bad) +
                    "\n  output: " + " | ".join(out[-12:]))
            if not quiet:
                print(f"[{i}] {tool}: " + " | ".join(out)[:300])
            continue
        params = substitute(s["params"], handles)
        if s["cmd"] in PATH_WRITERS or s["cmd"] in ("qsave",):
            p = params.get("path")
            if dry and p:
                print(f"[{i}] {s['cmd']}: skipped in dry run (writes {p})")
                continue
            if s["cmd"] == "qsave" and not p:
                die(f"step {i}: qsave without a path would overwrite the open drawing; give a path")
            if p and src and os.path.abspath(p) == os.path.abspath(src):
                die(f"step {i}: {s['cmd']} would overwrite the source drawing {src}")
        ok, data = sess.tool("execute", {"command": s["cmd"], "params": params})
        if not ok and s.get("ok_if_exists") and "already exists" in str(data):
            ok, data = True, "exists (kept)"
        if not ok:
            die(f"step {i} {s['cmd']} {json.dumps(params)[:200]} failed: {data}")
        if s.get("as"):
            hs = []
            if isinstance(data, dict):
                # mview answers {"viewports": [...]}, layout.new {"viewport": "…"}
                hs = ([data["handle"]] if data.get("handle") else []) + list(data.get("handles") or [])
                hs += list(data.get("viewports") or []) + ([data["viewport"]] if isinstance(
                    data.get("viewport"), str) else [])
            if not hs:
                die(f"step {i} {s['cmd']}: \"as\": {s['as']!r} but the result has no handle: {data}")
            handles[s["as"]] = hs
        if not quiet:
            print(f"[{i}] {s['cmd']}: " + json.dumps(data, ensure_ascii=False)[:300])
    return log, handles


def start(sess, src, metric):
    if src:
        ok, data = sess.tool("open", {"path": os.path.abspath(src)})
        if not ok:
            die(f"cannot open {src}: {data}")
    else:
        sess.tool("new_drawing", {"metric": bool(metric)})


def summary(info):
    lines = [f"entities: {info.get('entityCount')}  {json.dumps(info.get('counts'))}",
             f"extents: {info.get('extents')}",
             "layers: " + ", ".join(f"{l['name']}({l.get('color')}{'' if l.get('on', True) else ',off'})"
                                    for l in info.get("layers", []))]
    for k in ("blocks", "textStyles", "dimStyles", "layouts"):
        if info.get(k):
            lines.append(f"{k}: {info[k]}")
    return "\n".join(lines)


# ---------------------------------------------------------------- images
def light(png_in, png_out, mono=False):
    """Dark-canvas PNG -> plot-like PNG: white paper, neutral (colour 7) lines black,
    coloured lines keep their colour (mono=True: every line black, like monochrome.ctb)."""
    from PIL import Image, ImageChops
    im = Image.open(png_in).convert("RGB")
    bg = im.getpixel((0, 0))
    ink = ImageChops.subtract(im, Image.new("RGB", im.size, bg))       # p - bg, clamped
    r, g, b = ink.split()
    a = ImageChops.lighter(ImageChops.lighter(r, g), b)                  # coverage-ish
    spread = ImageChops.difference(a, ImageChops.darker(ImageChops.darker(r, g), b))
    neutral = spread.point(lambda v: 255 if v < 40 else 0)
    paper = Image.new("RGB", im.size, (255, 255, 255))
    inv_a = a.point(lambda v: 255 - v)
    coloured = Image.merge("RGB", [ImageChops.add(inv_a, c) for c in (r, g, b)])
    black = Image.merge("RGB", [inv_a] * 3)
    out = black if mono else Image.composite(black, coloured, neutral)
    out = Image.composite(paper, out, a.point(lambda v: 255 if v == 0 else 0))
    out.save(png_out)


def sheet_png(pdf, png, width=2400):
    """Raster preview of a plotted PDF (white paper, as printed). Uses Quick Look's
    thumbnailer (qlmanage, a CLI: no app window); falls back to sips (72 dpi)."""
    from PIL import Image
    if not os.path.exists(pdf) or os.path.getsize(pdf) == 0:
        die(f"no PDF to preview: {pdf}")
    tmp = tempfile.mkdtemp()
    try:
        try:
            subprocess.run(["qlmanage", "-t", "-s", str(width), "-o", tmp, pdf],
                           capture_output=True, timeout=60)
        except subprocess.TimeoutExpired:
            pass
        out = os.path.join(tmp, os.path.basename(pdf) + ".png")
        if not os.path.exists(out):
            subprocess.run(["sips", "-s", "format", "png", pdf, "--out", out], capture_output=True)
        im = Image.open(out).convert("RGBA")
        bg = Image.new("RGBA", im.size, (255, 255, 255, 255))
        Image.alpha_composite(bg, im).convert("RGB").save(png)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return png


def render(drawing, png, window=None, light_bg=False, mono=False):
    args = ["convert", drawing, png] + ([f"--window={window}"] if window else [])   # `=` form: a negative x0 is not a flag
    cli(*args)
    if light_bg or mono:
        light(png, png, mono)
    return png


# ---------------------------------------------------------------- subcommands
def load_recipe(a):
    if getattr(a, "recipe", None):
        return normalise(json.load(open(a.recipe)), os.path.dirname(os.path.abspath(a.recipe)))
    if getattr(a, "steps", None):
        return normalise(json.loads(a.steps))
    if getattr(a, "script", None):
        return [{"kind": "script", "text": a.script.replace("\\n", "\n")}]
    if getattr(a, "script_file", None):
        return [{"kind": "script", "text": open(a.script_file).read(), "file": os.path.abspath(a.script_file)}]
    die("give --recipe FILE, --steps JSON, --script TEXT or --script-file F.scr")


def add_recipe_args(p):
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--recipe")
    g.add_argument("--steps")
    g.add_argument("--script")
    g.add_argument("--script-file")


def validate_or_die(steps):
    errors, warnings = static_check(steps)
    for w in warnings:
        print("warning: " + w, file=sys.stderr)
    if errors:
        die("recipe rejected before running:\n  " + "\n  ".join(errors))


def fmt_list(text, allowed, what):
    out = [f.strip().lower().lstrip(".") for f in (text or "").split(",") if f.strip() not in ("", "none")]
    bad = [f for f in out if f not in allowed]
    if bad:
        die(f"{what} formats must be among {sorted(allowed)}, got {bad}")
    return out


def planned_outputs(stem, saves, exports):
    return [f"{stem}.{f}" for f in saves + exports] + [f"{stem}.recipe.json"]


def guard_outputs(src, stem, outs, force):
    sidecar = f"{stem}.recipe.json"
    ours = os.path.exists(sidecar)
    for o in outs:
        if src and os.path.abspath(o) == os.path.abspath(src):
            die(f"refusing to overwrite the source drawing {src}; pick another OUT_STEM")
        if os.path.exists(o) and not ours and not force:
            die(f"{o} exists and was not written by this runner (no {sidecar}); use --force to replace it")


def cmd_apply(a):
    steps = load_recipe(a)
    validate_or_die(steps)
    saves = fmt_list(a.save, SAVE_FORMATS, "--save")
    exports = fmt_list(a.export, EXPORT_FORMATS, "--export")
    stem = re.sub(r"\.(dxf|dwg|png|svg|pdf)$", "", a.out_stem, flags=re.I)
    src = None if a.new else a.src
    if not a.new and not a.src:
        die("give SRC or --new")
    outs = planned_outputs(stem, saves, exports)
    guard_outputs(src, stem, outs, a.force)
    os.makedirs(os.path.dirname(os.path.abspath(stem)), exist_ok=True)
    sess = Session()
    try:
        start(sess, src, a.metric)
        log, handles = run_steps(sess, steps, src=src)
        ok, info = sess.tool("inspect_drawing", {"entities": False})
        native = None
        for f in saves:
            ok, r = sess.tool("save", {"path": os.path.abspath(f"{stem}.{f}")})
            if not ok:
                die(f"save {stem}.{f} failed: {r}")
            native = native or f"{stem}.{f}"
            print(f"saved: {stem}.{f}")
        if sess.sheet and "pdf" in exports:
            # The deliverable is the plotted sheet, not a model-space PDF.
            ok, r = sess.tool("execute", {"command": "plot", "params": {
                "layout": sess.sheet["layout"], "path": os.path.abspath(f"{stem}.pdf"),
                "lineweights": True}})
            if not ok:
                die(f"plot {stem}.pdf failed: {r}")
        tmpdir = None
        if exports and not native:
            tmpdir = tempfile.mkdtemp()
            native = os.path.join(tmpdir, "render.dxf")
            sess.tool("save", {"path": native})
    finally:
        sess.close()
    for f in exports:
        out = f"{stem}.{f}"
        if f == "pdf" and sess.sheet:
            sheet_png(out, f"{stem}_sheet.png")
            print(f"exported: {out} (plotted {sess.sheet['paper']} sheet)\nexported: {stem}_sheet.png")
            continue
        render(native, out, a.window) if f == "png" else cli("convert", native, out,
                                                             *(["--window", a.window] if a.window else []))
        if f == "png" and (a.light or a.mono):
            light(out, out, a.mono)
        print(f"exported: {out}")
    if exports and not saves:
        shutil.rmtree(os.path.dirname(native), ignore_errors=True)
    with open(f"{stem}.recipe.json", "w") as fh:
        json.dump({"source": os.path.abspath(src) if src else None, "new": bool(a.new),
                   "metric": bool(a.metric), "engine": "cadcraft-cli mcp (headless)",
                   "cli_version": cli("--version").stdout.strip(), "steps": steps,
                   "handles": handles, "save": saves, "export": exports, "window": a.window,
                   "sheet": sess.sheet},
                  fh, indent=2, ensure_ascii=False)
    print(f"recipe: {stem}.recipe.json\n")
    if saves:
        # Summarise what the user actually gets: the saved file, read back by the engine.
        back = json.loads(cli("info", f"{stem}.{saves[0]}").stdout)
        if back.get("counts") != info.get("counts") and not sess.sheet:
            print(f"warning: saving changed the entities (session {json.dumps(info.get('counts'))} -> "
                  f"file {json.dumps(back.get('counts'))}); e.g. 0.5.0 writes MULTILEADER as LEADER+MTEXT",
                  file=sys.stderr)
        info = back
        print(f"read back from {stem}.{saves[0]}:")
    print(summary(info))


def cmd_check(a):
    steps = load_recipe(a)
    errors, warnings = static_check(steps)
    for w in warnings:
        print("warning: " + w)
    if errors:
        print("\n".join(errors))
        sys.exit(1)
    if not a.static:
        sess = Session()
        try:
            start(sess, a.src, a.metric)
            run_steps(sess, steps, dry=True, quiet=True)
        finally:
            sess.close()
        print("dry run ok")
    print("ok")


def cmd_oneshot(a):
    steps = load_recipe(a)
    validate_or_die(steps)
    stem = re.sub(r"\.(dxf|dwg|png|svg|pdf)$", "", a.out_stem, flags=re.I)
    saves = fmt_list(a.save, SAVE_FORMATS, "--save")
    exports = fmt_list(a.export, EXPORT_FORMATS, "--export")
    if len(saves) > 1 or len(exports) > 1:
        die("oneshot takes one --save and one --export format (cadcraft-cli run limits)")
    args = ["run"] + ([a.src] if a.src and not a.new else ["--metric"] if a.metric else [])
    for s in steps:
        if s["kind"] == "cmd":
            if any(True for _ in refs_in(s["params"])):
                die("oneshot can't resolve $references; use apply")
            args += ["--cmd", f"{s['cmd']} {json.dumps(s['params'], ensure_ascii=False)}"]
        elif s.get("file"):
            args += ["--script-file", s["file"]]
        else:
            text = s["text"] if s["kind"] == "script" else s["text"] + "\n"
            args += ["--script", text]
    if saves:
        args += ["--save", f"{stem}.{saves[0]}"]
    if exports:
        args += ["--export", f"{stem}.{exports[0]}"]
    if a.window:
        args += ["--window", a.window]
    import shlex
    print("cadcraft-cli " + " ".join(shlex.quote(x) for x in args), flush=True)
    if a.print:
        return
    guard_outputs(None if a.new else a.src, stem, planned_outputs(stem, saves, exports), a.force)
    p = cli(*args, check=False)
    print(p.stdout.strip())
    print(p.stderr.strip(), file=sys.stderr)
    bad = [l for l in p.stderr.splitlines() if PROMPT_ERROR.search(l)]
    if p.returncode or bad:
        die("run failed or printed prompt errors:\n  " + "\n  ".join(bad or [p.stderr.strip()]))


def cmd_describe(a):
    reg, al = registry(), aliases()
    for q in a.ids:
        cid = q if q in reg else al.get(q.lower())
        if not cid:
            print(f"{q}: not found; similar: {[k for k in reg if q.lower()[:4] in k][:10]}\n")
            continue
        c = reg[cid]
        print(f"{cid}  [{' > '.join(c.get('menu') or [])}]  {c.get('label')}"
              f"{'  aliases: ' + ', '.join(c['aliases']) if c.get('aliases') else ''}"
              f"{'  (interactive prompts)' if c.get('interactive') else ''}\n  params: {c['params'] or '{}'}\n"
              f"  keys: {sorted(param_keys(cid))}{'  (open-ended)' if open_ended(cid) else ''}\n")


def cmd_commands(a):
    for cid, c in registry().items():
        if a.filter and a.filter.lower() not in cid and a.filter.lower() not in (c.get("label") or "").lower():
            continue
        print(f"{cid:22} {c.get('label') or '':34} {(c['params'] or '')[:90]}")


def cmd_info(a):
    print(summary(json.loads(cli("info", a.file).stdout)))


def cmd_render(a):
    render(a.file, a.out, a.window, a.light, a.mono)
    print(a.out)


def cmd_compare(a):
    from PIL import Image, ImageDraw, ImageFont
    ims = [Image.open(p).convert("RGB") for p in (a.before, a.after)]
    w = 1200
    ims = [im.resize((w, round(w * im.height / im.width))) for im in ims]
    h = max(im.height for im in ims)
    sheet = Image.new("RGB", (2 * w + 30, h + 60), (245, 245, 245))
    d = ImageDraw.Draw(sheet)
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 28)
    except OSError:
        font = ImageFont.load_default()
    for i, (im, label) in enumerate(zip(ims, ("before", "after"))):
        sheet.paste(im, (10 + i * (w + 10), 50))
        d.text((14 + i * (w + 10), 12), label, fill=(20, 20, 20), font=font)
    sheet.save(a.out)
    print(a.out)


def cmd_template(a):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import templates as T
    if a.action == "test":
        template_test(T, a.id or "./craft-tests/cadcraft/templates")
        return
    if a.action == "list":
        for tid in T.list_ids():
            t = T.load(tid)
            print(f"{tid:16} {t.get('name', '')}\n{'':16} {t.get('use', '')}")
        return
    if not a.id:
        die("give a template ID (cadcraft.py template list)")
    if a.action == "show":
        t = T.load(a.id)
        print(f"{t['id']}: {t.get('name')}\n{t.get('use')}\nvariables:")
        for k, spec in t.get("vars", {}).items():
            print(f"  {k:12} = {json.dumps(spec.get('default'), ensure_ascii=False):34} {spec.get('help', '')}")
        thumb = os.path.join(T.TEMPLATE_DIR, "thumbs", f"{t['id']}.png")
        print(f"preview: {thumb if os.path.exists(thumb) else '(none yet)'}")
        return
    if not a.out:
        die("template apply ID OUT_STEM [--var key=value ...]")
    over = {}
    for kv in a.var or []:
        if "=" not in kv:
            die(f"--var takes key=value, got {kv!r}")
        k, v = kv.split("=", 1)
        over[k] = v
    try:
        steps, env, t = T.build(a.id, over)
    except (KeyError, ValueError) as e:
        die(str(e))
    stem = re.sub(r"\.(dxf|dwg|png|svg|pdf)$", "", a.out, flags=re.I)
    os.makedirs(os.path.dirname(os.path.abspath(stem)), exist_ok=True)
    rin = f"{stem}.recipe.in.json"
    with open(rin, "w", encoding="utf-8") as fh:
        json.dump({"template": a.id, "vars": {k: v for k, v in env.items() if k in t.get("vars", {})},
                   "steps": steps}, fh, indent=1, ensure_ascii=False)
    print(f"recipe: {rin} (template {a.id})")
    ns = argparse.Namespace(recipe=rin, steps=None, script=None, script_file=None, new=True,
                            metric=t.get("metric", True), src=None, out_stem=stem, save=a.save,
                            export=a.export, window=None, light=False, mono=False, force=a.force)
    cmd_apply(ns)
    if not a.no_critic and os.path.exists(f"{stem}.dxf"):
        import critic
        print()
        critic.main([f"{stem}.dxf"] + (["--pdf", f"{stem}.pdf"] if os.path.exists(f"{stem}.pdf") else []))


def template_test(T, outdir):
    """Build every template with its defaults, critique it, write templates/thumbs/<id>.png and
    templates/gallery.png (numbered contact sheet), and print a score table."""
    import critic
    from PIL import Image, ImageDraw, ImageFont
    thumbs = os.path.join(T.TEMPLATE_DIR, "thumbs")
    os.makedirs(thumbs, exist_ok=True)
    rows, ids = [], T.list_ids()
    for tid in ids:
        stem = os.path.join(outdir, tid, tid)
        p = subprocess.run([sys.executable, "-I", os.path.abspath(__file__), "template", "apply", tid, stem,
                            "--no-critic", "--force"], capture_output=True, text=True)
        if p.returncode:
            rows.append((tid, None, "build failed: " + (p.stderr or p.stdout).strip()[-300:]))
            continue
        R = critic.critique(f"{stem}.dxf", f"{stem}.pdf")
        sev = [i["check"] for i in R.issues.values() if i["severity"] == "severe"]
        with open(f"{stem}.critic.txt", "w") as fh:
            fh.write(critic.format_report(R, f"{stem}.dxf") + "\n")
        im = Image.open(f"{stem}_sheet.png").convert("RGB")
        im.thumbnail((1200, 1200))
        im.save(os.path.join(thumbs, f"{tid}.png"))
        rows.append((tid, R.score(), ", ".join(sev) or "-"))
    # contact sheet: 3 columns, numbered labels
    try:
        font = ImageFont.truetype("/System/Library/Fonts/Helvetica.ttc", 30)
    except OSError:
        font = ImageFont.load_default()
    cells = [(i + 1, tid) for i, tid in enumerate(ids) if os.path.exists(os.path.join(thumbs, f"{tid}.png"))]
    cw, ch, cols = 800, 566 + 56, 3
    sheet = Image.new("RGB", (cols * cw + (cols + 1) * 20, ((len(cells) + cols - 1) // cols) * (ch + 20) + 20),
                      (236, 236, 236))
    d = ImageDraw.Draw(sheet)
    for k, (n, tid) in enumerate(cells):
        x, y = 20 + (k % cols) * (cw + 20), 20 + (k // cols) * (ch + 20)
        im = Image.open(os.path.join(thumbs, f"{tid}.png")).convert("RGB")
        im.thumbnail((cw, 566))
        sheet.paste(im, (x, y + 56))
        score = next((r[1] for r in rows if r[0] == tid), None)
        d.text((x + 4, y + 12), f"{n}. {tid}   critic {score}/100", fill=(20, 20, 20), font=font)
    sheet.save(os.path.join(T.TEMPLATE_DIR, "gallery.png"))
    print(f"{'#':>2} {'template':16} score  severe")
    for i, (tid, sc, sev) in enumerate(rows, 1):
        print(f"{i:>2} {tid:16} {sc if sc is not None else 'FAIL':>5}  {sev}")
    print(f"gallery: {os.path.join(T.TEMPLATE_DIR, 'gallery.png')}")


def cmd_critic(a):
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import critic
    args = [a.file] + (["--pdf", a.pdf] if a.pdf else []) + (["--json"] if a.json else []) + \
        (["--scale", a.scale] if a.scale else [])
    sys.exit(critic.main(args))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("apply", "oneshot"):
        p = sub.add_parser(name)
        p.add_argument("src", nargs="?")
        p.add_argument("out_stem")
        p.add_argument("--new", action="store_true")
        p.add_argument("--metric", action="store_true")
        add_recipe_args(p)
        p.add_argument("--save", default="dxf")
        p.add_argument("--export", default="png")
        p.add_argument("--window")
        p.add_argument("--light", action="store_true")
        p.add_argument("--mono", action="store_true")
        p.add_argument("--force", action="store_true")
        if name == "oneshot":
            p.add_argument("--print", action="store_true")
        p.set_defaults(fn=cmd_apply if name == "apply" else cmd_oneshot)
    p = sub.add_parser("check")
    add_recipe_args(p)
    p.add_argument("--src")
    p.add_argument("--metric", action="store_true")
    p.add_argument("--static", action="store_true")
    p.set_defaults(fn=cmd_check)
    p = sub.add_parser("describe")
    p.add_argument("ids", nargs="+")
    p.set_defaults(fn=cmd_describe)
    p = sub.add_parser("commands")
    p.add_argument("filter", nargs="?")
    p.set_defaults(fn=cmd_commands)
    p = sub.add_parser("info")
    p.add_argument("file")
    p.set_defaults(fn=cmd_info)
    p = sub.add_parser("render")
    p.add_argument("file")
    p.add_argument("out")
    p.add_argument("--window")
    p.add_argument("--light", action="store_true")
    p.add_argument("--mono", action="store_true")
    p.set_defaults(fn=cmd_render)
    p = sub.add_parser("template")
    p.add_argument("action", choices=["list", "show", "apply", "test"])
    p.add_argument("id", nargs="?")
    p.add_argument("out", nargs="?")
    p.add_argument("--var", action="append", help="key=value (repeatable)")
    p.add_argument("--save", default="dxf")
    p.add_argument("--export", default="png,pdf")
    p.add_argument("--force", action="store_true")
    p.add_argument("--no-critic", action="store_true")
    p.set_defaults(fn=cmd_template)
    p = sub.add_parser("critic")
    p.add_argument("file", help="DXF (the saved drawing)")
    p.add_argument("--pdf", help="the plotted sheet PDF (adds raster checks)")
    p.add_argument("--scale", help="intended plot scale for a model-only drawing, e.g. 1:50")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_critic)
    p = sub.add_parser("compare")
    p.add_argument("before")
    p.add_argument("after")
    p.add_argument("out")
    p.set_defaults(fn=cmd_compare)
    a = ap.parse_args()
    if a.cmd in ("apply", "oneshot") and a.new and a.src:
        die("with --new give only OUT_STEM (no SRC)")
    a.fn(a)


if __name__ == "__main__":
    main()
