"""Parameterized recipe templates for CADCraft (templates/<id>.json).

Template file:
  {"id": "plate", "name": "...", "use": "...", "metric": true,
   "vars": {"width": {"default": 160, "help": "plate width, mm"}, ...},
   "steps": [ ...recipe steps with {{placeholders}}... ]}

Placeholders: "{{expr}}" where expr is arithmetic over the vars (+ - * / // % **, parentheses,
comparisons, `a if c else b`, min max abs round sqrt sin cos tan radians degrees int float str
len). A string that is exactly one placeholder becomes the expression's value (number, list,
bool), so ["circle", {"diameter": "{{hole_d}}"}] gets a number. Mixed strings are interpolated:
"4X\\~%%c{{hole_d}}\\~THRU". Numbers are printed without trailing zeros.

Built-in vars: k = model units per paper millimetre for `scale` and `units` (1 at 1:1 in mm,
50 at 1:50 in mm, 0.5 at 1:500 in metres): multiply every paper size (text 3.5 mm, arrow 3 mm,
dimension offsets 10 mm) by k so it plots at that size.

A step may carry "if": "{{expr}}"; it is dropped when the expression is false.
"""
import ast
import json
import math
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_DIR = os.path.join(os.path.dirname(HERE), "templates")

_FUNCS = {"min": min, "max": max, "abs": abs, "round": round, "sqrt": math.sqrt, "sin": math.sin,
          "cos": math.cos, "tan": math.tan, "radians": math.radians, "degrees": math.degrees,
          "int": int, "float": float, "str": str, "len": len, "pi": math.pi}
_NODES = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Compare, ast.BoolOp, ast.IfExp, ast.Call,
          ast.Name, ast.Load, ast.Constant, ast.List, ast.Tuple, ast.Subscript, ast.Index,
          ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow, ast.USub, ast.UAdd,
          ast.Not, ast.And, ast.Or, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In,
          ast.NotIn)
PH = re.compile(r"\{\{((?:(?!\{\{|\}\}).)+)\}\}")


def safe_eval(expr, env):
    tree = ast.parse(expr.strip(), mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, _NODES):
            raise ValueError(f"not allowed in template expression: {expr!r} ({type(node).__name__})")
        if isinstance(node, ast.Call) and not (isinstance(node.func, ast.Name) and node.func.id in _FUNCS):
            raise ValueError(f"function not allowed: {expr!r}")
        if isinstance(node, ast.Name) and node.id not in env and node.id not in _FUNCS:
            raise ValueError(f"unknown variable {node.id!r} in {expr!r}")
    return eval(compile(tree, "<template>", "eval"), {"__builtins__": {}}, {**_FUNCS, **env})


def fmt_num(v):
    if isinstance(v, float):
        v = round(v, 6)
        return str(int(v)) if v == int(v) else f"{v:g}"
    return str(v)


def fill(value, env):
    if isinstance(value, str):
        m = PH.fullmatch(value.strip())
        if m:
            v = safe_eval(m.group(1), env)
            return round(v, 6) if isinstance(v, float) else v
        return PH.sub(lambda mm: fmt_num(safe_eval(mm.group(1), env)), value)
    if isinstance(value, list):
        out = []
        for v in value:
            if isinstance(v, dict) and "if" in v:
                if not fill(v["if"], env):
                    continue
                v = {k: x for k, x in v.items() if k != "if"}
            out.append(fill(v, env))
        return out
    if isinstance(value, dict):
        return {k: fill(v, env) for k, v in value.items()}
    return value


def coerce(raw, default):
    if isinstance(default, bool):
        return str(raw).lower() in ("1", "true", "yes", "on")
    if isinstance(default, (int, float)):
        f = float(raw)
        return int(f) if f == int(f) and isinstance(default, int) else f
    if isinstance(default, (list, dict)):
        return json.loads(raw)
    return raw


def list_ids():
    return sorted(f[:-5] for f in os.listdir(TEMPLATE_DIR) if f.endswith(".json"))


def load(tid):
    path = os.path.join(TEMPLATE_DIR, f"{tid}.json")
    if not os.path.exists(path):
        raise FileNotFoundError(f"no template {tid!r}; have {list_ids()}")
    with open(path, encoding="utf-8") as fh:
        t = json.load(fh)
    if t.get("extends"):
        # a variant: the base template's steps and vars, with this file's var defaults on top
        base = load(t["extends"])
        merged = dict(base)
        merged.update({k: v for k, v in t.items() if k not in ("vars", "extends")})
        vars_ = {k: dict(v) for k, v in base.get("vars", {}).items()}
        for k, v in t.get("vars", {}).items():
            vars_.setdefault(k, {}).update(v)
        merged["vars"] = vars_
        return merged
    return t


def env_for(t, overrides):
    env = {}
    for name, spec in t.get("vars", {}).items():
        env[name] = spec.get("default") if isinstance(spec, dict) else spec
    for k, v in overrides.items():
        if k not in env:
            raise KeyError(f"template {t['id']} has no variable {k!r}; variables: {sorted(env)}")
        env[k] = coerce(v, env[k])
    if "scale" in env:
        import sheet
        env["k"] = sheet.model_per_paper_mm(env["scale"], env.get("units", "mm"))
    for name, expr in (t.get("derived") or {}).items():   # computed helpers, in order
        env[name] = fill(expr, env)
    return env


def build(tid, overrides):
    """(recipe steps, env, template) for a template and --var overrides."""
    t = load(tid)
    env = env_for(t, overrides)
    return fill(t["steps"], env), env, t
