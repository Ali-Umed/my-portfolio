"""Talk to a running CADCraft desktop app over its JSON-lines control channel
(docs/control-protocol.md). Use only with the user's OK; see SKILL.md "Live app".

  cadcraft_control.py status [--port 7979]
      Is CADCraft running, and does the port answer?
  cadcraft_control.py launch [--port 7979] [FILE.dxf|FILE.dwg]
      Start /Applications/CADCraft.app with `--control PORT` (only when CADCraft is NOT
      running: the user must save and quit first). Waits until the channel answers.
  cadcraft_control.py call METHOD [PARAMS_JSON] [--port 7979]
      One request, e.g.
        call cmdline.input '{"text":"circle 0,0 5"}'           type at the command line
        call engine.execute '{"command":"line","params":{"points":[[0,0],[10,0]]}}'
        call drawing.inspect '{"entities":false}'
        call ui.render '{"path":"/abs/shot.png"}'              headless render of the drawing
        call ui.screenshot '{"path":"/abs/window.png"}'        the window (needs a visible frame)
        call app.open '{"path":"/abs/in.dxf"}'   /   call app.save '{"path":"/abs/out.dxf"}'
  cadcraft_control.py script FILE.scr [--port 7979]   cmdline.script with the file's text
  cadcraft_control.py batch FILE.json [--port 7979]
      [{"method":..., "params":...}, ...] in order on one connection; stops at the first error
      or the first command line that reports an `error`.

The channel has NO authentication and NO folder restrictions (unlike PhotoCraft): any local
process can drive the app while the port is open, and app.open/app.save take any path. Open it
only for the task and quit the control-mode app afterwards.
"""
import argparse
import json
import os
import socket
import subprocess
import sys
import time

APP_BIN = "/Applications/CADCraft.app/Contents/MacOS/CADCraft"
DEFAULT_PORT = 7979


class Conn:
    def __init__(self, port, timeout=70):
        self.s = socket.create_connection(("127.0.0.1", port), timeout=timeout)
        self.f = self.s.makefile("rwb")
        self.n = 0

    def call(self, method, params=None):
        self.n += 1
        self.f.write((json.dumps({"id": self.n, "method": method, "params": params or {}}) + "\n").encode())
        self.f.flush()
        while True:
            line = self.f.readline()
            if not line:
                raise SystemExit("connection closed by CADCraft")
            msg = json.loads(line)
            if msg.get("id") == self.n:
                return msg


def running():
    return subprocess.run(["pgrep", "-x", "CADCraft"], capture_output=True).returncode == 0


def answers(port):
    try:
        return Conn(port, timeout=3).call("cmdline.state").get("ok", False)
    except OSError:
        return False


def failed(reply):
    """A reply is a failure when ok is false, or a typed line was refused (ok stays true)."""
    if not reply.get("ok"):
        return reply.get("error") or "error"
    res = reply.get("result")
    if isinstance(res, dict) and res.get("error"):
        return res["error"]
    return None


def show(reply):
    text = json.dumps(reply, ensure_ascii=False)
    if len(text) > 4000 and isinstance(reply.get("result"), dict) and "pngBase64" in reply["result"]:
        reply = dict(reply, result={k: v for k, v in reply["result"].items() if k != "pngBase64"})
        text = json.dumps(reply, ensure_ascii=False)
    print(text if len(text) < 4000 else text[:4000] + " …(truncated)")


def cmd_status(a):
    print(json.dumps({"running": running(), "port": a.port, "controlAnswers": answers(a.port)}))


def cmd_launch(a):
    if running():
        sys.exit("CADCraft is already running. Ask the user to save their drawings and quit it, "
                 "then launch again (control mode only starts at launch).")
    if not os.path.exists(APP_BIN):
        sys.exit(f"{APP_BIN} not found; is CADCraft installed in /Applications?")
    if answers(a.port):
        sys.exit(f"something already answers on 127.0.0.1:{a.port}; pick another --port")
    args = [APP_BIN, "--control", str(a.port)] + ([os.path.abspath(a.file)] if a.file else [])
    subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
    for _ in range(60):
        time.sleep(0.5)
        if answers(a.port):
            print(f"CADCraft control ready on 127.0.0.1:{a.port} (unauthenticated: quit it when done)")
            return
    sys.exit("CADCraft did not answer on the control port within 30 s")


def cmd_call(a):
    reply = Conn(a.port).call(a.method, json.loads(a.params) if a.params else {})
    show(reply)
    if failed(reply):
        sys.exit(1)


def cmd_script(a):
    reply = Conn(a.port).call("cmdline.script", {"text": open(a.file).read()})
    show(reply)
    if failed(reply):
        sys.exit(1)


def cmd_batch(a):
    c = Conn(a.port)
    for step in json.load(open(a.file)):
        reply = c.call(step["method"], step.get("params"))
        show(reply)
        err = failed(reply)
        if err:
            sys.exit(f"stopped: {err}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--port", type=int, default=DEFAULT_PORT)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("status").set_defaults(fn=cmd_status)
    p = sub.add_parser("launch")
    p.add_argument("file", nargs="?")
    p.set_defaults(fn=cmd_launch)
    p = sub.add_parser("call")
    p.add_argument("method")
    p.add_argument("params", nargs="?")
    p.set_defaults(fn=cmd_call)
    p = sub.add_parser("script")
    p.add_argument("file")
    p.set_defaults(fn=cmd_script)
    p = sub.add_parser("batch")
    p.add_argument("file")
    p.set_defaults(fn=cmd_batch)
    a = ap.parse_args()
    a.fn(a)


if __name__ == "__main__":
    main()
