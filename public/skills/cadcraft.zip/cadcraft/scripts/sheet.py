"""ISO drawing sheet for CADCraft: paper-space frame, zones, title block, notes, viewport.

Builds recipe steps for a paper-space layout at true millimetres:
  - ISO 5457 trimmed sheet (A4..A0), frame 20 mm left (filing) / 10 mm elsewhere, 0.7 mm,
    centring marks and grid-reference zones (numbers across, letters down)
  - ISO 7200-style title block, 180 mm wide, bottom-right, outline 0.7 mm, rules 0.25 mm,
    labels 1.8 mm, values 3.5 mm, title 7 mm, drawing number 5 mm (ISO 3098 heights)
  - optional general notes, north arrow and graphic scale bar above the title block
  - one viewport (no-plot layer) at an ISO 5455 scale, centred on the model content in the
    free area left of / above the title block; refuses if the content would not fit.
Kurdish (or any RTL) labels and values are drawn with shaped_text (filled outlines), because
0.5.0 TEXT cannot shape Arabic script.

Used by the runner as a recipe step:  {"sheet": {...params...}}  (see SHEET_KEYS).
"""
import math
import re

PAPER = {"A4": (210, 297), "A3": (297, 420), "A2": (420, 594), "A1": (594, 841), "A0": (841, 1189)}
# zones along (short side, long side), ISO 5457
ZONES = {"A4": (4, 6), "A3": (6, 8), "A2": (8, 12), "A1": (12, 16), "A0": (16, 24)}
ISO_SCALES = ["50:1", "20:1", "10:1", "5:1", "2:1", "1:1", "1:2", "1:5", "1:10", "1:20", "1:50",
              "1:100", "1:200", "1:500", "1:1000", "1:2000", "1:5000", "1:10000"]
UNIT_MM = {"mm": 1.0, "cm": 10.0, "m": 1000.0, "in": 25.4}

TB_W = 180.0
ROWS = [9.0, 9.0, 14.0, 11.0]          # top to bottom: people, data, title, identification
TB_H = sum(ROWS)

LABELS = {
    "en": {"drawn": "DRAWN", "checked": "CHECKED", "approved": "APPROVED", "material": "MATERIAL",
           "scale": "SCALE", "projection": "PROJECTION", "size": "SIZE",
           "tolerance": "GENERAL TOLERANCES / DIMENSIONS IN mm", "title": "TITLE",
           "owner": "OWNER", "dwg_no": "DRAWING No.", "rev": "REV", "date": "DATE",
           "sheet": "SHEET", "project": "PROJECT", "client": "CLIENT / LOCATION",
           "status": "STATUS", "notes": "NOTES", "north": "N"},
    "ku": {"drawn": "نەخشەکێش", "checked": "پشکنەر", "approved": "پەسەندکەر", "material": "کەرەستە",
           "scale": "پێوەر", "projection": "پرۆجێکشن", "size": "قەبارە",
           "tolerance": "تۆلێرانسی گشتی / پێوانەکان بە ملم", "title": "ناونیشان",
           "owner": "خاوەن", "dwg_no": "ژمارەی نەخشە", "rev": "وەشان", "date": "بەروار",
           "sheet": "پەڕە", "project": "پڕۆژە", "client": "خاوەنکار / شوێن", "status": "دۆخ",
           "notes": "تێبینییەکان", "north": "باکوور"},
}

SHEET_KEYS = {"paper", "landscape", "scale", "units", "kind", "lang", "ku_font", "zones",
              "view_center", "fields", "notes", "north", "scalebar", "layout", "content_gap"}

LAYERS = [  # name, colour, lineweight, plot
    ("G-SHEET-FRAM", 7, 0.7, True), ("G-SHEET-ZONE", 7, 0.25, True),
    ("G-TTLB-BORD", 7, 0.7, True), ("G-TTLB-LINE", 7, 0.25, True),
    ("G-TTLB-LABL", 251, 0.18, True), ("G-TTLB-TEXT", 7, 0.35, True),
    ("G-TTLB-TITL", 7, 0.5, True), ("G-ANNO-NOTE", 7, 0.25, True),
    ("G-ANNO-SYMB", 7, 0.35, True), ("G-VPRT", 8, 0.13, False)]


def parse_scale(s):
    """"1:50" -> paper/model ratio 0.02 (paper mm per drawing mm)."""
    m = re.fullmatch(r"\s*(\d+(?:\.\d+)?)\s*:\s*(\d+(?:\.\d+)?)\s*", str(s))
    if not m:
        raise ValueError(f"scale must look like 1:50 or 2:1, got {s!r}")
    return float(m.group(1)) / float(m.group(2))


def model_per_paper_mm(scale, units="mm"):
    """Model units per paper millimetre: multiply paper sizes (text 3.5 mm) by this."""
    return 1.0 / (parse_scale(scale) * UNIT_MM[units])


def is_rtl(t):
    return bool(re.search(r"[֐-ࣿיִ-﷿ﹰ-﻿]", t or ""))


class Builder:
    def __init__(self, p):
        self.p = p
        self.steps = []
        self.lang = p.get("lang", "en")
        self.font = p.get("ku_font")

    def add(self, *steps):
        self.steps += list(steps)

    def layer(self, name):
        self.add(["layer.current", {"name": name}])

    def line(self, a, b):
        self.add(["line", {"points": [list(map(float, a)), list(map(float, b))]}])

    def rect(self, x0, y0, x1, y1):
        self.add(["pline", {"vertices": [[x0, y0], [x1, y0], [x1, y1], [x0, y1]], "closed": True}])

    def text(self, at, s, h, justify="L", layer=None):
        """Latin -> TEXT (stroke font). RTL -> shaped outlines (the real string is kept on a
        no-plot layer)."""
        if s is None or s == "":
            return
        s = str(s)
        if is_rtl(s):
            # Arabic script reads small: draw it 1.4x the Latin cap height for equal presence.
            self.add({"shaped_text": s, "at": list(at), "height": round(h * 1.0, 3),
                      "font": self.font, "justify": justify, "layer": layer})
        else:
            if layer:
                self.layer(layer)
            self.add(["text", {"at": list(at), "text": s, "height": h, "justify": justify}])

    def label(self, key):
        if self.lang == "ku":
            return [LABELS["ku"][key]]
        if self.lang in ("en+ku", "ku+en"):
            return [LABELS["en"][key], LABELS["ku"][key]]
        return [LABELS["en"][key]]


def frame_rect(paper, landscape):
    w, h = PAPER[paper]
    if landscape:
        w, h = h, w
    return w, h, (20.0, 10.0, w - 10.0, h - 10.0)


def sheet_steps(p, model_extents):
    """Steps for the whole sheet. p: params (see SHEET_KEYS); model_extents [[x0,y0],[x1,y1]]."""
    bad = set(p) - SHEET_KEYS
    if bad:
        raise ValueError(f"sheet: unknown keys {sorted(bad)}; known: {sorted(SHEET_KEYS)}")
    paper = p.get("paper", "A3").upper()
    landscape = bool(p.get("landscape", paper != "A4"))
    scale = str(p.get("scale", "1:1"))
    if scale not in ISO_SCALES:
        raise ValueError(f"sheet: scale {scale} is not an ISO 5455 scale {ISO_SCALES}")
    units = p.get("units", "mm")
    kind = p.get("kind", "mech")
    layout = p.get("layout", "Layout1")
    f = dict(p.get("fields") or {})
    W, H, (fx0, fy0, fx1, fy1) = frame_rect(paper, landscape)
    b = Builder(p)

    for name, col, lw, plot in LAYERS:
        b.add({"cmd": "layer.new", "params": {"name": name, "color": col, "lineweight": lw},
               "ok_if_exists": True})
        if not plot:
            b.add(["layer.set", {"name": name, "plot": False}])
    b.add(["style", {"name": "Standard", "current": True}],
          ["pagesetup", {"layout": layout, "paper": paper, "landscape": landscape,
                         "margins": [0, 0, 0, 0], "lineweights": True}],
          ["layout.set", {"name": layout}])

    # ---- frame, centring marks, zones (ISO 5457)
    b.layer("G-SHEET-FRAM")
    b.rect(fx0, fy0, fx1, fy1)
    cx, cy = (fx0 + fx1) / 2, (fy0 + fy1) / 2
    b.line((cx, 0), (cx, fy0 + 5)); b.line((cx, H), (cx, fy1 - 5))
    b.line((0, cy), (fx0 + 5, cy)); b.line((W, cy), (fx1 - 5, cy))
    if p.get("zones", True):
        b.layer("G-SHEET-ZONE")
        nshort, nlong = ZONES.get(paper, (4, 6))
        ncol, nrow = (nlong, nshort) if landscape else (nshort, nlong)
        zh = 2.5 if paper == "A4" else 3.5
        dx, dy = (fx1 - fx0) / ncol, (fy1 - fy0) / nrow
        for i in range(ncol + 1):
            x = fx0 + i * dx
            if 0 < i < ncol:
                b.line((x, fy0), (x, fy0 - 5)); b.line((x, fy1), (x, fy1 + 5))
            if i < ncol:
                xm = x + dx / 2
                b.text((xm, fy1 + 5), str(i + 1), zh, "MC")
                b.text((xm, fy0 - 5), str(i + 1), zh, "MC")
        letters = "ABCDEFGHJKLMNPQRSTUVWXYZ"
        for j in range(nrow + 1):
            y = fy1 - j * dy
            if 0 < j < nrow:
                b.line((fx0, y), (fx0 - 5, y)); b.line((fx1, y), (fx1 + 5, y))
            if j < nrow:
                ym = y - dy / 2
                b.text((fx0 - 10, ym), letters[j], zh, "MC")
                b.text((fx1 + 5, ym), letters[j], zh, "MC")

    # ---- title block (ISO 7200 style)
    x0, y0 = fx1 - TB_W, fy0
    ys = [y0 + TB_H]
    for r in ROWS:
        ys.append(ys[-1] - r)              # ys[0]=top ... ys[4]=bottom
    b.layer("G-TTLB-BORD")
    b.rect(x0, y0, fx1, y0 + TB_H)
    b.layer("G-TTLB-LINE")
    for y in ys[1:4]:
        b.line((x0, y), (fx1, y))
    c = [x0 + 30 * i for i in range(7)]   # 6 columns of 30 mm
    # row 1 (people) and row 2 (data): 30 | 30 | 30 | 90
    for r in (0, 1):
        for xi in (c[1], c[2], c[3]):
            b.line((xi, ys[r]), (xi, ys[r + 1]))
    # row 3 (title 120 | owner 60)
    b.line((c[4], ys[2]), (c[4], ys[3]))
    # row 4 (dwg no 90 | rev 15 | date 45 | sheet 30)
    for xi in (c[3], c[3] + 15, c[5]):
        b.line((xi, ys[3]), (xi, ys[4]))

    mech = kind == "mech"
    cells = [  # key, x0, x1, row index, value key, value height, layer
        ("drawn", c[0], c[1], 0, "drawn", 3.5, "G-TTLB-TEXT"),
        ("checked", c[1], c[2], 0, "checked", 3.5, "G-TTLB-TEXT"),
        ("approved", c[2], c[3], 0, "approved", 3.5, "G-TTLB-TEXT"),
        ("material" if mech else "project", c[3], c[6], 0, "material" if mech else "project", 3.5,
         "G-TTLB-TEXT"),
        ("scale", c[0], c[1], 1, "scale", 3.5, "G-TTLB-TEXT"),
        ("projection" if mech else "status", c[1], c[2], 1, None if mech else "status", 3.5,
         "G-TTLB-TEXT"),
        ("size", c[2], c[3], 1, "size", 3.5, "G-TTLB-TEXT"),
        ("tolerance" if mech else "client", c[3], c[6], 1, "tolerance" if mech else "client", 3.5,
         "G-TTLB-TEXT"),
        ("title", c[0], c[4], 2, "title", 7.0, "G-TTLB-TITL"),
        ("owner", c[4], c[6], 2, "owner", 3.5, "G-TTLB-TEXT"),
        ("dwg_no", c[0], c[3], 3, "dwg_no", 5.0, "G-TTLB-TITL"),
        ("rev", c[3], c[3] + 15, 3, "rev", 3.5, "G-TTLB-TEXT"),
        ("date", c[3] + 15, c[5], 3, "date", 3.5, "G-TTLB-TEXT"),
        ("sheet", c[5], c[6], 3, "sheet", 3.5, "G-TTLB-TEXT"),
    ]
    f.setdefault("scale", scale)
    f.setdefault("size", paper)
    rtl_sheet = b.lang == "ku"
    for key, xa, xb, r, vkey, vh, vlayer in cells:
        top, bot = ys[r], ys[r + 1]
        labels = b.label(key)
        lab_h = 1.8
        # label: top-left, 1.2 mm below the rule; Kurdish labels right-aligned (RTL reading)
        lab_base = top - 1.2 - lab_h
        if len(labels) == 1:
            if is_rtl(labels[0]):
                b.text((xb - 1.5, lab_base), labels[0], lab_h, "R", "G-TTLB-LABL")
            else:
                b.text((xa + 1.5, lab_base), labels[0], lab_h, "L", "G-TTLB-LABL")
        else:   # bilingual: English left, Kurdish right (only where both fit)
            b.text((xa + 1.5, lab_base), labels[0], lab_h, "L", "G-TTLB-LABL")
            from shaped_text import outlines
            try:
                ku_w = outlines(labels[1], lab_h, b.font)[1]
            except Exception:
                ku_w = 0.6 * lab_h * len(labels[1])
            if (xb - xa) - 3 >= 0.9 * lab_h * len(labels[0]) + ku_w + 3:
                b.text((xb - 1.5, lab_base), labels[1], lab_h, "R", "G-TTLB-LABL")
        if vkey is None:   # projection symbol (first angle, ISO 5456-2)
            projection_symbol(b, (xa + xb) / 2, bot + 2.9)
            continue
        val = f.get(vkey, "")
        if val in (None, ""):
            continue
        val = str(val)
        h = vh
        # fit the cell: the stroke font advances ~0.9 h per character; step down the ISO
        # series (7 > 5 > 3.5 > 2.5) rather than overflow
        if not is_rtl(val):
            for cand in [x for x in (7.0, 5.0, 3.5, 2.5) if x <= vh]:
                h = cand
                if len(val) * 0.9 * cand <= (xb - xa) - 4:
                    break
        base = bot + (2.2 if r == 2 else 1.6)
        if is_rtl(val):
            # measure the shaped line itself and step down the ISO heights until it fits
            from shaped_text import outlines
            for cand in [x for x in (5.0, 3.5, 2.5, 1.8) if x <= max(vh, 3.5)]:
                h = cand
                try:
                    if outlines(val, cand, b.font)[1] <= (xb - xa) - 5:
                        break
                except Exception:
                    break
            b.text((xb - 2.5, base), val, h, "R", vlayer)
        else:
            b.text((xa + 2.5, base), val, h, "L", vlayer)
    if f.get("subtitle"):
        sub = str(f["subtitle"])
        if is_rtl(sub):
            b.text((c[4] - 2.5, ys[2] - 1.5 - 2.5 - 2.4), sub, 2.5, "R", "G-TTLB-TEXT")
        else:
            b.text((c[0] + 32, ys[2] - 1.5 - 1.8), sub, 1.8, "L", "G-TTLB-LABL")

    # ---- notes, north arrow, scale bar. On wide sheets they sit in the strip left of the
    # title block (same height), so the drawing keeps the full width above; on A4 portrait
    # (no strip) they stack above the title block.
    notes = [str(n) for n in (p.get("notes") or [])]
    has_sym = p.get("north") is not None or bool(p.get("scalebar"))
    strip_w = x0 - fx0
    # the strip holds 6 note lines, or 3 when a scale bar shares it
    use_strip = strip_w >= 150 and len(notes) <= (3 if p.get("scalebar") else 6)
    pitch, nh = 5.0, 2.5
    reserved_top = y0 + TB_H
    if use_strip:
        sx0, sx1, top = fx0 + 6, x0 - 6, y0 + TB_H - 4
        if has_sym:
            sym_x = sx1 - 14
            if p.get("north") is not None:
                north_arrow(b, sym_x, y0 + TB_H / 2 + 2, float(p.get("north") or 0), b.lang)
                sx1 = sym_x - 14
            notes_right = sx1  # notes sit above the scale bar, so they keep this width
            if p.get("scalebar"):
                bar_w = scale_bar_width(scale)
                scale_bar(b, sx1 - bar_w - 4, y0 + 7, scale, units, b.lang)
                sx1 = sx1 - bar_w - 12
        if notes:
            notes_block(b, notes, sx0, notes_right if has_sym else sx1, top, nh, pitch)
    else:
        stack_y = y0 + TB_H + 6
        if notes:
            top = stack_y + pitch * len(notes) + 7
            notes_block(b, notes, x0 + 2, fx1 - 2, top, nh, pitch)
            stack_y = top + 4
        if has_sym:
            if p.get("scalebar"):
                scale_bar(b, x0 + 4, stack_y + 6, scale, units, b.lang)
            if p.get("north") is not None:
                north_arrow(b, fx1 - 14, stack_y + 11, float(p.get("north") or 0), b.lang)
            stack_y += 24
        reserved_top = stack_y if (notes or has_sym) else y0 + TB_H

    # ---- viewport on a no-plot layer, scaled and centred on the model content
    (mx0, my0), (mx1, my1) = model_extents
    s = parse_scale(scale) * UNIT_MM[units]          # paper mm per model unit
    cw, ch = (mx1 - mx0) * s, (my1 - my0) * s
    gap = float(p.get("content_gap", 8))
    regions = {"top": (fx0 + gap, reserved_top + gap, fx1 - gap, fy1 - gap)}
    if not (use_strip and (notes or has_sym)):
        regions["left"] = (fx0 + gap, fy0 + gap, x0 - gap, fy1 - gap)
    best, best_m = None, -1e9
    for name, (ax0, ay0, ax1, ay1) in regions.items():
        m = min((ax1 - ax0) - cw, (ay1 - ay0) - ch)
        if m > best_m:
            best, best_m = name, m
    if best_m < 0:
        ax0, ay0, ax1, ay1 = regions[best]
        need = max(cw / max(ax1 - ax0, 1), ch / max(ay1 - ay0, 1))
        raise ValueError(
            f"sheet: content {cw:.0f}x{ch:.0f} mm at {scale} does not fit the free area of {paper} "
            f"(best region {ax1 - ax0:.0f}x{ay1 - ay0:.0f} mm). Use a smaller scale (about "
            f"{need:.2f}x smaller), a larger sheet, or fewer notes.")
    ax0, ay0, ax1, ay1 = regions[best]
    vc = p.get("view_center")
    if vc is None:
        vc = [(mx0 + mx1) / 2, (my0 + my1) / 2]
    pcx, pcy = (ax0 + ax1) / 2, (ay0 + ay1) / 2   # paper point that shows the view centre
    b.layer("G-VPRT")
    # viewport = the whole frame interior; its view is shifted so vc lands at (pcx, pcy)
    vx0, vy0, vx1, vy1 = fx0 + 1, fy0 + 1, fx1 - 1, fy1 - 1
    vcx, vcy = (vx0 + vx1) / 2, (vy0 + vy1) / 2
    centre = [vc[0] + (vcx - pcx) / s, vc[1] + (vcy - pcy) / s]
    b.add({"cmd": "mview", "params": {"p1": [vx0, vy0], "p2": [vx1, vy1]}, "as": "sheet_vp"},
          ["viewport.set", {"handle": "$sheet_vp", "scale": scale if units == "mm" else s,
                            "center": [round(centre[0], 4), round(centre[1], 4)],
                            "locked": True}])
    b.add(["layer.current", {"name": "G-TTLB-TEXT"}])
    meta = {"layout": layout, "paper": paper, "landscape": landscape, "scale": scale,
            "frame": [fx0, fy0, fx1, fy1], "title_block": [x0, y0, fx1, y0 + TB_H],
            "region": best, "fit_margin_mm": round(best_m, 1)}
    return b.steps, meta


def notes_block(b, notes, xl, xr, top, nh, pitch):
    """Heading + numbered notes; Kurdish notes are right-aligned at xr."""
    rtl = any(is_rtl(n) for n in notes) or b.lang == "ku"
    if rtl:
        b.text((xr, top - 3.5), LABELS["ku"]["notes"], 3.5, "R", "G-ANNO-NOTE")
    else:
        b.text((xl, top - 3.5), LABELS["en"]["notes"], 3.5, "L", "G-ANNO-NOTE")
    for i, n in enumerate(notes):
        y = top - 3.5 - 6.5 - i * pitch
        if is_rtl(n):   # Sorani numbering with Eastern Arabic digits, reads from the right
            num = "".join("٠١٢٣٤٥٦٧٨٩"[int(ch)] for ch in str(i + 1))
            b.text((xr, y), f"{num}. {n}", nh, "R", "G-ANNO-NOTE")
        else:
            b.text((xl, y), f"{i + 1}.  {n}", nh, "L", "G-ANNO-NOTE")


def scale_bar_width(scale):
    paper_per_m = parse_scale(scale) * 1000.0
    for cand in (0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 25, 50, 100, 200, 500):
        if cand * paper_per_m >= 12:
            return 4 * cand * paper_per_m
    return 60.0


def projection_symbol(b, cx, cy):
    """First-angle symbol: frustum side view (narrow end left) then its end view on the right."""
    b.layer("G-TTLB-LINE")
    D, d, L, g = 4.4, 2.2, 5.5, 2.8
    xa = cx - (L + g + D) / 2
    b.add(["pline", {"vertices": [[xa, cy - d / 2], [xa + L, cy - D / 2], [xa + L, cy + D / 2],
                                  [xa, cy + d / 2]], "closed": True}])
    ccx = xa + L + g + D / 2
    b.add(["circle", {"center": [ccx, cy], "diameter": D}], ["circle", {"center": [ccx, cy], "diameter": d}])
    b.line((xa - 1, cy), (ccx + D / 2 + 1, cy))
    b.line((ccx, cy - D / 2 - 1), (ccx, cy + D / 2 + 1))


def north_arrow(b, cx, cy, angle, lang):
    b.layer("G-ANNO-SYMB")
    r = 7.0
    b.add(["circle", {"center": [cx, cy], "radius": r}])
    a = math.radians(90 + angle)

    def rot(dx, dy):
        ca, sa = math.cos(a - math.pi / 2), math.sin(a - math.pi / 2)
        return [round(cx + dx * ca - dy * sa, 4), round(cy + dx * sa + dy * ca, 4)]

    tip, left, right, tail = rot(0, r + 2), rot(-3.2, -r + 1.5), rot(3.2, -r + 1.5), rot(0, -r + 4.5)
    b.add({"cmd": "pline", "params": {"vertices": [tip, right, tail], "closed": True}, "as": "na_half"},
          ["hatch", {"handles": ["$na_half"], "pattern": "SOLID"}],
          ["pline", {"vertices": [tip, left, tail], "closed": True}])
    lab = LABELS["ku"]["north"] if lang == "ku" else "N"
    tx, ty = rot(0, r + 3.5)
    if is_rtl(lab):
        b.text((tx, ty), lab, 2.5, "C", "G-ANNO-SYMB")
    else:
        b.text((tx, ty), lab, 3.5, "BC", "G-ANNO-SYMB")


def scale_bar(b, x, y, scale, units, lang):
    """Graphic scale: 4 alternating segments, ~60-100 mm long on paper, labelled in metres."""
    paper_per_m = parse_scale(scale) * 1000.0             # paper mm per metre on the ground
    step_m = 1
    for cand in (0.1, 0.2, 0.5, 1, 2, 5, 10, 20, 25, 50, 100, 200, 500):
        if cand * paper_per_m >= 12:
            step_m = cand
            break
    seg = step_m * paper_per_m
    b.layer("G-ANNO-SYMB")
    hgt = 2.0
    for i in range(4):
        h = f"sb{i}"
        b.add({"cmd": "pline", "params": {"vertices": [[x + i * seg, y], [x + (i + 1) * seg, y],
                                                      [x + (i + 1) * seg, y + hgt], [x + i * seg, y + hgt]],
                                          "closed": True}, "as": h})
        if i % 2 == 0:
            b.add(["hatch", {"handles": [f"${h}"], "pattern": "SOLID"}])
    fmt = (lambda v: f"{v:g}")
    for i in range(5):
        b.text((x + i * seg, y + hgt + 1.5), fmt(i * step_m), 2.5, "BC", "G-ANNO-SYMB")
    b.text((x + 4 * seg + 3, y), "m", 2.5, "L", "G-ANNO-SYMB")
    if lang == "ku":
        b.text((x + 4 * seg, y - 4.5), f"پێوەر {scale}", 2.5, "R", "G-ANNO-SYMB")
    else:
        b.text((x, y - 4.5), f"SCALE {scale}", 2.5, "L", "G-ANNO-SYMB")
