"""Right-to-left (Kurdish/Arabic/Persian) text as CAD geometry, for CADCraft 0.5.0.

Why: cadcraft-cli 0.5.0 lays out TEXT/MTEXT left-to-right in logical order and draws every
Arabic-script letter in its isolated form (no bidi, no OpenType shaping) in every font, so
Sorani comes out unreadable. Pillow here has libraqm (HarfBuzz + FriBiDi), which shapes and
orders the text correctly. This module renders the shaped line at high resolution, traces the
glyph outlines (marching squares on the antialiased mask, sub-pixel accurate), simplifies them
and returns recipe steps: closed `pline`s plus one SOLID `hatch` (even-odd fill of the nested
loops). The result plots as crisp vector letters at any scale, like AutoCAD's TXTEXP.

Optionally the real Unicode string is also written as TEXT on a no-plot layer (searchable and
editable later, and the critic reads it), so nothing is lost.

    from shaped_text import shaped_text_steps
    steps = shaped_text_steps("سڵاو", at=(100, 20), height=5, font="Rabar_021.ttf",
                              justify="R", layer="T-TEXT-KU")
"""
import os
import re

import numpy as np

FONT_DIRS = ["~/Library/Fonts", "/Library/Fonts", "/System/Library/Fonts/Supplemental",
             "/System/Library/Fonts"]
# Tested on this Mac (see references/kurdish-rtl.md). First = default.
# Fonts with every Sorani letter, joining, lam-alef and both digit sets AND Latin (mixed text).
# Rabar/Unikuweb are user-installed here; Tahoma and Arial ship with macOS (always there).
DEFAULT_FONTS = ["Rabar_016.ttf", "Unikuweb.ttf", "Tahoma.ttf", "Arial.ttf"]
PX = 160          # raster size (px) of the font em: ~0.03 mm resolution for 5 mm text
SIMPLIFY = 0.18   # Douglas-Peucker tolerance in px


def find_font(name):
    """Font file path from a path, a file name or a file-name stem ("Rabar_021")."""
    if not name:
        for n in DEFAULT_FONTS:
            p = find_font(n)
            if p:
                return p
        raise FileNotFoundError("no Arabic-script font found")
    p = os.path.expanduser(name)
    if os.path.isfile(p):
        return p
    want = re.sub(r"[\s_-]", "", name.lower())
    for d in FONT_DIRS:
        d = os.path.expanduser(d)
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            stem = re.sub(r"[\s_-]", "", f.lower())
            if stem == want or os.path.splitext(stem)[0] == want:
                return os.path.join(d, f)
    return None


def is_rtl(text):
    return bool(re.search(r"[֐-ࣿיִ-﷿ﹰ-﻿]", text))


def render_mask(text, font_path, px=PX, direction=None):
    """(alpha float array 0..1, baseline_y_px, cap_px) of one shaped line."""
    from PIL import Image, ImageDraw, ImageFont, features
    if not features.check("raqm"):
        raise RuntimeError("Pillow lacks libraqm: Arabic-script shaping unavailable")
    font = ImageFont.truetype(font_path, px, layout_engine=ImageFont.Layout.RAQM)
    direction = direction or ("rtl" if is_rtl(text) else "ltr")
    kw = {"direction": direction, "language": "ckb" if direction == "rtl" else None}
    kw = {k: v for k, v in kw.items() if v}
    l, t, r, b = font.getbbox(text, anchor="ls", **kw)
    pad = 6
    w, h = int(r - l) + 2 * pad, int(b - t) + 2 * pad
    im = Image.new("L", (w, h), 0)
    ImageDraw.Draw(im).text((pad - l, pad - t), text, fill=255, font=font, anchor="ls", **kw)
    base_y = pad - t
    # Reference height: Latin cap height if the font has Latin, else the Arabic alef height.
    ref = None
    for probe in ("H", "ا"):
        try:
            pl, pt, pr, pb = font.getbbox(probe, anchor="ls")
            if pb - pt > px * 0.3:
                ref = -pt
                break
        except Exception:
            continue
    return np.asarray(im, dtype=np.float32) / 255.0, base_y, (ref or px * 0.7)


def marching_squares(a, level=0.5):
    """Closed contours (lists of (x, y) in pixel coords, y down) of a 2-D field at `level`."""
    a = np.pad(a, 1)
    H, W = a.shape
    tl, tr, br, bl = a[:-1, :-1], a[:-1, 1:], a[1:, 1:], a[1:, :-1]
    idx = ((tl > level) * 8 + (tr > level) * 4 + (br > level) * 2 + (bl > level) * 1).astype(np.int8)
    ys, xs = np.nonzero((idx != 0) & (idx != 15))

    def interp(v0, v1):
        d = v1 - v0
        return 0.5 if d == 0 else (level - v0) / d

    # edge keys: ("t", y, x) top edge of cell (y,x) = between (y,x)-(y,x+1); ("l", y, x) left edge
    def pt(edge, y, x):
        if edge == "t":
            return ("h", y, x), (x + interp(a[y, x], a[y, x + 1]), y)
        if edge == "b":
            return ("h", y + 1, x), (x + interp(a[y + 1, x], a[y + 1, x + 1]), y + 1)
        if edge == "l":
            return ("v", y, x), (x, y + interp(a[y, x], a[y + 1, x]))
        return ("v", y, x + 1), (x + 1, y + interp(a[y, x + 1], a[y + 1, x + 1]))

    # segments oriented so the inside (> level) is on the left when y points down... any
    # consistent orientation works for even-odd hatching.
    table = {1: [("l", "b")], 2: [("b", "r")], 3: [("l", "r")], 4: [("r", "t")],
             6: [("b", "t")], 7: [("l", "t")], 8: [("t", "l")], 9: [("t", "b")],
             11: [("t", "r")], 12: [("r", "l")], 13: [("r", "b")], 14: [("b", "l")]}
    nxt, coord = {}, {}
    for y, x in zip(ys.tolist(), xs.tolist()):
        c = int(idx[y, x])
        if c in (5, 10):
            centre = (a[y, x] + a[y, x + 1] + a[y + 1, x] + a[y + 1, x + 1]) / 4
            if c == 5:
                segs = [("l", "t"), ("r", "b")] if centre > level else [("l", "b"), ("r", "t")]
            else:
                segs = [("t", "r"), ("b", "l")] if centre > level else [("t", "l"), ("b", "r")]
        else:
            segs = table[c]
        for e0, e1 in segs:
            k0, p0 = pt(e0, y, x)
            k1, p1 = pt(e1, y, x)
            coord[k0], coord[k1] = p0, p1
            nxt[k0] = k1
    loops, seen = [], set()
    for start in list(nxt):
        if start in seen:
            continue
        loop, k = [], start
        while k not in seen and k in nxt:
            seen.add(k)
            px_, py_ = coord[k]
            loop.append((px_ - 1, py_ - 1))   # undo the padding
            k = nxt[k]
        if len(loop) >= 3:
            loops.append(loop)
    return loops


def simplify(points, tol):
    """Douglas-Peucker on a closed loop."""
    pts = np.asarray(points, dtype=float)
    if len(pts) < 8:
        return pts.tolist()
    # split the loop at its two farthest-apart points so DP works on open chains
    i0 = 0
    i1 = int(np.argmax(((pts - pts[0]) ** 2).sum(1)))

    def dp(chain):
        if len(chain) < 3:
            return chain.tolist()
        a, b = chain[0], chain[-1]
        ab = b - a
        n = np.hypot(*ab)
        rel = chain - a
        d = (np.abs(ab[0] * rel[:, 1] - ab[1] * rel[:, 0]) / n) if n > 1e-12 else np.hypot(*rel.T)
        i = int(np.argmax(d))
        if d[i] <= tol:
            return [a.tolist(), b.tolist()]
        left, right = dp(chain[:i + 1]), dp(chain[i:])
        return left[:-1] + right

    c1 = dp(pts[i0:i1 + 1])
    c2 = dp(np.vstack([pts[i1:], pts[:1]]))
    return c1[:-1] + c2[:-1]


def signed_area(p):
    p = np.asarray(p)
    x, y = p[:, 0], p[:, 1]
    return 0.5 * float(np.dot(x, np.roll(y, -1)) - np.dot(y, np.roll(x, -1)))


def outlines(text, height, font=None, px=PX):
    """Loops in drawing units with (0,0) at the baseline start; returns (loops, width)."""
    path = find_font(font)
    if not path:
        raise FileNotFoundError(f"font not found: {font}")
    mask, base_y, ref_px = render_mask(text, path, px)
    s = height / ref_px
    loops = []
    for lp in marching_squares(mask):
        lp = simplify(lp, SIMPLIFY)
        if len(lp) < 3 or abs(signed_area(lp)) < 0.6:   # specks
            continue
        loops.append([(round(x * s, 4), round((base_y - y) * s, 4)) for x, y in lp])
    xs = [x for lp in loops for x, _ in lp] or [0]
    x0, x1 = min(xs), max(xs)
    loops = [[(round(x - x0, 4), y) for x, y in lp] for lp in loops]
    return loops, x1 - x0


def shaped_text_steps(text, at, height, font=None, justify="L", layer=None, keep_text=True,
                      rotation=0, source_layer="T-TEXT-SRC"):
    """Recipe steps drawing `text` as filled outlines. justify: L, C, R (baseline) or
    BL/BC/BR, ML/MC/MR, TL/TC/TR (cap-height box). rotation in degrees."""
    import math
    loops, width = outlines(text, height, font)
    j = (justify or "L").upper()
    h_al = j[-1] if j[-1] in "LCR" else "L"
    v_al = j[0] if len(j) == 2 else "B"
    dx = {"L": 0.0, "C": -width / 2, "R": -width}[h_al]
    dy = {"B": 0.0, "M": -height / 2, "T": -height}.get(v_al, 0.0)
    ca, sa = math.cos(math.radians(rotation)), math.sin(math.radians(rotation))

    def place(x, y):
        x, y = x + dx, y + dy
        return [round(at[0] + x * ca - y * sa, 4), round(at[1] + x * sa + y * ca, 4)]

    steps = []
    if layer:
        steps.append(["layer.current", {"name": layer}])
    names = []
    tag = f"st{abs(hash((text, tuple(at)))) % 10**8}"
    for i, lp in enumerate(loops):
        name = f"{tag}_{i}"
        names.append(f"${name}")
        steps.append({"cmd": "pline", "params": {"vertices": [place(x, y) for x, y in lp],
                                                 "closed": True}, "as": name})
    if names:
        # One SOLID hatch keeps the loops itself; the boundary plines are then erased so the
        # letters plot at their true weight (no outline stroke) and the file stays small.
        steps.append({"cmd": "hatch", "params": {"handles": names, "pattern": "SOLID",
                                                 "associative": False}, "as": f"{tag}_fill"})
        steps.append(["erase", {"handles": [n + ".all" for n in names]}])
    if keep_text:
        # The real string, searchable/editable, on a layer that does not plot.
        steps += [{"cmd": "layer.new", "params": {"name": source_layer, "color": 8},
                   "ok_if_exists": True},
                  ["layer.set", {"name": source_layer, "plot": False, "on": False}],
                  ["layer.current", {"name": source_layer}],
                  ["text", {"at": place(0, 0) if h_al == "L" else list(at), "text": text,
                            "height": height, "rotation": rotation,
                            "justify": {"L": "L", "C": "C", "R": "R"}[h_al]}]]
        if layer:
            steps.append(["layer.current", {"name": layer}])
    return steps


if __name__ == "__main__":
    import json
    import sys
    t = sys.argv[1] if len(sys.argv) > 1 else "سڵاو، ئەمە تاقیکردنەوەیە بۆ کوردی"
    lps, w = outlines(t, 5, sys.argv[2] if len(sys.argv) > 2 else None)
    print(json.dumps({"loops": len(lps), "vertices": sum(map(len, lps)), "width": round(w, 2)}))
