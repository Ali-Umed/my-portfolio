# CADCraft templates

Recipe templates in `templates/<id>.json`. Every one was built on cadcraft-cli 0.5.0 (all pass `check` on 0.6.2; flange re-rendered there after its ANSI31 scale fix) and scores
100/100 in the critic with no severe issue (`cadcraft.py template test` rebuilds all of them into
`./craft-tests/cadcraft/templates/`, refreshes `templates/thumbs/` and
`templates/gallery.png`, and prints the score table).

```bash
python3 -I <skill>/scripts/cadcraft.py template list
python3 -I <skill>/scripts/cadcraft.py template show plate
python3 -I <skill>/scripts/cadcraft.py template apply plate out/plate --var width=200 --var title="BASE PLATE"
```
`apply` writes `OUT.recipe.in.json` (the filled recipe: edit it and use `apply --recipe` for
one-off changes), `OUT.dxf`, `OUT.png` (model preview), `OUT.pdf` (the plotted sheet),
`OUT_sheet.png` (raster of the PDF) and runs the critic. List vars take JSON:
`--var 'notes=["NOTE ONE", "NOTE TWO"]'`. Unknown var names are rejected.

Common variables (all templates with a sheet): `title, dwg_no, rev, date, drawn, checked, approved,
owner, paper, scale, units, notes`; mechanical adds `material, tolerance`; plans add `project, client,
status, lang (en | ku | en+ku), north`.

| # | id | Use | Own variables (defaults) | Preview |
|---|---|---|---|---|
| 1 | `bracket` | Angle bracket, three views, A3 1:1: Bent-plate L bracket in first-angle projection (front, top below, left view on the right) with hidden and centre lines, bend radius, chain dimensions, hole callouts and title block | `length`=90; `height`=70; `width`=60; `t`=8; `r`=8; `base_hole`=11; `up_hole`=13; `hole_pitch`=36 | `templates/thumbs/bracket.png` |
| 2 | `flange` | Flange with section A-A, A3 1:1: Round flange with N bolt holes on a PCD: front view with pitch circle and cutting plane, hatched section A-A, diameter dimensions and an equally-spaced hole callout | `outer_d`=150; `bore_d`=60; `pcd`=110; `holes`=6; `hole_d`=14; `thickness`=16 | `templates/thumbs/flange.png` |
| 3 | `floor-plan` | Floor plan, A3 sheet 1:50: Small house or flat plan in mm: solid-poche walls, doors with swings, windows, furniture, room names with areas, tick-style dimension chains, north arrow, scale bar and an architectural title block | `living`="LIVING ROOM"; `bedroom`="BEDROOM"; `kitchen`="KITCHEN"; `width`=10000; `depth`=7000; `t`=250; `ti`=120; `px`=5200; `py`=3600; `area_unit`="m²" | `templates/thumbs/floor-plan.png` |
| 4 | `floor-plan-ku` | Floor plan in Sorani Kurdish, A3 1:50: The floor-plan template with Kurdish room names, notes and title-block labels (drawn as shaped outlines because CADCraft 0.5.0 TEXT cannot join Arabic script); numbers stay Latin | `living`="ژووری دانیشتن"; `bedroom`="ژووری نووستن"; `kitchen`="چێشتخانە"; `width`=10000; `depth`=7000; `t`=250; `ti`=120; `px`=5200; `py`=3600; `area_unit`="m²" | `templates/thumbs/floor-plan-ku.png` |
| 5 | `plate` | Mounting plate, A3 sheet 1:1: Flat plate with 4 corner holes, optional centre bore, front + edge view, ISO 129 chain dimensions, hole callout, notes and an ISO 7200 title block | `width`=160; `height`=100; `thickness`=6; `corner_r`=8; `hole_d`=9; `edge`=15; `bore_d`=40 | `templates/thumbs/plate.png` |
| 6 | `sheet-a3` | Title-block sheet, A3 landscape (ISO 5457 / ISO 7200): Empty A3 drawing sheet: frame with filing margin, centring marks, grid zones, ISO 7200 title block with first-angle symbol, mechanical layers and an ISO dimension style ready; draw in model space and the viewport shows it at the chosen scale | sheet fields only | `templates/thumbs/sheet-a3.png` |
| 7 | `sheet-a3-ku` | Bilingual English/Kurdish title-block sheet, A3 landscape: Empty ISO A3 sheet whose title block carries English and Sorani labels wherever both fit, a Kurdish title and owner; for permit and government submissions in the Kurdistan Region | sheet fields only | `templates/thumbs/sheet-a3-ku.png` |
| 8 | `sheet-a4` | Title-block sheet, A4 portrait (ISO 5457 / ISO 7200): Empty A4 portrait sheet with the same frame, zones and title block; for small parts, details and single-page issues | sheet fields only | `templates/thumbs/sheet-a4.png` |
| 9 | `site-plan` | Site plan, A3 1:200 in metres: Plot boundary (phantom), road with centre line, building footprint, parking, trees, setback and plot dimensions in metres, plot area and coverage, levels, north arrow and scale bar | `plot_w`=40; `plot_d`=25; `front`=6; `side`=4; `bw`=16; `bd`=11; `road_w`=10; `sidewalk`=2; `road_name`="ROAD 20 m"; `building`="PROPOSED HOUSE"; `ffl`="+1.20" | `templates/thumbs/site-plan.png` |

Contact sheet: `templates/gallery.png` (numbered in this order).

## Writing a template
- Same steps as any recipe, plus `{{expr}}` placeholders (arithmetic over vars,
  `min max round abs sqrt sin cos radians`), `derived` helper values, and `"if": "{{expr}}"` on a
  step to drop it. A string that is exactly one placeholder keeps its type (number, list).
- `k` is built in: model units per paper mm for `scale` + `units`. Size every paper-sized thing
  with it: text `{{3.5 * k}}`, dimension offsets `{{10 * k}}`, `DIMSCALE: "{{k}}"`.
- `"extends": "other-id"` makes a variant that only changes defaults (see floor-plan-ku).
- End with a `{"sheet": {...}}` step; it centres the viewport on whatever was drawn.
- Run `template test` and read every thumbnail before shipping a new template.
