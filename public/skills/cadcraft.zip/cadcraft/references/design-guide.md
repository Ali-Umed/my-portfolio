# CADCraft design guide: drafting standards for a clean, professional sheet

"Design" in CAD means following drafting standards so that anyone can read, plot and build
from the drawing: ISO 128 lines, ISO 129 dimensions, ISO 3098 lettering, ISO 5455 scales,
ISO 5457 sheets and ISO 7200 title blocks. Every rule below is tied to a CADCraft 0.5.0 command
and was checked on this Mac. `k` means **model units per paper millimetre** (1 at 1:1 in mm,
50 at 1:50 in mm, 0.2 at 1:200 in metres). Multiply every paper size (text, arrows, offsets)
by k when you draw it in model space, because the viewport shrinks it back.

## 1. Deliver on a sheet, not in model space
- Every deliverable gets a paper-space layout with a frame, a title block and one viewport at
  an ISO scale. Use the `{"sheet": {...}}` recipe step (scripts/sheet.py) or a template; it
  places everything below in true millimetres. A model-only PDF fits to the page at an
  arbitrary ratio (the old A4 test came out at 1.19:1), so nobody can measure from it.
- Paper sizes (ISO 216, trimmed): A4 210x297 (portrait), A3 420x297, A2 594x420, A1 841x594.
  Prefer A3 landscape for parts and plans, A4 portrait for small details and lists.
- Frame (ISO 5457): 20 mm from the left edge (filing margin), 10 mm elsewhere, line 0.7 mm.
  Centring marks at the middle of each side, 0.7 mm. Grid zones: A3 8x6, A4 4x6, numbers
  across, letters down, 3.5 mm (2.5 mm on A4) in the margin. Zones let a reviewer say "D5".
- Title block (ISO 7200): bottom-right of the frame, 180 mm wide (43 mm high here), outline
  0.7 mm, internal rules 0.25 mm. Fields: drawn / checked / approved, material or project,
  scale, projection symbol or status, size, tolerances or client, title, owner, drawing
  number, revision, date (ISO 8601: 2026-10-12), sheet "1 / 1".
- Field text: labels 1.8 mm (the only place 1.8 mm is allowed), values 3.5 mm, drawing number
  5 mm, title 7 mm (steps down to 5/3.5 to fit the cell rather than overflow).
- Viewport on a no-plot layer (`G-VPRT`: `layer.new` then `layer.set {plot: false}`), locked
  (`viewport.set {locked: true}`), so its border never prints and the scale can't drift.
- Free drawing area: keep 8 mm clear of the frame and title block (`content_gap`). On A3+ the
  notes, north arrow and scale bar go in the strip left of the title block, leaving the full
  width above for the drawing. The sheet step refuses content that would not fit and says
  which scale or paper would.

## 2. Scales (ISO 5455)
| Drawing | Scale | k (model mm per paper mm) |
|---|---|---|
| small parts, details | 2:1, 1:1, 1:2 | 0.5, 1, 2 |
| assemblies, brackets | 1:2, 1:5, 1:10 | 2, 5, 10 |
| floor plans, sections | 1:50 (1:100 for large buildings) | 50 (100) |
| site plans (model in metres) | 1:200, 1:500 | 0.2, 0.5 |
- Only use 1, 2, 5 steps (`sheet.ISO_SCALES`). The title-block SCALE field must equal the
  viewport scale; the critic fails the drawing (severe) if they differ.
- Choose the largest scale at which the views plus dimensions fit the free area with margin.
  A part that fills under 6 % of the frame reads as an afterthought: go up one scale or
  down one paper size.

## 3. Lines (ISO 128) and layers
CADCraft 0.5.0 plots layer lineweights (`plot {lineweights: true}`, PDF 0.5 mm = 1.417 pt) and
true layer colours. It ignores plot style tables, so draw in the colours you want on paper.

| Line (ISO 128) | Use | Weight | Linetype | Layer (mech / arch / civil) |
|---|---|---|---|---|
| continuous wide 01.2 | visible outlines, cut walls | 0.5 (0.7 on A1+) | Continuous | M-VISI / A-WALL / C-BLDG |
| continuous narrow 01.1 | dimensions, leaders, hatch, short centre marks | 0.25 / 0.18 | Continuous | M-DIMS / A-ANNO-DIMS / C-ANNO-DIMS |
| dashed narrow 02.1 | hidden edges | 0.25 | HIDDEN | M-HIDN |
| long-dash dot narrow 04.1 | centre lines, axes, pitch circles | 0.25 | CENTER | M-CNTR / C-ROAD-CNTR |
| long-dash dot wide 04.2 | cutting-plane ends | 0.5 | Continuous ends | M-CUTP |
| long-dash double-dot 05.1 | plot boundary, adjacent parts | 0.5 site / 0.25 | PHANTOM | C-PROP |
| frame and title border | sheet | 0.7 | Continuous | G-SHEET-FRAM, G-TTLB-BORD |
- Keep a 2:1 wide:narrow ratio (0.5 vs 0.25). The critic flags a drawing whose outlines are
  not at least 1.4x heavier than its dimensions.
- Linetype scale: `ltscale {scale: 0.5}`. Viewports scale linetypes in paper units
  (PSLTSCALE 1), so CENTER repeats every 25.4 mm on paper at any viewport scale and HIDDEN
  gives 3.2 mm dashes. Load linetypes before naming them in `layer.new`.
- Short centre lines on holes under about 12 mm read as continuous thin lines; that is
  accepted (ISO 128-24). Extend centre lines 2-3 mm beyond the outline, never to the dims.
- Layer names: discipline prefix + major group (NCS/AIA style, readable everywhere):
  `M-` mechanical, `A-` architecture, `C-` civil/site, `L-` landscape, `G-` sheet/general.
  Nothing on layer 0 except block contents; Defpoints never plots.

## 4. Colour on paper: plot palettes
Contrast is measured against white paper (WCAG ratio). Text and dimensions need >= 4.5:1, object
lines >= 3:1; fills and context may be lighter. CADCraft greys 250-254 plot as below.

| Palette | Lines / text | Secondary | Fill / context | Use |
|---|---|---|---|---|
| Monochrome ink | 7 black #000000 (21:1) | 7 | none | mechanical parts (all templates) |
| Architectural poché | 7 black | 251 #5c5c5c (6.7:1) walls poché | 8 #808080 (3.9:1) furniture | floor plans |
| Site / civil | 7 black | 8 #808080 trees, 252 #858585 (3.7:1) | 254 #d6d6d6 (1.5:1) building fill | site plans |
| Labels and soft text | 7 values | 251 labels (6.7:1) | - | title-block labels |
| Presentation accent | 7 black | navy "30,60,120" #1e3c78 (10.6:1) one accent | 254 fill | client sheets, one accent max |
| Markup | 7 | red 1 #ff0000 (4.0:1) lines only | - | revision clouds, never body text |
| Dark canvas (screen) | 7 shows white on #21262d | any | - | model-space PNG previews only |
- Never plot yellow 2 (1.1:1), green 3 (1.4:1), cyan 4 (1.3:1) or light grey 9 (1.8:1) as
  lines or text: they vanish on paper. They are screen colours from the dark canvas.
- 60-30-10 on a sheet: about 60 % white paper, 30 % black linework and text, 10 % grey poché
  or one accent. More colour reads as a screenshot, not a drawing.

## 5. Lettering (ISO 3098)
- Heights on paper: 2.5 (notes, dimensions minimum), 3.5 (general text, values, dimension text
  on A3), 5 (room names on large plans, drawing number), 7 (title). 1.8 only for title-block
  labels. Use at most 4 sizes per sheet; the critic flags more than 5.
- Font: the Standard style's CADCraft Stroke font, a single-stroke ISO-like lettering that
  plots at the layer lineweight. Give text layers h/10: 0.25 for 2.5 mm, 0.35 for 3.5 mm,
  0.5 for 5-7 mm. TTF styles (`style {name, font: "Arial"}`) plot filled; use one at most.
- Spacing: line pitch 1.6-2x the height (notes: 2.5 mm text on 5 mm pitch), at least one text
  height between separate labels. Upper case for drawing text; units lower case (mm, m²).
- Model-space text height = paper height x k (`text {height: "{{3.5 * k}}"}`).
- Kurdish/Arabic: never plain TEXT in 0.5.0 (unshaped, left-to-right). Use the `label` or
  `shaped_text` step (references/kurdish-rtl.md). Shaped text height = Latin cap height.

## 6. Dimensions (ISO 129-1)
Create the style once, current, scaled by k:
- Mechanical: `dimstyle {name: "ISO-35", DIMTXT: 3.5, DIMASZ: 3, DIMEXO: 1, DIMEXE: 2,
  DIMGAP: 1, DIMTAD: 1, DIMDEC: 0, DIMCEN: 0, DIMSCALE: k, current: true}` (closed filled
  arrows, text above the line, aligned with it). DIMCEN 0 stops radius dims drawing a cross.
- Architecture (mm): `DIMTXT 2.5, DIMTSZ 1.2` (oblique ticks), `DIMEXO 2, DIMEXE 1.5,
  DIMDLE 1.5, DIMGAP 0.8, DIMDEC 0`, DIMSCALE 50 at 1:50.
- Site (metres): as architecture plus `DIMDEC 2, DIMZIN 0` so it reads 40.00, not 40.
- Leaders: `mleaderstyle {name: "Standard", textHeight: 3.5k, arrowSize: 3k, landingGap: 1k,
  dogleg: 4k, current: true}` first: the metric Standard style keeps 0.18 text.
- Placement: first dimension line 10 mm (10k) from the outline, each further line 8 mm out
  (18k, 26k). Chains (`dimlinear` then `dimcontinue {points}`) for feature positions, overall
  size outermost. Dimension each feature once, in the view that shows its shape (a hole
  where it is a circle, a thickness in the edge view). No duplicates across views.
- Callouts: "4X Ø9 THRU", "6X Ø14 THRU EQ SP", "R8". In MLEADER text write `\~` between words
  (0.5.0 previews dropped plain spaces; fixed in CLI 0.6.2) and `%%c` for Ø, `%%d` for °, `%%p` for ±.
- Never type a number over a dimension. Use `text: "%%c<>"` (prefix/suffix around the
  measured value) or fix the geometry. The critic fails fake values (severe).
- Round numbers in design: place openings and holes on 50 mm (plans) or whole-mm (parts)
  positions so chains read 1500 / 2400 / 1300, not 1495 / 2419.

## 7. Views, sections and hatching
- Projection: first angle (ISO E), symbol in the title block. Top view goes **below** the
  front view, the view from the left goes **on the right**. Gap between views 35-45 mm
  (paper), aligned on shared edges.
- Sections: cutting plane as a centre line with short 0.5 mm ends, arrows and letters
  (5 mm), section labelled "A-A" (5 mm) above the view. Hatch cut material only, not holes.
- Hatch spacing on paper 1.5-4 mm. **ANSI31's base spacing is 3.175 drawing units in metric
  drawings (CLI 0.6.2; it was 0.125 in 0.5.0)**: scale 0.8k gives 2.5 mm, scale 0.63k in metres
  gives 2 mm. Hatch by boundary
  `handles`, not by picked point (islands).
- Poché: cut walls `hatch {pattern: "SOLID"}` on a grey layer (251) with black 0.5 outlines;
  openings cut with `wipeout {points}` then `wipeout {frames: "off"}`.

## 8. Plans
- Walls: outer + inner closed polylines hatched together (ring), partitions as rectangles.
  External 250, internal 120 (or your system). Doors 800-900 with a 40 mm leaf and a 90° swing
  arc (0.25 / 0.18); windows: wall faces plus a double glazing line.
- Room tag: name 3.5 mm, area 2.5 mm below ("31.8 m²", computed, one decimal), centred in the
  free floor area, clear of furniture. Furniture in grey 8 at 0.18.
- Dimensions outside the building: opening chain at 10 mm, overall at 18 mm, on at least two
  sides. North arrow and graphic scale bar on every plan and site plan.
- Site plans in metres: plot boundary PHANTOM 0.5, building footprint filled light grey,
  setbacks dimensioned from the boundary, plot area and coverage stated, levels with ±0.00.

## 9. What the critic checks (`cadcraft.py critic X.dxf [--pdf X.pdf]`)
Score = 100 minus severe 20 / major 8 / minor 3 per failed check (+1 per extra hit, max +4).
Deliver at >= 85 with no severe issue. It parses the DXF directly (stdlib), and the PDF via
Quick Look (`qlmanage`, a CLI thumbnailer) when given.

| Check | Measures | Severity |
|---|---|---|
| units | $INSUNITS set | minor |
| layers.zero | plotted objects on layer 0 | minor, major > 10 % |
| lineweight.explicit / .series | layer weights set and in the ISO 128 series | minor |
| lineweight.hierarchy | outline weight >= 1.4x dimension weight | major |
| linetype.semantics | centre/hidden-named layers using CENTER/HIDDEN | major |
| linetype.scale | dash period on paper 4-45 mm | minor |
| text.min_height | paper height < 1.8 severe; < 2.5 outside the title block major | severe/major |
| text.iso_series / .hierarchy / .fonts | ISO 3098 heights, <= 5 sizes, <= 2 fonts | minor |
| text.overlap | estimated text boxes overlapping > 25 % | major |
| dims.missing | >= 4 outline objects and no dimensions | major |
| dims.override | typed value that disagrees with the measured geometry | severe |
| dims.offset / .spacing | dimension line < 5.5 mm from its feature; parallel lines < 6 mm apart | minor |
| geometry.gaps | outline ends missing each other by <= 0.5 mm on paper | major |
| geometry.duplicates | identical objects stacked | minor |
| plot.contrast | layer colour vs white: text < 4.5:1, lines < 3:1 | severe (< 2:1 on a sheet)/major/minor |
| hatch.scale | hatch line spacing on paper < 0.9 or > 12 mm | minor |
| sheet.missing / .frame / .titleblock / .fields | layout, ISO frame, title block position/width, filled fields, no placeholders | major |
| sheet.scale_iso / .scale_match | viewport scale is ISO 5455; title-block SCALE equals it | major / severe |
| sheet.viewport_frame | viewport border on a plotting layer | minor |
| sheet.clipped / .overlap / .fill | content cut by the viewport, under the title block, < 6 % of the frame | severe/severe/minor |
| pdf.blank / pdf.pale_ink | plotted page empty; > 3 % of ink in pale colours | severe / major |

## 10. Common mistakes and fixes
| Mistake | Fix |
|---|---|
| Model-space PDF "sheet" at 1.19:1 | `{"sheet": {paper, scale}}` step; `--export pdf` then plots the layout |
| Yellow/cyan/green layers on the plot | `layer.set {name, color: 7}`; greys 250/251 for secondary |
| Everything 0.25 mm | `layer.set {name: "M-VISI", lineweight: 0.5}` |
| Invisible 0.18 leader text in mm drawings | `mleaderstyle {textHeight: 3.5k, …}` before `mleader` |
| Hatch prints as grey mush or stray lines | ANSI31 `scale: 0.8k` (mm) / `0.63k` (m) on CLI 0.6.2 |
| Radius dimension draws a cross at the centre | `DIMCEN: 0` in the dimstyle |
| Site dims show 40 instead of 40.00 | `DIMDEC: 2, DIMZIN: 0` |
| Kurdish text unjoined, backwards | `{"label": "…"}` or `{"shaped_text": "…"}` |
| Viewport border prints | viewport on `G-VPRT` with `layer.set {plot: false}` |
| Odd chain values (419, 975) | snap openings/holes to 50 mm or whole mm in the design |
| Same size dimensioned in two views | keep it once, in the view that shows the feature's shape |

## 11. Designer checklist (run before delivering)
1. Sheet: right paper, ISO scale, frame, zones, title block filled (title, number, rev, date,
   drawn, scale), no placeholders.
2. Lines: 0.5 outlines vs 0.25 thin, CENTER and HIDDEN where they belong, ltscale 0.5.
3. Text: 2.5 / 3.5 / 5 / 7 only, h/10 lineweights, nothing overlapping, Kurdish shaped.
4. Dimensions: every feature once, 10 / 8 mm spacing, chains plus overall, no typed values.
5. Plot: only black and greys (one accent at most); viewport border not printing.
6. `cadcraft.py critic out.dxf --pdf out.pdf` >= 85, no severe; then read `out_sheet.png`
   yourself, because the critic can't judge balance, duplicates across views or clashes
   between text and lines.
