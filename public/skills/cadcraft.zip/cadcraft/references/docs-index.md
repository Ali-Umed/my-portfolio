# storytold/cadcraft: every markdown file (24), read 2026-10-12

Repo HEAD as of 2026-10-12 (docs last updated 2026-10-11). Copies: `<scratch>/cadcraft-docs/`.
"Automation" says whether the file matters for driving CADCraft with code. The docs describe
`main`, which is ahead of the installed cadcraft-cli 0.6.2 / CADCraft app 0.5.0 (see cadcraft-engine.md).

| Path | What it covers | Automation |
|---|---|---|
| `AGENTS.md` | Contributor/agent rules: clean-room (never read AutoCAD's bundle or GPL CAD code), no Autodesk assets, never-crash standard, "everything is a command", layering, quality gates, how to run the app with `--control` and drive it with JSON lines, contributor-credit procedure | **Yes** (control-channel examples, headless CLI line). Contributor instructions are for repo work only |
| `CLAUDE.md` | Same text as AGENTS.md (minus the contributor-credits section) | Same as above |
| `README.md` | Overview, what works today (draw/modify/annotate/hatch/blocks/layouts/parametric), fonts (TTF/OTF, `FONTALT`, `FONTFALLBACK`, RTL/Arabic shaping), logs and env vars, MCP/CLI examples incl. `--window` framing, downloads per platform | **Yes**: CLI/MCP usage, framing rules, font env vars |
| `ROADMAP.md` | Stage pre-alpha; readiness ≈ 38%; parity by dimension and feature area; upcoming work; progress log | Context: what's weak |
| `ATTRIBUTION.md` | Asset licences (icons, DMG art, example DXF, screenshots, translations); no Autodesk assets | No |
| `docs/architecture.md` | Crates and layers (geom, dxf, doc, fonts, render, constraints, io, dwg via acadrust, engine, ui-egui, mcp), data model, entity kinds, rendering, files, agent control | Background: DXF native path, DWG bridge |
| `docs/contributors.md` | About-window credits from contributors.json / people.toml | No (contributor process) |
| `docs/control-protocol.md` | Desktop JSON-lines control channel: every method (`cmdline.*`, `engine.execute`, `drawing.inspect`, `ui.*`, `app.open/save/quit`), timeout states, command-line reply fields, docking, interface language | **Yes**: basis of `scripts/cadcraft_control.py` |
| `docs/file-format-parity.md` | DWG/DXF version-by-version read/write, per-entity round trip, other formats (PDF, SVG, PNG, DWT, .lin/.pat, plot styles, SVG import), test status (all synthetic) | **Yes**: what survives save; DWG caveats |
| `docs/gaps.md` | Ranked shortfalls: DWG save losses, no real-file corpus, tessellated ellipse/spline geometry, no block editor/dynamic blocks/XCLIP, plotting leftovers, UI, file formats, localization, stability, AutoLISP/SCRIPT/Express Tools, AI | **Yes**: known gaps section |
| `docs/geometry-parity.md` | Geometry kernel audit: tolerances, curve support, intersections, offsets, trim/extend/fillet/chamfer, measurement precision, hatch boundaries, constraint solver | **Yes**: accuracy caveats (ellipse/spline, bulge offsets, tessellated AREA) |
| `docs/hardware-parity.md` | GPU backends, input devices, HiDPI, plotters/printers, internal perf numbers | No (perf context only) |
| `docs/localization-parity.md` | Language coverage vs AutoCAD (uk, de, cs full catalogs; fr, ru partial), script support | No (CLI/MCP replies stay English) |
| `docs/localization.md` | Interface language switching (`ui.language`), catalogs, `CADCRAFT_LOCALE` | Minor: `ui.language` over control |
| `docs/mcp.md` | MCP server: headless vs `--connect`, tools and schemas, error model (`-32602`, `isError`), typical session | **Yes**: basis of the runner's MCP session |
| `docs/parity-checklist.md` | Generated menu-breadth checklist (236/491) and the list of uncovered AutoCAD menu items | Yes, to answer "does it have X?" (uncovered = no) |
| `docs/plot-styles.md` | CTB/STB plot style tables, built-in tables, fields, `pagesetup`/`plot`/`plotstyle`/`stylesmanager` | CLI 0.6.2: yes (`plotstyle`, `stylesmanager`, `plotStyleTable` applied by `plot`); app 0.5.0: no |
| `docs/plotters.md` | Plotter devices (PDF/PNG/SVG), paper sizes, `.plotter.json`, `plottermanager`, `pagesetup {device}` | CLI 0.6.2: yes (`plottermanager`, `pagesetup {device}`); app 0.5.0: no |
| `docs/releasing.md` | Release pipeline, version bump, artifacts and signing | No |
| `docs/roadmap.md` | Current focus, alpha gate (4 of 5 core workflows fail), beta checklist, milestones | Context |
| `docs/target-app-parity.md` | How parity is measured; mainstream/essentials readiness; per-area depth and hours | Context |
| `docs/ui-parity.md` | Point entry (`@`, `<`, FROM, M2P, filters, snap overrides), object snaps, tracking, dynamic input, grips, selection keywords, command line, navigation | **Yes**: what command-line input syntax works |
| `packaging/macos/dmg/README.md` | DMG background/layout assets and how to regenerate them | No |
| `packaging/web/README.md` | Hosting the WASM build: MIME, compression, iframe embedding, `?webgl`/`?cpu` flags | No (web build only) |

Also read (pointed to by the docs): `apps/cadcraft-cli/src/main.rs` (run/convert/info/commands
implementation, step order, framing, exit codes), `apps/cadcraft-cli/tests/cli.rs`,
`crates/mcp/src/tests.rs`, `apps/cadcraft/src/main.rs` and `control_server.rs` (launch flags,
127.0.0.1 bind, no auth).

## Agent-directed instructions found (reported, not followed)
- AGENTS.md / CLAUDE.md: "Read `plan/STATUS.md`… Follow the autonomous operation protocol… Don't
  stop to ask", "Commit after every feature arc… and push to `main`", read `craftrules/AGENTS.md`
  and contribute learnings back.
- AGENTS.md: when preparing a PR, ask the human about adding a credit entry to
  `contributors/people.toml`.
- gaps.md: "agents pick from here (top of a section first)".
- target-app-parity.md / ROADMAP.md: hour estimates "for an Opus 5.5 agent".
These are for contributors working in the repo. The skill never edits the repo, picks gap work,
commits, pushes or edits credits.
