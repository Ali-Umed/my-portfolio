# CADCraft cookbook: what the user says → what to run

All recipes are for `scripts/cadcraft.py apply` (JSON list or `{"steps": […]}`). Check exact
params with `cadcraft.py describe ID`. Units: metric = mm (`--metric`), default = inches.
Tested recipes live in `./craft-tests/cadcraft/` (`*.recipe.in.json`).

| User says | Recipe idea |
|---|---|
| "Draw a 160×100 plate with 4 Ø9 holes 15 mm from the corners, R8 corners, dimension it" | `--new --metric`; `layer.new` OUTLINE/HOLES/CENTER/DIMS; `{"script":"RECTANG F 8 0,0 160,100\n"}`; 4× `circle {center, diameter: 9}` with `"as"`; `centermark {handles}`; `dimlinear` ×4; `dimdiameter`; `mleaderstyle` (3.5 mm) + `mleader "4X\\~%%c9\\~THRU"`. Test: `01-plate/` |
| "Make a flange / bolt circle with N holes on a PCD" | `.scr`: `CIRCLE 45,0 D 11` then `ARRAYPOLAR L` + blank line + `0,0 I 6` + blank line; or JSON `arraypolar {handles:["$hole"], center:[0,0], count:6}`; PCD circle on a CENTER-linetype layer. Test: `03-flange-script/` |
| "Rename this room / fix this text" | `entities {"type":"Text"}` to find the handle → `textedit {handle, text}` |
| "Hatch the walls" | `hatch {handles:[outer, inner], pattern:"ANSI31", scale}` (by handles, not by point, so furniture isn't hatched) |
| "How big is this room?" | `boundary {points:[[x,y]]}` as `room` → `area {handle:"$room"}` → `erase {handles:["$room.all"]}`; convert units yourself (in²/144 = ft²) |
| "Add overall dimensions" | `dimlinear {p1, p2, at}` per side; chains with `dimcontinue {points}` or `dimbaseline {points}`; imperial plans: `dimstyle {name:"ARCH", DIMSCALE:36, DIMLUNIT:4, current:true}` first |
| "Add a room schedule / parts list" | `tablestyle {name:"Standard", textHeight, current:true}` then `table {at, rows, cols, rowHeight, colWidth, title, header, cells}` |
| "Put a title / note" | `text {at, text, height, justify?}` (TEXT keeps spaces in previews); `mtext {at, text, height, width}` with `\P` for new lines |
| "Leader note pointing at X" | `mleaderstyle` sized for the units, then `mleader {points:[[arrow],[landing]], text}`; saved as LEADER+MTEXT in 0.5.0, native MULTILEADER in CLI 0.6.2 |
| "Move / copy / rotate / mirror these" | find handles (`entities {window:[[x0,y0],[x1,y1]]}` or `qselect`), then `move {handles, delta}`, `copy {handles, delta, count?}`, `rotate {handles, base, angle}`, `mirror {handles, p1, p2}` |
| "Offset this outline by 5" | `offset {handle, distance:5, side:[x,y]}` (side = a point on the wanted side) |
| "Round / chamfer the corners" | `fillet {handle, polyline:true, radius}`; `chamfer {handle, polyline:true, d1, d2}`; or `rectang {p1, p2, fillet}` |
| "Put everything on layer X / change colours" | `layer.new`, `laymch {handles, layer}` or `properties.set {handles, layer|color|linetype|lineweight}` |
| "Make a block of this and insert it 3 times" | `block {name, base, handles}` → `insert {name, at, scale?, rotation?}` ×3 |
| "Convert this DWG to DXF / PDF / PNG / SVG" | `cadcraft-cli convert in.dwg out.dxf` (or `.pdf`, `.png`, `.svg`); for a part: `--window x0,y0,x1,y1` |
| "Print it on A4 / A3" | `pagesetup {layout:"Layout1", paper:"A4", landscape:true}`, `layout.set {name:"Layout1"}`, `mview {}`, `plot {layout:"Layout1", path:"/abs/x.pdf"}` (PDF only; colours as drawn in 0.5.0) |
| "Black-and-white preview" | `cadcraft.py render x.dxf x_mono.png --mono` |
| "Here are AutoCAD commands, run them" | save them as `x.scr` and `apply --script-file x.scr`, but rewrite line ends: a blank line is Enter, a plain line break is not |
| "Show me / open it in CADCraft" | deliver the DXF and `open -a CADCraft file.dxf` (works with the app running); live control only with the user's OK |

## Designer-grade jobs (templates and the sheet step)
| User says | Do |
|---|---|
| "Put it on an A3 sheet with a title block" | end the recipe with `{"sheet": {paper: "A3", scale: "1:…", fields: {title, dwg_no, drawn, date, …}}}`; `--export pdf` plots it |
| "Draw a mounting plate / bracket / flange" | `template apply plate|bracket|flange out/x --var …` (sizes, material, title) |
| "Draw a floor plan" | `template apply floor-plan out/x --var width=… --var depth=… --var px=… --var py=…`; rooms renamed with `--var living=…` |
| "Site plan for the permit" | `template apply site-plan out/x --var plot_w=… --var plot_d=… --var front=… --var side=…` (metres, 1:200) |
| "In Kurdish" / "bilingual title block" | `floor-plan-ku`, `sheet-a3-ku`, or `--var lang=ku|en+ku`; Kurdish strings via `{"label": …}` |
| "Make this drawing look professional" | `critic in.dxf`, then fix what it lists (colours to 7/greys, lineweights, ISO text heights, sheet step); compare scores |
| "Is this drawing OK to send?" | `critic x.dxf --pdf x.pdf` + read the sheet PNG; report score and the top fixes |
