# CADCraft engine reference (cadcraft-cli 0.6.2)

Sources: the storytold/cadcraft docs (README, AGENTS.md, docs/control-protocol.md, docs/mcp.md,
docs/gaps.md, docs/file-format-parity.md, docs/plot-styles.md, docs/plotters.md), the CLI source
(`apps/cadcraft-cli/src/main.rs`) and the live registry (`cadcraft-cli commands`, 404 commands in
0.6.2; 305 in 0.5.0). The live registry is the source of truth: `scripts/cadcraft.py describe ID` prints any
command's exact params, and `scripts/cadcraft.py commands WORD` searches ids and labels.

**The docs describe `main`, which can be ahead of the installed CLI.** Most commands the docs
listed as missing from 0.5.0 arrived in 0.6.2 (`group`, `xattach`/xrefs, `tolerance`,
`plottermanager`, `stylesmanager`, `plotstyle`, `publish`, `audit`, `recover`, `dataextraction`,
`tableexport`, `compare`, `scalelistedit`, `isoplane`, native MULTILEADER). `attach`, `share` and
`3dorbit` exist but answer "not available yet". Always check with `describe` before relying on
something the docs mention.

## How it works
- Every menu item, tool and prompt is an engine **command**: id = AutoCAD's command name in
  lower case (`circle`, `dimlinear`, `layer.new`), a JSON params form, aliases (`c`, `l`, `dli`)
  for the command line, and usually an interactive prompt sequence.
- Two ways in, same engine:
  1. **Command-line text** (AutoCAD style): `circle 0,0 5`, `line 0,0 @10,0 @0,5 c`,
     `rectang f 8 0,0 160,100`. Accepts aliases, keywords, `@dx,dy`, `@d<a`, `#x,y`,
     direct distance entry. Via `--script`/`--script-file` (CLI), `script`/`command_line` (MCP),
     `cmdline.input`/`cmdline.script` (control channel).
  2. **JSON** (`id {params}`): `--cmd 'circle {"center":[0,0],"radius":5}'` (CLI), `execute`
     (MCP), `engine.execute` (control). Never opens a dialog. **Ids only: aliases are refused**
     (`unknown command 'c'`).
- JSON results are printed per command, e.g. `{"handle":"10B"}`. Handles are hex strings; use
  them in later steps (`centermark {"handles":[…]}`, `dimdiameter {"handle":…}`). The runner's
  `"as"` / `"$name"` does this for you inside one session.
- **Unknown JSON keys are silently ignored** (`layer.new {"colour":"red"}` makes a white layer).
  A missing required key is an error (`circle {"radus":5}` → "`radius` or `diameter` is
  required"). `cadcraft.py check` catches both before running.

## CLI (one-shot) — `cadcraft-cli run`
```
cadcraft-cli run [FILE | --sample | --metric] [--script TEXT] [--script-file F.scr]
                 [--cmd 'id {json}']... [--save OUT.dxf|.dwg] [--export OUT.png|.svg|.pdf]
                 [--window x0,y0,x1,y1 | --view extents|current]
cadcraft-cli info FILE          # drawing.inspect summary as JSON
cadcraft-cli convert IN OUT.(dxf|dwg|svg|png|pdf) [--window …|--view …]
cadcraft-cli commands [FILTER]  # JSON catalog (no --json flag: it is always JSON)
cadcraft-cli sample bracket|floorplan OUT.(dxf|dwg|svg|png)
cadcraft-cli mcp [--connect 127.0.0.1:PORT]
```
- Steps run in the order given; `--script` and `--cmd` can be interleaved. In `--script`, the
  two characters `\n` become a newline.
- With no FILE a new **imperial** drawing is created; `--metric` makes a metric one (ISO-25
  dimension style). `--sample` opens the built-in bracket.
- Exit status: an unknown command or a failed `--cmd` → 1. **A refused answer inside a script
  (bad point, unknown keyword, unknown hatch pattern) still exits 0** and the command stays
  waiting at its prompt; the messages only appear on stderr. That's why the runner uses MCP.
- `--save` writes .dxf (R2000 structure, version 2018 by default) or .dwg (via acadrust).
  `--export` / `convert` write PNG 2400×1600 (dark canvas like the app), SVG (white
  background) or PDF (model-space extents). Exports are always **model space**; for a paper
  sheet use the `plot` command with a `layout`.
- Image framing: `convert` fits extents; `run --export` uses the current view if a step changed
  it (zoom, pan, view.set), else extents; `--window` shows exactly that rectangle.

## Headless MCP — `cadcraft-cli mcp` (what `scripts/cadcraft.py` uses)
JSON-RPC 2.0 over stdio, one in-process session (no window, no network). Tools:
`command_line {text}`, `script {text}`, `execute {command, params}`, `list_commands {filter?}`,
`inspect_drawing {entities?, limit?}`, `query_entities {type?, layer?, window?, crossing?, limit?,
offset?}`, `render {width?, height?, fit?, path?}`, `new_drawing {metric?}`, `open {path}`,
`save {path?}`, `cancel`. `execute` failures come back as `isError`; `command_line`/`script`
return the prompt state: `output` lines, `error` (refused line), `running` (command still
waiting), `prompt`, `keywords`. Paths are plain file paths (no automation roots). **`save`
without a path writes over the opened file**; always pass a new path.

## Script (command-line) rules (tested on 0.5.0)
- Every space or newline separates answers. **Enter is a blank line, or a double space inside
  a line. A line break alone is NOT Enter** (AutoCAD .scr treats it as Enter; CADCraft doesn't).
  A trailing space before the newline doesn't count either.
- So end every command that keeps prompting (LINE, PLINE, -LAYER, ARRAYPOLAR selection, TEXT)
  with a blank line. Commands that finish on their own (CIRCLE, RECTANG, DIMLINEAR) need none.
- **A blank line while idle repeats the last command.** Don't put two blank lines in a row.
- Text prompts (TEXT contents, HATCH pattern name, MTEXT contents) take the **whole rest of the
  line**, spaces included. TEXT then asks for the next line until it gets a blank line.
- `-LAYER M NAME C 1 NAME L CENTER NAME` then a blank line works, but the linetype must be
  loaded first (`linetype {"load":"CENTER"}` in JSON). `-LINETYPE L CENTER` at the command line
  silently ignores the options.
- `ARRAYPOLAR L` + blank line (end selection) + `0,0 I 6` + blank line (exit) works.
- Prefer JSON steps for text, hatch, dimensions and anything with handles; use script text for
  quick geometry or when the user hands you AutoCAD-style commands.

## Recommended step order
1. Settings: `units`, `linetype {"load": …}`, `ltscale`, styles (`dimstyle`, `mleaderstyle`,
   `tablestyle`, `style`) sized for the drawing's units (see gotchas).
2. Layers: `layer.new {name, color, linetype, lineweight}`; switch with `layer.current`.
3. Geometry (JSON with `"as"` names, or script text), then modify (`offset`, `trim`, `fillet`,
   `array*`, `mirror`).
4. Annotation last: `centermark`, dimensions, `mleader`, `text`/`mtext`, `hatch`, `table`.
5. Optional sheet: `pagesetup {layout, paper, landscape}`, `layout.set`, `mview`, `plot {layout,
   path}`.
6. Verify: `inspect_drawing`/`info`, `entities {type}`, `area`/`dist` for numbers, then render
   and look at the PNG.

## Commands (verbatim params, 0.6.2)
Notation from the registry: `?` optional, `|` alternatives, points `[x,y]`, angles in degrees,
handles hex strings. `(interactive)` prompt sequences exist for most; the JSON form skips them.

### Files and session

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `new` | qnew | `{metric?: bool, template?: path to a .dwt/.dxf template ("." for none; default QNEWTEMPLATE)}` |
| `open` |  | `{path} \| {data: base64, name}` |
| `saveas` |  | `{path, version?: 2000\|2004\|2007\|2010\|2013\|2018, binary?: bool}` |
| `qsave` | save | `{path?}` |
| `document.bytes` |  | `{format?: dxf, version?: 2000…2018, binary?: bool} → {data: base64}` |
| `undo` |  | `{count?: n} \| {mode: mark\|begin\|end} \| {mode: back, confirm?: bool (no mark: undo everything; default true)} \| {mode: auto, on: bool} \| {mode: control, control: all\|none\|one\|combine\|layer, on?: bool (combine/layer)}` |
| `redo` |  | `{count?: n}` |

### Draw

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `line` | l | `{points: [[x,y],...], closed?: bool}` |
| `pline` | pl | `{vertices: [[x,y] \| {p:[x,y], bulge, startWidth, endWidth}], closed?, width?}` |
| `circle` | c | `{center, radius} \| {center, diameter} \| {p1, p2} \| {p1, p2, p3}` |
| `arc` | a | `{p1, p2, p3} \| {center, radius, start, end (degrees)} \| {start, center, end}` |
| `rectang` | rec, rectangle | `{p1, p2 \| dimensions: [l, w] (p2 picks the quadrant) \| area + length\|breadth, rotation? (deg), fillet?, chamfer?: [d1, d2], width?, elevation?, thickness?}` |
| `polygon` | pol | `{sides, center, radius, inscribed?: bool, angle?: deg to a vertex (inscribed) or edge midpoint (default: bottom edge horizontal)} \| {sides, edge: [[x,y],[x,y]]}` |
| `ellipse` | el | `{center, major: [dx,dy], ratio, start?, end? (degrees)} \| {isocircle: {center, radius \| diameter, plane?}}` |
| `spline` | spl | `{fit: [[x,y],...], closed?, knots?: chord\|sqrt\|uniform, startTangent?, endTangent? ([dx,dy]), tolerance?} \| {control: [...], degree?} \| {object: handle\|true, handles?} (polyline to spline)` |
| `point` | po | `{at: [x,y]} \| {points: [...]}` |
| `xline` | xl | `{base, through} \| {base, angle (degrees)} \| {base, hor\|ver: true} \| {vertex, start, end} (bisect) \| {handle, distance, side} \| {handle, through} (offset)` |
| `donut` | do, doughnut | `{center, inside, outside}` |
| `revcloud` |  | `{p1, p2} \| {points: [...]} \| {freehand: [...]} \| {handle}, arcLength?, style?: normal\|calligraphy, reverse?` |
| `text` | dt, dtext | `{at, text, height?, rotation? (degrees), justify?: L\|C\|R\|M\|TL\|TC\|TR\|ML\|MC\|MR\|BL\|BC\|BR}` |
| `mtext` | t, mt | `{at, text, height?, width?, attach?: 1..9 \| justify?: TL..BR, rotation?, style?, lineSpacing?, lineSpacingExact?, list?: bullet\|number\|lower\|upper, indent?, firstIndent?, rightIndent?, tabs?: [..], align?: left\|center\|right\|justify\|distributed, columns?: {type: static\|dynamic, count?, gutter?, height, heights?, reversed?}} (indents and tabs in text heights; width = one column)` |

### Modify

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `erase` | e, delete | `{handles?: [hex]} (default: selection)` |
| `move` | m | `{handles?, from?: [x,y], to?: [x,y] \| delta: [dx,dy]}` |
| `copy` | co, cp | `{handles?, delta: [dx,dy] \| from,to, count?: n}` |
| `rotate` | ro | `{handles?, base: [x,y], angle (degrees), copy?: bool}` |
| `scale` | sc | `{handles?, base: [x,y], factor, copy?: bool}` |
| `mirror` | mi | `{handles?, p1, p2, erase?: bool}` |
| `stretch` | s | `{window: [[x,y],[x,y]], delta: [dx,dy]}` |
| `offset` | o | `{handle, distance, side: [x,y], erase?: bool, layer?: "source"\|"current"}` |
| `trim` | tr | `{handle, pick: [x,y] \| fence: [[x,y],...] \| crossing: [[x,y],[x,y]], edges?: [hex], edgeMode?: "extend"\|"none", mode?: "quick"\|"standard"}` |
| `extend` | ex | `{handle, pick: [x,y] \| fence: [[x,y],...] \| crossing: [[x,y],[x,y]], edges?: [hex], edgeMode?: "extend"\|"none"}` |
| `fillet` | f | `{h1, p1, h2, p2, radius?, trim?: bool} (lines, arcs, circles) \| {handle, polyline: true, radius?}` |
| `chamfer` | cha | `{h1, p1, h2, p2, d1?, d2? \| length, angle (degrees), trim?: bool} \| {handle, polyline: true, d1?, d2? \| length, angle}` |
| `explode` | x | `{handles?}` |
| `join` | j | `{handles?}` |
| `break` | br | `{handle, p1, p2}` |
| `array` | ar | `{type?: "rectangular" (default) \| "polar" \| "path", ...the parameters of arrayrect, arraypolar or arraypath}` |
| `arrayrect` |  | `{handles?, rows, cols, rowSpacing, colSpacing, levels? (1), levelSpacing?, rowElevation?, axisAngle? (degrees), base? ([x, y], default the objects' centre), associative?: bool (default ARRAYASSOCIATIVITY, on)} → {handle (the array, when associative), created (copies)}` |
| `arraypolar` |  | `{handles?, center, count, angle? (degrees, default 360), rotate?: bool, rows? (1), rowSpacing?, rowElevation?, levels? (1), levelSpacing?, base? ([x, y], default the first object's centre), associative?: bool (default ARRAYASSOCIATIVITY, on)} → {handle (the array, when associative), created (copies)}` |
| `arraypath` |  | `{handles?, path (handle), count? (default 6) \| spacing?, align?: bool (default true)}` |
| `align` | al | `{handles?, s1, d1, s2?, d2?, scale?: bool}` |
| `lengthen` | len | `{handle, pick?: [x,y] (end), delta? \| deltaAngle? (deg) \| percent? \| total? \| totalAngle? (deg) \| to?: [x,y]} ({handle} alone measures)` |
| `pedit` | pe | `{handle \| handles, option: close\|open\|join\|width\|fit\|spline\|decurve\|reverse\|ltypegen\|vertex, width?, handles2? (join), fuzz?, action?: move\|insert\|straighten\|break\|width\|regen, index?, index2? (straighten, break), to?, startWidth?, endWidth?, tangents?: [{index, angle (deg) \| direction}] (fit), convert?: bool}` |
| `textedit` | ed, ddedit | `{handle, text} (text, mtext, attribute definitions, dimension text override)` |
| `properties.set` |  | `{handles?, layer?, color?, linetype?, lineweight?, ltscale?, transparency?: "ByLayer" \| "ByBlock" \| 0..90, visible?, <geometry fields: radius, center, start, end, text, height, rotation…>}` |
| `matchprop` | ma, painter | `{source, targets?: [hex] (default: selection), properties?: [name] \| {name: bool} (default: all; names: color, layer, linetype, ltscale, lineweight, transparency, thickness, plotStyle, dimension, text, hatch, polyline, viewport, table, multileader)} → {changed}` |

### Selection and query

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `select` |  | `{handles: [hex]} \| {window: [[x,y],[x,y]], crossing?: bool} \| {at: [x,y]} \| {clear: true} \| {add?: bool}` |
| `qselect` | qs | `{type?: "Line"\|"Circle"\|..., property?, operator?: "="\|"!="\|">"\|"<"\|"*" (wildcard), value?, mode?: new\|append\|exclude, applyTo?: drawing\|selection, layer?, color?} → selected handles` |
| `entities` |  | `{type?, layer?, window?: [[x,y],[x,y]], crossing?: bool (default true; false = entirely inside), limit?, offset?} → {count (all matches), returned, offset, entities}` |
| `drawing.inspect` |  | `{entities?: bool, limit?: n}` |
| `list` | li, ls | `{handles?}` |
| `dist` | di | `{p1, p2}` |
| `area` | aa | `{points: [[x,y],...]} \| {handle}` |
| `massprop` |  | `{handles?} (regions) → properties of each` |
| `id` |  | `{at}` |
| `count` |  | `{block?, object?: handle (count objects like this one), space?: current\|model\|all\|<layout> (default current), handles?: [...] (count in these objects), nested?: bool (default true), highlight?: bool} → {blocks: {name: n}, nested: {name: n}, spaces: {space: {name: n}}, total} \| {block, count, nested, handles}, plus 'message'` |
| `find` |  | `{find, replace?, matchCase?: bool, wholeWord?: bool}` |

### Layers, linetypes, properties

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `layer.new` |  | `{name, color?, linetype?, lineweight? (mm), current?: bool}` |
| `layer.set` |  | `{name, on?, frozen?, locked?, plot?, color?, linetype?, lineweight?, transparency?, description?, newVpFreeze?, plotStyle? (named plot style), newName?}` |
| `layer.current` | clayer | `{name}` |
| `layer` | la, layers, -layer | `{} → layers, states (typed -LAYER: option prompts)` |
| `linetype` | lt, ltype | `{current?: name, load?: name \| "*" (with a file: comma-separated names, wildcards), file?: path to a .lin file \| text?: its contents, reload?: bool}` |
| `ltscale` | lts | `{scale}` |
| `color` | col, colour | `{color: "ByLayer" \| "red" \| 1..255 \| "r,g,b"}` |
| `lweight` | lw, lineweight | `{lineweight: mm \| ByLayer}` |
| `units` | un | `{lunits?: 1..5, luprec?: 0..8, aunits?: 0..4, auprec?: 0..8, insunits?}` |
| `limits` |  | `{min: [x,y], max: [x,y]}` |
| `setvar` | set | `{name, value}` |
| `getvar` |  | `{name}` |

### Annotation

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `dimlinear` | dli, dimlin | `{p1, p2, at, rotation? (degrees; default: horizontal/vertical from 'at'), text?} \| {object: hex, at} (associative)` |
| `dimaligned` | dal, dimali | `{p1, p2, at, text?}` |
| `dimradius` | dra, dimrad | `{handle, at?} \| {center, point}` |
| `dimdiameter` | ddi, dimdia | `{handle, at?} \| {center, point}` |
| `dimangular` | dan, dimang | `{vertex, p1, p2, at} \| {lines: [hex, hex], at} \| {arc: hex, at} (associative)` |
| `dimarc` | dar | `{handle, at}` |
| `dimordinate` | dor, dimord | `{feature, leader, xtype?: bool}` |
| `dimcontinue` | dco, dimcont | `{points: [[x,y]...]} (continues the last linear dimension)` |
| `dimbaseline` | dba, dimbase | `{points: [[x,y]...]} (baseline from the last linear dimension)` |
| `qdim` |  | `{handles?, at: [x,y] (dimension line position), mode?: continuous\|staggered\|baseline\|ordinate\|radius\|diameter (default continuous), vertical?: bool (default: from 'at'), datum?: [x,y] (baseline and ordinate; default the first point, or the origin for ordinate), add?: [[x,y]], remove?: [[x,y]] (dimension points; removes those within 'tolerance')}` |
| `dimstyle` | d, dst, ddim | `{name, current?, <style fields or DIM* variables, e.g. arrowSize / DIMASZ, DIMTSZ, DIMBLK, DIMTAD, DIMLUNIT…>} → styles` |
| `dimoverride` | dov, dimover | `{handles?, <DimStyle fields or DIM* variables: values>, clear?: bool, text?: override text}` |
| `mleader` | mld | `{points: [[arrow], ..., [landing]] ([location] with leaderType none), text?, leaderType?: straight\|spline\|none, block?: name, blockAttach?: center\|insertion}` |
| `leader` | lead | `{points: [[x,y]...], text?}` |
| `mleaderstyle` | mls | `{name, arrowSize?, textHeight?, landingGap?, dogleg?, textStyle?, annotative?, current?} → styles` |
| `style` | st | `{name, font?, bigFont?, height?, widthFactor?, oblique? (degrees), backwards?, upsideDown?, vertical?, annotative?, current?} → styles` |
| `table` | tb | `{at: [x,y], rows (data rows), cols, rowHeight?, colWidth?, cells?: [[text]], title?: text, header?: [text]}` |
| `table.set` |  | `{handle, row, col, text? (text starting with = is a formula), formula?: "=Sum(A2:A5)"}` |
| `tablestyle` | ts | `{name, textHeight?, margin?, title?, header?, current?, cellStyle?: {name, …} (see tablestyle.cellstyle)} → styles` |
| `centermark` |  | `{handle \| handles} (circles/arcs; lines on the CENTER linetype)` |
| `centerline` |  | `{h1, h2} (two lines)` |

### Hatch, blocks

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `hatch` | h, bh, -hatch | `{points?: [[x,y]] (internal points) \| handles?: [hex] (closed objects), pattern?: "ANSI31", scale?, angle? (degrees), associative? (HPASSOC), separate? (HPSEPARATE: a hatch per point/object), origin?: [x,y] (HPORIGIN) \| originMode?: "current"\|"bottomLeft"\|"bottomRight"\|"topLeft"\|"topRight"\|"center" (HPORIGINMODE), style?: "normal"\|"outer"\|"ignore" (HPISLANDDETECTION)} — gaps up to HPGAPTOL close` |
| `gradient` | gd | `{points? \| handles?, color1?, color2?, angle?}` |
| `boundary` | bo, bpoly | `{points: [[x,y]]}` |
| `hatchedit` | he, -hatchedit | `{handles?, pattern?, scale?, angle?, associative?: bool (false unlinks; true links each loop to a closed object of the same shape, or to 'boundary' objects), boundary?: [hex], style?, origin? \| originMode?, separate?: true, recreate?: "polyline"\|"region", associate?: bool (link to the recreated boundary)}` |
| `block` | b, bmake | `{name, base: [x,y], handles?, keep?: "convert"\|"retain"\|"delete" (default "convert"), description?, annotative?}` |
| `insert` | i, -insert, ddinsert | `{name ("*NAME": exploded), file?: DXF/DWG path (defines or redefines block 'name', default the file name, from its model space; base point $INSBASE), at: [x,y], scale?: number \| [x, y], rotation? (degrees), basePoint?: [x,y] (block coordinates), attribs?: {TAG: value}, explode?: bool}` |
| `attdef` | att, -attdef | `{tag, prompt?, default?, at, height?, invisible?}` |
| `attedit` | ate, eattedit | `{handle, values: {TAG: value} (tags in any case)} → {changed, unknownTags?}` |
| `wblock` | w | `{path, name? \| handles?, base?}` |
| `purge` | pu, -purge | `{type?: all\|blocks\|dimstyles\|groups\|layers\|linetypes\|mleaderstyles\|tablestyles\|textstyles\|zerolength\|emptytext (default all: every named type), names?: "A*,B" (default *)} → purged` |
| `blocks.list` |  | `{}` |

### Views, layouts, plotting

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `zoom` | z | `{mode: extents\|all\|window\|previous\|in\|out\|center\|dynamic\|scale\|realtime\|object, p1?, p2?, center?, height?, factor?, xp?: bool (scale relative to paper space: in a viewport, 'factor' paper units per model unit), limits?: bool (scale relative to the limits)} (center/dynamic: 'center' + 'height', or 'factor' with 'xp'/'limits'; realtime: 'factor' about the view centre; typed: Enter at the first prompt starts Realtime)` |
| `pan` | p | `{delta: [dx,dy]} \| {from, to} \| {center}` |
| `view.set` |  | `{center: [x,y], height}` |
| `layout.new` |  | `{name?, viewport?: bool (default true)} → {name, viewport}` |
| `layout.set` |  | `{name: "Model" \| layout name}` |
| `layout.list` |  | `→ [{name, tabOrder, page, viewports}]` |
| `mview` | mv | `{option?: fit\|polygonal\|object\|on\|off\|lock\|restore, p1?, p2? (default: printable area), count?: 1-4, arrangement?: vertical\|horizontal\|left\|right\|above\|below, points?: [[x,y]…] + bulges? (polygonal), object? (closed object to clip by), handles? + locked? (on/off/lock), name? (restore: a model space viewport configuration, default *Active; its viewports fill p1-p2 or the printable area), layout?}` |
| `viewport.set` |  | `{handle? (default: selected viewports), scale?: paper units per model unit \| "1:50", viewHeight?, center?: [x,y], locked?, freeze?: [layer], thaw?: [layer], colors?: {layer: color \| null}}` |
| `pagesetup` |  | `{layout?: current, device?: plotter name (PLOTTERMANAGER) \| "None", paper?: the device's paper \| "A4"\|"A3"\|"Letter"\|"ANSI B"\|…, width?, height? (mm), landscape?, margins?: [l,b,r,t] mm, lineweights?, plotArea?, scale?, scaleToFit?, center?, plotStyleTable?: "monochrome.ctb"\|"grayscale.ctb"\|"default.ctb"\|"None"\|…, displayPlotStyles?: bool}` |
| `plot` | print | `{path? (else returns base64 'data'), layout?: current\|"Model", paper?, landscape?, fit?: bool, scale?: number \| "1:50", lineweights?: bool, plotArea?: extents\|display\|limits\|window (Model) \| layout, window?: [[x1,y1],[x2,y2]]} (typed or from the menu: the Plot dialog)` |
| `exportpdf` |  | `{path? (else returns base64 'data'), layout?, paper?, landscape?, fit?, scale?, lineweights?, plotArea?, window?} (as PLOT)` |

### Parametric

| id | aliases | params (verbatim from `cadcraft-cli commands`) |
|---|---|---|
| `geomconstraint` | gcon | `{type: coincident\|collinear\|concentric\|fix\|parallel\|perpendicular\|horizontal\|vertical\|tangent\|smooth\|symmetric\|equal, h1, p1?, h2?, p2?, h3?, p3?}` |
| `dimconstraint` | dcon | `{type: linear\|aligned\|horizontal\|vertical\|angular\|radius\|diameter, h1, p1?, h2?, p2?, expr? \| value?, name?}` |
| `parameters` | par, parametersclose | `{} lists; {name, expr \| value, description?} sets (new name = user parameter) and re-solves; {delete: name}` |
| `autoconstrain` |  | `{handles?, tolerance?, angleTolerance? (degrees), types?: [names]}` |
| `constraints.inspect` |  | `{} → constraints, glyph anchors, parameters, settings, dof` |

Also present: `arc.*` (11 methods: `arc.sce`, `arc.ser`, …), `circle.2p/3p/ttr/ttt`,
`ellipse.arc`, `divide`, `measure`, `wipeout`, `mline`, `helix`, `dimtedit*`, `dimspace`,
`dimreassociate`, `layiso`/`layfrz`/`layoff`/…, `layerstate.*`, `vports*`, `grip.*`, `gc*`/`dc*`
constraints, `cal`, `measuregeom`, `osnap`/`ortho`/`grid`/`snap`, `mredo` (no longer an alias of
`redo`). `commands` lists all 404.

### New in 0.6.2 (99 commands; `describe ID` for exact params)
- **Files:** `export {path?, format: dxf|dwg|svg|png|pdf}`, `import {path, at?, scale?}` (DXF/DWG
  into the drawing), `publish {path: "NAME.pdf", layouts?}` (one PDF per sheet), `preview` (base64
  PNG of a layout), `audit {fix?}`, `recover {path}`, `drawingrecovery`, `compare {path}` +
  `compare.next`/`compareclose`. `saveas`/`document.bytes` take `version` 2000–2018 and `binary`.
- **Groups and selection:** `group {name?, handles?}`, `ungroup`, `groupedit`, `groups.list`,
  `-group`, `pickstyle`, `selectsimilar`, `isolateobjects`/`hideobjects`/`unisolateobjects`.
- **Draw order:** `draworder {handles, order: front|back|above|under, reference?}`,
  `texttofront {objects?}`, `hatchtoback`.
- **Annotation:** `tolerance {at, symbol, tol1, datums…}` (GD&T frames), `dimbreak`, `dimjogline`,
  `dimjogged`, `diminspect`, `dimedit`, `mlstyle`/`mledit`, annotative scaling (`objectscale`,
  `scalelistedit`, `annoreset`, `annoupdate`, `annovisible.*`, `aiobjectscaleadd/remove`).
- **Tables and data:** `table.formula`, `table.recalc`, `tabledit`, `table.cellstyle`,
  `table.break`, `tablestyle.cellstyle`, `tableexport {handle, path?}` (CSV), `datalink`/
  `datalinkupdate`, `dataextraction`/`eattext` (block attributes → CSV or table),
  `countlist`/`counttable`.
- **Plotting:** `plotstyle`, `stylesmanager` (CTB/STB), `plottermanager`, `plotwindow`;
  `pagesetup {plotStyleTable: "monochrome.ctb"}` now applies to `plot`; `plot {scale: "1:50",
  plotArea, window}`.
- **Viewports and views:** `vpclip`, `mview.polygonal`, `mview {option: polygonal|object|lock…}`,
  `-vports`, `vports.activate`, `view {option: save|restore|…}`, `zoom.dynamic`/`zoom.realtime`.
- **Xrefs:** `xattach {path, at?, overlay?}`, `xref` (list), `-xref`, `xbind`, `xopen`.
- **Arrays and editing:** associative arrays (`arrayrect`/`arraypolar {associative}` return
  `{handle, created}`), `arrayedit`, `arrayclose`, `grip.option`, `overkill {tolerance, ignore…}`,
  regions `union`/`subtract`/`intersect`, `isoplane`, `ellipse {isocircle}`.
- **Customisation:** `hatch.patterns {file|text}` (.pat), `linetype {file|text}` (.lin),
  `-linetype`, `aliasedit`/`reinit` (.pgp), `options`, `script {path}` (.scr inside the engine),
  `quickcalc.pick`, `constraints.dof`, `constraintinfer`, `undo {mode: mark|back|begin|end…}`,
  `mredo`.

## Verified examples (tested)
```json
["linetype", {"load": "CENTER"}]
["layer.new", {"name": "CENTER", "color": 1, "linetype": "CENTER"}]
{"script": "RECTANG F 8 0,0 160,100\n"}
{"cmd": "circle", "params": {"center": [80, 50], "diameter": 40}, "as": "bore"}
["centermark", {"handles": ["$bore"]}]
["dimlinear", {"p1": [0, 0], "p2": [160, 0], "at": [80, -14]}]
["dimdiameter", {"handle": "$bore", "at": [104, 72]}]
["dimdiameter", {"center": [0, 0], "point": [42.426, 42.426]}]
["dimcontinue", {"points": [[172, 0], [354, 0]]}]
["mleaderstyle", {"name": "Standard", "textHeight": 3.5, "arrowSize": 2.5, "dogleg": 6, "landingGap": 1, "current": true}]
["mleader", {"points": [[148, 18], [170, 32]], "text": "4X\\~%%c9\\~THRU"}]
["hatch", {"handles": ["100", "101"], "pattern": "ANSI31", "scale": 4}]
{"cmd": "boundary", "params": {"points": [[80, 60]]}, "as": "room"}
["area", {"handle": "$room"}]
["erase", {"handles": ["$room.all"]}]
["textedit", {"handle": "10C", "text": "MASTER BEDROOM"}]
["dimstyle", {"name": "ARCH", "DIMSCALE": 36, "DIMLUNIT": 4, "DIMTAD": 1, "current": true}]
["tablestyle", {"name": "Standard", "textHeight": 6, "margin": 2, "current": true}]
["table", {"at": [420, 240], "rows": 2, "cols": 2, "rowHeight": 14, "colWidth": 90, "title": "ROOM SCHEDULE", "header": ["ROOM", "AREA (SF)"], "cells": [["LIVING ROOM", "256.5"], ["MASTER BEDROOM", "288.2"]]}]
["pagesetup", {"layout": "Layout1", "paper": "A4", "landscape": true}]
["layout.set", {"name": "Layout1"}]
["mview", {}]
["plot", {"layout": "Layout1", "path": "/abs/out/sheet_A4.pdf"}]
```
Hatch patterns (0.5.0 list; 0.6.2 also loads .pat files via `hatch.patterns`): SOLID, ANSI31–ANSI38, LINE, NET, NET3, DOTS, DASH, BRICK, SQUARE,
CROSS, EARTH, GRASS, HONEY, ZIGZAG, AR-CONC, AR-SAND. Linetypes: BORDER, CENTER, CENTER2,
CENTERX2, DASHDOT(2), DASHED(2/X2), DIVIDE, DOT(2), HIDDEN(2/X2), PHANTOM(2), FENCELINE1,
ZIGZAG. Text codes: `%%c` Ø, `%%d` °, `%%p` ±; MTEXT `\~` non-breaking space, `\P` new paragraph.

## Saving, export and formats
| Need | How | Notes |
|---|---|---|
| Editable drawing | `--save x.dxf` / MCP `save {path: x.dxf}` | DXF 2000–2018 (2018 default), ASCII; `saveas {path, version?, binary?}` (no `format` key since 0.6.2: the extension decides) |
| AutoCAD DWG | `--save x.dwg` | via acadrust bridge; tested only on synthetic files; drops custom objects |
| Preview | `--export x.png` / `convert` | 2400×1600, dark canvas; `cadcraft.py render --light/--mono` for paper look |
| Vector image | `.svg` | white background, plot colours |
| PDF | `.pdf` export (model extents) or `plot {layout, path}` (paper sheet); `publish` for one PDF per layout | `plot` always writes PDF, even for a `.png` path |
| Read | DXF R12–2018 ASCII/binary, DWG R13–2018 | DXF from Finder may not open in the app (#158) |

## Gotchas (verified headlessly; 0.6.2 rechecks dated 2026-10-13)
- **0.6.2: ANSI31 (and the other ANSI patterns) use the metric acadiso definition in `--metric`
  drawings: base spacing 3.175 drawing units (imperial drawings keep 0.125).** The 0.5.0 rule
  `scale: 20k` now gives 63.5 mm spacing. Use `scale: 0.8k` (≈2.5 mm on paper) in mm drawings,
  `0.63k` for 2 mm in metres. The critic's `hatch.scale` check reads the DXF and catches it.
- **Imperial defaults leak into metric drawings** (still true in 0.6.2). In `--metric` drawings the dimension style is
  ISO-25 (fine), but the Standard **multileader** style has text 0.18 and arrows 0.18, and the
  Standard **table** style has text 0.18: the text is invisible at mm scale. Set
  `mleaderstyle`/`tablestyle` sizes first. Imperial drawings in inches with feet-sized parts need
  `dimstyle {DIMSCALE: …}` too.
- MTEXT and MLEADER spaces rendered as nothing in 0.5.0 previews; **fixed in 0.6.2** (plain
  spaces render; `\~` still works).
- MULTILEADER was saved as LEADER + MTEXT in 0.5.0; **0.6.2 writes native MULTILEADER** to DXF.
- **Hatch by internal point alternates islands** by default. 0.6.2 adds `style: "outer"` (or
  `"ignore"`) and `separate`; `outer` was verified to skip the inner island. Hatching by
  `handles` of the boundary polylines (`[outer, inner]` for a ring) still works.
- `boundary` returns several handles (outer loop and islands); remove them with `"$name.all"`.
  A boundary also cuts out door swings, so check `area` results against hand maths.
- AREA's `message` formats square inches as a length ("7200'-0\""): read the numeric `area`
  (drawing units²) and convert yourself (in² / 144 = ft²).
- `pagesetup {plotStyleTable}` was ignored by `plot` in 0.5.0; **0.6.2 applies it**
  (`"monochrome.ctb"` turned a yellow layer black in a test plot). The viewport frame prints unless it is on a no-plot layer
  (`layer.new {name: "VPORTS"}` + `layer.set {plot: false}` before `mview`).
- `execute` ids only (no aliases). Script text takes aliases.
- The built-in floor-plan sample's dimension has measurement 0 and draws as a box.

## Known gaps (docs/gaps.md, file-format-parity.md, target-app-parity.md)
- Stage **pre-alpha**, ready for real work ≈ 38%, file formats ≈ 30% of AutoCAD.
- **DWG save drops what CADCraft doesn't model** (custom-class objects, xdata on tables/blocks,
  colour books, reactors); never verified in AutoCAD; no real-file corpus; a 10 MB DWG took ~2 min
  to fail (#57). Treat DWG output as "probably opens", and keep the user's original.
- Ellipse/spline intersections, offsets and closest points are tessellated (approximate);
  polyline offset doesn't recompute bulges.
- No block editor (BEDIT), dynamic blocks, REFEDIT, XCLIP; no 3D (solids, surfaces, UCS, views).
- No SHX fonts (stroke font stands in, so text widths differ from AutoCAD); no AutoLISP, no
  SCRIPT command for `.scr` files inside the app (scripts run through CLI/MCP/control only).
- No system printers: plot writes PDF (0.6.2 adds PNG/SVG plotter devices via `plottermanager`).
- Hatch: 23 own patterns (AutoCAD ~85), no hatch dialog; dimensions: no DIMSTYLE manager dialog.
- Prompt options that print "not available yet": STRETCH polygon/fence selection, -ATTEDIT
  one-at-a-time Position/Height/Angle/Style, MVIEW Restore, -RENAME of materials/plot styles.
- Web build: no DWG, no autosave.

## Live desktop app (control channel)
`CADCraft --control PORT` (or `CADCRAFT_CONTROL_PORT`) listens on 127.0.0.1 with JSON lines:
`{"id":1,"method":"cmdline.input","params":{"text":"circle 0,0 5"}}`. **No token and no folder
restrictions.** Methods: `cmdline.input {text}`, `cmdline.script {text}`, `cmdline.key {key}`,
`cmdline.state`, `engine.execute {command, params}`, `engine.commands`, `drawing.inspect
{entities?, limit?}`, `ui.inspect`, `ui.elements`, `ui.menu.list`, `ui.menu.invoke {command}`,
`ui.pointer`, `ui.click`, `ui.drag`, `ui.key`, `ui.text`, `ui.set`, `ui.resize`, `ui.focus`,
`ui.screenshot {path?}` (needs a presented frame), `ui.render {path?, width?, height?, fit?}`
(headless), `app.open {path}`, `app.save {path}`, `app.quit`. Replies time out after 60 s with
`state: "not-run"` (safe to resend) or `"may-have-run"` (inspect first). A refused command line
still replies `ok: true` with an `error` field. `cadcraft-cli mcp --connect 127.0.0.1:PORT`
wraps the same channel as MCP (adds `screenshot`, `ui_inspect`, `ui_click`).

## Verified for the design upgrade (2026-10-12)
- Paper space: after `pagesetup {layout, paper, landscape, margins: [0,0,0,0]}` and
  `layout.set {name}`, drawing commands go to that layout in paper mm. `mview {p1, p2}` returns
  `{"viewports": [h]}` (the runner's `"as"` takes it). `viewport.set {handle, scale: "1:50" |
  number, center, locked}`; numeric scale = paper mm per model unit (5 for 1:200 in metres).
- `plot {layout, path, lineweights: true}` honours layer lineweights (0.5 mm = 1.417 pt) and
  plots layer colours as true RGB (7 → black; greys 250–255 = 51, 91, 132, 173, 214, 255).
  Stroke-font TEXT plots as strokes at the layer lineweight; TTF styles plot filled.
- Linetypes in viewports are scaled in paper units (PSLTSCALE 1): `ltscale 0.5` gives CENTER a
  25.4 mm period at every viewport scale. Pattern lengths: CENTER 50.8, HIDDEN 9.525,
  PHANTOM 63.5, DASHDOT 25.4.
- ANSI31's line spacing was 0.125 drawing units in every drawing in 0.5.0 (`scale 20` → 2.5 mm).
  **0.6.2: 3.175 in metric drawings** (`scale 0.8` → 2.54 mm); see Gotchas.
- `wipeout {points: [[x,y]…]}` masks earlier objects (walls, hatch) in model and plot;
  `wipeout {frames: "off"}` hides its border. `hatch` without boundaries can be kept after
  `erase` of its boundary polylines (non-associative); one SOLID hatch with nested loops fills
  even-odd.
- `arraypolar` returned `{"created": n}` (no handles) in 0.5.0. In 0.6.2 arrays are associative by
  default and return `{handle, created}`: the handle is one array object (block reference) that
  includes the source, so pass `associative: false` when copies need their own handles. Blocks with `attdef` + `insert {attribs}`
  work in paper space.
- Dimension variables accepted by `dimstyle`: DIMTXT, DIMASZ, DIMTSZ (ticks), DIMEXO, DIMEXE,
  DIMDLE, DIMGAP, DIMTAD, DIMDEC, DIMZIN, DIMCEN, DIMLFAC, DIMSCALE. The DXF does not store the
  measured value (group 42); the critic recomputes it from the definition points.
- Arabic-script TEXT/MTEXT: no bidi and no shaping in 0.5.0 (see kurdish-rtl.md). 0.6.2 adds
  bidi and Arabic-script shaping: a Sorani TEXT in the Standard style rendered joined and
  right-to-left in a headless PNG (one sample; plots and fonts not re-tested). DXF stores
  non-ASCII as `\U+XXXX`.
- `cadcraft-cli info` reports model-space counts only. The runner skips its "saving changed
  the entities" warning once a sheet exists.
