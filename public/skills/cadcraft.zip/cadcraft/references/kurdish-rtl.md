# Kurdish (Sorani) and other right-to-left text in CADCraft 0.5.0

> CLI 0.6.2 adds bidi and Arabic-script shaping to TEXT/MTEXT; one Sorani TEXT sample rendered
> joined and right-to-left headless (2026-10-13). The font matrix below is from 0.5.0 and has not
> been re-run, and the desktop app is still 0.5.0, so the shaped-outline workaround stays the default.

Tested 2026-10-12 with cadcraft-cli 0.5.0 on this Mac. Evidence:
`./craft-tests/cadcraft/kurdish/` (one zoomed PNG per font,
`kurdish_matrix_sheet.png`, `matrix.json`, `kurdish_matrix.py` to re-run it).
Test string: `سڵاو، ئەمە تاقیکردنەوەیە بۆ کوردی: ێ ۆ ڵ ڕ ە ڤ ـ ١٢٣ 123 ArtCraft`.

## The engine: native TEXT/MTEXT fails in every font
The README (written for `main`) promises bidi and OpenType shaping. **0.5.0 has neither.** A
TEXT or MTEXT with Arabic script, in any style font, draws every letter in its isolated form,
left to right in logical order, so Sorani is unreadable (top line of every pair in the
evidence). This is a property of the 0.5.0 layout engine, not of the font. Fallback fonts do
supply the glyphs, so nothing turns into boxes, but nothing joins either. There is no direction
or RTL setting in 0.5.0 (no MTEXT direction code, no DIMSTYLE RTL); justification (`justify`
L/C/R, MTEXT `attach`) is the only alignment control.

## The workaround the skill uses: shaped outlines
`scripts/shaped_text.py` shapes the line with Pillow's libraqm (HarfBuzz + FriBiDi; installed
here), traces the glyphs with sub-pixel marching squares, simplifies them (Douglas-Peucker 0.18
px) and draws one SOLID `hatch` per string (the temporary boundary polylines are erased).
It also writes the real Unicode string as TEXT on the no-plot, off layer `T-TEXT-SRC`, so the
text stays searchable and editable and the critic can measure its height and position. The
letters plot as crisp vector fills at any scale (like AutoCAD's TXTEXP).

Recipe steps (the runner expands them):
```json
{"label": "ژووری نووستن", "at": [7500, 5300], "height": 175, "justify": "BC", "layer": "A-AREA-IDEN"}
{"shaped_text": "پلانی نهۆمی زەوی", "at": [300, 20], "height": 5, "font": "Rabar_016.ttf", "justify": "R"}
```
- `label` picks TEXT for Latin and shaped outlines for Arabic script; use it in templates
  whose strings can be either language. `shaped_text` always shapes.
- `height` = the font's Latin cap height (the alef height for fonts without Latin), so a
  shaped label lines up with stroke-font TEXT of the same height.
- `justify`: L, C, R (baseline) or BL…TR. For Kurdish use R (reads from the right edge).
- `font`: file name, stem or path; default chain Rabar_016 → Unikuweb → Tahoma → Arial.
- The sheet step uses this for Kurdish labels (`"lang": "ku"` or bilingual `"en+ku"`), titles,
  values and notes (numbered with Eastern Arabic digits ١. ٢. ٣.).

Limits: shaped text is geometry, so `textedit` can't change it; re-run the recipe with the new
string (the source TEXT on T-TEXT-SRC shows what it says). About 1 hatch per string, 60-90 KB
of DXF per 60 characters. MTEXT-style wrapping is not done: write one line per step.

## Font matrix (shaped path; native TEXT fails for all)
PASS = every Sorani letter present, ێ ڵ ڤ join on both sides, ۆ ڕ ە join from the right,
lam-alef ligature, Eastern Arabic digits, and Latin + digits for mixed text. KU-ONLY = Kurdish is
correct but the font has no Latin (mixed strings show boxes). Joining was tested by comparing
`بXب` with `ب‌X‌ب` (ZWNJ): identical pixels mean no joining.

| Font (location) | Result | Notes |
|---|---|---|
| Rabar_016 (~/Library/Fonts) | PASS | clean sans, good Latin: **default for labels and notes** |
| Rabar_031 (~/Library/Fonts) | PASS | bold: titles |
| Unikuweb (~/Library/Fonts) | PASS | Tahoma-like, compact |
| K24KurdishLight-Light | PASS | light, wide letter spacing |
| Speda-Bold | PASS | bold display |
| Peshang_Des_2 | PASS | bold, wide |
| UniQAIDAR_Hewal011 | PASS | Latin is bold |
| rudawregular2 | PASS | news style, bold Latin |
| UniMahanNurhan | PASS | calligraphic, not for drawings |
| Tahoma (system) | PASS | always present: fallback |
| Arial, Arial Unicode, Times New Roman (system) | PASS | Arial Unicode appears to draw ڵا as two joined letters rather than the lam-alef ligature |
| Noto Naskh Arabic UI Bold, Nizar Nastaliq Kurdish | KU-ONLY | no Latin (Nizar maps Latin to logo glyphs) |
| Geeza Pro, SF Arabic, Damascus (system) | KU-ONLY | no Latin glyphs |
| Baghdad, Kufi Standard GK, DecoType Naskh, Al Bayan, Nadeem, Farah, Muna, Al Nile, Beirut, Diwan Kufi | FAIL | lack ێ ۆ ڵ ڕ ە (Farah, Muna, Al Nile, Beirut, Diwan Kufi also lack Kurdish ک ی) |
| Noto Nastaliq Urdu | FAIL | lacks ێ ڵ ڕ |

## Recommended pairs
- Drawing text: CADCraft Stroke (Standard style) for Latin, numbers and dimensions + **Rabar_016**
  for Kurdish labels. Same cap height, both plain and technical.
- Titles: Rabar_031 (bold) for the Kurdish title + stroke font 7 mm for the drawing number.
- Without the user fonts (another Mac): Tahoma for Kurdish + stroke font for Latin.
- Keep numbers, dimensions and drawing numbers in Latin digits (as Kurdistan engineering
  offices do); Eastern digits only inside Kurdish sentences.

## Layout rules for Kurdish sheets
- Right-align Kurdish labels and values in each cell (the sheet step does). Keep the title
  block in the bottom-right corner (ISO), as Kurdistan Region permit drawings do.
- Arabic script reads smaller than Latin at the same cap height: never set Kurdish below 1.8 mm
  (labels) or 2.5 mm (notes, room names); room names 3.5 mm.
- Bilingual cells: English label left, Kurdish label right, both 1.8 mm; the sheet step drops
  the Kurdish label where both don't fit (measured, not guessed).
- Kurdish file and layer names: DXF stores non-ASCII as `\U+XXXX` (the critic decodes it);
  keep layer names ASCII (`A-AREA-IDEN`) so every CAD program reads them.

## Known RTL bugs in 0.5.0 and workarounds
| Bug | Workaround |
|---|---|
| TEXT/MTEXT unshaped and left-to-right in every font | `label` / `shaped_text` steps |
| Attributes (ATTRIB) can't carry shaped Kurdish | title-block values are plain TEXT or shaped hatches, not attributes |
| `textedit` can't edit shaped text | re-run the step with the new string |
| MTEXT spaces vanish in previews (all scripts) | one line per step, or `\~` in MTEXT |
| Some fonts lack Latin: boxes in mixed strings | choose a PASS font, or split Latin into its own TEXT |
