# CADCraft skill for Claude

Lets Claude draw and edit 2D CAD drawings in CADCraft (the open-source AutoCAD-style app from the ArtCraft suite)
with code: layers, dimensions, hatches, blocks, title blocks, PDF/PNG/SVG export, and a critic that scores each drawing.

Install (Claude Code): copy this folder to `~/.claude/skills/cadcraft/`. Claude apps: upload the zip under
Settings > Capabilities > Skills. Needs CADCraft with `cadcraft-cli` and Python 3.

`examples/episode-02/` is from "One car, 17 apps", Episode 2: the prompt, the inputs (`moon-spec.xlsx` from
Episode 1, `moon-r1-outlines.json`), the blueprint Claude drew (`moon-blueprint.dxf`, `moon-blueprint.pdf`) and
the 30 cm longer version (`moon-blueprint-longer.dxf`, made with one `stretch` command; every dimension re-measured itself).
Video: https://youtu.be/NhS7boB-8WI
