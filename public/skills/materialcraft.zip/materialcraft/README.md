# MaterialCraft skill for Claude

Lets Claude build procedural PBR materials in MaterialCraft (Substance Designer-style node graphs) with code:
templates, pixel-processor patterns, exposed inputs, previews on the material ball and texture map export.

Install (Claude Code): copy this folder to `~/.claude/skills/materialcraft/`. Claude apps: upload the zip under
Settings > Capabilities > Skills. Needs MaterialCraft with `materialcraft-cli`.

`examples/episode-05/` is from "One car, 17 apps", Episode 5: the prompt, `moon-materials.sbs` (Moon Orange paint
and a carbon fibre twill Claude wrote itself, with live inputs paint_color, roughness and weave_size), the
previews `paint.png` and `carbon.png`, and `paint-matte.png`, made with
`materialcraft-cli render moon-materials.sbs paint-matte.png --graph 0 --scene material_ball --hq --set roughness=0.8`.
The 12 texture maps are one command away: `materialcraft-cli export moon-materials.sbs maps --graph 0` (and `--graph 1`).
Video: https://youtu.be/k2PaWwfpDEk
