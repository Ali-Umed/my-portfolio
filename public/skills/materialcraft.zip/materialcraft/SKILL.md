---
name: materialcraft
description: "Build procedural PBR materials with code through MaterialCraft, the ArtCraft open-source Substance Designer clone (materialcraft-cli). Node graphs in .sbs/.mcraft packages from templates (bricks, wood, marble, rusty metal, lava, fabric, ground...), tweak inputs, cook, render a preview and export basecolor/normal/roughness maps (PNG, EXR...). Use it when the user mentions MaterialCraft, .sbs/.mcraft, or wants a seamless texture or 3D material made with the ArtCraft apps. Sibling - TextureCraft paints these materials onto models."
---

# MaterialCraft (materialcraft-cli)

```bash
materialcraft-cli new <template> out.sbs [--size 2048] [--name Name]
#   templates: empty pbr bricks stone_tiles wood metal_plates rusty_metal lava marble wicker fabric ground
materialcraft-cli info out.sbs                         # graphs, nodes, outputs, inputs (JSON)
materialcraft-cli nodes --filter noise                 # node library: ids, ports, parameters
materialcraft-cli commands --filter node               # engine commands + params
materialcraft-cli run out.sbs <command-id> '{...}' -o out.sbs
materialcraft-cli batch script.json                    # {"open": in, "steps": [{"id","params"}...], "save": out}
materialcraft-cli cook out.sbs [--set <input>=<value>]  # timings and errors per node
materialcraft-cli render out.sbs preview.png --size 1080x1080 [--view 3d|2d] [--tiling 2] [--hq]
materialcraft-cli export out.sbs maps/ [--set <input>=<value>] [--format png|exr] [--depth 16]
```

Tested: `new wood wood.sbs --size 512` then `render wood.sbs wood.png --size 480x480`.

- Change look with the graph's exposed inputs (`info` lists them) via `--set`, before editing nodes.
- Show `--view 2d --tiling 2` to prove a texture is seamless.
- MCP / live app work like TextureCraft (`mcp --read-root/--write-root`); adding MCP to Claude's config needs the user's OK.

## Lessons from the Craft series Episode 5 (2026-11-22, CLI 0.4.1)
- 0.4.1 templates are only `empty`, `pbr` and `atomics` (no wood/bricks/fabric...), and the pattern libraries are not
  installed: build patterns yourself in a `pixel_processor` function graph (a 2x2 carbon twill worked; floor a float
  input inside the function to keep the tiling seamless). Check tiling with `render --view 2d --tiling 2`.
- Expose inputs with `graph.exposed.add`, then change them per render/export with `--set name=value`
  (`--set roughness=0.8` turned a gloss paint matte in ~2 s; `--set paint_color="#2E6BFF"`).
- `graph.node.rename` needs the node selected first; node ids are renumbered when a package is saved and reopened, so
  re-read ids (`info`) before wiring in a later batch.
- A weave that looks too bumpy on the `--hq` material ball is usually the normal intensity, not the height/displacement.
- Turntable: `render ... --scene material_ball --hq --yaw 0..354 --pitch 10` (~4 s per 1000x1000 frame). In zsh never
  pass `--set x=y` through an unquoted variable: it stays one word and the render fails.
